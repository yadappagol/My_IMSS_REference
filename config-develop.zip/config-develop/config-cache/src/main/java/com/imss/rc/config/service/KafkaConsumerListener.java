package com.imss.rc.config.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class KafkaConsumerListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaConsumerListener.class);

    @KafkaListener(topics = "${kafka.rc.config.cache.response.topic}", containerFactory="configCacheListenerFactory")
    public void consumeData(Map<String, String> data) throws JsonProcessingException {

        ConfigCache.putConfigDetails(data.get("key"),data);

        LOGGER.info("Loading Config Cache : {} ", data.get("key"));

    }

}
