package com.imss.rc.config.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * This class will send out the request on kafka to lod the config data on start up
 * So any module that has included this dependency, on start up will
 * load the config cache.
 */
@Component
public class ConfigCacheRequestSender {
    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigCacheRequestSender.class);


    @Autowired
    @Qualifier("configCacheRequestDataTemplate")
    public KafkaTemplate<String, Object> ConfigCacheRequestDataTemplate;

    @Value("${kafka.rc.config.cache.request.topic}")
    private String topicName;

    @PostConstruct
    public void requestForAllCacheData() {
        LOGGER.info("Sending request to load config cache on topic {}", topicName);

        ConfigCacheRequestDataTemplate.send(topicName,"getAllData");

        LOGGER.info("Request to load config cache data sent successfully");

    }
}
