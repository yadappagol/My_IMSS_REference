package com.imss.rc.config.service;

import com.imss.rc.config.exception.ConfigException;
import org.springframework.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

public class ConfigCache
{
    private static Map<String,Map<String,String>> cache = new HashMap<>();

    public static String getConfigValue(String configType) {
        if(cache.isEmpty() || cache.get(configType) == null){
            throw new ConfigException(ConfigException.CONFIG_CACHE_NOT_INITIALIZED, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return cache.get(configType).get("value");
    }

    public static void putConfigDetails(String key, Map<String,String> obj){
        cache.put(key, obj);
    }

}
