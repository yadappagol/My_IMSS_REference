package com.imss.rc.config.service;

import com.imss.rc.config.assembler.ConfigDetailsAssembler;
import com.imss.rc.config.assembler.ConfigGroupAssembler;
import com.imss.rc.config.dto.ConfigDetailsDto;
import com.imss.rc.config.dto.ConfigGroupDto;
import com.imss.rc.config.entity.ConfigDetailsEntity;
import com.imss.rc.config.entity.ConfigGroupEntity;
import com.imss.rc.config.exception.ConfigException;
import com.imss.rc.config.util.ConfigValidation;
import com.imss.rc.config.util.KafkaSendMessage;
import com.imss.rc.cdh.repository.CoreDataDetailsRepository;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.config.repository.ConfigDetailsRepository;
import com.imss.rc.config.repository.ConfigGroupRepository;
import org.hibernate.HibernateException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.boot.test.context.SpringBootTest;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static com.imss.rc.config.util.TestConstants.TEST_CASE_FAILED;
import static com.imss.rc.config.util.TestConstants.EXCEPTION_OCCURRED;
import static com.imss.rc.config.util.TestConstants.CHECKING_RIGHT_ERROR_CODE;
import static com.imss.rc.config.util.TestConstants.EXECUTION_WENT_THROUGH;

@RunWith(PowerMockRunner.class)
@SpringBootTest(classes= ConfigGroupServiceImplTest.class)
public class ConfigGroupServiceImplTest {

    @InjectMocks
    private  ConfigGroupServiceImpl configGroupServiceImpl;

    @Mock
    private ConfigGroupRepository configGroupRepository;

    @Mock
    ConfigGroupAssembler assembler;

    @Mock
    private ConfigValidation configValidation;

    @Mock
    private KafkaSendMessage kafkaSendMessage;

    @Mock
    private CoreDataDetailsRepository coreDataDetailsRepository;
    @Mock
    private ConfigDetailsRepository configDetailsRepository;

    @Mock
    private ConfigDetailsAssembler configDetailsAssembler;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void testGetAllConfigs() throws ConfigException {
        try {
            List<ConfigGroupEntity> configGroupEntityList = new ArrayList<>();

            ConfigGroupEntity groupEntity= new ConfigGroupEntity();
            groupEntity.setId(100101);
            groupEntity.setAdditionalData("Details to send out mails");
            groupEntity.setCategoryId(1002);
            groupEntity.setIsTestEnabled(1);
            groupEntity.setName("notify.mail");

            ConfigGroupEntity groupEntity1= new ConfigGroupEntity();
            groupEntity1.setId(100201);
            groupEntity1.setAdditionalData("Description for port");
            groupEntity1.setCategoryId(10);
            groupEntity1.setIsTestEnabled(1);
            groupEntity1.setName("port");

            configGroupEntityList.add(groupEntity);
            configGroupEntityList.add(groupEntity1);

            List<ConfigGroupDto> configGroupDtoList = new ArrayList<>();
            ConfigGroupDto configGroupDto = new ConfigGroupDto();
            ConfigGroupDto configGroupDto1 = new ConfigGroupDto();

            PaginationDto paginationDto = new PaginationDto();
            paginationDto.setLimit(10);
            paginationDto.setPage(1);
            configGroupDto.setPagination(paginationDto);

            configGroupDto.setId(100101);
            configGroupDto.setAdditionalData("Details to send out emails");
            configGroupDto.setCategoryId(10);
            configGroupDto.setIsTestEnabled(1);
            configGroupDto.setName("notify.mail");
            configGroupDto.setPagination(paginationDto);
            configGroupDtoList.add(configGroupDto);

            configGroupDto1.setId(100201);
            configGroupDto1.setAdditionalData("Description for port");
            configGroupDto1.setCategoryId(10);
            configGroupDto1.setIsTestEnabled(1);
            configGroupDto1.setName("port");
            configGroupDto1.setPagination(paginationDto);
            configGroupDtoList.add(configGroupDto1);

            PageableEntity<ConfigGroupEntity> list = new PageableEntity<>();
            list.setData(configGroupEntityList);
            list.setCount(20);


            when(configGroupRepository.getAllConfigGroupsWithFilters(Mockito.any(),Mockito.any())).thenReturn(list);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(configGroupDtoList);
            BaseListDto<ConfigGroupDto> result = configGroupServiceImpl.getConfigGroups(configGroupDto);
            assertEquals(2, result.getDataList().size());
            assertEquals(20, result.getPagination().getCount());
        }
        catch(Exception ex){
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }

    @Test
    public void testGetAllConfigsNegative() throws ConfigException {
        try {
            List<ConfigGroupEntity> configGroupEntityList = new ArrayList<>();

            ConfigGroupEntity groupEntity= new ConfigGroupEntity();
            groupEntity.setId(100101);
            groupEntity.setAdditionalData("Details to send out mails");
            groupEntity.setCategoryId(1002);
            groupEntity.setIsTestEnabled(1);
            groupEntity.setName("notify.mail");

            ConfigGroupEntity groupEntity1= new ConfigGroupEntity();
            groupEntity1.setId(100201);
            groupEntity1.setAdditionalData("Description for port");
            groupEntity1.setCategoryId(10);
            groupEntity1.setIsTestEnabled(1);
            groupEntity1.setName("port");

            configGroupEntityList.add(groupEntity);
            configGroupEntityList.add(groupEntity1);

            List<ConfigGroupDto> configGroupDtoList = new ArrayList<>();
            ConfigGroupDto configGroupDto = new ConfigGroupDto();
            ConfigGroupDto configGroupDto1 = new ConfigGroupDto();

            PaginationDto paginationDto = new PaginationDto();
            paginationDto.setLimit(10);
            paginationDto.setPage(1);
            configGroupDto.setPagination(paginationDto);

            configGroupDto.setId(100101);
            configGroupDto.setAdditionalData("Details to send out emails");
            configGroupDto.setCategoryId(10);
            configGroupDto.setIsTestEnabled(1);
            configGroupDto.setName("notify.mail");
            configGroupDto.setPagination(paginationDto);
            configGroupDtoList.add(configGroupDto);

            configGroupDto1.setId(100201);
            configGroupDto1.setAdditionalData("Description for port");
            configGroupDto1.setCategoryId(10);
            configGroupDto1.setIsTestEnabled(1);
            configGroupDto1.setName("port");
            configGroupDto1.setPagination(paginationDto);
            configGroupDtoList.add(configGroupDto1);

            PageableEntity<ConfigGroupEntity> list = new PageableEntity<>();
            list.setData(configGroupEntityList);
            list.setCount(20);

            when(configGroupRepository.getAllConfigGroupsWithFilters(Mockito.any(),Mockito.any())).thenReturn(null);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(configGroupDtoList);
            configGroupServiceImpl.getConfigGroups(configGroupDto);
            Assert.assertTrue(EXECUTION_WENT_THROUGH,TEST_CASE_FAILED);
        } catch (ConfigException ex) {
            Assert.assertEquals(CHECKING_RIGHT_ERROR_CODE, ConfigException.CONFIG_GROUPS_NOT_FOUND, ex.getCode());

        }
    }

    // TestCase for updating the value with empty DataListId
    @Test
    public void testUpdate() throws ConfigException {
        try {
            ConfigDetailsEntity configDetailsEntity = new ConfigDetailsEntity();
            configDetailsEntity.setId(10010101);
            configDetailsEntity.setIsDeleted((short) 0);
            configDetailsEntity.setIsEditable((short)1);
            configDetailsEntity.setMaxLength(10);
            configDetailsEntity.setValue("notify.host");
            configDetailsEntity.setMinLength(5);
            configDetailsEntity.setIsVisible(1);
            configDetailsEntity.setKey("13");
            configDetailsEntity.setGroupId(12);
            configDetailsEntity.setUom("UOM");
            configDetailsEntity.setDataType(18);

            ConfigDetailsDto configDetailsDto = new ConfigDetailsDto();
            configDetailsDto.setId(10010101);
            configDetailsDto.setValue("SMTPDetailsUpdated");
            configDetailsDto.setRowVersion(1);
            configDetailsDto.setIsEditable((short)1);
            configDetailsDto.setDataType(18);

            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.dtoToEntity(configDetailsDto)).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.entityToDto(configDetailsEntity)).thenReturn(configDetailsDto);
            when(configValidation.validateMaxLength(configDetailsDto.getValue().length(), configDetailsEntity.getMaxLength())).thenReturn(true);
            when(configValidation.validateMinLength(configDetailsDto.getValue().length(), configDetailsEntity.getMinLength())).thenReturn(true);
            when(configValidation.validateDataType(configDetailsEntity.getDataType(), configDetailsDto.getValue())).thenReturn(true);
            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsRepository.saveAndFlush(configDetailsEntity)).thenReturn(configDetailsEntity);
            ConfigDetailsDto configDetailsDto1 = configGroupServiceImpl.updateConfigDetails(configDetailsDto.getId(), configDetailsDto);
            assertEquals("SMTPDetailsUpdated", configDetailsDto1.getValue());
            assertEquals(10010101, configDetailsDto1.getId());
        } catch (Exception ex) {
            Assert.assertTrue(EXCEPTION_OCCURRED,TEST_CASE_FAILED);
        }
    }

    //TestCase for updating the value with dataListTypeId and dataType other than checkbox
    @Test
    public void testUpdateForDataListId() throws ConfigException {
        try {
            ConfigDetailsEntity configDetailsEntity = new ConfigDetailsEntity();
            configDetailsEntity.setId(10010101);
            configDetailsEntity.setIsDeleted((short) 0);
            configDetailsEntity.setIsEditable((short)1);
            configDetailsEntity.setMaxLength(10);
            configDetailsEntity.setValue("10");
            configDetailsEntity.setMinLength(5);
            configDetailsEntity.setIsVisible(1);
            configDetailsEntity.setKey("13");
            configDetailsEntity.setGroupId(12);
            configDetailsEntity.setUom("UOM");
            configDetailsEntity.setDataType(2005);
            configDetailsEntity.setDataListTypeId(10);

            ConfigDetailsDto configDetailsDto = new ConfigDetailsDto();
            configDetailsDto.setId(10010101);
            configDetailsDto.setValue("10");
            configDetailsDto.setRowVersion(1);
            configDetailsDto.setIsEditable((short)1);
            configDetailsDto.setDataType(2005);
            configDetailsDto.setDataListTypeId(10);

            List<Integer> dataListId=new ArrayList<>();
            dataListId.add(10);

            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.dtoToEntity(configDetailsDto)).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.entityToDto(configDetailsEntity)).thenReturn(configDetailsDto);
            when(configValidation.validateMaxLength(configDetailsDto.getValue().length(), configDetailsEntity.getMaxLength())).thenReturn(true);
            when(configValidation.validateMinLength(configDetailsDto.getValue().length(), configDetailsEntity.getMinLength())).thenReturn(true);
            when(configValidation.validateDataType(configDetailsEntity.getDataType(), configDetailsDto.getValue())).thenReturn(true);
            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsRepository.saveAndFlush(configDetailsEntity)).thenReturn(configDetailsEntity);
            when(coreDataDetailsRepository.getDataListId(configDetailsEntity.getDataListTypeId())).thenReturn((dataListId));
            ConfigDetailsDto configDetailsDto1 = configGroupServiceImpl.updateConfigDetails(configDetailsDto.getId(), configDetailsDto);
            assertEquals("10", configDetailsDto1.getValue());
            assertEquals(10010101, configDetailsDto1.getId());
        } catch (Exception ex) {
            Assert.assertTrue(EXCEPTION_OCCURRED,TEST_CASE_FAILED);
        }
    }

    //TestCase for updating the value with dataListTypeId and dataType other than checkbox with incorrect values
    @Test
    public void testUpdateForDataListNeg() throws ConfigException,ParseException {
        try {
            ConfigDetailsEntity configDetailsEntity = new ConfigDetailsEntity();
            configDetailsEntity.setId(10010101);
            configDetailsEntity.setIsDeleted((short) 0);
            configDetailsEntity.setIsEditable((short)1);
            configDetailsEntity.setMaxLength(10);
            configDetailsEntity.setValue("30");
            configDetailsEntity.setMinLength(5);
            configDetailsEntity.setIsVisible(1);
            configDetailsEntity.setKey("13");
            configDetailsEntity.setGroupId(12);
            configDetailsEntity.setUom("UOM");
            configDetailsEntity.setDataType(2006);
            configDetailsEntity.setDataListTypeId(10);

            ConfigDetailsDto configDetailsDto = new ConfigDetailsDto();
            configDetailsDto.setId(10010101);
            configDetailsDto.setValue("30");
            configDetailsDto.setRowVersion(1);
            configDetailsDto.setIsEditable((short)1);
            configDetailsDto.setDataType(2005);
            configDetailsDto.setDataListTypeId(10);

            List<Integer> dataListId=new ArrayList<>();
            dataListId.add(10);
            dataListId.add(20);

            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.dtoToEntity(configDetailsDto)).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.entityToDto(configDetailsEntity)).thenReturn(configDetailsDto);
            when(configValidation.validateMaxLength(configDetailsDto.getValue().length(), configDetailsEntity.getMaxLength())).thenReturn(true);
            when(configValidation.validateMinLength(configDetailsDto.getValue().length(), configDetailsEntity.getMinLength())).thenReturn(true);
            when(configValidation.validateDataType(configDetailsEntity.getDataType(), configDetailsDto.getValue())).thenReturn(true);
            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsRepository.saveAndFlush(configDetailsEntity)).thenReturn(configDetailsEntity);
            when(coreDataDetailsRepository.getDataListId(configDetailsEntity.getDataListTypeId())).thenReturn((dataListId));
            configGroupServiceImpl.updateConfigDetails(configDetailsDto.getId(), configDetailsDto);
            Assert.assertTrue(EXECUTION_WENT_THROUGH,TEST_CASE_FAILED);
        } catch(ConfigException ex) {
            Assert.assertEquals(CHECKING_RIGHT_ERROR_CODE, ConfigException.DATA_LIST_VALIDATION_FAILED, ex.getCode());
        }
    }

    //TestCase for updating the value with dataListTypeId and dataType checkbox
    @Test
    public void testUpdateForDataListCheckBox() throws ConfigException {
        try {
            ConfigDetailsEntity configDetailsEntity = new ConfigDetailsEntity();
            configDetailsEntity.setId(10010101);
            configDetailsEntity.setIsDeleted((short) 0);
            configDetailsEntity.setIsEditable((short)1);
            configDetailsEntity.setMaxLength(10);
            configDetailsEntity.setValue("10");
            configDetailsEntity.setMinLength(5);
            configDetailsEntity.setIsVisible(1);
            configDetailsEntity.setKey("13");
            configDetailsEntity.setGroupId(12);
            configDetailsEntity.setUom("UOM");
            //For Checkbox
            configDetailsEntity.setDataType(2006);
            configDetailsEntity.setDataListTypeId(10);

            ConfigDetailsDto configDetailsDto = new ConfigDetailsDto();
            configDetailsDto.setId(10010101);
            configDetailsDto.setValue("10");
            configDetailsDto.setRowVersion(1);
            configDetailsDto.setIsEditable((short)1);
            configDetailsDto.setDataType(2005);
            configDetailsDto.setDataListTypeId(10);

            List<Integer> dataListId=new ArrayList<>();
            dataListId.add(10);
            dataListId.add(20);

            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.dtoToEntity(configDetailsDto)).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.entityToDto(configDetailsEntity)).thenReturn(configDetailsDto);
            when(configValidation.validateMaxLength(configDetailsDto.getValue().length(), configDetailsEntity.getMaxLength())).thenReturn(true);
            when(configValidation.validateMinLength(configDetailsDto.getValue().length(), configDetailsEntity.getMinLength())).thenReturn(true);
            when(configValidation.validateDataType(configDetailsEntity.getDataType(), configDetailsDto.getValue())).thenReturn(true);
            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsRepository.saveAndFlush(configDetailsEntity)).thenReturn(configDetailsEntity);
            when(coreDataDetailsRepository.getDataListId(configDetailsEntity.getDataListTypeId())).thenReturn((dataListId));
            ConfigDetailsDto configDetailsDto1 = configGroupServiceImpl.updateConfigDetails(configDetailsDto.getId(), configDetailsDto);
            assertEquals("10", configDetailsDto1.getValue());
            assertEquals(10010101, configDetailsDto1.getId());
        } catch (Exception ex) {
            Assert.assertTrue(EXCEPTION_OCCURRED,TEST_CASE_FAILED);
        }
    }

    //TestCase for updating the value with dataListTypeId and dataType checkbox for incorrect values
    @Test
    public void testUpdateForDataListCheckBoxNeg() throws ConfigException,ParseException {
        try {
            ConfigDetailsEntity configDetailsEntity = new ConfigDetailsEntity();
            configDetailsEntity.setId(10010101);
            configDetailsEntity.setIsDeleted((short) 0);
            configDetailsEntity.setIsEditable((short)1);
            configDetailsEntity.setMaxLength(10);
            configDetailsEntity.setValue("30");
            configDetailsEntity.setMinLength(5);
            configDetailsEntity.setIsVisible(1);
            configDetailsEntity.setKey("13");
            configDetailsEntity.setGroupId(12);
            configDetailsEntity.setUom("UOM");
            //For Checkbox
            configDetailsEntity.setDataType(2006);
            configDetailsEntity.setDataListTypeId(10);

            ConfigDetailsDto configDetailsDto = new ConfigDetailsDto();
            configDetailsDto.setId(10010101);
            configDetailsDto.setValue("30");
            configDetailsDto.setRowVersion(1);
            configDetailsDto.setIsEditable((short)1);
            configDetailsDto.setDataType(2005);
            configDetailsDto.setDataListTypeId(10);

            List<Integer> dataListId=new ArrayList<>();
            dataListId.add(10);
            dataListId.add(20);

            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.dtoToEntity(configDetailsDto)).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.entityToDto(configDetailsEntity)).thenReturn(configDetailsDto);
            when(configValidation.validateMaxLength(configDetailsDto.getValue().length(), configDetailsEntity.getMaxLength())).thenReturn(true);
            when(configValidation.validateMinLength(configDetailsDto.getValue().length(), configDetailsEntity.getMinLength())).thenReturn(true);
            when(configValidation.validateDataType(configDetailsEntity.getDataType(), configDetailsDto.getValue())).thenReturn(true);
            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsRepository.saveAndFlush(configDetailsEntity)).thenReturn(configDetailsEntity);
            when(coreDataDetailsRepository.getDataListId(configDetailsEntity.getDataListTypeId())).thenReturn((dataListId));
            configGroupServiceImpl.updateConfigDetails(configDetailsDto.getId(), configDetailsDto);
            Assert.assertTrue(EXECUTION_WENT_THROUGH,TEST_CASE_FAILED);
        } catch(ConfigException ex) {
            Assert.assertEquals(CHECKING_RIGHT_ERROR_CODE, ConfigException.DATA_LIST_VALIDATION_FAILED, ex.getCode());
        }
    }

    //Test Case for updating the details when validation fails
    @Test
    public void testUpdateConfigNeg() throws ConfigException, ParseException {
        try {
            ConfigDetailsEntity configDetailsEntity = new ConfigDetailsEntity();
            configDetailsEntity.setMaxLength(10);
            configDetailsEntity.setValue("notify.host");
            configDetailsEntity.setMinLength(5);
            configDetailsEntity.setIsVisible(1);
            configDetailsEntity.setKey("13");
            configDetailsEntity.setId(10010101);
            configDetailsEntity.setIsDeleted((short)0);
            configDetailsEntity.setRowVersion(1);
            configDetailsEntity.setGroupId(12);
            configDetailsEntity.setUom("UOM");
            configDetailsEntity.setModifiedDate(new Date());
            configDetailsEntity.setDataType(18);
            configDetailsEntity.setIsEditable(1);

            ConfigDetailsDto configDetailsDto = new ConfigDetailsDto();
            configDetailsDto.setId(10010101);
            configDetailsDto.setValue("notify.port");
            configDetailsDto.setRowVersion(1);
            configDetailsDto.setDataType(18);

            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.dtoToEntity(configDetailsDto)).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.entityToDto(configDetailsEntity)).thenReturn(configDetailsDto);
            when(configValidation.validateMaxLength(configDetailsDto.getValue().length(), configDetailsEntity.getMaxLength())).thenReturn(false);
            when(configValidation.validateMinLength(configDetailsDto.getValue().length(), configDetailsEntity.getMinLength())).thenReturn(true);
            when(configValidation.validateDataType(configDetailsEntity.getDataType(), configDetailsDto.getValue())).thenReturn(true);
            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsRepository.saveAndFlush(configDetailsEntity)).thenReturn(configDetailsEntity);
            configGroupServiceImpl.updateConfigDetails(configDetailsDto.getId(), configDetailsDto);
            Assert.assertTrue(EXECUTION_WENT_THROUGH,TEST_CASE_FAILED);
        } catch(ConfigException ex) {
            Assert.assertEquals(CHECKING_RIGHT_ERROR_CODE, ConfigException.VALIDATION_FAILED, ex.getCode());
        }
    }

    //Test Case for updating the details when dataType validation fails
    @Test
    public void testUpdateConfigForDataType() throws ConfigException, ParseException {
        try {
            ConfigDetailsEntity configDetailsEntity = new ConfigDetailsEntity();
            configDetailsEntity.setMaxLength(10);
            configDetailsEntity.setMinLength(5);
            configDetailsEntity.setIsVisible(1);
            configDetailsEntity.setKey("13");
            configDetailsEntity.setId(10010101);
            configDetailsEntity.setValue("543");
            configDetailsEntity.setIsDeleted((short)0);
            configDetailsEntity.setRowVersion(1);
            configDetailsEntity.setGroupId(12);
            configDetailsEntity.setUom("UOM");
            configDetailsEntity.setModifiedDate(new Date());
            configDetailsEntity.setDataType(18);
            configDetailsEntity.setIsEditable(1);

            ConfigDetailsDto configDetailsDto = new ConfigDetailsDto();
            configDetailsDto.setId(10010101);
            configDetailsDto.setValue("5432");
            configDetailsDto.setRowVersion(1);
            configDetailsDto.setDataType(18);

            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.dtoToEntity(configDetailsDto)).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.entityToDto(configDetailsEntity)).thenReturn(configDetailsDto);
            when(configValidation.validateMaxLength(configDetailsDto.getValue().length(), configDetailsEntity.getMaxLength())).thenReturn(true);
            when(configValidation.validateMinLength(configDetailsDto.getValue().length(), configDetailsEntity.getMinLength())).thenReturn(true);
            when(configValidation.validateDataType(configDetailsEntity.getDataType(), configDetailsDto.getValue())).thenReturn(false);
            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsRepository.saveAndFlush(configDetailsEntity)).thenReturn(configDetailsEntity);
            configGroupServiceImpl.updateConfigDetails(configDetailsDto.getId(), configDetailsDto);
            Assert.assertTrue(EXECUTION_WENT_THROUGH,TEST_CASE_FAILED);
        } catch(ConfigException ex) {
            Assert.assertEquals(CHECKING_RIGHT_ERROR_CODE, ConfigException.DATA_TYPE_VALIDATION_FAILED, ex.getCode());
        }
    }

    //Test Case for updating the details when isEditable set to 0
    @Test
    public void testUpdateConfigForIsEditable() throws ConfigException, ParseException {
        try {
            ConfigDetailsEntity configDetailsEntity = new ConfigDetailsEntity();
            configDetailsEntity.setValue("test@gmail.com");
            configDetailsEntity.setId(10010101);
            configDetailsEntity.setIsDeleted((short)0);
            configDetailsEntity.setIsEditable((short)0);

            ConfigDetailsDto configDetailsDto = new ConfigDetailsDto();
            configDetailsDto.setId(10010101);
            configDetailsDto.setValue("test@gmail.com.updated");
            configDetailsDto.setRowVersion(1);
            configDetailsDto.setIsEditable((short)0);

            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.dtoToEntity(configDetailsDto)).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.entityToDto(configDetailsEntity)).thenReturn(configDetailsDto);
            when(configValidation.validateMaxLength(configDetailsDto.getValue().length(), configDetailsEntity.getMaxLength())).thenReturn(true);
            when(configValidation.validateMinLength(configDetailsDto.getValue().length(), configDetailsEntity.getMinLength())).thenReturn(true);
            when(configValidation.validateDataType(configDetailsEntity.getDataType(), configDetailsDto.getValue())).thenReturn(true);
            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsRepository.saveAndFlush(configDetailsEntity)).thenReturn(configDetailsEntity);
            configGroupServiceImpl.updateConfigDetails(configDetailsDto.getId(), configDetailsDto);
            Assert.assertTrue(EXECUTION_WENT_THROUGH,TEST_CASE_FAILED);
        } catch(ConfigException ex) {
            Assert.assertEquals(CHECKING_RIGHT_ERROR_CODE, ConfigException.CONFIG_DETAILS_NOT_EDITABLE, ex.getCode());
        }
    }

    //Test Case for updating the details when isDeleted set to 1
    @Test
    public void testUpdateConfigForIsDeleted() throws ConfigException, ParseException {
        try {
            ConfigDetailsEntity configDetailsEntity = new ConfigDetailsEntity();
            configDetailsEntity.setIsDeleted((short)1);
            configDetailsEntity.setValue("gmail.com");

            ConfigDetailsDto configDetailsDto = new ConfigDetailsDto();
            configDetailsDto.setId(10010101);
            configDetailsDto.setValue("smtp.gmail.com");
            configDetailsDto.setRowVersion(1);

            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.dtoToEntity(configDetailsDto)).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.entityToDto(configDetailsEntity)).thenReturn(configDetailsDto);
            when(configValidation.validateMaxLength(configDetailsDto.getValue().length(), configDetailsEntity.getMaxLength())).thenReturn(true);
            when(configValidation.validateMinLength(configDetailsDto.getValue().length(), configDetailsEntity.getMinLength())).thenReturn(true);
            when(configValidation.validateDataType(configDetailsEntity.getDataType(), configDetailsDto.getValue())).thenReturn(true);
            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsRepository.saveAndFlush(configDetailsEntity)).thenReturn(configDetailsEntity);
            configGroupServiceImpl.updateConfigDetails(configDetailsDto.getId(), configDetailsDto);
            Assert.assertTrue(EXECUTION_WENT_THROUGH,TEST_CASE_FAILED);
        } catch(ConfigException ex) {
            Assert.assertEquals(CHECKING_RIGHT_ERROR_CODE, ConfigException.CONFIG_DETAILS_NOT_FOUND, ex.getCode());
        }
    }

    //Test case for updating details when fails to save to database
    @Test
    public void testUpdateConfigNegative() throws ConfigException, ParseException {
        try {
            ConfigDetailsEntity configDetailsEntity = new ConfigDetailsEntity();
            configDetailsEntity.setMaxLength(10);
            configDetailsEntity.setValue("notify.host");
            configDetailsEntity.setMinLength(5);
            configDetailsEntity.setIsVisible(1);
            configDetailsEntity.setKey("13");
            configDetailsEntity.setId(10010101);
            configDetailsEntity.setIsDeleted((short)0);
            configDetailsEntity.setRowVersion(1);
            configDetailsEntity.setGroupId(12);
            configDetailsEntity.setUom("UOM");
            configDetailsEntity.setModifiedDate(new Date());
            configDetailsEntity.setDataType(18);
            configDetailsEntity.setIsEditable(1);

            ConfigDetailsDto configDetailsDto = new ConfigDetailsDto();
            configDetailsDto.setId(10010101);
            configDetailsDto.setValue("notify.port");
            configDetailsDto.setRowVersion(1);
            configDetailsDto.setDataType(18);

            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.dtoToEntity(configDetailsDto)).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.entityToDto(configDetailsEntity)).thenReturn(configDetailsDto);
            when(configValidation.validateMaxLength(configDetailsDto.getValue().length(), configDetailsEntity.getMaxLength())).thenReturn(true);
            when(configValidation.validateMinLength(configDetailsDto.getValue().length(), configDetailsEntity.getMinLength())).thenReturn(true);
            when(configValidation.validateDataType(configDetailsEntity.getDataType(), configDetailsDto.getValue())).thenReturn(true);
            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            doThrow(new HibernateException("CONFIG_DETAILS_NOT_UPDATED")).when(configDetailsRepository).saveAndFlush(configDetailsEntity);
            configGroupServiceImpl.updateConfigDetails(configDetailsDto.getId(), configDetailsDto);
            Assert.assertTrue(EXECUTION_WENT_THROUGH,TEST_CASE_FAILED);
        } catch(ConfigException ex) {
            Assert.assertEquals(CHECKING_RIGHT_ERROR_CODE, ConfigException.CONFIG_DETAILS_NOT_UPDATED, ex.getCode());
        }
    }

    //Test case for updating details for validating Regular Expressions
    @Test
    public void testUpdateConfigForRegEx() throws ConfigException, ParseException {
        try {
            ConfigDetailsEntity configDetailsEntity = new ConfigDetailsEntity();
            configDetailsEntity.setMaxLength(10);
            configDetailsEntity.setValue("notify.host");
            configDetailsEntity.setMinLength(5);
            configDetailsEntity.setIsVisible(1);
            configDetailsEntity.setKey("13");
            configDetailsEntity.setId(10010101);
            configDetailsEntity.setIsDeleted((short)0);
            configDetailsEntity.setRowVersion(1);
            configDetailsEntity.setGroupId(12);
            configDetailsEntity.setUom("UOM");
            configDetailsEntity.setModifiedDate(new Date());
            configDetailsEntity.setDataType(18);
            configDetailsEntity.setIsEditable(1);
            configDetailsEntity.setRegExp("^$%!123");

            ConfigDetailsDto configDetailsDto = new ConfigDetailsDto();
            configDetailsDto.setId(10010101);
            configDetailsDto.setValue("notify.port");
            configDetailsDto.setRowVersion(1);
            configDetailsDto.setDataType(18);

            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.dtoToEntity(configDetailsDto)).thenReturn(configDetailsEntity);
            when(configDetailsAssembler.entityToDto(configDetailsEntity)).thenReturn(configDetailsDto);
            when(configValidation.validateMaxLength(configDetailsDto.getValue().length(), configDetailsEntity.getMaxLength())).thenReturn(true);
            when(configValidation.validateMinLength(configDetailsDto.getValue().length(), configDetailsEntity.getMinLength())).thenReturn(true);
            when(configValidation.validateRegex(configDetailsDto.getValue(),configDetailsEntity.getRegExp())).thenReturn(true);
            when(configValidation.validateDataType(configDetailsEntity.getDataType(), configDetailsDto.getValue())).thenReturn(true);
            when(configDetailsRepository.getOne(Mockito.anyInt())).thenReturn(configDetailsEntity);
            when(configDetailsRepository.saveAndFlush(configDetailsEntity)).thenReturn(configDetailsEntity);
            ConfigDetailsDto configDetailsDto1 = configGroupServiceImpl.updateConfigDetails(configDetailsDto.getId(), configDetailsDto);
            assertEquals("notify.port", configDetailsDto1.getValue());
            assertEquals(10010101, configDetailsDto1.getId());
        } catch (Exception ex) {
            Assert.assertTrue(EXCEPTION_OCCURRED,TEST_CASE_FAILED);
        }
    }

}






