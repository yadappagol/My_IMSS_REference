package com.imss.rc.config.service;

import com.imss.rc.config.assembler.ConfigDetailsAssembler;
import com.imss.rc.config.dto.ConfigDetailsDto;
import com.imss.rc.config.entity.ConfigDetailsEntity;
import com.imss.rc.config.exception.ConfigException;
import com.imss.rc.config.util.KafkaSendMessage;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.config.repository.ConfigDetailsRepository;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.boot.test.context.SpringBootTest;

import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.imss.rc.config.util.TestConstants.EXCEPTION_OCCURRED;
import static com.imss.rc.config.util.TestConstants.TEST_CASE_FAILED;
import static org.mockito.Mockito.*;

@RunWith(PowerMockRunner.class)
@SpringBootTest(classes= ConfigServiceTest.class)
public class ConfigServiceTest {

    @InjectMocks
    private ConfigServiceImpl configService;

    @Mock
    private ConfigDetailsRepository configDetailsRepository;

    @Mock
    private ConfigDetailsAssembler configDetailsAssembler;

    @Mock
    EntityManager em;

    @Mock
    private KafkaSendMessage kafkaSendMessage;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllConfigDetails() throws ConfigException {
    try {
        ConfigDetailsEntity configDetailsEntity = new ConfigDetailsEntity();
        configDetailsEntity.setName("Motor");
        configDetailsEntity.setDescription("Vehicles");
        configDetailsEntity.setModifiedDate(new Date());
        configDetailsEntity.setIsDeleted((short) 0);
        configDetailsEntity.setId(10);
        configDetailsEntity.setIsEditable(1);
        configDetailsEntity.setIsVisible(1);
        configDetailsEntity.setMinLength(5);
        configDetailsEntity.setMaxLength(15);

        List<ConfigDetailsEntity> entityList = new ArrayList<>();
        entityList.add(configDetailsEntity);

        PageableEntity<ConfigDetailsEntity> list = new PageableEntity<>();
        list.setData(entityList);
        list.setCount(1);

        PaginationDto pageDto = new PaginationDto();
        pageDto.setLimit(5);
        pageDto.setPage(1);

        ConfigDetailsDto productMasterDto = new ConfigDetailsDto();
        productMasterDto.setId(10);
        productMasterDto.setName("Motor");
        productMasterDto.setDescription("Vehicles");
        productMasterDto.setModifiedBy("Admin");
        productMasterDto.setCreatedBy("Admin");
        productMasterDto.setCreatedDate(new Date(2020 - 12 - 11));
        productMasterDto.setIsDeleted((short) 0);
        productMasterDto.setPaginationDto(pageDto);

        List<ConfigDetailsDto> dtoList = new ArrayList<>();
        dtoList.add(productMasterDto);

        when(configDetailsRepository.getAllDetailsWithFilters(em, productMasterDto)).thenReturn(list);
        when(configDetailsAssembler.entityListToDtoList(list.getData())).thenReturn(dtoList);
        BaseListDto<ConfigDetailsDto> result = configService.getConfigDetails(productMasterDto);
        Assert.assertEquals(1, result.getPagination().getCount());
    }
    catch (ConfigException ex){
        Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
    }

    }

}
