package com.imss.rc.config.controller;

import com.imss.rc.config.dto.ConfigDetailsDto;
import com.imss.rc.config.dto.ConfigResponse;
import com.imss.rc.config.exception.ConfigException;
import com.imss.rc.commons.dto.BaseListDto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

public interface ConfigController {

    @GetMapping(value = "/configs",produces = "application/json")
    public @ResponseBody
    BaseListDto<ConfigDetailsDto> getConfigDetails(@RequestParam(required = false) Integer groupId,
                                                   @RequestParam Integer page,
                                                   @RequestParam Integer limit,
                                                   @RequestParam(required = false) String sortBy,
                                                   @RequestParam(required = false) String sortType,
                                                   @RequestParam(required = false) String name, HttpServletRequest request) throws ConfigException;



    @GetMapping(value = "/configs/ui", produces = "application/json")
    public @ResponseBody BaseListDto<ConfigResponse> getConfigValues(HttpServletRequest request);

    @GetMapping(value = "/configs/guest/ui", produces = "application/json")
    public @ResponseBody BaseListDto<ConfigResponse> getConfigValuesForGuest(HttpServletRequest request);

}
