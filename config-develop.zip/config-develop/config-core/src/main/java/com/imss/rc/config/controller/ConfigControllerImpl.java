package com.imss.rc.config.controller;

import com.imss.rc.config.dto.ConfigDetailsDto;
import com.imss.rc.config.dto.ConfigResponse;
import com.imss.rc.config.exception.ConfigException;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import com.imss.rc.config.service.ConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Objects;

@RestController
public class ConfigControllerImpl implements ConfigController{

    @Autowired
    ConfigService configService;

    @Override
    public BaseListDto<ConfigDetailsDto> getConfigDetails(Integer groupId, Integer page, Integer limit, String sortType, String sortBy, String name, HttpServletRequest request) throws ConfigException {
        if (Objects.isNull(page)||page < GlobalYesNoEnum.YES.getValue()) {
            throw new ConfigException(ConfigException.INVALID_PAGE, HttpStatus.BAD_REQUEST);
        }
        if (Objects.isNull(limit) || limit < GlobalYesNoEnum.YES.getValue()) {
            throw new ConfigException(ConfigException.INVALID_LIMIT, HttpStatus.BAD_REQUEST);
        }
        ConfigDetailsDto dto = new ConfigDetailsDto();
        dto.setName(name);
        if(groupId != null) {
            dto.setGroupId(groupId); }
        PaginationDto pageDto = new PaginationDto();
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);

        dto.setPaginationDto(pageDto);
        UserAuthDataHandler.resolveAuthBaseData(dto, request);
        return configService.getConfigDetails(dto);
    }


    @Override
    public BaseListDto<ConfigResponse> getConfigValues(HttpServletRequest request)
    {
        return configService.getConfigValues(false);
    }

    @Override
    public BaseListDto<ConfigResponse> getConfigValuesForGuest(HttpServletRequest request)
    {
        return configService.getConfigValues(true);
    }
}
