package com.imss.rc.config.util;

import com.imss.rc.config.exception.ConfigException;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.service.KafkaProducerSender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class KafkaSendMessage
{
    @Autowired
    KafkaProducerSender kafkaProducerSender;

    private static final Logger LOG = LoggerFactory.getLogger(KafkaSendMessage.class);

    public void sendMessage(AuditMasterDto auditMasterDto)
    {
        try {
            kafkaProducerSender.sendData(auditMasterDto);
        }
        catch (Exception e) {
            LOG.error(ConfigException.MESSAGE_NOT_SENT);
        }
    }
}

