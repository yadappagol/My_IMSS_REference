package com.imss.rc.config.service;

import com.imss.rc.config.dto.ConfigDetailsDto;
import com.imss.rc.config.dto.ConfigGroupDto;
import com.imss.rc.config.exception.ConfigException;
import com.imss.rc.commons.dto.BaseListDto;

public interface ConfigGroupService {

  public BaseListDto<ConfigGroupDto> getConfigGroups(ConfigGroupDto configGroupDto) throws ConfigException;

  public ConfigDetailsDto updateConfigDetails(Integer id, ConfigDetailsDto configDetailsDto) throws ConfigException;

  public BaseListDto<ConfigDetailsDto> updateMultipleConfigDetails(BaseListDto<ConfigDetailsDto> configDetailsList) throws ConfigException;
}