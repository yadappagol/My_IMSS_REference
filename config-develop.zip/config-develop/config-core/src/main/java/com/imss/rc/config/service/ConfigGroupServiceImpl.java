package com.imss.rc.config.service;

import com.imss.rc.config.assembler.ConfigDetailsAssembler;
import com.imss.rc.config.assembler.ConfigGroupAssembler;
import com.imss.rc.config.dto.ConfigDetailsDto;
import com.imss.rc.config.dto.ConfigGroupDto;
import com.imss.rc.config.entity.ConfigDetailsEntity;
import com.imss.rc.config.entity.ConfigGroupEntity;
import com.imss.rc.config.exception.ConfigException;
import com.imss.rc.config.repository.ConfigDetailsRepository;
import com.imss.rc.config.repository.ConfigGroupRepository;
import com.imss.rc.config.util.*;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.enums.AuditEnum;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.cdh.repository.CoreDataDetailsRepository;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.ActionTypeEnum;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import com.imss.rc.commons.util.ExceptionMessageResolver;
import com.imss.rc.config.dto.*;
import com.imss.rc.config.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.List;

@Service
public class ConfigGroupServiceImpl implements ConfigGroupService {

    private static final Logger LOG = LoggerFactory.getLogger(ConfigGroupServiceImpl.class);

    @Autowired
    ConfigGroupRepository configGroupRepository;

    @Autowired
    ConfigDetailsRepository configDetailsRepository;

    @Autowired
    ConfigGroupAssembler configGroupAssembler;

    @Autowired
    ConfigDetailsAssembler configDetailsAssembler;

    @Autowired
    ConfigValidation configValidation;

    @Autowired
    EntityManager em;

    @Autowired
    CoreDataDetailsRepository coreDataDetailsRepository;

    @Autowired
    KafkaSendMessage kafkaSendMessage;

    @Autowired
    MasterDataKafkaSender masterDataKafkaSender;

    @Autowired
    ConfigUtil configUtil;

    /**
     * This method retrieves the list of configuration groups
     * @param configGroupDto for which the list of configuration groups need to be retrieved
     * @return
     * @throws ConfigException
     */
    @Override
    public BaseListDto<ConfigGroupDto> getConfigGroups(ConfigGroupDto configGroupDto) throws ConfigException {
        BaseListDto<ConfigGroupDto> configGroupDtoBaseListDto = new BaseListDto();
        AuditMasterDto auditMasterDto = new AuditMasterDto();
        try {
            //If the order by is blank then setting it to default by asc
            if (configGroupDto.getPagination().getSortType() == null || configGroupDto.getPagination().getSortType().isEmpty()) {
                configGroupDto.getPagination().setSortType("asc");
            }
            //If the sort by is blank then set the default sort by column to name and order by asc
            if (configGroupDto.getPagination().getSortBy() == null || configGroupDto.getPagination().getSortBy().isEmpty()) {
                configGroupDto.getPagination().setSortBy("dispOrder");
                configGroupDto.getPagination().setSortType("asc");
            }
            PageableEntity<ConfigGroupEntity> data = configGroupRepository.getAllConfigGroupsWithFilters(em, configGroupDto);

            PaginationDto pageDto = configGroupDto.getPagination();
            pageDto.setCount(data.getCount());

            configGroupDtoBaseListDto.setPagination(pageDto);
            configGroupDtoBaseListDto.setDataList(configGroupAssembler.entityListToDtoList(data.getData()));
            configGroupDtoBaseListDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            configGroupDtoBaseListDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            configGroupDtoBaseListDto.setAuditEventId(AuditEnum.CONFIGURATION_UPDATES.getValue());

            auditMasterDto.setEventId(AuditEnum.CONFIGURATION_UPDATES.getValue());
            auditMasterDto.setWhen(configGroupDto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(configGroupDtoBaseListDto.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(configGroupDto.getCreatedBy());
            auditMasterDto.setDescription(String.format(AuditConstants.VIEW_ALL_CONFIG_GROUPS,
                    configGroupDtoBaseListDto.getPagination().getPage(),
                    configGroupDtoBaseListDto.getPagination().getLimit(),
                    configGroupDtoBaseListDto.getPagination().getSortBy(),
                    configGroupDtoBaseListDto.getPagination().getSortType(),
                    configGroupDtoBaseListDto.getPagination().getCount())
            );
            kafkaSendMessage.sendMessage(auditMasterDto);
            return configGroupDtoBaseListDto;
        } catch (ConfigException ex) {
            throw ex;
        } catch (Exception ex) {
            LOG.error("Exception:", ex);
            throw new ConfigException(ConfigException.CONFIG_GROUPS_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * This method updates the configuration details based on the id
     * @param id for which the configuration details need to be retrieved and updated
     * @return
     * @throws ConfigException
     */
    @Override
    public ConfigDetailsDto updateConfigDetails(Integer id, ConfigDetailsDto configDetailsDto) throws ConfigException {
        AuditMasterDto auditMasterDto = new AuditMasterDto();
        try {
            ConfigDetailsEntity configDetailsEntity = configDetailsRepository.getOne(id);
            if (configDetailsEntity == null || configDetailsEntity.getIsDeleted() == GlobalYesNoEnum.YES.getValue()) {
                throw new ConfigException(ConfigException.CONFIG_DETAILS_NOT_FOUND, HttpStatus.NOT_FOUND);
            }
            if (configDetailsEntity.getIsEditable() == GlobalYesNoEnum.NO.getValue()) {
                throw new ConfigException(ConfigException.CONFIG_DETAILS_NOT_EDITABLE, HttpStatus.INTERNAL_SERVER_ERROR);
            }
            String dataBefore = configDetailsEntity.getValue();
            configValidation.validateValue(configDetailsDto.getValue());
            if (configValidation.validateMaxLength(configDetailsDto.getValue().length(), configDetailsEntity.getMaxLength()) &&
                    configValidation.validateMinLength(configDetailsDto.getValue().length(), configDetailsEntity.getMinLength())) {
                if (configDetailsEntity.getRegExp() != null && !configDetailsEntity.getRegExp().trim().isEmpty()) {
                    configValidation.validateRegex(configDetailsDto.getValue(), configDetailsEntity.getRegExp());
                }
                if (configDetailsEntity.getDataListTypeId() != GlobalYesNoEnum.NO.getValue()) {
                    List<Integer> dataListId = coreDataDetailsRepository.getDataListId(configDetailsEntity.getDataListTypeId());
                    if (configDetailsEntity.getDataType() != DataType.FIELD_TYPE_CHECKBOX) {
                        boolean res = dataListId.contains(Integer.parseInt(configDetailsDto.getValue()));
                        if (!res) {
                            throw new ConfigException(ConfigException.DATA_LIST_VALIDATION_FAILED, HttpStatus.BAD_REQUEST);
                        }
                    } else {
                        //If it is checkbox then it can have a comma separated list of values
                        String list[] = configDetailsDto.getValue().split(",");
                        for (String listVal : list) {
                            if (!dataListId.contains(Integer.parseInt(listVal))) {
                                throw new ConfigException(ConfigException.DATA_LIST_VALIDATION_FAILED, HttpStatus.BAD_REQUEST);
                            }
                        }
                    }
                }
                if (configValidation.validateDataType(configDetailsEntity.getDataType(), configDetailsDto.getValue())) {
                    configDetailsEntity.setValue(configDetailsDto.getValue());

                    //Use the auth data in the dto to resolve the base data
                    UserAuthDataHandler.resolveEntityBaseData(configDetailsDto, configDetailsEntity);

                    configDetailsEntity.setRowVersion(configDetailsDto.getRowVersion());
                    configDetailsRepository.saveAndFlush(configDetailsEntity);
                    ConfigDetailsDto configDetailDto = configDetailsAssembler.entityToDto(configDetailsEntity);
                    configDetailDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                    configDetailDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                    configDetailDto.setResponseMessage("Config Details is updated successfully");

                    //Republish the changed config to the cache
                    masterDataKafkaSender.sendConfigIntoTopic(configDetailDto.getId(),configDetailDto.getKey(),configUtil.getValueForConfig(configDetailDto));

                    //audit the changes done
                    auditMasterDto.setEventId(AuditEnum.CONFIGURATION_UPDATES.getValue());
                    auditMasterDto.setWhen(configDetailDto.getModifiedDate());
                    auditMasterDto.setReferenceId(String.valueOf(id));
                    auditMasterDto.setActionType(ActionTypeEnum.UPDATE.getValue());
                    auditMasterDto.setWho(configDetailsDto.getModifiedBy());
                    auditMasterDto.setDescription(String.format(AuditConstants.UPDATED_CONFIG_DETAILS,configDetailDto.getName()));

                    //If DataType of the details is not Password then audit the values
                    if (configDetailDto.getDataType()!= DataType.FIELD_TYPE_PASSWORD) {
                        auditMasterDto.setDataBefore(dataBefore);
                        auditMasterDto.setDataAfter(configDetailDto.getValue());
                    }
                    kafkaSendMessage.sendMessage(auditMasterDto);
                    return configDetailDto;
                } else
                    throw new ConfigException(ConfigException.DATA_TYPE_VALIDATION_FAILED, HttpStatus.BAD_REQUEST);
            } else
                throw new ConfigException(ConfigException.VALIDATION_FAILED, HttpStatus.BAD_REQUEST);
        } catch (ConfigException ex) {
            throw ex;
        } catch (Exception ex) {
            LOG.error("Exception in Updating Config details:", ex);
            throw new ConfigException(ConfigException.CONFIG_DETAILS_NOT_UPDATED, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @Override
    public BaseListDto<ConfigDetailsDto> updateMultipleConfigDetails(BaseListDto<ConfigDetailsDto> configDetailsList) throws ConfigException {

        BaseListDto<ConfigDetailsDto> retObj = new BaseListDto<>();
        ArrayList<ConfigDetailsDto> list = new ArrayList<>();
        ConfigDetailsDto retConfigDto;
        for (ConfigDetailsDto configDto : configDetailsList.getDataList()) {
            retConfigDto = configDto;

            configDto.setModifiedBy(configDetailsList.getModifiedBy());
            configDto.setModifiedDate(configDetailsList.getModifiedDate());
            
            //Here the exception is caught and resolved as the individual messages need to be captured
            try{
                retConfigDto = updateConfigDetails(configDto.getId(), configDto);
            } catch (ConfigException cex){
                ExceptionMessageResolver.resolveMessage(retConfigDto,cex, null);
            }

            list.add(retConfigDto);
        }
        retObj.setDataList(list);

        return retObj;
    }
}
