package com.imss.rc.config.repository;

import com.imss.rc.config.assembler.ConfigDetailsAssembler;
import com.imss.rc.config.dto.ConfigDetailsDto;
import com.imss.rc.config.entity.ConfigDetailsEntity;
import com.imss.rc.config.exception.ConfigException;
import com.imss.rc.commons.entity.BaseEntity;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public interface ConfigDetailsRepository extends JpaRepository<ConfigDetailsEntity,Integer> {

    default PageableEntity<ConfigDetailsEntity> getAllDetailsWithFilters(EntityManager em, ConfigDetailsDto configDetailsDto) throws ConfigException {

        PageableEntity<ConfigDetailsEntity> retData = new PageableEntity<>();

        List<Predicate> predicateList = new ArrayList<>();
        CriteriaBuilder criteriaBuilder;
        Root<ConfigDetailsEntity> configDetailsRoot;

        /** This is to get the count of records */
        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        configDetailsRoot = countQuery.from(ConfigDetailsEntity.class);

        predicateList = applySearchFilters(criteriaBuilder, predicateList, configDetailsRoot, configDetailsDto);

        countQuery.select(criteriaBuilder.count(configDetailsRoot));
        countQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));
        long count = em.createQuery(countQuery).getSingleResult();
        retData.setCount(count);
        /***********************************/


        /** This is to get the list based on the page and limit *******/

        //Clear out the predicateList created using the count root
        predicateList.clear();

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<ConfigDetailsEntity> listCriteriaQuery = criteriaBuilder.createQuery(ConfigDetailsEntity.class);

        configDetailsRoot = listCriteriaQuery.from(ConfigDetailsEntity.class);

        listCriteriaQuery.select(configDetailsRoot);
        predicateList = applySearchFilters(criteriaBuilder, predicateList, configDetailsRoot, configDetailsDto);

        listCriteriaQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));

        String sortByColumn = ConfigDetailsAssembler.getSortByColumn(configDetailsDto.getPaginationDto().getSortBy());

        Order order;
        if ("asc".equals(configDetailsDto.getPaginationDto().getSortType())) {
            order = criteriaBuilder.asc(configDetailsRoot.get(sortByColumn));
        } else {
            order = criteriaBuilder.desc(configDetailsRoot.get(sortByColumn));
        }

        TypedQuery<ConfigDetailsEntity> query = em.createQuery(listCriteriaQuery.orderBy(order))
                .setFirstResult((configDetailsDto.getPaginationDto().getPage() - 1) * configDetailsDto.getPaginationDto().getLimit())
                .setMaxResults(configDetailsDto.getPaginationDto().getLimit());
        retData.setData(query.getResultList());
        /***********************************/


        return retData;
    }


    default List<Predicate> applySearchFilters(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Root<ConfigDetailsEntity> configDetailsEntityRoot,
                                               ConfigDetailsDto configDetailsDto) throws ConfigException {

        predicateList.add(criteriaBuilder.equal(configDetailsEntityRoot.get(BaseEntity.COLUMN_NAME_IS_DELETED), GlobalYesNoEnum.NO.getValue()));
        //Adding filter for group id if present
        if (Optional.ofNullable(configDetailsDto.getGroupId()).isPresent() && configDetailsDto.getGroupId() != GlobalYesNoEnum.NO.getValue()) {
            predicateList.add(criteriaBuilder.equal(configDetailsEntityRoot.get(ConfigDetailsEntity.COLUMN_NAME_GROUP_ID), configDetailsDto.getGroupId()));
        }

        //Adding filter for action type if present
        if (Optional.ofNullable(configDetailsDto.getName()).isPresent() && !configDetailsDto.getName().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.like(criteriaBuilder.upper(configDetailsEntityRoot.get(ConfigDetailsEntity.COLUMN_NAME_BY_NAME)), "%" + configDetailsDto.getName().toUpperCase() + "%"));

        }
        return predicateList;
    }



    @Query(value="from ConfigDetailsEntity sc where sc.isDeleted=0")
    public List<ConfigDetailsEntity> getConfigDetails();

    @Query(value="from ConfigDetailsEntity sc where sc.isSendToUi=1")
    List<ConfigDetailsEntity> getDetailsBySendToUi();

    @Query(value="from ConfigDetailsEntity sc where sc.isSendToUi = 1 and isSendToGuestUi = 1")
    List<ConfigDetailsEntity> getDetailsBySendToUiAndGuest();
}
