package com.imss.rc.config.service;

import com.imss.rc.config.assembler.ConfigDetailsAssembler;
import com.imss.rc.config.dto.ConfigDetailsDto;
import com.imss.rc.config.dto.ConfigResponse;
import com.imss.rc.config.entity.ConfigDetailsEntity;
import com.imss.rc.config.exception.ConfigException;
import com.imss.rc.config.repository.ConfigDetailsRepository;
import com.imss.rc.config.util.ConfigUtil;
import com.imss.rc.config.util.KafkaSendMessage;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.enums.AuditEnum;
import com.imss.rc.cdh.entity.CoreDataDetailsEntity;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.ActionTypeEnum;
import com.imss.rc.config.dto.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.List;

@Service
public class ConfigServiceImpl implements ConfigService {

    @Autowired
    ConfigDetailsRepository configDetailsRepository;

    @Autowired
    ConfigDetailsAssembler configDetailsAssembler;

    @Autowired
    EntityManager em;

    @Autowired
    MasterDataKafkaSender masterDataKafkaSender;

    @Autowired
    KafkaSendMessage kafkaSendMessage;

    @Autowired
    ConfigUtil configUtil;


    private static final Logger LOG = LoggerFactory.getLogger(ConfigServiceImpl.class);


    /**
     * This method retrieves the list of configuration details
     * @param dto for which the list of configuration details need to be retrieved
     * @return
     * @throws ConfigException
     */
    @Override
    public BaseListDto<ConfigDetailsDto> getConfigDetails(ConfigDetailsDto dto) throws ConfigException {
        BaseListDto<ConfigDetailsDto> dtoList = new BaseListDto();
        AuditMasterDto auditMasterDto = new AuditMasterDto();
        try {
            //If the order by is blank then setting it to default by asc
            if (dto.getPaginationDto().getSortType() == null || dto.getPaginationDto().getSortType().isEmpty()) {
                dto.getPaginationDto().setSortType("asc");
            }

            //If the sort by is blank then set the default sort by column to name and order by asc
            if (dto.getPaginationDto().getSortBy() == null || dto.getPaginationDto().getSortBy().isEmpty()) {
                dto.getPaginationDto().setSortBy("dispOrder");
                dto.getPaginationDto().setSortType("asc");
            }
            PageableEntity<ConfigDetailsEntity> pagedResult = configDetailsRepository.getAllDetailsWithFilters(em, dto);
            PaginationDto pageDto = dto.getPaginationDto();
            pageDto.setCount(pagedResult.getCount());

            dtoList.setPagination(pageDto);
            dtoList.setDataList(configDetailsAssembler.entityListToDtoList(pagedResult.getData()));
            dtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            dtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            dtoList.setAuditEventId(AuditEnum.CONFIGURATION_UPDATES.getValue());

            auditMasterDto.setEventId(AuditEnum.CONFIGURATION_UPDATES.getValue());
            auditMasterDto.setWhen(dto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(dto.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(dto.getCreatedBy());
            auditMasterDto.setDescription("Viewed all configurations");
            kafkaSendMessage.sendMessage(auditMasterDto);
            return dtoList;

        }  catch (ConfigException ex) {
            throw ex;
        } catch (Exception ex) {
            LOG.error("Exception in view All Config Details:" ,ex);
            throw new ConfigException(ConfigException.UNABLE_TO_FIND_DETAILS, HttpStatus.NOT_FOUND);
        }
        }

    @Override
    @PostConstruct
    public BaseListDto<ConfigDetailsDto> sendAllConfigList() throws ConfigException {
        BaseListDto<ConfigDetailsDto> configDetailsDtoList = new  BaseListDto();
      try{

            List<ConfigDetailsEntity> configDetailsEntity= configDetailsRepository.getConfigDetails();
            if(configDetailsEntity == null || configDetailsEntity.isEmpty()){
                throw new ConfigException(ConfigException.UNABLE_TO_FIND_DETAILS,HttpStatus.NOT_FOUND);
            }
            configDetailsDtoList.setDataList(configDetailsAssembler.entityListToDtoList(configDetailsEntity));
            for(ConfigDetailsDto dto : configDetailsDtoList.getDataList()) {
                masterDataKafkaSender.sendConfigIntoTopic(dto.getId(),dto.getKey(),configUtil.getValueForConfig(dto));
            }

        } catch (ConfigException ex) {
            throw ex;

        } catch (Exception ex) {
            LOG.error("Exception in findAll:", ex);

            throw new ConfigException(ConfigException.UNABLE_TO_FIND_DETAILS,HttpStatus.NOT_FOUND);
        }
        return configDetailsDtoList;
    }


    @Override
    public BaseListDto<ConfigResponse> getConfigValues(boolean isGuest)
    {
        BaseListDto<ConfigResponse> list= new BaseListDto<>();
        List<ConfigDetailsEntity> configDetailsEntity = null;
        List<ConfigDetailsDto> configDetailsDtos;
        List<ConfigResponse> configList= new ArrayList<>();;
        String name="";
        try{
                if(isGuest){
                    configDetailsEntity = configDetailsRepository.getDetailsBySendToUiAndGuest();
                } else {
                    configDetailsEntity = configDetailsRepository.getDetailsBySendToUi();
                }
                configDetailsDtos=configDetailsAssembler.entityListToDtoList(configDetailsEntity);
                for(ConfigDetailsDto dto: configDetailsDtos )
                {
                    ConfigResponse configDto= new ConfigResponse();
                    name = configUtil.getValueForConfig(dto);
                    configDto.setKey(dto.getKey());
                    configDto.setValue(name);
                    configList.add(configDto);
                }
                list.setDataList(configList);
                if(configDetailsEntity == null || configDetailsEntity.isEmpty())
                {
                     throw new ConfigException(ConfigException.UNABLE_TO_FIND_DETAILS,HttpStatus.NOT_FOUND);
                }
        }
        catch (ConfigException ex) {
            throw ex;

        } catch (Exception ex) {
            LOG.error("Exception in findAll By isSendToUi:", ex);

            throw new ConfigException(ConfigException.UNABLE_TO_FIND_DETAILS,HttpStatus.NOT_FOUND);
        }
        return list;
    }
}

