package com.imss.rc.config.repository;

import com.imss.rc.config.assembler.ConfigGroupAssembler;
import com.imss.rc.config.dto.ConfigGroupDto;
import com.imss.rc.config.entity.ConfigGroupEntity;
import com.imss.rc.config.exception.ConfigException;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
@Transactional
public interface ConfigGroupRepository extends JpaRepository<ConfigGroupEntity,Integer> {

    default PageableEntity<ConfigGroupEntity> getAllConfigGroupsWithFilters(EntityManager em, ConfigGroupDto configGroupDto) throws ConfigException {

        PageableEntity<ConfigGroupEntity> retData = new PageableEntity<>();

        List<Predicate> predicateList = new ArrayList<>();
        CriteriaBuilder criteriaBuilder ;
        Root<ConfigGroupEntity> configGroupEntityRoot ;

        /** This is to get the count of records */
        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        configGroupEntityRoot = countQuery.from(ConfigGroupEntity.class);

        predicateList = applySearchFilters(criteriaBuilder, predicateList, configGroupEntityRoot, configGroupDto);

        countQuery.select(criteriaBuilder.count(configGroupEntityRoot));
        countQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));
        long count = em.createQuery(countQuery).getSingleResult();
        retData.setCount(count);
        /***********************************/


        /** This is to get the list based on the page and limit *******/

        //Clear out the predicateList created using the count root
        predicateList.clear();

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<ConfigGroupEntity> listCriteriaQuery = criteriaBuilder.createQuery(ConfigGroupEntity.class);

        configGroupEntityRoot = listCriteriaQuery.from(ConfigGroupEntity.class);

        listCriteriaQuery.select(configGroupEntityRoot);
        predicateList = applySearchFilters(criteriaBuilder, predicateList, configGroupEntityRoot, configGroupDto);

        listCriteriaQuery.where( criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));

        String sortByColumn = ConfigGroupAssembler.getSortByColumn(configGroupDto.getPagination().getSortBy());

        Order order;
        if("asc".equals( configGroupDto.getPagination().getSortType())){
            order = criteriaBuilder.asc(configGroupEntityRoot.get(sortByColumn));
        } else {
            order = criteriaBuilder.desc(configGroupEntityRoot.get(sortByColumn));
        }

        TypedQuery<ConfigGroupEntity> query = em.createQuery(listCriteriaQuery.orderBy(order))
                .setFirstResult((configGroupDto.getPagination().getPage() - 1) * configGroupDto.getPagination().getLimit())
                .setMaxResults(configGroupDto.getPagination().getLimit());
        retData.setData(query.getResultList());
        /***********************************/


        return retData;
    }


    default List<Predicate> applySearchFilters(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Root<ConfigGroupEntity> configGroupEntityRoot,
                                               ConfigGroupDto configGroupDto) throws ConfigException {

        //Adding filter for name if present
        if (Optional.ofNullable(configGroupDto.getName()).isPresent() && !configGroupDto.getName().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.like(criteriaBuilder.upper(configGroupEntityRoot.get(ConfigGroupEntity.COLUMN_NAME_CONFIG_NAME)), "%"+configGroupDto.getName().toUpperCase()+"%"));
        }

        //Adding filter for category Id if present
        if (Optional.ofNullable(configGroupDto.getCategoryId()).isPresent() && configGroupDto.getCategoryId()!= GlobalYesNoEnum.NO.getValue()) {
            predicateList.add(criteriaBuilder.equal(configGroupEntityRoot.get(ConfigGroupEntity.COLUMN_NAME_CATEGORY_ID), configGroupDto.getCategoryId()));
        }

        return predicateList;
    }


}
