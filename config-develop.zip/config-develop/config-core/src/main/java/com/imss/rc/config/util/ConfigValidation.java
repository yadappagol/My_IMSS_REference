package com.imss.rc.config.util;

import com.imss.rc.config.exception.ConfigException;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Objects;

import static com.imss.rc.config.util.AuditConstants.*;

@Component
public class ConfigValidation
{
    public boolean validateMinLength(int length,int minLength) throws ConfigException {
        if(minLength<=length){
            return true;
        }
        throw new ConfigException(ConfigException.MIN_LENGTH_VALIDATION_FAILED,new Integer[]{minLength,length},HttpStatus.BAD_REQUEST) ;
    }

    public boolean validateMaxLength(int length,int maxLength) throws ConfigException {
        if(maxLength>=length){
            return true;
        }
        throw new ConfigException(ConfigException.MAX_LENGTH_VALIDATION_FAILED,new Integer[]{maxLength,length},HttpStatus.BAD_REQUEST) ;
    }

    public boolean validateRegex(String value,String regex) throws ConfigException {
        if(value.matches(regex)){
            return true;
        }
        throw new ConfigException(ConfigException.REGEX_VALIDATION_FAILED,HttpStatus.BAD_REQUEST) ;
    }

    public boolean validateDataType(Integer fieldType,String value) throws ConfigException {

        if(DataType.FIELD_TYPE_STRING == fieldType){
           if (value instanceof String){
               if(value.equalsIgnoreCase(BOOLEAN_TRUE)|| value.equalsIgnoreCase(BOOLEAN_FALSE)){
                   throw new ConfigException(ConfigException.STRING_VALIDATION_FAILED,HttpStatus.BAD_REQUEST) ;
               }
               return true;
           }
            throw new ConfigException(ConfigException.STRING_VALIDATION_FAILED,HttpStatus.BAD_REQUEST) ;
        }
       else if(DataType.FIELD_TYPE_NUMBER == fieldType){
            if(value.matches(NUM_REGEX)) {
                return true;
            }
            throw new ConfigException(ConfigException.NUMERIC_VALIDATION_FAILED,HttpStatus.BAD_REQUEST) ;
        }
       else  if(DataType.FIELD_TYPE_DATE == fieldType){
            DateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
            sdf.setLenient(false);
            try {
                sdf.parse(value);
                return true;
            }
            catch(Exception ex){
                throw new ConfigException(ConfigException.DATE_VALIDATION_FAILED, new String[]{DATE_FORMAT, value}, HttpStatus.BAD_REQUEST) ;
            }
        }
        else  if(DataType.FIELD_TYPE_DATE_AND_TIME == fieldType){
            DateFormat sdf = new SimpleDateFormat(DATE_TIME_FORMAT);
            sdf.setLenient(false);
            try {
               sdf.parse(value);
                return true;
            } catch (ParseException e) {
                throw new ConfigException(ConfigException.DATE_AND_TIME_VALIDATION_FAILED,new String[]{DATE_TIME_FORMAT,value},HttpStatus.BAD_REQUEST) ;
            }

        }
      else if(DataType.FIELD_TYPE_BOOLEAN == fieldType){
          if(value.equalsIgnoreCase(BOOLEAN_TRUE)|| value.equalsIgnoreCase(BOOLEAN_FALSE)){
              return true;
          }
            throw new ConfigException(ConfigException.BOOLEAN_VALIDATION_FAILED,HttpStatus.BAD_REQUEST) ;
        } else if(DataType.FIELD_TYPE_RADIO == fieldType){
            //TODO: Write logic to validate
            return true;
        } else if(DataType.FIELD_TYPE_CHECKBOX == fieldType){
            //TODO: Write logic to validate
            return true;
        } else if(DataType.FIELD_TYPE_PASSWORD == fieldType){
            //TODO: Write logic to validate
            return true;
        } else if(DataType.FIELD_TYPE_DROPDOWN == fieldType){
            //TODO: Write logic to validate
            return true;
        } else if(DataType.FIELD_TYPE_RICH_TEXT == fieldType){
            try {
                String textValue=Jsoup.parse(value).text();
                if(StringUtils.isBlank(textValue)){
                    throw new ConfigException(ConfigException.VALUE_REQUIRED,HttpStatus.BAD_REQUEST) ;
                }
                if (!value.equals(Jsoup.parse(value).text())) {
                  Jsoup.parse(value).text();
                  return true;
                }
                throw new ConfigException(ConfigException.RICH_TEXT_VALIDATION_FAILED,HttpStatus.BAD_REQUEST) ;
            } catch (ConfigException e) {
                throw new ConfigException(ConfigException.RICH_TEXT_VALIDATION_FAILED,HttpStatus.BAD_REQUEST) ;
            }
        }else {
            throw new ConfigException(ConfigException.UNKNOWN_DATATYPE, HttpStatus.BAD_REQUEST);
        }

    }

    public boolean validateValue(String value) {
        if(StringUtils.isNotBlank(value)||Objects.nonNull(value)){
            return true;
        }
        throw new ConfigException(ConfigException.MANDATORY_FIELD_VALUE,HttpStatus.BAD_REQUEST) ;
    }
}

