package com.imss.rc.config.service;

import com.imss.rc.config.dto.ConfigDetailsDto;
import com.imss.rc.config.dto.ConfigResponse;
import com.imss.rc.config.exception.ConfigException;
import com.imss.rc.commons.dto.BaseListDto;

public interface ConfigService {

  public BaseListDto<ConfigDetailsDto> getConfigDetails(ConfigDetailsDto dto) throws ConfigException;

  public BaseListDto<ConfigDetailsDto> sendAllConfigList() throws ConfigException;

  public BaseListDto<ConfigResponse> getConfigValues(boolean isGuest) throws ConfigException;
}
