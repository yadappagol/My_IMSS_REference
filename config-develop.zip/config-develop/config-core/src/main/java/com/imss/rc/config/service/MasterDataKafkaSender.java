package com.imss.rc.config.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class MasterDataKafkaSender
{
    private static final Logger LOGGER = LoggerFactory.getLogger(MasterDataKafkaSender.class);

    @Autowired
    @Qualifier("configCacheProducerTemplate")
    public  KafkaTemplate<String, Object> kafkaTemplate;

    @Value("${kafka.rc.config.cache.response.topic}")
    private String topicName;

    public void sendConfigIntoTopic(Integer id, String key, String value){
        Map<String, String> dataToSend = new HashMap<>();
        dataToSend.put("type","config");
        dataToSend.put("id", String.valueOf(id));
        dataToSend.put("key", key);
        dataToSend.put("value", value);
        kafkaTemplate.send(topicName,dataToSend);
        LOGGER.info("Published Config : {} ",key);
    }

}
