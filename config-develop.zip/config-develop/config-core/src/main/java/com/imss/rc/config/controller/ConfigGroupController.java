package com.imss.rc.config.controller;

import com.imss.rc.config.dto.ConfigDetailsDto;
import com.imss.rc.config.dto.ConfigGroupDto;
import com.imss.rc.config.exception.ConfigException;
import com.imss.rc.commons.dto.BaseListDto;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

public interface ConfigGroupController {

    @GetMapping(value = "/config/groups",produces = "application/json")
    public @ResponseBody
    BaseListDto<ConfigGroupDto> getConfigGroups(@RequestParam Integer page,
                                                @RequestParam Integer limit,
                                                @RequestParam(required = false) String categoryId,
                                                @RequestParam(required = false) String name,
                                                @RequestParam(required = false) String sortBy,
                                                @RequestParam(required = false) String sortType,
                                                HttpServletRequest request) throws ConfigException;


    @PutMapping(value = "/configs/{id}", produces = "application/json")
    public ConfigDetailsDto updateConfigDetails(@PathVariable("id") Integer id, @RequestBody ConfigDetailsDto configDetailsDto, HttpServletRequest request) throws ConfigException;


    @PutMapping(value = "/configs", produces = "application/json")
    public BaseListDto<ConfigDetailsDto> updateMultipleConfigDetails( @RequestBody BaseListDto<ConfigDetailsDto> configDetailsList, HttpServletRequest request) throws ConfigException;

}
