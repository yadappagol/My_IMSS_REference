package com.imss.rc.config.service;

import com.imss.rc.config.exception.ConfigException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class MasterDataKafkaListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(MasterDataKafkaListener.class);

    @Autowired
    private ConfigServiceImpl configService;


    @KafkaListener(topics = "${kafka.rc.config.cache.request.topic}", containerFactory="configCacheCoreListenerFactory")
    public void consumeSubCategoryMasterList(String request) throws ConfigException {
         configService.sendAllConfigList();
        LOGGER.debug("Data - " + request+ " - received");

    }
}
