package com.imss.rc.config.util;

import com.imss.rc.config.exception.ConfigException;
import com.imss.rc.cdh.entity.CoreDataDetailsEntity;
import com.imss.rc.cdh.repository.CoreDataDetailsRepository;
import com.imss.rc.config.dto.ConfigDetailsDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class ConfigUtil {


    @Autowired
    CoreDataDetailsRepository coreDataDetailsRepository;

    public String getValueForConfig(ConfigDetailsDto dto)
    {
        if(dto.getDataType().intValue() == DataType.FIELD_TYPE_STRING ||
                dto.getDataType().intValue() == DataType.FIELD_TYPE_NUMBER ||
                dto.getDataType().intValue() == DataType.FIELD_TYPE_DATE ||
                dto.getDataType().intValue() == DataType.FIELD_TYPE_DATE_AND_TIME ||
                dto.getDataType().intValue() == DataType.FIELD_TYPE_PASSWORD ||
                dto.getDataType().intValue() == DataType.FIELD_TYPE_BOOLEAN||
                dto.getDataType().intValue() == DataType.FIELD_TYPE_RICH_TEXT
        ) {
            //directly return the value
            return dto.getValue();
        } else  if(dto.getDataType().intValue() == DataType.FIELD_TYPE_RADIO ||
                dto.getDataType().intValue() == DataType.FIELD_TYPE_DROPDOWN
        ) {
            //Get the value from core data details based on the selected id in the value
            Optional<CoreDataDetailsEntity> entity = coreDataDetailsRepository.findById(Integer.parseInt(dto.getValue()));
            if(entity.isPresent()){
                return entity.get().getName();
            } else {
                throw new ConfigException(ConfigException.UNKNOWN_MASTER_VALUE, HttpStatus.BAD_REQUEST);
            }

        } else if (dto.getDataType().intValue() == DataType.FIELD_TYPE_CHECKBOX ){

            //Get the value from core data details based on the selected comma separated value
            Optional<CoreDataDetailsEntity> entity ;
            StringBuilder actualValues = new StringBuilder();

            String configValue = dto.getValue();
            String[] configValues = configValue.split(",");
            for(String val : configValues){
                entity = coreDataDetailsRepository.findById(Integer.parseInt(val));
                if(entity.isPresent()){
                    actualValues.append(entity.get().getName()).append(",");
                } else {
                    throw new ConfigException(ConfigException.UNKNOWN_MASTER_VALUE,HttpStatus.BAD_REQUEST);
                }
            }
            return actualValues.toString();

        } else {
            throw new ConfigException(ConfigException.UNKNOWN_DATATYPE,HttpStatus.BAD_REQUEST);
        }
    }
}
