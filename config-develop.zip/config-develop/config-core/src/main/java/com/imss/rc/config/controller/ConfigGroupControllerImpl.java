package com.imss.rc.config.controller;

import com.imss.rc.config.dto.ConfigDetailsDto;
import com.imss.rc.config.dto.ConfigGroupDto;
import com.imss.rc.config.exception.ConfigException;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import com.imss.rc.config.service.ConfigGroupService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Objects;

@RestController
public class ConfigGroupControllerImpl implements ConfigGroupController {

    @Autowired
    ConfigGroupService configGroupService;

    private static final Logger LOG = LoggerFactory.getLogger(ConfigGroupControllerImpl.class);

    @Override
    public BaseListDto<ConfigGroupDto> getConfigGroups(Integer page, Integer limit, String categoryId, String name, String sortBy, String sortType, HttpServletRequest request) throws ConfigException {
        LOG.info("Get All Configs  : Received request: ");
        if (Objects.isNull(page)||page < GlobalYesNoEnum.YES.getValue()) {
            throw new ConfigException(ConfigException.INVALID_PAGE, HttpStatus.BAD_REQUEST);
        }
        if (Objects.isNull(limit) || limit < GlobalYesNoEnum.YES.getValue()) {
            throw new ConfigException(ConfigException.INVALID_LIMIT, HttpStatus.BAD_REQUEST);
        }
        String regex = "\\d+";
        ConfigGroupDto configGroupDto = new ConfigGroupDto();
        configGroupDto.setName(name);
        if(categoryId!=null) {
            if(!categoryId.matches(regex)){
                throw new ConfigException(ConfigException.WRONG_INPUT_CATEGORY_ID, HttpStatus.BAD_REQUEST);
            }
            configGroupDto.setCategoryId(Integer.valueOf(categoryId));
        }

        PaginationDto pageDto = new PaginationDto();
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);
        configGroupDto.setPagination(pageDto);
        UserAuthDataHandler.resolveAuthBaseData(configGroupDto, request);
        return configGroupService.getConfigGroups(configGroupDto);
    }

    @Override
    public ConfigDetailsDto updateConfigDetails(Integer id, ConfigDetailsDto configDetailsDto, HttpServletRequest request) throws ConfigException {
        LOG.info("Update Config details Received request: ");
        if(Objects.isNull(configDetailsDto.getRowVersion() )|| configDetailsDto.getRowVersion()< GlobalYesNoEnum.NO.getValue()){
            throw new ConfigException(ConfigException.MANDATORY_FIELD_ROW_VERSION, HttpStatus.BAD_REQUEST);
        }
        UserAuthDataHandler.resolveAuthBaseData(configDetailsDto, request);
        return configGroupService.updateConfigDetails(id,configDetailsDto);
    }

    @Override
    public BaseListDto<ConfigDetailsDto> updateMultipleConfigDetails( BaseListDto<ConfigDetailsDto> configDetailsList ,HttpServletRequest request) throws ConfigException {
        LOG.info("Update Multiple Config details Received request: ");

        UserAuthDataHandler.resolveAuthBaseData(configDetailsList, request);

        return configGroupService.updateMultipleConfigDetails(configDetailsList);
    }

}
