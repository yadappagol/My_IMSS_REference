
if [ $# != 6 ]
then
        echo 'USAGE : run_script.sh <iscreatedb> <istestdatarequired> <username> <password> <db> <host>' 
        echo 'example : run_script.sh true false test_user test123 testdb 172.16.2.22' 
else

        if [ $1 == true ]
        then
				echo 'Dropping all tables and constriants'
                PGPASSWORD=$4 psql -U $3 -h $6 -d $5 < 99_config_drop_all_tables.sql
                
				echo 'Creating table structures'
				PGPASSWORD=$4 psql -U $3 -h $6 -d $5 < 01_config_base_scripts.sql
                
				echo 'Creating all constraints'
				PGPASSWORD=$4 psql -U $3 -h $6 -d $5 < 02_config_base_constraints.sql
                
				echo 'Inserting all default data'
				PGPASSWORD=$4 psql -U $3 -h $6 -d $5 < 03_config_defaut_data.sql

				if [ $2 == true ]
				then
					echo 'Inserting test data'
					PGPASSWORD=$4 psql -U $3 -h $6 -d $5 < 98_config_test_defaut_data.sql
				else
					echo 'Skipping test data insertion'
				fi
        else
                echo 'Skipping creation of database'
        fi
fi
