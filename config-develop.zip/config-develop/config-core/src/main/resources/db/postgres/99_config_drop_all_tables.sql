ALTER TABLE core_data_details
    DROP CONSTRAINT core_data_details_type_id_fkey ;
			
ALTER TABLE config_group
    DROP CONSTRAINT config_group_category_id_fkey ;
			
ALTER TABLE config_details
    DROP CONSTRAINT config_details_group_id_fkey ;
			
	
DROP TABLE config_details;
DROP TABLE config_group;