insert into core_data_types (pk_id, core_key, name, description, additional_data, is_visible) values
(20,'config.field.types','Configuration Field Types', 'Various insurance field types', '',0);

insert into core_data_details (pk_id, type_id, name, description, is_editable,is_deleted,created_by,created_date,modified_by,modified_date,row_version) values
(2001, 20, 'String', 'Field type string', 0, 0, 'system',now(),'system',now(),1),
(2002, 20, 'Number', 'Field type number', 0, 0, 'system',now(),'system',now(),1),
(2003, 20, 'Date', 'Field type date', 0, 0, 'system',now(),'system',now(),1),
(2004, 20, 'Date & Time', 'Field type date & time', 0, 0, 'system',now(),'system',now(),1),
(2005, 20, 'Radio', 'Field type radio', 0, 0, 'system',now(),'system',now(),1),
(2006, 20, 'Checkbox', 'Field type checkbox', 0, 0, 'system',now(),'system',now(),1),
(2007, 20, 'Password', 'Field type password', 0, 0, 'system',now(),'system',now(),1),
(2008, 20, 'Dropdown', 'Field type dropdown', 0, 0, 'system',now(),'system',now(),1),
(2009, 20, 'Boolean', 'Field type boolean, used for Yes / No fields', 0, 0, 'system',now(),'system',now(),1),
(2010, 20, 'Rich Text', 'Used for displaying the rich text formatting control', 0, 0, 'system',now(),'system',now(),1);

