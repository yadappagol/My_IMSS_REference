ALTER TABLE config_details
    DROP FOREIGN KEY config_details_group_id_fkey ;
			
	
DROP TABLE config_details;
DROP TABLE config_group;