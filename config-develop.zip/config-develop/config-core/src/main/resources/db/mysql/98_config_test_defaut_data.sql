
insert into core_data_types (pk_id, core_key, name, description, additional_data, is_visible) values
(9090,'test.options','sample options for test', 'sample options for test', '',0),
(9091,'test.options','sample options for test', 'sample options for test', '',0);

insert into core_data_details (pk_id, type_id, name, description, is_editable, additional_data, is_deleted,created_by,created_date,modified_by,modified_date,row_version) values
(90901, 9090, 'Option1', '', 0, '',  0, 'system',now(),'system',now(),1),
(90902, 9090, 'Option2', '', 0, '',  0, 'system',now(),'system',now(),1);

insert into core_data_details (pk_id, type_id, name, description, is_editable, additional_data, is_deleted,created_by,created_date,modified_by,modified_date,row_version) values
(90911, 9091, 'Another Option1', '', 0, '',  0, 'system',now(),'system',now(),1),
(90912, 9091, 'Another Option2', '', 0, '',  0, 'system',now(),'system',now(),1);



insert into core_data_details (pk_id, type_id, name, description, is_editable,is_deleted,created_by,created_date,modified_by,modified_date,row_version)
values (1090, 10, 'Test Category', 'This is the category is for testing only', 0, 0, 'system',now(),'system',now(),1);


insert into config_group (pk_id, category_id, name, description, is_test_enabled, additional_data, display_order) values
(109001, 1090, 'Test Group', 'Test group', 0, '', 10),
(109002, 1090, 'Test Group Two', 'Test group', 0, '', 20);

insert into config_details (pk_id, group_id, config_key, config_value, name, description, uom, data_type, data_list_type_id, min_length, max_length, reg_exp, is_visible, is_editable, display_order, is_deleted, created_by,created_date,modified_by,modified_date,row_version,is_send_to_ui,is_send_to_guest_ui) values
(10900101, 109001, 'test.field.string', 'String vlaue', 'String Field' , 'String filed desc', '', 2001, 0, 1, 50, '', 1,1, 10, 0, 'system',now(),'system',now(),1,1,0),
(10900102, 109001, 'test.field.number', '123456', 'Number Field' , 'Number field desc', '', 2002, 0, 10, 50, '', 1,1, 20, 0, 'system',now(),'system',now(),1,1,0),
(10900103, 109001, 'test.field.date', '2021-04-28', 'Date Field' , 'date field desc', '', 2003, 0, 10, 10, '', 1,1, 30, 0, 'system',now(),'system',now(),1,1,0),
(10900104, 109001, 'test.field.datetime', '2021-04-28 19:30', 'Date Time Field' , 'Datetime field desc', '', 2004, 0, 19, 19, '', 1,1, 40, 0, 'system',now(),'system',now(),1,1,0),
(10900105, 109001, 'test.field.radio', '90902', 'Radio Field' , 'Radio field desc', '', 2005, 9090, 1, 50, '', 1,1, 50, 0, 'system',now(),'system',now(),1,1,0),
(10900106, 109001, 'test.field.checkbox', '4001,4002', 'Checkbox Field' , 'Checkbox field desc', '', 2006, 40, 1, 500, '', 1,1, 60, 0, 'system',now(),'system',now(),1,1,0),
(10900107, 109001, 'test.field.password', 'test@gmail.com', 'Password Field' , 'Password field box', '', 2007, 0, 4, 50, '', 1,1, 70, 0, 'system',now(),'system',now(),1,1,0),
(10900108, 109001, 'test.field.dropdown', '90902', 'Dropdown Field' , 'Dropdown field box', '', 2008, 9090, 1, 50, '', 1,1, 80, 0, 'system',now(),'system',now(),1,1,0),
(10900109, 109001, 'test.field.boolean', 'true', 'Boolean Field' , 'Boolean field box', '', 2009, 0, 1, 1, '', 1,1, 90, 0, 'system',now(),'system',now(),1,1,0),
(10900110, 109001, 'test.field.radio2', '90911', 'Radio Field 2' , 'Radio field 2 desc', '', 2005, 9091, 1, 50, '', 1,1, 100, 0, 'system',now(),'system',now(),1,1,0),
(10900111, 109001, 'test.field.checkbox2', '90901,90902', 'Checkbox Field ' , 'Checkbox field 2 desc', '', 2006, 9090, 1, 50, '', 1,1, 110, 0, 'system',now(),'system',now(),1,1,0),
(10900112, 109001, 'test.field.dropdown2', '90902', 'Dropdown Field ' , 'Dropdown field 2 box', '', 2008, 9091, 1, 500, '', 1,1, 120, 0, 'system',now(),'system',now(),1,1,0),
(10900113, 109001, 'test.field.rich.text', '<b>Bold Text</b> With <i>Italic Text</i>', 'Rich Text Field' , 'Rich text field one', '', 2010, 0, 1, 5000, '', 1,1, 120, 0, 'system',now(),'system',now(),1,1,0),
(10900114, 109001, 'test.field.rich.text2', '<b>Bold Text2</b> With <i>Italic Text2</i>', 'Rich Text Field' , 'Rich text field one', '', 2010, 0, 1, 5000, '', 1,1, 120, 0, 'system',now(),'system',now(),1,1,0),

(10900201, 109002, 'test.field.string2', 'String vlaue', 'String Field' , 'String filed desc', '', 2001, 0, 10, 50, '', 1,1, 10, 0, 'system',now(),'system',now(),1,1,0),
(10900202, 109002, 'test.field.number2', '123456', 'Number Field' , 'Number field desc', '', 2002, 0, 10, 50, '', 1,1, 20, 0, 'system',now(),'system',now(),1,1,0),
(10900203, 109002, 'test.field.date2', '04-02-2021', 'Date Field' , 'date field desc', '', 2003, 0, 10, 50, '', 1,1, 30, 0, 'system',now(),'system',now(),1,1,0),
(10900204, 109002, 'test.field.rich.text3', '<b>Bold Text3</b> With <i>Italic Text3</i>', 'Rich Text Field' , 'Rich text field one', '', 2010, 0, 1, 5000, '', 1,1, 120, 0, 'system',now(),'system',now(),1,1,0);
