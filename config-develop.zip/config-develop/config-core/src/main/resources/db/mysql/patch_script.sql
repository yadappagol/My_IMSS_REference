


ALTER TABLE config_details
    ADD is_send_to_ui integer;
