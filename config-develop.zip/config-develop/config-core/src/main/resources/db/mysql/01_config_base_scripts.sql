
CREATE TABLE config_group (
    pk_id int NOT NULL AUTO_INCREMENT,
    name varchar(255),
    description varchar(255),
    category_id int,
    is_test_enabled smallint,
    display_order smallint,
    additional_data varchar(255),
	CONSTRAINT config_group_pkey PRIMARY KEY (pk_id)
)ENGINE=InnoDB AUTO_INCREMENT=200000 DEFAULT CHARSET=utf8;

CREATE TABLE config_details (
    pk_id int NOT NULL AUTO_INCREMENT,
    group_id int,
    config_key varchar(255),
    config_value varchar(5000),
    name varchar(255),
    description varchar(255),
    uom varchar(255),
    data_type int,
    data_list_type_id int,
    min_length int,
    max_length int,
    reg_exp varchar(255),
    is_visible smallint,
    is_editable smallint,
    display_order smallint,
    is_deleted smallint,
    created_by varchar(255),
    created_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_by varchar(255),
    modified_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    row_version int	,
    is_send_to_ui int,
    is_send_to_guest_ui int,
	CONSTRAINT config_details_pkey PRIMARY KEY (pk_id)
)ENGINE=InnoDB AUTO_INCREMENT=20000000 DEFAULT CHARSET=utf8;