ALTER TABLE config_group
    ADD CONSTRAINT config_group_category_id_fkey 
		FOREIGN KEY(category_id) 
			REFERENCES core_data_details(pk_id);
			
ALTER TABLE config_details
    ADD CONSTRAINT config_details_group_id_fkey 
		FOREIGN KEY(group_id) 
			REFERENCES config_group(pk_id);