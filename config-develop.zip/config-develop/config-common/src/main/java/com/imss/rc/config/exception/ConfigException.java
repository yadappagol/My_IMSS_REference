/**
 * COPYRIGHT: Jakkur Technoparks Pvt. Ltd. (JTPL)
 * This software is the sole property of JTPL
 * and is protected by copyright law and international
 * treaty provisions. Unauthorized reproduction or
 * redistribution of this program, or any portion of
 * it may result in severe civil and criminal penalties
 * and will be prosecuted to the maximum extent possible
 * under the law. JTPL reserves all rights not
 * expressly granted. You may not reverse engineer, decompile,
 * or disassemble the software, except and only to the
 * extent that such activity is expressly permitted
 * by applicable law notwithstanding this limitation.
 * THIS SOFTWARE IS PROVIDED TO YOU "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
 * YOU ASSUME THE ENTIRE RISK AS TO THE ACCURACY
 * AND THE USE OF THIS SOFTWARE. JTPL SHALL NOT BE LIABLE FOR
 * ANY DAMAGES WHATSOEVER ARISING OUT OF THE USE OF OR INABILITY TO
 * USE THIS SOFTWARE, EVEN IF JTPL HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/
package com.imss.rc.config.exception;

import com.imss.rc.commons.exception.IMSSException;
import org.springframework.http.HttpStatus;

public class ConfigException extends IMSSException  {

    public static final String CONFIG_GROUPS_NOT_FOUND = "1001";
    public static final String UNABLE_TO_FIND_FIELDS = "1002";
    public static final String INVALID_ORDER_BY_COLUMN = "1003";
    public static final String UNABLE_TO_FIND_DETAILS = "1004";
    public static final String NAME_NOT_VALID = "1005";
    public static final String KEY_VALIDATION_FAILED ="1006" ;
    public static final String MAX_MIN_LENGTH_VALIDATION_FAILED = "1007";
    public static final String ERROR_OCCURRED = "1009";
    public static final String MIN_LENGTH_VALIDATION_FAILED = "1010";
    public static final String MAX_LENGTH_VALIDATION_FAILED ="1011" ;
    public static final String REGEX_VALIDATION_FAILED = "1012";
    public static final String DATA_LIST_VALIDATION_FAILED="1013";
    public static final String STRING_VALIDATION_FAILED = "1014";
    public static final String NUMERIC_VALIDATION_FAILED = "1015";
    public static final String DATE_VALIDATION_FAILED = "1016";
    public static final String DATE_AND_TIME_VALIDATION_FAILED ="1017" ;
    public static final String BOOLEAN_VALIDATION_FAILED ="1018";
    public static final String UNKNOWN_DATATYPE = "1019";
    public static final String UNABLE_TO_FIND_CONFIG_GROUPS ="1020" ;
    public static final String VALIDATION_FAILED = "1021";
    public static final String CONFIG_DETAILS_NOT_UPDATED = "1022";
    public static final String CONFIG_DETAILS_NOT_FOUND ="1023" ;
    public static final String CONFIG_DETAILS_NOT_EDITABLE = "1024";
    public static final String MESSAGE_NOT_SENT ="1025" ;
    public static final String DATA_TYPE_VALIDATION_FAILED = "1026";
    public static final String WRONG_INPUT_CATEGORY_ID = "1027";
    public static final String UNKNOWN_MASTER_VALUE = "1028";
    public static final String CONFIG_CACHE_NOT_INITIALIZED = "1029";
    public static final String MANDATORY_FIELD_ROW_VERSION = "1030";
    public static final String INVALID_PAGE = "1031";
    public static final String INVALID_LIMIT ="1032" ;
    public static final String RICH_TEXT_VALIDATION_FAILED = "1033";
    public static final String MANDATORY_FIELD_VALUE = "1034";
    public static final String VALUE_REQUIRED = "1035";

    public static final String MESSAGE_BUNDLE_NAME = "config_errors_messages";
    public static final String MODULE_CODE = "CFG";
    public static final String ERROR_CODE_PREFIX = "config.error.";


    public ConfigException(String code, Object[] args, Throwable cause, HttpStatus httpStatus) {
        super(code, args, cause,httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

    public ConfigException(String code, Object[] args,HttpStatus httpStatus) {
        super(code, args,httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

    public ConfigException(String code, Throwable cause,HttpStatus httpStatus) {
        super(code, cause,httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

    public ConfigException(String code,HttpStatus httpStatus) {
        super(code,httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

}
