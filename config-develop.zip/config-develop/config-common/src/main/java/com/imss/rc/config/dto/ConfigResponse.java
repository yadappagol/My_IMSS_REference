package com.imss.rc.config.dto;

import lombok.Data;

@Data
public class ConfigResponse
{
    private String key;
    private String value;
}
