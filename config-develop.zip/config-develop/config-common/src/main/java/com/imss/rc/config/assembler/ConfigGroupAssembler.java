package com.imss.rc.config.assembler;

import com.imss.rc.config.exception.ConfigException;
import com.imss.rc.commons.assembler.BaseAssembler;
import com.imss.rc.config.dto.ConfigGroupDto;
import com.imss.rc.config.entity.ConfigGroupEntity;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ConfigGroupAssembler {

    private static Map<String, String> sortByList;

    static {
        sortByList = new HashMap<>();
        sortByList.put("category",ConfigGroupEntity.COLUMN_NAME_CATEGORY_ID);
        sortByList.put("name",ConfigGroupEntity.COLUMN_NAME_CONFIG_NAME);
        sortByList.put("dispOrder",ConfigGroupEntity.COLUMN_NAME_DISPLAY_ORDER);
    }
    /**
     * Method to return the entity column variable name based on the sort by field value received from the ui
     * @param input The sort by field as received from the UI
     * @return The column variable name based on which the sorting should happen
     */
    public static String getSortByColumn(String input) throws ConfigException {
        return BaseAssembler.getSortByColumn(input, sortByList);
    }

    private static BaseAssembler<ConfigGroupDto, ConfigGroupEntity> getBaseAssembler(){
        return new BaseAssembler<>(ConfigGroupDto::new, ConfigGroupEntity::new);
    }

    /**
     * Method to convert ConfigGroupEntity entity object to ConfigGroupDto dto object
     * @param entity the entity object with the data
     * @return A new ConfigGroupDto object with the data from the entity object
     */
    public ConfigGroupDto entityToDto(ConfigGroupEntity entity){
        return getBaseAssembler().entityToDto(entity);
    }

    /**
     * Method to convert ConfigGroupDto dto object to ConfigGroupEntity entity object
     * @param dto the dto object with the data
     * @return A new ConfigGroupEntity entity object with the data from the dto object
     */
    public ConfigGroupEntity dtoToEntity(ConfigGroupDto dto){

        return getBaseAssembler().dtoToEntity(dto);
    }


    /**
     * Method to convert a list of ConfigGroupDto dto objects to a list of ConfigGroupEntity entity objects
     * @param entityList A list of ConfigGroupEntity entity objects
     * @return A new list of ConfigGroupDto dto objects
     */
    public List<ConfigGroupDto> entityListToDtoList(List<ConfigGroupEntity> entityList)
    {
        return getBaseAssembler().entityListToDtoList(entityList);
    }


    /**
     * Method to convert a list of ConfigGroupEntity entity objects to a list of ConfigGroupDto dto objects
     * @param dtoList A list of ConfigGroupDto dto objects
     * @return A new list of ConfigGroupEntity entity objects
     */
    public List<ConfigGroupEntity> dtoListToEntityList(List<ConfigGroupDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }
}
