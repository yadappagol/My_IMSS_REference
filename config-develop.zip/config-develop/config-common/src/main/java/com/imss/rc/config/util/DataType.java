package com.imss.rc.config.util;

public final class DataType {

    private DataType(){

    }

    public static final int FIELD_TYPE_STRING = 2001;

    public static final int FIELD_TYPE_NUMBER = 2002;

    public static final int FIELD_TYPE_DATE = 2003;

    public static final int FIELD_TYPE_DATE_AND_TIME = 2004;

    public static final int FIELD_TYPE_RADIO = 2005;

    public static final int FIELD_TYPE_CHECKBOX = 2006;

    public static final int FIELD_TYPE_PASSWORD = 2007;

    public static final int FIELD_TYPE_DROPDOWN = 2008;

    public static final int FIELD_TYPE_BOOLEAN = 2009;

    public static final int FIELD_TYPE_RICH_TEXT = 2010;

}
