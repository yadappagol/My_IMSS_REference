package com.imss.rc.config.util;

public class AuditConstants
{

    public static final String VIEW_ALL_CONFIG_GROUPS = "Retrieved page %s with limit of %s records of configuration groups list sorted by %s in %s order, total of %s records were found.";
    public static final String UPDATED_CONFIG_DETAILS = "Updated configuration details of '%s'.";


    public static final String NUM_REGEX = "\\d+";
    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd hh:mm:ss";
    public static final String BOOLEAN_TRUE = "true";
    public static final String BOOLEAN_FALSE = "false";

    private AuditConstants(){
    }
}
