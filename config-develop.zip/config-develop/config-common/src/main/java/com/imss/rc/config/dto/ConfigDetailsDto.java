package com.imss.rc.config.dto;

import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.PaginationDto;
import lombok.Data;

@Data
public class ConfigDetailsDto  extends BaseDto {

    private String groupName;
    private int groupId;
    private String key;
    private String value;
    private String name;
    private String description;
    private String uom;
    private Integer  dataType;
    private int dataListTypeId;
    private int minLength;
    private int maxLength;
    private String regExp;
    private int isVisible;
    private int isEditable;
    private int displayOrder;
    private int isSendToUi;
    private int isSendToGuestUi;

    private PaginationDto paginationDto;


}
