package com.imss.rc.config.entity;

import com.imss.rc.commons.entity.BaseEntity;
import lombok.Data;
import lombok.ToString;
import javax.persistence.*;

@Entity
@Data
@Table(name="config_details")
@ToString(exclude = {"groupIdObj"})
public class ConfigDetailsEntity extends BaseEntity {

    public static final String COLUMN_NAME_GROUP_ID = "groupId";
    public static final String COLUMN_NAME_BY_NAME = "name";
    public static final String COLUMN_NAME_DISPLAY_ORDER = "displayOrder";

    @ManyToOne(targetEntity = ConfigGroupEntity.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "group_id", referencedColumnName = "pk_id", insertable = false, updatable = false)
    private ConfigGroupEntity groupIdObj;

    @Column(name="group_id")
    private int groupId;

    @Column(name="config_key")
    private String key;

    @Column(name = "config_value")
    private String value;

    @Column(name = "name")
    private String name;

    @Column(name="description")
    private String description;

    @Column(name ="uom")
    private String uom;

    @Column(name="data_type")
    private Integer  dataType;

    @Column(name="data_list_type_id")
    private int dataListTypeId;

    @Column(name="min_length")
    private int minLength;

    @Column(name="max_length")
    private int maxLength;

    @Column(name="reg_exp")
    private String regExp;

    @Column(name="is_visible")
    private int isVisible;

    @Column(name="is_editable")
    private int isEditable;

    @Column(name="display_order")
    private int displayOrder;

    @Column(name="is_send_to_ui")
    private int isSendToUi;

    @Column(name="is_send_to_guest_ui")
    private int isSendToGuestUi;

}
