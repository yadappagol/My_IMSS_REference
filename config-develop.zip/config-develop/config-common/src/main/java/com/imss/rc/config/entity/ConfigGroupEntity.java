package com.imss.rc.config.entity;

import com.imss.rc.commons.entity.IdEntity;
import lombok.Data;

import javax.persistence.*;


@Entity
@Data
@Table(name="config_group")
public class ConfigGroupEntity extends IdEntity {

    public static final String COLUMN_NAME_CATEGORY_ID ="categoryId" ;
    public static final String COLUMN_NAME_CONFIG_NAME = "name";
    public static final String COLUMN_NAME_DISPLAY_ORDER = "displayOrder";

    @Column(name="category_id")
    private int categoryId;

    @Column(name="name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name="is_test_enabled")
    private int isTestEnabled;

    @Column(name="additional_data")
    private String  additionalData;

    @Column(name="display_order")
    private int displayOrder;
}
