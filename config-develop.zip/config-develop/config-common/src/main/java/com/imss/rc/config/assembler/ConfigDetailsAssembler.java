package com.imss.rc.config.assembler;

import com.imss.rc.config.entity.ConfigDetailsEntity;
import com.imss.rc.config.exception.ConfigException;
import com.imss.rc.commons.assembler.BaseAssembler;
import com.imss.rc.config.dto.ConfigDetailsDto;
import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ConfigDetailsAssembler {


    private static Map<String, String> sortByList;

    static {
        sortByList = new HashMap<>();
        sortByList.put("name", ConfigDetailsEntity.COLUMN_NAME_BY_NAME);
        sortByList.put("groupId",ConfigDetailsEntity.COLUMN_NAME_GROUP_ID);
        sortByList.put("dispOrder", ConfigDetailsEntity.COLUMN_NAME_DISPLAY_ORDER);
    }
    private static BaseAssembler<ConfigDetailsDto, ConfigDetailsEntity> getBaseAssembler(){
        return new BaseAssembler<>(ConfigDetailsDto::new, ConfigDetailsEntity::new);
    }

    /**
     * Method to convert ConfigDetailsEntity entity object to ConfigDetailsDto dto object
     * @param entity the entity object with the data
     * @return A new ConfigDetailsDto object with the data from the entity object
     */
    public ConfigDetailsDto entityToDto(ConfigDetailsEntity entity){
        return getBaseAssembler().entityToDto(entity);
    }

    /**
     * Method to convert ConfigDetailsDto dto object to ConfigDetailsEntity entity object
     * @param dto the dto object with the data
     * @return A new ConfigDetailsEntity entity object with the data from the dto object
     */
    public ConfigDetailsEntity dtoToEntity(ConfigDetailsDto dto){

        return getBaseAssembler().dtoToEntity(dto);
    }


    /**
     * Method to convert a list of ConfigDetailsDto dto objects to a list of ConfigDetailsEntity entity objects
     * @param entityList A list of ConfigDetailsEntity entity objects
     * @return A new list of ConfigDetailsDto dto objects
     */
    public List<ConfigDetailsDto> entityListToDtoList(List<ConfigDetailsEntity> entityList)
    {
        ArrayList<ConfigDetailsDto> dtoList = new ArrayList();
        entityList.stream().forEach((k) -> {
                    ConfigDetailsDto dto = this.entityToDto(k);
                    if(k.getGroupIdObj()!= null && Hibernate.isInitialized(k.getGroupIdObj())){
                        dto.setGroupName(k.getGroupIdObj().getName());
                    }
            dtoList.add(dto);
        });
        return dtoList;
    }


    /**
     * Method to convert a list of ConfigDetailsEntity entity objects to a list of ConfigDetailsDto dto objects
     * @param dtoList A list of ConfigDetailsDto dto objects
     * @return A new list of ConfigDetailsEntity entity objects
     */
    public List<ConfigDetailsEntity> dtoListToEntityList(List<ConfigDetailsDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }

    public static String getSortByColumn(String input) throws ConfigException {
        return BaseAssembler.getSortByColumn(input, sortByList);
    }
}
