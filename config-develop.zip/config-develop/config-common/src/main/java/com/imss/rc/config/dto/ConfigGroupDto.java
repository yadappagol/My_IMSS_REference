package com.imss.rc.config.dto;

import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.PaginationDto;
import lombok.Data;

@Data
public class ConfigGroupDto extends BaseDto {

    private int categoryId;
    private String name;
    private String description;
    private int isTestEnabled;
    private int displayOrder;
    private String  additionalData;
    private PaginationDto pagination;

}
