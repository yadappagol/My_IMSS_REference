package com.imss.rc.config.enums;

public enum ConfigurationTypeEnum {
    NOTIFY_EMAIL_SUBJECT_PREFIX("notify.email.sub.prefix"),
    NOTIFY_EMAIL_TEMPLATE("notify.email.template"),
    NOTIFY_SMTP_EMAIL("notify.smtp.email"),
    NOTIFY_SMTP_HOST("notify.smtp.host"),
    NOTIFY_SMTP_PASSWORD("notify.smtp.password"),
    NOTIFY_SMTP_PORT("notify.smtp.port"),
    NOTIFY_SMTP_IS_SSL_ENABLED("notify.smtp.is.ssl"),
    NOTIFY_SMTP_IS_AUTH_ENABLED("notify.smtp.is.auth"),
    NOTIFY_SMS_URL("notify.sms.url"),
    NOTIFY_SMS_API_KEY("notify.sms.key"),
    NOTIFY_SMS_NUMBER_PLACEHOLDER("notify.sms.num.rep") ,
    NOTIFY_SMS_API_PLACEHOLDER("notify.sms.api.rep") ,
    NOTIFY_SMS_MESSAGE_PLACEHOLDER("notify.sms.msg.rep"),
    GENERAL_DATE_FORMAT("gen.date.format"),
    GENERAL_DATE_TIME_FORMAT("gen.datetime.format"),
    GENERAL_UI_LANGUAGE("gen.ui.language"),
    GENERAL_PORTAL_NAME("gen.portal.name") ,
    GENERAL_RECORDS_PER_PAGE("gen.rec.per.page"),
    GENERAL_UI_BASE_URL("gen.ui.base.url"),
    GENERAL_OTP_RESEND_TIME("gen.otp.resent.time"),
    GENERAL_FILE_MAX_SIZE("gen.file.max.size"),
    GENERAL_FILE_ALLOWED_FORMATS("gen.file.allowed.formats"),
    /**
     * @Deprecated This will be removed in the future versions. Use AUTH_PASSWORD_POLICY_EXPRESSION instead
     */
    @Deprecated
    GENERAL_PASSWORD_POLICY_EXPRESSION("gen.password.policy") ,
    AUTH_PASSWORD_POLICY_EXPRESSION("gen.password.policy") ,
    /**
     * @Deprecated This will be removed in the future versions. Use AUTH_PASSWORD_POLICY_DESCRIPTION instead
     */
    @Deprecated
    GENERAL_PASSWORD_POLICY_DESCRIPTION("gen.password.policy.desc"),
    AUTH_PASSWORD_POLICY_DESCRIPTION("gen.password.policy.desc"),
    /**
     * @Deprecated This will be removed in the future versions. Use AUTH_PASSWORD_TOKEN_EXPIRY instead
     */
    @Deprecated
    GENERAL_PASSWORD_TOKEN_EXPIRY("gen.password.token.expiry"),
    GENERAL_PROFILE_IMAGE_MAX_SIZE("gen.image.max.size"),
    AUTH_PASSWORD_TOKEN_EXPIRY("gen.password.token.expiry"),
    AUTH_SHORT_TOKEN_LENGTH("auth.short.token.length"),
    AUTH_SHORT_TOKEN_EXPIRY("auth.short.token.expiry"),
    AUTH_SIGNUP_GEO_FENCE("signup.geo.fence");

    private final String key;

    ConfigurationTypeEnum( final String newKey)
    {
        this.key =  newKey;
    }
    public String getKey()
    {
        return key;
    }
}
