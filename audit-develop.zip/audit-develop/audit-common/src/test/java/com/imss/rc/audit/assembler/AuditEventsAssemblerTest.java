package com.imss.rc.audit.assembler;

import com.imss.rc.audit.constants.Constants;
import com.imss.rc.audit.dto.AuditEventsDto;
import com.imss.rc.audit.entity.AuditEventsEntity;
import com.imss.rc.audit.util.AuditTestConstants;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Date;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(PowerMockRunner.class)
public class AuditEventsAssemblerTest {

    @InjectMocks
    private  AuditEventsAssembler  assembler;

    @Test
    public void testA03DtoListToEntityList() {
        ArrayList<AuditEventsDto> dtoList = new ArrayList<>();

        dtoList.add(getDto());

        ArrayList<AuditEventsEntity> entityList = (ArrayList) assembler.dtoListToEntityList(dtoList);

        int index = 0;
        for (AuditEventsEntity entity : entityList) {


            Assert.assertEquals(AuditTestConstants.CHECK_DELETE, entity.getIsDeleted(), dtoList.get(index).getIsDeleted());
            Assert.assertEquals(AuditTestConstants.CHECK_ARCHIVE_IN, entity.getArchiveIn(), dtoList.get(index).getArchiveIn());
            Assert.assertEquals(AuditTestConstants.CHECK_DESCRIPTION, entity.getDescription(), dtoList.get(index).getDescription());
            Assert.assertEquals(AuditTestConstants.CHECK_IS_ENABLED, entity.getIsEnabled(), dtoList.get(index).getIsEnabled());
            Assert.assertEquals(AuditTestConstants.CHECK_NAME, entity.getName(), dtoList.get(index).getName());
            Assert.assertEquals(AuditTestConstants.CHECK_PURGE_IN, entity.getPurgeIn(), dtoList.get(index).getPurgeIn());
            Assert.assertEquals(AuditTestConstants.CHECK_CREATED_BY, entity.getCreatedBy(), dtoList.get(index).getCreatedBy());
            Assert.assertEquals(AuditTestConstants.CHECK_CREATED_DATE, entity.getCreatedDate(), dtoList.get(index).getCreatedDate());
            Assert.assertEquals(AuditTestConstants.CHECK_ID, entity.getId(), dtoList.get(index).getId());
            Assert.assertEquals(AuditTestConstants.CHECK_MODIFIED_BY, entity.getModifiedBy(), dtoList.get(index).getModifiedBy());
            Assert.assertEquals(AuditTestConstants.CHECK_MODIFIED_DATE, entity.getModifiedDate(), dtoList.get(index).getModifiedDate());
            Assert.assertEquals(AuditTestConstants.CHECK_ROW_VERSION, entity.getRowVersion(), dtoList.get(index).getRowVersion());


            index++;
        }
    }
    @Test
    public void testA04EntityListToDtoList() {
        ArrayList<AuditEventsEntity> entityList = new ArrayList<>();

        entityList.add(getEntity());


        ArrayList<AuditEventsDto> dtoList = (ArrayList)assembler.entityListToDtoList(entityList);

        int index= 0;
        for (AuditEventsDto dto : dtoList) {

            Assert.assertEquals(AuditTestConstants.CHECK_DELETE, dto.getIsDeleted(), entityList.get(index).getIsDeleted());
            Assert.assertEquals(AuditTestConstants.CHECK_ARCHIVE_IN, dto.getArchiveIn(), entityList.get(index).getArchiveIn());
            Assert.assertEquals(AuditTestConstants.CHECK_DESCRIPTION, dto.getDescription(), entityList.get(index).getDescription());
            Assert.assertEquals(AuditTestConstants.CHECK_IS_ENABLED ,dto.getIsEnabled(), entityList.get(index).getIsEnabled());
            Assert.assertEquals(AuditTestConstants.CHECK_NAME, dto.getName(), entityList.get(index).getName());
            Assert.assertEquals(AuditTestConstants.CHECK_PURGE_IN, dto.getPurgeIn(), entityList.get(index).getPurgeIn());
            Assert.assertEquals(AuditTestConstants.CHECK_CREATED_BY, dto.getCreatedBy(), entityList.get(index).getCreatedBy());
            Assert.assertEquals(AuditTestConstants.CHECK_CREATED_DATE, dto.getCreatedDate(), entityList.get(index).getCreatedDate());
            Assert.assertEquals(AuditTestConstants.CHECK_ID, dto.getId(), entityList.get(index).getId());
            Assert.assertEquals(AuditTestConstants.CHECK_MODIFIED_BY, dto.getModifiedBy(), entityList.get(index).getModifiedBy());
            Assert.assertEquals(AuditTestConstants.CHECK_MODIFIED_DATE, dto.getModifiedDate(), entityList.get(index).getModifiedDate());
            Assert.assertEquals(AuditTestConstants.CHECK_ROW_VERSION, dto.getRowVersion(), entityList.get(index).getRowVersion());

            index++;
        }
    }

    @Test
    public void testA01EntityToDto() {
        AuditEventsEntity entity = getEntity();
        AuditEventsDto dto = assembler.entityToDto(entity);


        Assert.assertEquals(AuditTestConstants.CHECK_DELETE, entity.getIsDeleted(), dto.getIsDeleted());
        Assert.assertEquals(AuditTestConstants.CHECK_ARCHIVE_IN, entity.getArchiveIn(), dto.getArchiveIn());
        Assert.assertEquals(AuditTestConstants.CHECK_DESCRIPTION, entity.getDescription(), dto.getDescription());
        Assert.assertEquals(AuditTestConstants.CHECK_IS_ENABLED, entity.getIsEnabled(), dto.getIsEnabled());
        Assert.assertEquals(AuditTestConstants.CHECK_NAME, entity.getName(), dto.getName());
        Assert.assertEquals(AuditTestConstants.CHECK_PURGE_IN, entity.getPurgeIn(), dto.getPurgeIn());
        Assert.assertEquals(AuditTestConstants.CHECK_CREATED_BY, entity.getCreatedBy(), dto.getCreatedBy());
        Assert.assertEquals(AuditTestConstants.CHECK_CREATED_DATE, entity.getCreatedDate(), dto.getCreatedDate());
        Assert.assertEquals(AuditTestConstants.CHECK_ID, entity.getId(), dto.getId());
        Assert.assertEquals(AuditTestConstants.CHECK_MODIFIED_BY, entity.getModifiedBy(), dto.getModifiedBy());
        Assert.assertEquals(AuditTestConstants.CHECK_MODIFIED_DATE, entity.getModifiedDate(), dto.getModifiedDate());
        Assert.assertEquals(AuditTestConstants.CHECK_ROW_VERSION, entity.getRowVersion(), dto.getRowVersion());


    }

    @Test
    public void testA02DtoToEntity() {
        AuditEventsDto dto = getDto();
        AuditEventsEntity entity = assembler.dtoToEntity(dto);

        Assert.assertEquals(AuditTestConstants.CHECK_DELETE, dto.getIsDeleted(), entity.getIsDeleted());
        Assert.assertEquals(AuditTestConstants.CHECK_ARCHIVE_IN, dto.getArchiveIn(), entity.getArchiveIn());
        Assert.assertEquals(AuditTestConstants.CHECK_DESCRIPTION, dto.getDescription(), entity.getDescription());
        Assert.assertEquals(AuditTestConstants.CHECK_IS_ENABLED, dto.getIsEnabled(), entity.getIsEnabled());
        Assert.assertEquals(AuditTestConstants.CHECK_NAME, dto.getName(), entity.getName());
        Assert.assertEquals(AuditTestConstants.CHECK_PURGE_IN, dto.getPurgeIn(), entity.getPurgeIn());
        Assert.assertEquals(AuditTestConstants.CHECK_CREATED_BY, dto.getCreatedBy(), entity.getCreatedBy());
        Assert.assertEquals(AuditTestConstants.CHECK_CREATED_DATE, dto.getCreatedDate(), entity.getCreatedDate());
        Assert.assertEquals(AuditTestConstants.CHECK_IS_ENABLED, dto.getId(), entity.getId());
        Assert.assertEquals(AuditTestConstants.CHECK_MODIFIED_BY, dto.getModifiedBy(), entity.getModifiedBy());
        Assert.assertEquals(AuditTestConstants.CHECK_MODIFIED_DATE, dto.getModifiedDate(), entity.getModifiedDate());
        Assert.assertEquals(AuditTestConstants.CHECK_ROW_VERSION, dto.getRowVersion(), entity.getRowVersion());
    }


    private AuditEventsEntity getEntity() {
        AuditEventsEntity entity = new AuditEventsEntity();

        entity.setIsDeleted((short)0);
        entity.setArchiveIn(100);
        entity.setDescription("R1");
        entity.setIsEnabled((short) 1);
        entity.setName("User Registration");
        entity.setPurgeIn(365);
        entity.setCreatedBy(Constants.ROLE);
        entity.setCreatedDate(new Date(System.currentTimeMillis()));
        entity.setId(1000001);
        entity.setIsDeleted((short)0);
        entity.setModifiedBy(Constants.ROLE);
        entity.setModifiedDate(new Date(System.currentTimeMillis()));
        entity.setRowVersion(1);

        return entity;
    }


    private AuditEventsDto getDto() {
        AuditEventsDto dto = new AuditEventsDto();

        dto.setIsDeleted((short)0);
        dto.setArchiveIn(100);
        dto.setDescription("R1");
        dto.setIsEnabled((short)1);
        dto.setName("User Registration");
        dto.setPurgeIn(365);
        dto.setCreatedBy(Constants.ROLE);
        dto.setCreatedDate(new Date(System.currentTimeMillis()));
        dto.setId(1000001);
        dto.setIsDeleted((short)0);
        dto.setModifiedBy(Constants.ROLE);
        dto.setModifiedDate(new Date(System.currentTimeMillis()));
        dto.setRowVersion(1);

        return dto;
    }

}
