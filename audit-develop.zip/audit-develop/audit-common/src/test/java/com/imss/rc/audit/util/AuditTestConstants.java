package com.imss.rc.audit.util;

public class AuditTestConstants {

    public static final String CHECK_DESCRIPTION="Checking Description";
    public static final String CHECK_NAME="Checking Name";
    public static final String CHECK_ARCHIVE_IN="Checking Archive In";
    public static final String CHECK_PURGE_IN="Checking Purge In";
    public static final String CHECK_IS_ENABLED="Checking Is Enabled";
    public static final String CHECK_ID="Checking id";
    public static final String CHECK_CREATED_BY="Checking created by";
    public static final String CHECK_CREATED_DATE="Checking created date";
    public static final String CHECK_MODIFIED_BY="Checking Modified by";
    public static final String CHECK_MODIFIED_DATE="Checking Modified Date";
    public static final String CHECK_ROW_VERSION="Checking Row Version";
    public static final String CHECK_DELETE="Checking is delete";

    private AuditTestConstants(){
    }

}
