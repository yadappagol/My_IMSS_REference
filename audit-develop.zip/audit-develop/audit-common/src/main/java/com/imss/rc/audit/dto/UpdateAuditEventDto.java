package com.imss.rc.audit.dto;

import lombok.Data;

@Data
public class UpdateAuditEventDto {

    private String name;
    private String description;
    private int archiveIn;
    private int purgeIn;
    private int  isEnabled;
    private Integer rowVersion;

}
