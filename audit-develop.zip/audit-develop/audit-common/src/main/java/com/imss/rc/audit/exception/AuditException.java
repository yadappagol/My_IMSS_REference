/**
 * COPYRIGHT: Jakkur Technoparks Pvt. Ltd. (JTPL)
 * This software is the sole property of JTPL
 * and is protected by copyright law and international
 * treaty provisions. Unauthorized reproduction or
 * redistribution of this program, or any portion of
 * it may result in severe civil and criminal penalties
 * and will be prosecuted to the maximum extent possible
 * under the law. JTPL reserves all rights not
 * expressly granted. You may not reverse engineer, decompile,
 * or disassemble the software, except and only to the
 * extent that such activity is expressly permitted
 * by applicable law notwithstanding this limitation.
 * THIS SOFTWARE IS PROVIDED TO YOU "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
 * YOU ASSUME THE ENTIRE RISK AS TO THE ACCURACY
 * AND THE USE OF THIS SOFTWARE. JTPL SHALL NOT BE LIABLE FOR
 * ANY DAMAGES WHATSOEVER ARISING OUT OF THE USE OF OR INABILITY TO
 * USE THIS SOFTWARE, EVEN IF JTPL HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/
package com.imss.rc.audit.exception;

import com.imss.rc.commons.exception.IMSSException;
import org.springframework.http.HttpStatus;


public class AuditException extends IMSSException {

    public static final String MESSAGE_BUNDLE_NAME = "audit_errors_messages";
    public static final String MODULE_CODE = "AUD";
    public static final String ERROR_CODE_PREFIX = "audit.error.";

    public static final String ERROR_OCCURRED ="1000" ;
    public static final String EVENTS_NOT_FOUND ="1001" ;
    public static final String UNABLE_TO_FIND_EVENTS = "1002";
    public static final String NO_RECORDS_FOUND = "1003";
    public static final String INVALID_DATE_FORMAT = "1004";
    public static final String FIELD_VALUE_MISSING = "1005";
    public static final String UNABLE_TO_RETRIEVE_AUDIT_DETAILS = "1007";
    public static final String UNABLE_TO_DELETE_EVENTS = "1008";
    public static final String UNABLE_TO_UPDATE_EVENTS = "1009";
    public static final String MANDATORY_FIELD_NAME_REQUIRED ="1010" ;
    public static final String MANDATORY_FIELD_DESCRIPTION_REQUIRED = "1011";
    public static final String MANDATORY_FIELD_ARCHIVE_IN_REQUIRED ="1012" ;
    public static final String MANDATORY_FIELD_PURGE_IN_REQUIRED = "1013";
    public static final String MANDATORY_FIELD_IS_ENABLED_REQUIRED = "1014";
    public static final String MANDATORY_FIELD_ROW_VERSION_REQUIRED ="1015" ;
    public static final String VALID_VALUE_IS_ENABLED = "1016";
    public static final String INVALID_PURGE_IN = "1017";
    public static final String INVALID_ROW_VERSION_VALUE ="1018" ;
    public static final String INVALID_ARCHIVE_IN ="1019" ;
    public static final String NAME_VALIDATION_FAILED ="1020" ;
    public static final String INVALID_PAGE = "1021";
    public static final String INVALID_LIMIT = "1022";
    public static final String INVALID_ACTION_TYPE_FORMAT ="1023" ;
    public static final String INVALID_EVENT_ID_FORMAT = "1024";


    public AuditException(String code, Object[] args, Throwable cause, HttpStatus httpStatus) {
        super(code, args, cause, httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

    public AuditException(String code, Object[] args, HttpStatus httpStatus) {
        super(code, args, httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

    public AuditException(String code, Throwable cause, HttpStatus httpStatus) {
        super(code, cause, httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

    public AuditException(String code, HttpStatus httpStatus) {
        super(code, httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

}
