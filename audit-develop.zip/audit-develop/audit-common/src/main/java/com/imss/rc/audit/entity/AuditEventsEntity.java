package com.imss.rc.audit.entity;

import com.imss.rc.commons.entity.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Data
@Entity
@Table(name = "audit_events")
public class AuditEventsEntity extends BaseEntity {

    public static final String COLUMN_NAME_NAME = "name";
    public static final String COLUMN_NAME_IS_ENABLED = "isEnabled";

    @Column(name="name")
    private String name;

    @Column(name="description")
    private String description;

    @Column(name="archive_in")
    private int archiveIn;

    @Column(name="purge_in")
    private int purgeIn;

    @Column(name ="is_enabled")
    private Short  isEnabled;

    @OneToMany(targetEntity = AuditMasterEntity.class, mappedBy = "eventIdObj", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<AuditMasterEntity> auditDetails;

}
