package com.imss.rc.audit.util;

import com.imss.rc.audit.exception.AuditException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

    private static final Logger LOG = LoggerFactory.getLogger(DateUtil.class);

    //TODO: Pick this from the configuration once the config module is ready
    public static final String UI_DATE_FORMAT = "dd-MM-yyyy HH:mm:ss";

    public static Date convertUiStringToDate(String dateString, String fieldName) throws AuditException {
        Date dtObj = null;
        try {
            if (!dateString.isEmpty()) {
                SimpleDateFormat dateFormat = new SimpleDateFormat(UI_DATE_FORMAT);
                dtObj = dateFormat.parse(dateString);
            } else {
                throw new AuditException(AuditException.FIELD_VALUE_MISSING, new String[]{fieldName}, HttpStatus.BAD_REQUEST);
            }
        } catch (ParseException ae) {
            LOG.error("Exception occurred at convertUiStringToDate ", ae);
            throw new AuditException(AuditException.INVALID_DATE_FORMAT,
                    new String[]{fieldName, UI_DATE_FORMAT}, HttpStatus.BAD_REQUEST);
        }
        return dtObj;
    }

    private DateUtil(){
    }
}
