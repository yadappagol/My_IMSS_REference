package com.imss.rc.audit.assembler;

import com.imss.rc.audit.entity.AuditEventsEntity;
import com.imss.rc.audit.dto.AuditEventsDto;
import com.imss.rc.commons.assembler.BaseAssembler;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class AuditEventsAssembler {

    private static Map<String, String> sortByList;

    static {
        sortByList = new HashMap<>();
        sortByList.put("name", AuditEventsEntity.COLUMN_NAME_NAME);
        sortByList.put("isEnabled",AuditEventsEntity.COLUMN_NAME_IS_ENABLED);
    }

    /**
     * Method to return the entity column variable name based on the sort by field value received from the ui
     * @param input The sort by field as received from the UI
     * @return The column variable name based on which the sorting should happen
     */
    public static String getSortByColumn(String input){
        return BaseAssembler.getSortByColumn(input, sortByList);
    }


    private static BaseAssembler<AuditEventsDto, AuditEventsEntity> getBaseAssembler(){
        return new BaseAssembler<>(AuditEventsDto::new, AuditEventsEntity::new);
    }

    /**
     * Method to convert AuditEventsEntity entity object to AuditEventsDto dto object
     * @param entity the entity object with the data
     * @return A new AuditEventsDto object with the data from the entity object
     */
    public AuditEventsDto entityToDto(AuditEventsEntity entity){
        return getBaseAssembler().entityToDto(entity);
    }

    /**
     * Method to convert AuditEventsDto dto object to AuditEventsEntity entity object
     * @param dto the dto object with the data
     * @return A new AuditEventsEntity entity object with the data from the dto object
     */
    public AuditEventsEntity dtoToEntity(AuditEventsDto dto){

        return getBaseAssembler().dtoToEntity(dto);
    }


    /**
     * Method to convert a list of AuditEventsDto dto objects to a list of AuditEventsEntity entity objects
     * @param entityList A list of AuditEventsEntity entity objects
     * @return A new list of AuditEventsDto dto objects
     */
    public List<AuditEventsDto> entityListToDtoList(List<AuditEventsEntity> entityList)
    {
        return getBaseAssembler().entityListToDtoList(entityList);
    }


    /**
     * Method to convert a list of AuditEventsEntity entity objects to a list of AuditEventsDto dto objects
     * @param dtoList A list of AuditEventsDto dto objects
     * @return A new list of AuditEventsEntity entity objects
     */
    public List<AuditEventsEntity> dtoListToEntityList(List<AuditEventsDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }
}
