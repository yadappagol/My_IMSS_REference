package com.imss.rc.audit.assembler;

import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.entity.AuditMasterEntity;
import com.imss.rc.commons.assembler.BaseAssembler;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class AuditMasterAssembler{

    private static Map<String, String> sortByList;
    static {
        sortByList = new HashMap<>();
        sortByList.put("event",AuditMasterEntity.COLUMN_NAME_EVENT_ID);
        sortByList.put("action",AuditMasterEntity.COLUMN_NAME_ACTION_TYPE);
        sortByList.put("user",AuditMasterEntity.COLUMN_NAME_WHO);
        sortByList.put("when",AuditMasterEntity.COLUMN_NAME_WHEN);
    }

    /**
     * Method to return the entity column variable name based on the sort by field value received from the ui
     * @param input The sort by field as received from the UI
     * @return The column variable name based on which the sorting should happen
     */
    public static String getSortByColumn(String input){
        return BaseAssembler.getSortByColumn(input, sortByList);
    }

    private static BaseAssembler<AuditMasterDto, AuditMasterEntity> getBaseAssembler(){
        return new BaseAssembler<>(AuditMasterDto::new, AuditMasterEntity::new);
    }

    /**
     * Method to convert AuditEventsEntity entity object to AuditEventsDto dto object
     * @param entity the entity object with the data
     * @return A new AuditEventsDto object with the data from the entity object
     */
    public AuditMasterDto entityToDto(AuditMasterEntity entity){
        return getBaseAssembler().entityToDto(entity);
    }

    /**
     * Method to convert AuditEventsDto dto object to AuditEventsEntity entity object
     * @param dto the dto object with the data
     * @return A new AuditEventsEntity entity object with the data from the dto object
     */
    public AuditMasterEntity dtoToEntity(AuditMasterDto dto){

        return getBaseAssembler().dtoToEntity(dto);
    }


    /**
     * Method to convert a list of AuditEventsDto dto objects to a list of AuditEventsEntity entity objects
     * @param entityList A list of AuditEventsEntity entity objects
     * @return A new list of AuditEventsDto dto objects
     */
    public List<AuditMasterDto> entityListToDtoList(List<AuditMasterEntity> entityList)
    {
        ArrayList<AuditMasterDto> dtoList = new ArrayList();

        entityList.stream().forEach((k) -> {
            AuditMasterDto dto = this.entityToDto(k);
            if(k.getEventIdObj() != null){
                dto.setEventName(k.getEventIdObj().getName());
            }
            if(k.getAuditDetails() != null){
                dto.setDataBefore(k.getAuditDetails().getDataBefore());
                dto.setDataAfter(k.getAuditDetails().getDataAfter());
                dto.setAddtionalData(k.getAuditDetails().getAdditionalData());
            }
            dtoList.add(dto);
        });
        return dtoList;
    }


    /**
     * Method to convert a list of AuditEventsEntity entity objects to a list of AuditEventsDto dto objects
     * @param dtoList A list of AuditEventsDto dto objects
     * @return A new list of AuditEventsEntity entity objects
     */
    public List<AuditMasterEntity> dtoListToEntityList(List<AuditMasterDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }
}
