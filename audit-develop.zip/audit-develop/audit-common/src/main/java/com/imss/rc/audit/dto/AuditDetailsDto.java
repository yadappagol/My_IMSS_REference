package com.imss.rc.audit.dto;

import com.imss.rc.commons.dto.GenericBaseDto;
import lombok.Data;

@Data
public class AuditDetailsDto extends GenericBaseDto {


    private int auditId;
    private String dataBefore;
    private String dataAfter;
    private String addtionalData;


}

