package com.imss.rc.audit.entity;

import com.imss.rc.commons.entity.GenericBaseEntity;
import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name="audit_details_archive")
@Data
public class AuditDetailsArchiveEntity extends GenericBaseEntity {

    @Column(name="audit_id")
    private int auditId;

    @Column(name="data_before")
    private  String dataBefore;

    @Column(name="data_after")
    private String dataAfter;

    @Column(name="additional_data")
    private String additionalData;

    
}
