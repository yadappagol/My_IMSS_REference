package com.imss.rc.audit.entity;

import com.imss.rc.commons.entity.GenericBaseEntity;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="audit_master_archive")
@Data
public class AuditMasterArchiveEntity extends GenericBaseEntity
{
    @Column(name = "event_id")
    private int eventId;

    @Column(name = "description")
    private String description;

    @Column(name="action_type")
    private char actionType;

    @Column(name = "who")
    private String who;

    @Column(name = "audit_when")
    @Temporal(TemporalType.TIMESTAMP)
    private Date when;

    @Column(name="reference_id")
    private String referenceId;

}
