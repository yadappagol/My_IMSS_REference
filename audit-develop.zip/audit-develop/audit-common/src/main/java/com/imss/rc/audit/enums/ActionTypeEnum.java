package com.imss.rc.audit.enums;

public enum ActionTypeEnum {
    ADD(0),
    MODIFY(1),
    VIEW(2),
    DELETE(3);

    private int value;
    ActionTypeEnum(int value) {
        this.value = value;
    }

    public int getValue(){
        return this.value;
    }
}
