package com.imss.rc.audit.dto;

import com.imss.rc.commons.dto.PaginationDto;
import lombok.Data;

import java.util.Date;


@Data
public class AuditMasterDto extends AuditDetailsDto
{

    private int eventId;
    private String eventName;
    private String description;
    private Short actionType;
    private String who;
    private Date when;
    private String referenceId;


    private String startDate;
    private String endDate;
    private PaginationDto pagination;

}
