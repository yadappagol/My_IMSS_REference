package com.imss.rc.audit.dto;

import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.PaginationDto;
import lombok.Data;

@Data
public class AuditEventsDto extends BaseDto {
    private String name;
    private String description;
    private int archiveIn;
    private int purgeIn;
    private Short  isEnabled;

    private PaginationDto pagination;

    public AuditEventsDto() {

    }
}
