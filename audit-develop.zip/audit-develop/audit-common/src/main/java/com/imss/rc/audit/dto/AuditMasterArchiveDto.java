package com.imss.rc.audit.dto;

import com.imss.rc.commons.dto.GenericBaseDto;
import lombok.Data;
import java.util.Date;


@Data
public class AuditMasterArchiveDto extends GenericBaseDto
{

    private int eventId;
    private String description;
    private char actionType;
    private String who;

    private Date when;
    private String referenceId;

  

}
