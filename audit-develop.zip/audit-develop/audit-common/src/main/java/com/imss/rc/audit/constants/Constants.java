package com.imss.rc.audit.constants;

public final class  Constants{


        public static final String ROLE = "admin";
        public static final String SORT_BY_NAME = "name";
        public static final String SORT_BY_WHEN = "when";
        public static final String NAME_REGEX_PATTERN= "^(?![0-9]*$)[a-zA-Z0-9]+$";


        public static final String EDIT_EVENTS = "Details of audit event '%s' was edited";
        public static final String VIEW_EVENT_LIST = "Retrieved page %s with limit of %s records of audit events list sorted by %s in %s order, total of %s records were found.";
        public static final String VIEW_EVENT = "Details of audit event '%s' was viewed";
        public static final String DELETE_EVENT= "Audit event '%s' was deleted Successfully ";
        public static final String REGEX = "^\\d+(,\\d+)*$";

        private Constants() {
        }
}
