package com.imss.rc.audit.entity;

import com.imss.rc.commons.entity.GenericBaseEntity;
import lombok.Data;


import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="audit_master")
@Data
public class AuditMasterEntity extends GenericBaseEntity
{
    public static final String COLUMN_NAME_WHEN = "when";
    public static final String COLUMN_NAME_WHO = "who";
    public static final String COLUMN_NAME_ACTION_TYPE = "actionType";
    public static final String COLUMN_NAME_EVENT_ID = "eventId";
    public static final String COLUMN_NAME_REFERENCE_ID = "referenceId";
    public static final String COLUMN_NAME_DESCRIPTION = "description";

    @Column(name="event_id")
    private int eventId;

    @ManyToOne(targetEntity = AuditEventsEntity.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "event_id", referencedColumnName = "pk_id", insertable = false, updatable = false)
    private AuditEventsEntity eventIdObj;

    @Column(name = "description")
    private String description;

    @Column(name="action_type")
    private Short actionType;

    @Column(name = "who")
    private String who;

    //The extra double quotes are required to escape when as it is a key word
    @Column(name="audit_when")
    @Temporal(TemporalType.TIMESTAMP)
    private Date when;

    @Column(name="reference_id")
    private String referenceId;

    @OneToOne(targetEntity = AuditDetailsEntity.class, fetch = FetchType.EAGER)
    @JoinColumn(name = "pk_id", referencedColumnName = "audit_id", insertable = false, updatable = false)
    private AuditDetailsEntity auditDetails;
}
