package com.imss.rc.audit.enums;

public enum IncludeArchive
{
    Yes(0), No(1);

    private int numVal;

    IncludeArchive(int numVal) {

        this.numVal = numVal;
    }

    public int getNumVal() {

        return numVal;
    }
}
