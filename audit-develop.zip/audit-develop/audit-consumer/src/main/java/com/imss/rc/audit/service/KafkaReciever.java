package com.imss.rc.audit.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.audit.repository.AuditConsumerMasterRepository;
import com.imss.rc.audit.assembler.AuditMasterAssembler;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.entity.AuditDetailsEntity;
import com.imss.rc.audit.entity.AuditEventsEntity;
import com.imss.rc.audit.entity.AuditMasterEntity;
import com.imss.rc.audit.repository.AuditConsumerDetailsRepository;
import com.imss.rc.audit.repository.AuditConsumerEventsRepository;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class KafkaReciever {

	@Autowired
	AuditConsumerMasterRepository auditMasterRepository;
	@Autowired
    AuditConsumerDetailsRepository auditDetailsRepository;
	@Autowired
	AuditConsumerEventsRepository auditEventsRepository;

	@Autowired
	AuditMasterAssembler assembler;

	private static final Logger LOGGER = LoggerFactory.getLogger(KafkaReciever.class);

	@KafkaListener(topics = "${kafka.rc.audit.log.topic}", groupId = "${kafka.rc.audit.consumer.group.id}")
	public void consumeData(AuditMasterDto auditMasterDto) throws JsonProcessingException {

		LOGGER.debug("Received Audit Data - " + auditMasterDto.toString());

		new ObjectMapper().writeValueAsString(auditMasterDto);
		AuditMasterEntity auditMasterEntity = assembler.dtoToEntity(auditMasterDto);
		auditMasterRepository.save(auditMasterEntity);
		LOGGER.debug("Data - " + auditMasterDto.toString() + " - received");
		AuditDetailsEntity auditDetailsEntity;
		Optional<AuditEventsEntity> auditEventEntity = auditEventsRepository.findById(auditMasterEntity.getEventId());

		//Checking if the audit event is valid and present
		if(auditEventEntity.isPresent()){
			//Checking if the audit is enabled for the event
			if(auditEventEntity.get().getIsEnabled() == GlobalYesNoEnum.YES.getValue()){

				auditMasterEntity = auditMasterRepository.save(auditMasterEntity);


				if( (auditMasterDto.getDataAfter() != null && !auditMasterDto.getDataAfter().isEmpty()) ||
						(auditMasterDto.getDataBefore() != null && !auditMasterDto.getDataBefore().isEmpty()) ||
						(auditMasterDto.getAddtionalData() != null && !auditMasterDto.getAddtionalData().isEmpty())
				){
					//This means the additional data is present and it needs to be logged.

					auditDetailsEntity = new AuditDetailsEntity();
					auditDetailsEntity.setAuditId(auditMasterEntity.getId());
					auditDetailsEntity.setDataAfter(auditMasterDto.getDataAfter());
					auditDetailsEntity.setDataBefore(auditMasterDto.getDataBefore());
					auditDetailsEntity.setAdditionalData(auditMasterDto.getAddtionalData());

					auditDetailsRepository.save(auditDetailsEntity);
				}
			} else {
				//This is just for debugging indicating that it is not loggig
				LOGGER.debug("Audit Logging is disabled for Event : {}({})", auditEventEntity.get().getName(), auditMasterEntity.getEventId());
			}
		} else {
			//This is an error, logging an event that is not in DB
			LOGGER.error("Audit Event Id : {} Not found hence skipping logging audit", auditMasterEntity.getEventId());
		}
	}
}
