package com.imss.rc.audit.repository;

import com.imss.rc.audit.entity.AuditMasterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditConsumerMasterRepository extends JpaRepository<AuditMasterEntity, Integer>
{

}
