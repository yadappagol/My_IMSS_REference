package com.imss.rc.audit.service;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.powermock.modules.junit4.PowerMockRunner;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(PowerMockRunner.class)
public class KafkaReceiverTest {


    @Test
    public void testA01() {
        //This is a dummy test need to add in right test content
        Assert.assertEquals("a","a","a");
    }

}

