
if [ $# != 6 ]
then
        echo 'USAGE : run_script.sh <iscreatedb> <istestdatarequired> <username> <password> <db> <host>' 
        echo 'example : run_script.sh true false test_user test123 testdb 172.16.2.22' 
else

        if [ $1 == true ]
        then

                PGPASSWORD=$4 psql -U $3 -h $6 -d $5 < 99_audit_drop_all_tables.sql
                PGPASSWORD=$4 psql -U $3 -h $6 -d $5 < 01_audit_base_scripts.sql
                PGPASSWORD=$4 psql -U $3 -h $6 -d $5 < 02_audit_base_constraints.sql
                PGPASSWORD=$4 psql -U $3 -h $6 -d $5 < 03_audit_defaut_data.sql
        else
                echo 'Skipping creation of database'
        fi
fi
