CREATE TABLE `audit_events` (
  `pk_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `archive_in` int(11) DEFAULT NULL,
  `purge_in` int(11) DEFAULT NULL,
  `is_enabled` int(11) DEFAULT NULL,
  `is_deleted` smallint(6) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` varchar(255) DEFAULT NULL,
  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `row_version` int(11) DEFAULT NULL,
  CONSTRAINT audit_events_pkey PRIMARY KEY (`pk_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;


CREATE TABLE `audit_master` (
  `pk_id` int(11) NOT NULL AUTO_INCREMENT,
  `row_version` int(11) DEFAULT NULL,
  `action_type` smallint(6) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  `reference_id` varchar(255) DEFAULT NULL,
  `audit_when` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `who` varchar(255) DEFAULT NULL,
 CONSTRAINT audit_master_pkey  PRIMARY KEY (`pk_id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;



CREATE TABLE `audit_details` (
  `pk_id` int(11) NOT NULL AUTO_INCREMENT,
  `row_version` int(11) DEFAULT NULL,
  `audit_id` int(11) DEFAULT NULL,
  `data_before` varchar(255) DEFAULT NULL,
  `additional_data` varchar(255) DEFAULT NULL,
  `data_after` varchar(255) DEFAULT NULL,
 CONSTRAINT audit_details_pkey PRIMARY KEY (`pk_id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;


CREATE TABLE `audit_master_archive` (
  `pk_id` int(11) NOT NULL AUTO_INCREMENT,
  `row_version` int(11) DEFAULT NULL,
  `action_type` char(1) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  `reference_id` varchar(255) DEFAULT NULL,
  `audit_when` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `who` varchar(255) DEFAULT NULL,
 CONSTRAINT audit_master_archive_pkey PRIMARY KEY (`pk_id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;



CREATE TABLE `audit_details_archive` (
  `pk_id` int(11) NOT NULL AUTO_INCREMENT,
  `row_version` int(11) DEFAULT NULL,
  `audit_id` int(11) DEFAULT NULL,
  `data_before` varchar(255) DEFAULT NULL,
  `additional_data` varchar(255) DEFAULT NULL,
  `data_after` varchar(255) DEFAULT NULL,
 CONSTRAINT audit_details_archive_pkey PRIMARY KEY (`pk_id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;
