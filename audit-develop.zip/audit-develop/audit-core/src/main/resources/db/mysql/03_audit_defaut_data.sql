insert into audit_events (pk_id, name, description,archive_in,purge_in,is_enabled,is_deleted,created_by,created_date,modified_by,modified_date,row_version) VALUES
(1, 'Audit Events','To track all updates on audit events', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(2, 'Configuration Updates','To track all updates on configuration', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(3, 'Insurance Core Data','To track all updates on insurance core data', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(4, 'Insurance Sub Category','To track all updates on insurance sub category', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(5, 'Insurance Product Types','To track all updates on insurance product types', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(6, 'Insurance Input Fields','To track all updates on insurance input fields', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(7, 'Insurance Products','To track all updates on insurance products', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(8, 'Insurance Providers','To track all updates on insurance providers', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(9, 'Notification Events','To track all updates on notification events', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(10, 'Notification User Preferences','To track all updates on notification user preferences', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(11, 'Notification Templates','To track all updates on notification templates', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(12, 'Third Party Integration','To track all updates on 3rd party integrations updates', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(13, 'Transactions - Enquiries','To track all updates on enquiries', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(14, 'Transactions - Policies','To track all updates on policies', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(15, 'Transactions - Feedback','To track all updates on feedback on policy and purchase', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(16, 'User Management','To track all updates on users of the system', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(17, 'Role Management','To track all updates on roles defined in the system', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(18, 'Agent Management','To track all updates on the agents and their mappings', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(19, 'Commission Management','To track all updates on the commission rules', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(20, 'Login/Logout','To track all logins to and logouts from the portal', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(21, 'Tpi Request Response','To track all updates on the tpi request and responses', 1095, 1825, 1, 0, 'system',now(),'system',now(),1),
(22, 'Document Management','To track all updates on the documents uploaded', 1095, 1825, 1, 0, 'system',now(),'system',now(),1);



