ALTER TABLE audit_master
    ADD CONSTRAINT audit_master_event_id_fkey 
		FOREIGN KEY(event_id) 
			REFERENCES audit_events(pk_id);
			
ALTER TABLE audit_details
    ADD CONSTRAINT audit_details_audit_id_fkey 
		FOREIGN KEY(audit_id) 
			REFERENCES audit_master(pk_id);
			
			
ALTER TABLE audit_master_archive
    ADD CONSTRAINT audit_master_archive_event_id_fkey 
		FOREIGN KEY(event_id) 
			REFERENCES audit_events(pk_id);
			
ALTER TABLE audit_details_archive
    ADD CONSTRAINT audit_details_archive_audit_id_fkey 
		FOREIGN KEY(audit_id) 
			REFERENCES audit_master_archive(pk_id);