ALTER TABLE audit_master DROP FOREIGN KEY audit_master_event_id_fkey ;

ALTER TABLE audit_details
    DROP FOREIGN KEY audit_details_audit_id_fkey ;
	
ALTER TABLE audit_master_archive
    DROP FOREIGN KEY audit_master_archive_event_id_fkey ;
	
ALTER TABLE audit_details_archive
    DROP FOREIGN KEY audit_details_archive_audit_id_fkey ;
	
DROP TABLE audit_details_archive;
DROP TABLE audit_master_archive;
DROP TABLE audit_details;
DROP TABLE audit_master;
DROP TABLE audit_events;
