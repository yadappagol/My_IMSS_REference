package com.imss.rc.audit.service;

public interface AuditArchiveService {

    public void purgeAndArchive();

}
