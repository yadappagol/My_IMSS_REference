package com.imss.rc.audit.service;

import com.imss.rc.audit.repository.AuditMasterRepository;
import com.imss.rc.audit.assembler.AuditMasterAssembler;
import com.imss.rc.audit.constants.Constants;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.entity.AuditMasterEntity;
import com.imss.rc.audit.exception.AuditException;
import com.imss.rc.commons.constants.SortTypeConstants;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.entity.PageableEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;

@Service
public class AuditMasterServiceImpl implements AuditMasterService {

    private static final Logger LOG = LoggerFactory.getLogger(AuditMasterServiceImpl.class);

    @Autowired
    AuditMasterRepository auditRepository;

    @Autowired
    AuditMasterAssembler auditMasterAssembler;

    @Autowired
    private EntityManager em;

    /**
     * This method retrieves the list of audit details
     * @param dto for which the list of audit details need to be retrieved
     * @return List of AuditMasterDto
     * @throws AuditException is thrrown
     */
    public BaseListDto<AuditMasterDto> getDetails(AuditMasterDto dto )  {

        BaseListDto<AuditMasterDto> auditDtoList = new BaseListDto<>();

        try{

            //If the order by is blank then setting it to default by desc
            if(dto.getPagination().getSortType() == null || dto.getPagination().getSortType().isEmpty()){
                dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_DESC);
            }

            //If the sort by is blank then set the default sort by column to when and order by desc
            //This is specifically for audit
            if(dto.getPagination().getSortBy() == null || dto.getPagination().getSortBy().isEmpty()){
                dto.getPagination().setSortBy(Constants.SORT_BY_WHEN);
                dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_DESC);
            }

            PageableEntity<AuditMasterEntity> data = auditRepository.getAllAuditWithFilters(em, dto);
            PaginationDto pageDto = dto.getPagination();
            pageDto.setCount(data.getCount());

            auditDtoList.setPagination(pageDto);
            auditDtoList.setDataList(auditMasterAssembler.entityListToDtoList(data.getData()));
            auditDtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            auditDtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);

            return auditDtoList;

        }  catch (AuditException ex) {
            throw ex;
        } catch (Exception ex) {
            LOG.error("Exception in getDetails:", ex);
            throw new AuditException(AuditException.UNABLE_TO_RETRIEVE_AUDIT_DETAILS, HttpStatus.NOT_FOUND);
        }
    }



}
