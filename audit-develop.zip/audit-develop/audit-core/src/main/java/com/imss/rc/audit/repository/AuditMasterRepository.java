package com.imss.rc.audit.repository;

import com.imss.rc.audit.assembler.AuditMasterAssembler;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.entity.AuditMasterArchiveEntity;
import com.imss.rc.audit.entity.AuditMasterEntity;
import com.imss.rc.audit.exception.AuditException;
import com.imss.rc.audit.util.DateUtil;
import com.imss.rc.commons.entity.PageableEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import javax.transaction.Transactional;
import java.util.*;

@Transactional
@Repository
public interface AuditMasterRepository extends JpaRepository<AuditMasterEntity, Integer> {


    @Query(value = " select *  from audit_master union all select * from audit_master_archive", nativeQuery = true)
    Page<AuditMasterEntity> getAll(Pageable pageable);


    // get only event IDs
    @Query(value = "select ae.pk_id from audit_events ae", nativeQuery = true)
    List<Integer> getEventIds();

    // inserting into Master archive table
    @Query(value = " select * from audit_master am full join audit_events ae on am.event_id = ae.pk_id where (date(now()) - date(am.when) >= ae.archive_in ) ", nativeQuery = true)
    public List<AuditMasterEntity> getAuditMastersByEventIds();

    @Modifying
    @Query(value ="insert into audit_master_archive  select * from audit_master am where am.pk_id in (:masterIds )", nativeQuery = true)
    public void insertAuditMasterArchive(List<Integer> masterIds);

    @Modifying
    @Query(value = "insert into audit_details_archive select * from audit_details ad where ad.audit_id in (:masterIds)", nativeQuery = true)
    public void insertAuditDetailsArchive(List<Integer> masterIds);


    // deleting the moved records from Master and details table
    @Modifying
    @Query(value = "delete from audit_master am where am.pk_id in (select ar.pk_id from audit_master_archive ar)", nativeQuery = true)
    public void deleteMaster();

    @Modifying
    @Query(value = "delete from audit_details ad where ad.pk_id in (select a.pk_id from audit_details_archive a)", nativeQuery = true)
    public void deleteDetails();


    //delete records from archive table
    @Query(value = " from AuditMasterArchiveEntity ama full join AuditEventsEntity aee on aee.id=ama.eventId \n" +
            "where (date(now()) - date(ama.when) >= aee.purgeIn ) ")
    List<AuditMasterArchiveEntity> deleteEvents();

    @Modifying
    @Query(value = " delete from audit_master_archive am where am.pk_id in :auditID", nativeQuery = true)
    public void deleteAuditMasterArchive(List<Integer> auditID);

    @Modifying
    @Query(value = " delete from audit_details_archive am where am.audit_id in :auditIDs", nativeQuery = true)
    public void deleteAuditDetailsArchive(List<Integer> auditIDs);

    default PageableEntity<AuditMasterEntity> getAllAuditWithFilters(EntityManager em, AuditMasterDto auditMasterDto) throws AuditException{

        PageableEntity<AuditMasterEntity> retData = new PageableEntity<>();

        List<Predicate> predicateList = new ArrayList<>();
        CriteriaBuilder criteriaBuilder ;
        Root<AuditMasterEntity> auditMasterRoot ;

        /** This is to get the count of records */
        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        auditMasterRoot = countQuery.from(AuditMasterEntity.class);

        predicateList = applySearchFilters(criteriaBuilder, predicateList, auditMasterRoot, auditMasterDto);

        countQuery.select(criteriaBuilder.count(auditMasterRoot));
        countQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));
        long count = em.createQuery(countQuery).getSingleResult();
        retData.setCount(count);
        /***********************************/


        /** This is to get the list based on the page and limit *******/

        //Clear out the predicateList created using the count root
        predicateList.clear();

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<AuditMasterEntity> listCriteriaQuery = criteriaBuilder.createQuery(AuditMasterEntity.class);

        auditMasterRoot = listCriteriaQuery.from(AuditMasterEntity.class);

        listCriteriaQuery.select(auditMasterRoot);
        predicateList = applySearchFilters(criteriaBuilder, predicateList, auditMasterRoot, auditMasterDto);

        listCriteriaQuery.where( criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));

        String sortByColumn = AuditMasterAssembler.getSortByColumn(auditMasterDto.getPagination().getSortBy());

        Order order;
        if("asc".equals( auditMasterDto.getPagination().getSortType())){
            order = criteriaBuilder.asc(auditMasterRoot.get(sortByColumn));
        } else {
            order = criteriaBuilder.desc(auditMasterRoot.get(sortByColumn));
        }

        TypedQuery<AuditMasterEntity> query = em.createQuery(listCriteriaQuery.orderBy(order))
                .setFirstResult((auditMasterDto.getPagination().getPage() - 1) * auditMasterDto.getPagination().getLimit())
                .setMaxResults(auditMasterDto.getPagination().getLimit());
        retData.setData(query.getResultList());
        /***********************************/


        return retData;
    }


    default List<Predicate> applySearchFilters(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Root<AuditMasterEntity> auditMasterRoot,
                                               AuditMasterDto auditMasterDto) throws AuditException {

        //Adding filter for action type if present
        if (Optional.ofNullable(auditMasterDto.getActionType()).isPresent()) {
            predicateList.add(criteriaBuilder.equal(auditMasterRoot.get(AuditMasterEntity.COLUMN_NAME_ACTION_TYPE), auditMasterDto.getActionType()));
        }
        //Adding filter for event id if present
        if (Optional.ofNullable(auditMasterDto.getEventId()).isPresent() && auditMasterDto.getEventId() != 0 ) {
            predicateList.add(criteriaBuilder.equal(auditMasterRoot.get(AuditMasterEntity.COLUMN_NAME_EVENT_ID), auditMasterDto.getEventId()));
        }
        //Adding filter for reference Id if present
        if (Optional.ofNullable(auditMasterDto.getReferenceId()).isPresent() && !auditMasterDto.getReferenceId().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.equal(auditMasterRoot.get(AuditMasterEntity.COLUMN_NAME_REFERENCE_ID), auditMasterDto.getReferenceId()));
        }
        //Adding filter for user name (who) if present
        if (Optional.ofNullable(auditMasterDto.getWho()).isPresent() && !auditMasterDto.getWho().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.like(criteriaBuilder.upper(auditMasterRoot.get(AuditMasterEntity.COLUMN_NAME_WHO)), "%"+auditMasterDto.getWho().toUpperCase()+"%"));
        }
        //Adding filter for user name (who) if present
        if (Optional.ofNullable(auditMasterDto.getDescription()).isPresent() && !auditMasterDto.getDescription().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.like(criteriaBuilder.upper(auditMasterRoot.get(AuditMasterEntity.COLUMN_NAME_DESCRIPTION)), "%"+auditMasterDto.getDescription().toUpperCase()+"%"));
        }
        //Adding filter for date if present
        if (Optional.ofNullable(auditMasterDto.getStartDate()).isPresent()) {
            if (Optional.ofNullable(auditMasterDto.getEndDate()).isPresent()) {
                predicateList.add(criteriaBuilder.between(auditMasterRoot.get(AuditMasterEntity.COLUMN_NAME_WHEN),
                        DateUtil.convertUiStringToDate(auditMasterDto.getStartDate(), "startDate"),
                        DateUtil.convertUiStringToDate(auditMasterDto.getEndDate(), "endDate") ) );
            } else {
                predicateList.add(criteriaBuilder.between(auditMasterRoot.get(AuditMasterEntity.COLUMN_NAME_WHEN),
                        DateUtil.convertUiStringToDate(auditMasterDto.getStartDate(),"startDate"),
                        new Date(System.currentTimeMillis())));
            }
        }

        return predicateList;
    }

}
