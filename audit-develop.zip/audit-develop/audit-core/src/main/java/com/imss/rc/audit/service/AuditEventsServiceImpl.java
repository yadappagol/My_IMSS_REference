package com.imss.rc.audit.service;

import com.imss.rc.audit.repository.AuditEventsRepository;
import com.imss.rc.audit.validation.AuditValidation;
import com.imss.rc.audit.assembler.AuditEventsAssembler;
import com.imss.rc.audit.constants.Constants;
import com.imss.rc.audit.dto.AuditEventsDto;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.entity.AuditEventsEntity;
import com.imss.rc.audit.enums.AuditEnum;
import com.imss.rc.audit.exception.AuditException;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.commons.constants.SortTypeConstants;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.ActionTypeEnum;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;

@Service
public class AuditEventsServiceImpl implements AuditEventsService {

    private static final Logger LOG = LoggerFactory.getLogger(AuditEventsServiceImpl.class);

    @Autowired
    private EntityManager em;

    @Autowired
    AuditEventsRepository auditEventsRepository;

    @Autowired
    AuditEventsAssembler auditEventsAssembler;

    @Autowired
    AuditValidation auditValidation;

    @Autowired
    KafkaProducerSender kafkaProducerSender;

    /**
     * This method retrieves the list of events based
     * @param dto for which the list of events need to be retrieved
     * @return AuditEventsDto
     * @throws AuditException is thrown
     */
    @Override
    public BaseListDto<AuditEventsDto> getEvents(AuditEventsDto dto) throws AuditException{
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        BaseListDto<AuditEventsDto> auditDtoList = new  BaseListDto<>();
        try{
            //If the order by is blank then setting it to default by asc
            if(dto.getPagination().getSortType() == null || dto.getPagination().getSortType().isEmpty()){
                dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }

            //If the sort by is blank then set the default sort by column to name and order by asc
            if(dto.getPagination().getSortBy() == null || dto.getPagination().getSortBy().isEmpty()){
                dto.getPagination().setSortBy(Constants.SORT_BY_NAME);
                dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }
            PageableEntity<AuditEventsEntity> data= auditEventsRepository.findAllWithFilters(em, dto);
            PaginationDto pageDto = dto.getPagination();
            pageDto.setCount(data.getCount());

            auditDtoList.setPagination(pageDto);
            auditDtoList.setDataList(auditEventsAssembler.entityListToDtoList(data.getData()));
            auditDtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            auditDtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            auditDtoList.setAuditEventId(AuditEnum.AUDIT_EVENTS.getValue());

            auditMasterDto.setEventId(AuditEnum.AUDIT_EVENTS.getValue());
            auditMasterDto.setWhen(dto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(auditDtoList.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(dto.getCreatedBy());
            auditMasterDto.setDescription(String.format(Constants.VIEW_EVENT_LIST,
                    auditDtoList.getPagination().getPage(),
                    auditDtoList.getPagination().getLimit(),
                    auditDtoList.getPagination().getSortBy(),
                    auditDtoList.getPagination().getSortType(),
                    auditDtoList.getPagination().getCount())
            );
            kafkaProducerSender.sendData(auditMasterDto);
            return auditDtoList;

        } catch (AuditException ex) {
            throw ex;
        } catch (Exception ex) {
            LOG.error("Exception in retrieving Audit events:", ex);
            throw new AuditException(AuditException.UNABLE_TO_FIND_EVENTS, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * This method deletes the events based on the id
     * @param auditEventsDto The enquiry Id for which the quotations need to tbe retrieved
     * @return IdDto
     * @throws AuditException thrown
     */
    @Override
    public IdDto deleteEventById(AuditEventsDto auditEventsDto) throws AuditException{
        IdDto idDto=new IdDto();
        try {
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            AuditEventsEntity auditEventsEntity=auditEventsRepository.getOne(auditEventsDto.getId());
            if( auditEventsEntity.getIsDeleted()== GlobalYesNoEnum.YES.getValue()){
                throw  new AuditException(AuditException.EVENTS_NOT_FOUND,new String[]{String.valueOf(auditEventsDto.getId())},HttpStatus.NOT_FOUND) ;
            }
            //set isDeleted Column to 1
            auditEventsEntity.setIsDeleted((short) GlobalYesNoEnum.YES.getValue());

            //Use the auth data in the dto to resolve the base data
            UserAuthDataHandler.resolveEntityBaseData(auditEventsDto, auditEventsEntity);

            auditEventsRepository.save(auditEventsEntity);
            idDto.setId(auditEventsEntity.getId());

            auditMasterDto.setEventId(AuditEnum.AUDIT_EVENTS.getValue());
            auditMasterDto.setWhen(auditEventsEntity.getModifiedDate());
            auditMasterDto.setReferenceId(String.valueOf(auditEventsEntity.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.DELETE.getValue());
            auditMasterDto.setWho(auditEventsEntity.getModifiedBy());
            auditMasterDto.setDescription(String.format(Constants.DELETE_EVENT,auditEventsEntity.getName()));
            kafkaProducerSender.sendData(auditMasterDto);

            return idDto;
        } catch (AuditException ex) {
            throw ex;
        }catch (EntityNotFoundException ex) {
            throw new AuditException(AuditException.UNABLE_TO_FIND_EVENTS, new String[]{String.valueOf(auditEventsDto.getId())}, HttpStatus.NOT_FOUND) ;
        } catch (Exception ex) {
            LOG.error("Exception in deleting events:", ex);
            throw new AuditException(AuditException.UNABLE_TO_DELETE_EVENTS,new String[]{String.valueOf(auditEventsDto.getId())},HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * This method retrieves the events based on the id
     * @param id The  Id for which the events need to be retrieved
     * @return AuditEventsDto
     * @throws AuditException thrown
     */
    @Override
    public AuditEventsDto getEventById(Integer id) throws AuditException {
        try{
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            AuditEventsEntity auditEventEntity= auditEventsRepository.getOne(id);
            if(auditEventEntity.getIsDeleted()== GlobalYesNoEnum.YES.getValue()){
                throw new AuditException(AuditException.EVENTS_NOT_FOUND,new String[]{String.valueOf(id)},HttpStatus.NOT_FOUND);
            }
            AuditEventsDto auditEventsDto=auditEventsAssembler.entityToDto(auditEventEntity);
            auditEventsDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            auditEventsDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);

            auditMasterDto.setEventId(AuditEnum.AUDIT_EVENTS.getValue());
            auditMasterDto.setWhen(auditEventEntity.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(auditEventEntity.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(auditEventEntity.getCreatedBy());
            auditMasterDto.setDescription(String.format(Constants.VIEW_EVENT,auditEventEntity.getName()));
            kafkaProducerSender.sendData(auditMasterDto);

            return auditEventsDto;
        }
        catch (AuditException ex) {
            throw ex;
        }catch (EntityNotFoundException ex) {
            throw new AuditException(AuditException.UNABLE_TO_FIND_EVENTS, new String[]{String.valueOf(id)}, HttpStatus.NOT_FOUND) ;
        }  catch (Exception ex) {
            LOG.error("Exception in get Audit EventsById:", ex);
            throw new AuditException(AuditException.UNABLE_TO_FIND_EVENTS,new String[]{String.valueOf(id)},HttpStatus.NOT_FOUND);
        }
    }

    /**
     * This method updates the events based on the id
     * @param id The  Id for which the events need to be updated
     * @return AuditEventsDto
     * @throws AuditException thrown
     */
    @Override
    public AuditEventsDto updateEventById(AuditEventsDto auditEventsDto, Integer id) throws AuditException{
        try {
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            AuditEventsEntity auditEventsEntity = auditEventsRepository.getOne(id);

            if( auditEventsEntity.getIsDeleted()==GlobalYesNoEnum.YES.getValue()){
                throw  new AuditException(AuditException.EVENTS_NOT_FOUND,HttpStatus.NOT_FOUND) ;
            }
            //Validations for event name
            if(auditValidation.isNameValid(auditEventsDto.getName())){
                auditEventsEntity.setName(auditEventsDto.getName());
            }
            auditEventsEntity.setDescription(auditEventsDto.getDescription());
            auditEventsEntity.setArchiveIn(auditEventsDto.getArchiveIn());
            auditEventsEntity.setPurgeIn(auditEventsDto.getPurgeIn());
            auditEventsEntity.setIsEnabled(auditEventsDto.getIsEnabled());
            auditEventsEntity.setRowVersion(auditEventsDto.getRowVersion());

            //Use the auth data in the dto to resolve the base data
            UserAuthDataHandler.resolveEntityBaseData(auditEventsDto, auditEventsEntity);

            auditEventsRepository.saveAndFlush(auditEventsEntity);
            AuditEventsDto auditEventDto=auditEventsAssembler.entityToDto(auditEventsEntity);
            auditEventDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            auditEventDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);

            auditMasterDto.setEventId(AuditEnum.AUDIT_EVENTS.getValue());
            auditMasterDto.setWhen(auditEventsEntity.getModifiedDate());
            auditMasterDto.setReferenceId(String.valueOf(auditEventsEntity.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.UPDATE.getValue());
            auditMasterDto.setWho(auditEventsEntity.getModifiedBy());
            auditMasterDto.setDescription(String.format(Constants.EDIT_EVENTS,auditEventsEntity.getName()));
            kafkaProducerSender.sendData(auditMasterDto);

            return auditEventDto;
        }
        catch (AuditException ex) {
            throw ex;
        }catch (EntityNotFoundException ex) {
            throw new AuditException(AuditException.EVENTS_NOT_FOUND, new String[]{String.valueOf(id)}, HttpStatus.NOT_FOUND) ;
        } catch (Exception ex) {
            LOG.error("Exception in update events:", ex);
            throw new AuditException(AuditException.UNABLE_TO_UPDATE_EVENTS, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
