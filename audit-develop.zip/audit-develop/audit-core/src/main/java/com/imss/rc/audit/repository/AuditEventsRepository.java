package com.imss.rc.audit.repository;

import com.imss.rc.audit.assembler.AuditEventsAssembler;
import com.imss.rc.audit.dto.AuditEventsDto;
import com.imss.rc.audit.entity.AuditEventsEntity;
import com.imss.rc.audit.exception.AuditException;
import com.imss.rc.commons.entity.BaseEntity;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.data.jpa.repository.JpaRepository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public interface AuditEventsRepository extends JpaRepository<AuditEventsEntity, Integer> {


    default PageableEntity<AuditEventsEntity> findAllWithFilters(EntityManager em, AuditEventsDto auditEventDto) throws AuditException {

        PageableEntity<AuditEventsEntity> retData = new PageableEntity<>();

        List<Predicate> predicateList = new ArrayList<>();
        CriteriaBuilder criteriaBuilder ;
        Root<AuditEventsEntity> auditEventRoot ;

        /** This is to get the count of records */
        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        auditEventRoot = countQuery.from(AuditEventsEntity.class);

        predicateList = applySearchFilters(criteriaBuilder, predicateList, auditEventRoot, auditEventDto);

        countQuery.select(criteriaBuilder.count(auditEventRoot));
        countQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));
        long count = em.createQuery(countQuery).getSingleResult();
        retData.setCount(count);
        /***********************************/


        /** This is to get the list based on the page and limit *******/

        //Clear out the predicateList created using the count root
        predicateList.clear();

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<AuditEventsEntity> listCriteriaQuery = criteriaBuilder.createQuery(AuditEventsEntity.class);

        auditEventRoot = listCriteriaQuery.from(AuditEventsEntity.class);

        listCriteriaQuery.select(auditEventRoot);
        predicateList = applySearchFilters(criteriaBuilder, predicateList, auditEventRoot, auditEventDto);

        listCriteriaQuery.where( criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));

        String sortByColumn = AuditEventsAssembler.getSortByColumn(auditEventDto.getPagination().getSortBy());

        Order order;
        if("asc".equals( auditEventDto.getPagination().getSortType())){
            order = criteriaBuilder.asc(auditEventRoot.get(sortByColumn));
        } else {
            order = criteriaBuilder.desc(auditEventRoot.get(sortByColumn));
        }

        TypedQuery<AuditEventsEntity> query = em.createQuery(listCriteriaQuery.orderBy(order))
                .setFirstResult((auditEventDto.getPagination().getPage() - 1) * auditEventDto.getPagination().getLimit())
                .setMaxResults(auditEventDto.getPagination().getLimit());
        retData.setData(query.getResultList());
        /***********************************/


        return retData;
    }


    default List<Predicate> applySearchFilters(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Root<AuditEventsEntity> auditEventRoot,
                                               AuditEventsDto auditEventDto) throws AuditException {

        //Adding the default is_deleted filter
        predicateList.add(criteriaBuilder.equal(auditEventRoot.get(BaseEntity.COLUMN_NAME_IS_DELETED), GlobalYesNoEnum.NO.getValue()));

        //Adding filter for name if present
        if (Optional.ofNullable(auditEventDto.getName()).isPresent() && !auditEventDto.getName().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.like(criteriaBuilder.upper(auditEventRoot.get(AuditEventsEntity.COLUMN_NAME_NAME)), "%"+auditEventDto.getName().toUpperCase()+"%"));
        }
        //Adding filter for is Enabled if present
        if (auditEventDto.getIsEnabled() != null ) {
            predicateList.add(criteriaBuilder.equal(auditEventRoot.get(AuditEventsEntity.COLUMN_NAME_IS_ENABLED), auditEventDto.getIsEnabled()));
        }

        return predicateList;
    }
}
