package com.imss.rc.audit.controller;


import com.imss.rc.audit.dto.AuditEventsDto;
import com.imss.rc.audit.exception.AuditException;
import com.imss.rc.audit.service.AuditEventsService;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import com.imss.rc.commons.validation.ValidateCommons;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Objects;

@RestController
public class AuditEventControllerImpl implements AuditEventController
{

    @Autowired
    AuditEventsService auditEventsService;

    @Autowired
    ValidateCommons validateCommons;

    private static final Logger LOG = LoggerFactory.getLogger(AuditMasterControllerImpl.class);

    @GetMapping(value = "/audit/events",produces = "application/json")
    public @ResponseBody BaseListDto<AuditEventsDto> getEvents(@RequestParam Integer page,
                                                               @RequestParam Integer limit,
                                                               @RequestParam(required = false) String sortBy,
                                                               @RequestParam(required = false) String sortType,
                                                               @RequestParam(required = false) String name,
                                                               @RequestParam(required = false) Short isEnabled, HttpServletRequest request)throws AuditException {
        LOG.info("getEvents List: Received request URL: " );
        if (Objects.isNull(page)||page < GlobalYesNoEnum.YES.getValue()) {
            throw new AuditException(AuditException.INVALID_PAGE, HttpStatus.BAD_REQUEST);
        }
        if (Objects.isNull(limit) || limit < GlobalYesNoEnum.YES.getValue()) {
            throw new AuditException(AuditException.INVALID_LIMIT, HttpStatus.BAD_REQUEST);
        }
        AuditEventsDto dto = new AuditEventsDto();
        dto.setName(name);
        if(isEnabled != null) {
            dto.setIsEnabled(isEnabled);
        }

        PaginationDto pageDto = new PaginationDto();
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);

        dto.setPagination(pageDto);
        return auditEventsService.getEvents(dto);

    }


    @GetMapping(value = "/audit/events/{id}", produces = "application/json")
    public @ResponseBody AuditEventsDto getEventById(@PathVariable("id") Integer id,HttpServletRequest request) throws AuditException {
        LOG.info("getEventById: Received request: ");
        AuditEventsDto auditEventsDto=new AuditEventsDto();
        auditEventsDto.setId(id);
        UserAuthDataHandler.resolveAuthBaseData(auditEventsDto, request);
        return auditEventsService.getEventById(id);
    }


    @DeleteMapping(value = "/audit/events/{id}", produces = "application/json")
    public @ResponseBody IdDto deleteEventById(@PathVariable("id") Integer id,HttpServletRequest request) throws AuditException {
        LOG.info("deleteEvent: Received request: " );
        AuditEventsDto auditEventsDto=new AuditEventsDto();
        auditEventsDto.setId(id);
        UserAuthDataHandler.resolveAuthBaseData(auditEventsDto, request);
        return auditEventsService.deleteEventById(auditEventsDto);
    }

    @PutMapping(value = "/audit/events/{id}", produces = "application/json")
    public @ResponseBody AuditEventsDto  updateEventById(@RequestBody AuditEventsDto auditEventsDto, @PathVariable("id") Integer id,HttpServletRequest request) throws AuditException {
        LOG.info("update AuditEvent");
       UserAuthDataHandler.resolveAuthBaseData(auditEventsDto, request);

        if(auditEventsDto.getArchiveIn()<=GlobalYesNoEnum.NO.getValue()){
            if(auditEventsDto.getArchiveIn()<GlobalYesNoEnum.NO.getValue()){
                throw new AuditException(AuditException.INVALID_ARCHIVE_IN, HttpStatus.BAD_REQUEST);
            }
            throw new AuditException(AuditException.MANDATORY_FIELD_ARCHIVE_IN_REQUIRED, HttpStatus.BAD_REQUEST);
        }
        else if(auditEventsDto.getPurgeIn()<=GlobalYesNoEnum.NO.getValue()){
            if(auditEventsDto.getPurgeIn()<GlobalYesNoEnum.NO.getValue()){
                throw new AuditException(AuditException.INVALID_PURGE_IN, HttpStatus.BAD_REQUEST);
            }
            throw new AuditException(AuditException.MANDATORY_FIELD_PURGE_IN_REQUIRED, HttpStatus.BAD_REQUEST);
        }
        else if(auditEventsDto.getIsEnabled()==null||!validateCommons.isValidFlag(auditEventsDto.getIsEnabled()))
        {
            throw new AuditException(AuditException.VALID_VALUE_IS_ENABLED,HttpStatus.NOT_FOUND);
        }
        else if(auditEventsDto.getRowVersion()==null){
            throw new AuditException(AuditException.MANDATORY_FIELD_ROW_VERSION_REQUIRED, HttpStatus.BAD_REQUEST);
        }
        else if(auditEventsDto.getRowVersion()<GlobalYesNoEnum.NO.getValue()){
            throw new AuditException(AuditException.INVALID_ROW_VERSION_VALUE, HttpStatus.BAD_REQUEST);
        }
        else if(Objects.isNull(auditEventsDto.getDescription())|| StringUtils.isEmpty(auditEventsDto.getDescription())){
            throw new AuditException(AuditException.MANDATORY_FIELD_DESCRIPTION_REQUIRED, HttpStatus.BAD_REQUEST);
        }

        return auditEventsService.updateEventById(auditEventsDto,id);
    }
}
