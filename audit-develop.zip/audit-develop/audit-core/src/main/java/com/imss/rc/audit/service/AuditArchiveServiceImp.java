package com.imss.rc.audit.service;

import com.imss.rc.audit.repository.AuditMasterRepository;
import com.imss.rc.audit.entity.AuditMasterArchiveEntity;
import com.imss.rc.audit.entity.AuditMasterEntity;
import com.imss.rc.audit.exception.AuditException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AuditArchiveServiceImp implements AuditArchiveService
{

    @Autowired
    AuditMasterRepository auditEventsRepository;

    private static final Logger LOG = LoggerFactory.getLogger(AuditArchiveServiceImp.class);

    public void purgeAndArchive() {
        try {
            List<Integer> eventIds = auditEventsRepository.getEventIds();
           LOG.info("event IDs----->" + eventIds);

            //logic to get all master records
            List<AuditMasterEntity> masterRecords = auditEventsRepository.getAuditMastersByEventIds();
          LOG.info("Master records ----->" + masterRecords);
            List<Integer> masterId = new ArrayList<>();
            for (AuditMasterEntity masterRecord : masterRecords) {
                masterId.add(masterRecord.getId());
            }
            auditEventsRepository.insertAuditMasterArchive(masterId);
           LOG.info("Master IDs----->" + masterId);

            auditEventsRepository.insertAuditDetailsArchive(masterId);
            if(masterRecords==null || masterRecords.isEmpty() )
            {
                throw new AuditException(AuditException.EVENTS_NOT_FOUND, HttpStatus.INTERNAL_SERVER_ERROR);
            }

            //deleting moved records
            auditEventsRepository.deleteMaster();
            auditEventsRepository.deleteDetails();

            List<AuditMasterArchiveEntity> archiveRecords = auditEventsRepository.deleteEvents();
            List<Integer> auditID = new ArrayList<>();
            LOG.info("Archive Records----->" + archiveRecords);

            if (auditEventsRepository.deleteEvents() != null || !(auditEventsRepository.deleteEvents().isEmpty())) {
               for (AuditMasterArchiveEntity masterRecord : archiveRecords) {
                    auditID.add(masterRecord.getId());
}
                auditEventsRepository.deleteAuditMasterArchive(auditID);
               LOG.info("Audit IDs----->" + auditID);
                    auditEventsRepository.deleteAuditDetailsArchive(auditID);
            } else {
                throw new AuditException(AuditException.EVENTS_NOT_FOUND, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception ex) {
            LOG.error("Exception in getEvents:", ex);
        }

    }
}
