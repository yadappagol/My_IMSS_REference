package com.imss.rc.audit.service;

import com.imss.rc.audit.exception.AuditException;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;

import com.imss.rc.audit.dto.AuditEventsDto;

public interface AuditEventsService {

    public BaseListDto<AuditEventsDto> getEvents(AuditEventsDto dto) throws AuditException;

   public IdDto deleteEventById(AuditEventsDto auditEventsDto) throws AuditException;

   public AuditEventsDto getEventById(Integer id ) throws AuditException;

   public AuditEventsDto updateEventById(AuditEventsDto auditEventsDto, Integer id) throws AuditException;

}
