package com.imss.rc.audit.controller;

import com.imss.rc.audit.dto.AuditEventsDto;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.audit.exception.AuditException;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

public interface AuditEventController
{
    @GetMapping(value = "/audit/events",produces = "application/json")
    public @ResponseBody BaseListDto<AuditEventsDto> getEvents(@RequestParam Integer page,
                                          @RequestParam Integer limit,
                                          @RequestParam(required = false) String sortBy,
                                          @RequestParam(required = false) String sortType,
                                          @RequestParam(required = false) String name,
                                          @RequestParam(required = false) Short isEnabled,HttpServletRequest request) throws  AuditException;

    @GetMapping(value = "/audit/events/{id}", produces = "application/json")
    public @ResponseBody AuditEventsDto getEventById(@PathVariable("id") Integer id,HttpServletRequest request) throws AuditException ;

    @DeleteMapping(value = "/audit/events/{id}", produces = "application/json")
    public IdDto deleteEventById(@PathVariable("id") Integer id,HttpServletRequest request) throws AuditException;

    @PutMapping(value = "/audit/events/{id}", produces = "application/json")
    public @ResponseBody AuditEventsDto updateEventById(@RequestBody AuditEventsDto auditEventsDto, @PathVariable("id") Integer id,HttpServletRequest request) throws AuditException;
}
