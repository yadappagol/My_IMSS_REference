package com.imss.rc.audit.repository;

import com.imss.rc.audit.entity.AuditMasterArchiveEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditMasterArchiveRepository extends JpaRepository<AuditMasterArchiveEntity,Integer>
{

}
