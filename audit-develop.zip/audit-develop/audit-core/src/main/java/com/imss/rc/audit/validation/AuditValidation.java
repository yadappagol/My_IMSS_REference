package com.imss.rc.audit.validation;

import com.imss.rc.audit.constants.Constants;
import com.imss.rc.audit.exception.AuditException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class AuditValidation {

    public boolean isNameValid(String name) throws AuditException {
        if(name==null || name.isEmpty())
        {
            throw new AuditException(AuditException.MANDATORY_FIELD_NAME_REQUIRED, HttpStatus.BAD_REQUEST);
        }
        if (name.length()<=50 && name.trim().replace(" ","").matches(Constants.NAME_REGEX_PATTERN)) {
            return true;
        }
        else{
            throw new AuditException(AuditException.NAME_VALIDATION_FAILED,  HttpStatus.BAD_REQUEST);
        }
    }

}
