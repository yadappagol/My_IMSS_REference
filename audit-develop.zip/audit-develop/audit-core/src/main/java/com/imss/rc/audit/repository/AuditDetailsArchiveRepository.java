package com.imss.rc.audit.repository;

import com.imss.rc.audit.entity.AuditDetailsArchiveEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditDetailsArchiveRepository extends JpaRepository<AuditDetailsArchiveEntity,Integer>
{

}
