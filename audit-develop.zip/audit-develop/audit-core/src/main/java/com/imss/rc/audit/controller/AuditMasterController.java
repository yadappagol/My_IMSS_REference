package com.imss.rc.audit.controller;

import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.commons.dto.BaseListDto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.imss.rc.audit.exception.AuditException;

import javax.servlet.http.HttpServletRequest;


public interface AuditMasterController {

    @GetMapping(value = "/audit/details", produces = "application/json")
    BaseListDto<BaseListDto<AuditMasterDto>> getDetails(@RequestParam Integer page,
                                           @RequestParam Integer limit,
                                           @RequestParam(required = false) String sortBy,
                                           @RequestParam(required = false) String sortType,
                                           @RequestParam(required = false) String eventIds,
                                           @RequestParam(required = false) String actionTypes,
                                           @RequestParam(required = false) String userName,
                                           @RequestParam(required = false) String startDate,
                                           @RequestParam(required = false) String endDate,
                                           @RequestParam(required = false) String referenceId,
                                           @RequestParam(required = false) String description,
                                           @RequestParam(required = false) Integer includeArchive, HttpServletRequest request
                                           ) throws AuditException;


    @GetMapping(value="/audit/purgeArchive", produces = "application/jason")
    public void purgeArchive(HttpServletRequest request);
}
