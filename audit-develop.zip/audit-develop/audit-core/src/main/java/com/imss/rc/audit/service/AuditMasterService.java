package com.imss.rc.audit.service;

import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.exception.AuditException;
import com.imss.rc.commons.dto.BaseListDto;

public interface AuditMasterService
{
    public BaseListDto<AuditMasterDto> getDetails(AuditMasterDto dto) throws AuditException;
}
