package com.imss.rc.audit.exception;

import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.exception.IMSSException;
import com.imss.rc.commons.util.ExceptionMessageResolver;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.HashMap;
import java.util.Map;

/**
 * Generic REST exception handler to handle all the exceptions of the application
 *
 * @author Sandeep
 */
@ControllerAdvice
public class AuditCoreRestExceptionHandler extends ResponseEntityExceptionHandler {

    private static final String LANGUAGE_CONSTANT = "language";

    /**
     * handles any exception
     *
     * @param e       exception to handle
     * @param request current request
     * @return error ResponseEntity
     */
    @ExceptionHandler(Exception.class)
    @ResponseBody
    public ResponseEntity<ResponseDto> handleAnyException(Exception e, WebRequest request) {
        final MediaType mediaType = getMediaType(request);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(mediaType);

        ResponseDto dto = new ResponseDto();
        ExceptionMessageResolver.resolveMessage(dto  ,new AuditException(AuditException.ERROR_OCCURRED,HttpStatus.INTERNAL_SERVER_ERROR) ,null);

        return new ResponseEntity<>(dto, httpHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Handles {@link IPPException}
     *
     * @param e       exception to handle
     * @param request current request
     * @return error ResponseEntity
     */
    @ExceptionHandler(IMSSException.class)
    @ResponseBody
    public ResponseEntity<ResponseDto> handleApplicationException(IMSSException e, WebRequest request) {
        final MediaType mediaType = getMediaType(request);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(mediaType);
        ResponseDto dto = new ResponseDto();

        ExceptionMessageResolver.resolveMessage(dto  ,e ,null);

        HttpStatus status = e.getHttpStatus();
        if (status == null) {
            status = HttpStatus.BAD_REQUEST;
        } else {
            status = e.getHttpStatus();
        }
        return new ResponseEntity<>(dto, httpHeaders, status);
    }

    protected MediaType getMediaType(WebRequest request) {
        String mediaType = request.getHeader("Content-Type");
        if (MediaType.APPLICATION_XML_VALUE.equalsIgnoreCase(mediaType)) {
            return MediaType.APPLICATION_XML;
        } else {
            return MediaType.APPLICATION_JSON;
        }
    }

    protected Map<String, Object> getReqMapFromHeader(WebRequest request) {
        HashMap<String, Object> reqDataMap = new HashMap<>();
        if (request.getHeader("accept-language") != null) {
            reqDataMap.put(LANGUAGE_CONSTANT, request.getHeader("accept-language"));
        }
        return reqDataMap;
    }
}
