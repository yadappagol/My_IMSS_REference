package com.imss.rc.audit.controller;

import com.imss.rc.audit.constants.Constants;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.exception.AuditException;
import com.imss.rc.audit.service.AuditArchiveServiceImp;
import com.imss.rc.audit.service.AuditMasterService;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.apache.commons.lang3.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


@RestController
public class AuditMasterControllerImpl implements AuditMasterController {

    @Autowired
    AuditMasterService auditMasterService;

    @Autowired
    AuditArchiveServiceImp auditArchiveServiceImp;

    public BaseListDto<BaseListDto<AuditMasterDto>> getDetails(@RequestParam Integer page,
                                                               @RequestParam Integer limit,
                                                               @RequestParam(required = false) String sortBy,
                                                               @RequestParam(required = false) String sortType,
                                                               @RequestParam(required = false) String eventIds,
                                                               @RequestParam(required = false) String actionTypes,
                                                               @RequestParam(required = false) String userName,
                                                               @RequestParam(required = false) String startDate,
                                                               @RequestParam(required = false) String endDate,
                                                               @RequestParam(required = false) String referenceId,
                                                               @RequestParam(required = false) String description,
                                                               @RequestParam(required = false) Integer includeArchive,
                                                               HttpServletRequest request) throws AuditException {
        BaseListDto<BaseListDto<AuditMasterDto>> listOfMasters = new BaseListDto<>();
        List<BaseListDto<AuditMasterDto>> dtoList = new ArrayList<>();
        if (Objects.isNull(page)||page < GlobalYesNoEnum.YES.getValue()) {
            throw new AuditException(AuditException.INVALID_PAGE, HttpStatus.BAD_REQUEST);
        }
        if (Objects.isNull(limit) || limit < GlobalYesNoEnum.YES.getValue()) {
            throw new AuditException(AuditException.INVALID_LIMIT, HttpStatus.BAD_REQUEST);
        }
        if (StringUtils.isNotBlank(eventIds)|| Objects.nonNull(eventIds)){
            if (!eventIds.trim().replace(" ","").matches(Constants.REGEX)) {
                throw new AuditException(AuditException.INVALID_EVENT_ID_FORMAT, HttpStatus.BAD_REQUEST);
            }
        }
        if (StringUtils.isNotBlank(actionTypes)||Objects.nonNull(actionTypes)){
            if (!actionTypes.trim().replace(" ","").matches(Constants.REGEX)) {
                throw new AuditException(AuditException.INVALID_ACTION_TYPE_FORMAT, HttpStatus.BAD_REQUEST);
            }
        }
        if(StringUtils.isBlank(eventIds) &&  StringUtils.isBlank(actionTypes) && Objects.isNull(eventIds) && Objects.isNull(actionTypes)  ) {
        AuditMasterDto dto = new AuditMasterDto();
        dto.setWho(userName);
        dto.setStartDate(startDate);
        dto.setEndDate(endDate);
        dto.setReferenceId(referenceId);
        dto.setDescription(description);

        PaginationDto pageDto = new PaginationDto();
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);

        dto.setPagination(pageDto);
        dtoList.add(auditMasterService.getDetails(dto));

        }
        else if(Objects.nonNull(eventIds)&& Objects.nonNull(actionTypes)){
            String eventIDs=eventIds.trim();
            String actiontypes=actionTypes.trim();
            String[] indvEventId = eventIDs.replace(" ","").split(",");
            String[] indvActionType = actiontypes.replace(" ","").split(",");
            for (String eventId : indvEventId) {
                for (String actionType : indvActionType) {
                    AuditMasterDto dto = new AuditMasterDto();
                    dto.setActionType(Short.valueOf(actionType));
                    dto.setEventId(Integer.parseInt(eventId));
                    dto.setWho(userName);
                    dto.setStartDate(startDate);
                    dto.setEndDate(endDate);
                    dto.setReferenceId(referenceId);
                    dto.setDescription(description);
                    PaginationDto pageDto = new PaginationDto();
                    pageDto.setLimit(limit);
                    pageDto.setPage(page);
                    pageDto.setSortType(sortType);
                    pageDto.setSortBy(sortBy);
                    dto.setPagination(pageDto);
                    UserAuthDataHandler.resolveAuthBaseData(dto, request);
                    dtoList.add(auditMasterService.getDetails(dto));
                }
            }
        }
        else if(Objects.nonNull(eventIds)){
            String eventIDs=eventIds.trim();
            String[] indvEventId = eventIDs.replaceAll(" ","").split(",");
            for (String eventId : indvEventId) {
                    AuditMasterDto dto = new AuditMasterDto();
                    dto.setEventId(Integer.parseInt(eventId));
                    dto.setWho(userName);
                    dto.setStartDate(startDate);
                    dto.setEndDate(endDate);
                    dto.setReferenceId(referenceId);
                    dto.setDescription(description);
                    PaginationDto pageDto = new PaginationDto();
                    pageDto.setLimit(limit);
                    pageDto.setPage(page);
                    pageDto.setSortType(sortType);
                    pageDto.setSortBy(sortBy);
                    dto.setPagination(pageDto);
                    UserAuthDataHandler.resolveAuthBaseData(dto, request);
                    dtoList.add(auditMasterService.getDetails(dto));
                }
        }
        else {
            String actiontypes=actionTypes.trim();
            String[] indvActionType = actiontypes.replace(" ","").split(",");
            for (String actionType : indvActionType) {
                AuditMasterDto dto = new AuditMasterDto();
                dto.setActionType(Short.valueOf(actionType));
                dto.setWho(userName);
                dto.setStartDate(startDate);
                dto.setEndDate(endDate);
                dto.setReferenceId(referenceId);
                dto.setDescription(description);
                PaginationDto pageDto = new PaginationDto();
                pageDto.setLimit(limit);
                pageDto.setPage(page);
                pageDto.setSortType(sortType);
                pageDto.setSortBy(sortBy);
                dto.setPagination(pageDto);
                UserAuthDataHandler.resolveAuthBaseData(dto, request);
                dtoList.add(auditMasterService.getDetails(dto));
            }
        }
        listOfMasters.setDataList(dtoList);
        return listOfMasters;
    }

    @Override
    public void purgeArchive(HttpServletRequest request) {
        auditArchiveServiceImp.purgeAndArchive();

    }
}