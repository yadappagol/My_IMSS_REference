package com.imss.rc.audit.util;

public class TestConstants {

    public static final boolean TEST_CASE_FAILED = true;

    public static final String EXECUTION_WENT_THROUGH = "Execution went through";
    public static final String EXCEPTION_OCCURRED = "Exception occurred";
    public static final String CHECKING_RIGHT_ERROR_CODE = "Checking Right Error Code";
    public static final Short VALUE_FOR_IS_DELETED = 1;
    public static final short VALUE_FOR_ID = 1;
    public static final short VALUE_FOR_SIZE_FIELD =1 ;
    public static final short VALUE_FOR_COUNT_FIELD = 10;

    public static final String VALUE_FOR_NAME_FIELD = "Insurance notifications";
    public static final String VALUE_FOR_DESCRIPTION_FIELD = "List of Audit Insurance notifications";
    public static final int VALUE_FOR_ARCHIVE_IN_FIELD = 130;
    public static final int VALUE_FOR_PURGE_IN_FIELD = 365;

    public static final String UPDATED_VALUE_FOR_NAME_FIELD = "Updated Insurance notifications";
    public static final String UPDATED_VALUE_FOR_DESCRIPTION_FIELD = "Updated List of Audit Insurance notifications";
    public static final int UPDATED_VALUE_FOR_ARCHIVE_IN_FIELD = 100;
    public static final int UPDATED_VALUE_FOR_PURGE_IN_FIELD = 2000;

    public static final String REGEX = "^\\d+(,\\d+)*$";

    private TestConstants(){
    }
}
