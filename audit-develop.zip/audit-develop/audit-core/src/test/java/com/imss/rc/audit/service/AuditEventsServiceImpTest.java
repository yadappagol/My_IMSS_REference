package com.imss.rc.audit.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.imss.rc.audit.assembler.AuditEventsAssembler;
import com.imss.rc.audit.dto.AuditEventsDto;
import com.imss.rc.audit.entity.AuditEventsEntity;
import com.imss.rc.audit.exception.AuditException;
import com.imss.rc.audit.repository.AuditEventsRepository;
import com.imss.rc.audit.util.TestConstants;
import com.imss.rc.audit.validation.AuditValidation;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.entity.PageableEntity;
import org.hibernate.HibernateException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.imss.rc.audit.util.TestConstants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;


@RunWith(PowerMockRunner.class)
@SpringBootTest(classes= AuditEventsServiceImpTest.class)
public class AuditEventsServiceImpTest {

    private static final Logger LOG = LoggerFactory.getLogger(AuditMasterServiceImplTest.class);

    @InjectMocks
    private AuditEventsServiceImpl auditService;

    @Mock
    private AuditEventsRepository auditRepository;

    @Mock
    private AuditEventsAssembler assembler;

    @Mock
    private AuditValidation auditValidation;

    @Mock
    KafkaProducerSender kafkaProducerSender;

    private AuditEventsDto auditEventsDto;

    private AuditEventsDto auditEventsUpdateDto;

    private AuditEventsEntity auditEventsEntity;

    private PaginationDto paginationDto;


    private JSONObject convertJsonToObject(String fileName) throws IOException, ParseException {
        JSONObject jsonObject;
        try {
            JSONParser jsonParser = new JSONParser();
            FileReader reader = new FileReader(fileName);
            Object obj = jsonParser.parse(reader);
            jsonObject = (JSONObject) obj;
        }
        catch(Exception ex)
        {
            LOG.error(EXCEPTION_OCCURRED,ex);
            throw ex;
        }
        return jsonObject;
    }
    @Before
    public void init() throws IOException, ParseException {
        try {
            /**
             *  Audit Events Entity and DTO
             */
            Gson gson = new GsonBuilder().create();
            MockitoAnnotations.initMocks(this);
            JSONObject jsonFieldObj = convertJsonToObject("src/test/java/com/imss/rc/audit/util/AuditEventsEntity.json");
            auditEventsEntity = gson.fromJson(String.valueOf(jsonFieldObj), AuditEventsEntity.class);
            auditEventsDto = gson.fromJson(String.valueOf(jsonFieldObj), AuditEventsDto.class);

            JSONObject jsonFieldObjectDto = convertJsonToObject("src/test/java/com/imss/rc/audit/util/AuditEventsUpdateDto.json");
            auditEventsUpdateDto = gson.fromJson(String.valueOf(jsonFieldObjectDto), AuditEventsDto.class);

            /**
             *  Pagination DTO
             */
            JSONObject jsonFieldObject = convertJsonToObject("src/test/java/com/imss/rc/audit/util/PaginationDto.json");
            paginationDto = gson.fromJson(String.valueOf(jsonFieldObject), PaginationDto.class);
        } catch(Exception ex){
            LOG.error(EXCEPTION_OCCURRED,ex);
            throw ex;
        }
    }

    @Test
    public void testGetAllEvents() throws AuditException {
        try {

            List<AuditEventsEntity> auditEventsEntityList = new ArrayList<>();
            auditEventsEntityList.add(auditEventsEntity);

            PageableEntity<AuditEventsEntity> list = new PageableEntity<>();
            list.setData(auditEventsEntityList);
            list.setCount(TestConstants.VALUE_FOR_COUNT_FIELD);

            List<AuditEventsDto> auditEventsDtoList = new ArrayList<>();

            auditEventsDto.setPagination(paginationDto);
            auditEventsDtoList.add(auditEventsDto);

            when(auditRepository.findAllWithFilters(Mockito.any(), Mockito.any())).thenReturn(list);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(auditEventsDtoList);
            BaseListDto<AuditEventsDto> result = auditService.getEvents(auditEventsDto);
            assertEquals(TestConstants.VALUE_FOR_SIZE_FIELD, result.getDataList().size());
            assertEquals(TestConstants.VALUE_FOR_COUNT_FIELD, result.getPagination().getCount());
        }
        catch(Exception ex){
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }

    @Test
    public void testGetAllEventsNegative() throws AuditException {
        try {
            List<AuditEventsEntity> auditEventsEntityList = new ArrayList<>();
            auditEventsEntityList.add(auditEventsEntity);

            PageableEntity<AuditEventsEntity> list = new PageableEntity<>();
            list.setData(auditEventsEntityList);
            list.setCount(TestConstants.VALUE_FOR_COUNT_FIELD);

            List<AuditEventsDto> auditEventsDtoList = new ArrayList<>();

            auditEventsDto.setPagination(paginationDto);
            auditEventsDtoList.add(auditEventsDto);

            when(auditRepository.findAllWithFilters(Mockito.any(), Mockito.any())).thenReturn(null);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(auditEventsDtoList);
            auditService.getEvents(auditEventsDto);
            Assert.assertTrue(EXECUTION_WENT_THROUGH,TEST_CASE_FAILED);
        } catch (AuditException ex) {
            Assert.assertEquals(CHECKING_RIGHT_ERROR_CODE, AuditException.UNABLE_TO_FIND_EVENTS, ex.getCode());

        }
    }

    @Test
    public void testGetEventsById() throws AuditException {
        try {
            when(auditRepository.getOne(auditEventsEntity.getId())).thenReturn(auditEventsEntity);
            when(assembler.entityToDto(auditEventsEntity)).thenReturn(auditEventsDto);
            AuditEventsDto auditEventDto = auditService.getEventById(auditEventsEntity.getId());
            assertEquals(VALUE_FOR_NAME_FIELD, auditEventDto.getName());
            assertEquals(VALUE_FOR_DESCRIPTION_FIELD, auditEventDto.getDescription());
            assertEquals(VALUE_FOR_ARCHIVE_IN_FIELD, auditEventDto.getArchiveIn());
            assertEquals(VALUE_FOR_PURGE_IN_FIELD, auditEventDto.getPurgeIn());
        } catch (Exception ex) {
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }

    @Test
    public void testGetEventsByIdNeg() throws AuditException {
        try {
            auditEventsEntity.setIsDeleted(TestConstants.VALUE_FOR_IS_DELETED);
            when(auditRepository.getOne(auditEventsEntity.getId())).thenReturn(auditEventsEntity);
            when(assembler.entityToDto(auditEventsEntity)).thenReturn(auditEventsDto);
            auditService.getEventById(auditEventsEntity.getId());
            Assert.assertTrue(EXECUTION_WENT_THROUGH,TEST_CASE_FAILED);
        } catch (AuditException ex) {
            Assert.assertEquals(CHECKING_RIGHT_ERROR_CODE, AuditException.EVENTS_NOT_FOUND, ex.getCode());

        }
    }

    @Test
    public void testGetEventsByIdNegative() throws AuditException {
        try {
            when(auditRepository.getOne(auditEventsEntity.getId())).thenReturn(auditEventsEntity);
            doThrow(new HibernateException("UNABLE_TO_FIND_EVENTS")).when(assembler).entityToDto(auditEventsEntity);
            auditService.getEventById(auditEventsEntity.getId());
            Assert.assertTrue(EXECUTION_WENT_THROUGH,TEST_CASE_FAILED);
        } catch (AuditException ex) {
            Assert.assertEquals(CHECKING_RIGHT_ERROR_CODE, AuditException.UNABLE_TO_FIND_EVENTS, ex.getCode());

        }
    }

    @Test
    public void testDeleteEvents() throws AuditException {
        try {
            when(auditRepository.getOne(auditEventsEntity.getId())).thenReturn(auditEventsEntity);
            when(assembler.entityToDto(auditEventsEntity)).thenReturn(auditEventsDto);
            IdDto idDto = auditService.deleteEventById(auditEventsDto);
            assertEquals(TestConstants.VALUE_FOR_IS_DELETED, auditEventsEntity.getIsDeleted());
            assertEquals(TestConstants.VALUE_FOR_ID,idDto.getId());
        } catch (Exception ex) {
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }

    @Test
    public void testDeleteEventsByIsDeleted() throws AuditException {
        try {
            auditEventsEntity.setIsDeleted(TestConstants.VALUE_FOR_IS_DELETED);
            when(auditRepository.getOne(auditEventsEntity.getId())).thenReturn(auditEventsEntity);
            when(assembler.entityToDto(auditEventsEntity)).thenReturn(auditEventsDto);
            auditService.deleteEventById(auditEventsDto);
            Assert.assertTrue(EXECUTION_WENT_THROUGH,TEST_CASE_FAILED);
        } catch (AuditException ex) {
            Assert.assertEquals(CHECKING_RIGHT_ERROR_CODE, AuditException.EVENTS_NOT_FOUND, ex.getCode());

        }
    }

    @Test
    public void testDeleteEventNeg() throws  AuditException {
        try {
            when(auditRepository.getOne(auditEventsEntity.getId())).thenReturn(auditEventsEntity);
            doThrow(new HibernateException("UNABLE_TO_DELETE_EVENTS")).when(auditRepository).save(auditEventsEntity);

            auditService.deleteEventById(auditEventsDto);
            Assert.assertTrue(EXECUTION_WENT_THROUGH,TEST_CASE_FAILED);
        } catch (AuditException ex) {
            Assert.assertEquals(CHECKING_RIGHT_ERROR_CODE, AuditException.UNABLE_TO_DELETE_EVENTS, ex.getCode());

        }
    }


    @Test
    public void testUpdateEvents() throws AuditException {
        try {
            when(auditRepository.getOne(auditEventsEntity.getId())).thenReturn(auditEventsEntity);
            when(assembler.entityToDto(auditEventsEntity)).thenReturn(auditEventsUpdateDto);
            when(auditValidation.isNameValid(Mockito.anyString())).thenReturn(true);
            AuditEventsDto auditEventsDto1 = auditService.updateEventById(auditEventsUpdateDto, auditEventsEntity.getId());
            assertEquals(UPDATED_VALUE_FOR_NAME_FIELD, auditEventsDto1.getName());
            assertEquals(UPDATED_VALUE_FOR_DESCRIPTION_FIELD, auditEventsDto1.getDescription());
            assertEquals(UPDATED_VALUE_FOR_ARCHIVE_IN_FIELD, auditEventsDto1.getArchiveIn());
            assertEquals(UPDATED_VALUE_FOR_PURGE_IN_FIELD, auditEventsDto1.getPurgeIn());
        } catch (Exception ex) {
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }

    @Test
    public void testUpdateEventsNeg() throws AuditException {
        try {
            auditEventsEntity.setIsDeleted(TestConstants.VALUE_FOR_IS_DELETED);
            when(auditRepository.getOne(auditEventsEntity.getId())).thenReturn(auditEventsEntity);
            when(assembler.entityToDto(auditEventsEntity)).thenReturn(auditEventsDto);
            auditService.updateEventById(auditEventsDto, auditEventsEntity.getId());
            Assert.assertTrue(EXECUTION_WENT_THROUGH,TEST_CASE_FAILED);
        } catch (AuditException ex) {
            Assert.assertEquals(CHECKING_RIGHT_ERROR_CODE, AuditException.EVENTS_NOT_FOUND, ex.getCode());

        }
    }

    @Test
    public void testUpdateEventsNegative() throws AuditException {
        try {
            when(auditRepository.getOne(auditEventsEntity.getId())).thenReturn(auditEventsEntity);
            when(assembler.entityToDto(auditEventsEntity)).thenReturn(auditEventsDto);

            doThrow(new HibernateException("UNABLE_TO_UPDATE_EVENTS")).when(auditRepository).saveAndFlush(auditEventsEntity);
            auditService.updateEventById(auditEventsDto, auditEventsEntity.getId());
            Assert.assertTrue(EXECUTION_WENT_THROUGH,TEST_CASE_FAILED);
        } catch (AuditException ex) {
            Assert.assertEquals(CHECKING_RIGHT_ERROR_CODE, AuditException.UNABLE_TO_UPDATE_EVENTS, ex.getCode());

        }
    }

}
