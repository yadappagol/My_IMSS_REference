package com.imss.rc.audit.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.imss.rc.audit.assembler.AuditMasterAssembler;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.entity.AuditMasterEntity;
import com.imss.rc.audit.exception.AuditException;
import com.imss.rc.audit.repository.AuditMasterRepository;
import com.imss.rc.audit.util.TestConstants;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.entity.PageableEntity;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import static com.imss.rc.audit.util.TestConstants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@SpringBootTest(classes= AuditMasterServiceImplTest.class)
public class AuditMasterServiceImplTest {

    private static final Logger LOG = LoggerFactory.getLogger(AuditMasterServiceImplTest.class);

    @InjectMocks
    private AuditMasterServiceImpl auditMasterService;

    @Mock
    private AuditMasterRepository auditMasterRepository;

    @Mock
    private AuditMasterAssembler assembler;

    private AuditMasterDto auditMasterDto;

    private AuditMasterEntity auditMasterEntity;

    private PaginationDto paginationDto;

    private JSONObject convertJsonToObject(String fileName) throws IOException, ParseException {
        JSONObject jsonObject;
        try {
            JSONParser jsonParser = new JSONParser();
            FileReader reader = new FileReader(fileName);
            Object obj = jsonParser.parse(reader);
            jsonObject = (JSONObject) obj;
        }
        catch(Exception ex)
        {
            LOG.error(EXCEPTION_OCCURRED,ex);
            throw ex;
        }
        return jsonObject;
    }
    @Before
    public void init() throws IOException, ParseException {
        try {
            /**
             *  Audit Master Entity and DTO
             */
            Gson gson = new GsonBuilder().create();
            MockitoAnnotations.initMocks(this);
            JSONObject jsonFieldObj = convertJsonToObject("src/test/java/com/imss/rc/audit/util/AuditMasterEntity.json");
            auditMasterEntity = gson.fromJson(String.valueOf(jsonFieldObj), AuditMasterEntity.class);
            auditMasterDto = gson.fromJson(String.valueOf(jsonFieldObj), AuditMasterDto.class);

            /**
             *  Pagination DTO
             */
            JSONObject jsonFieldObject = convertJsonToObject("src/test/java/com/imss/rc/audit/util/PaginationDto.json");
            paginationDto = gson.fromJson(String.valueOf(jsonFieldObject), PaginationDto.class);
        } catch(Exception ex){
            LOG.error(EXCEPTION_OCCURRED,ex);
            throw ex;
        }
    }

    @Test
    public void testGetAllAuditDetails() throws AuditException {
        try {

            List<AuditMasterEntity> auditMasterEntityArrayList = new ArrayList<>();
            auditMasterEntityArrayList.add(auditMasterEntity);

            PageableEntity<AuditMasterEntity> list = new PageableEntity<>();
            list.setData(auditMasterEntityArrayList);
            list.setCount(TestConstants.VALUE_FOR_COUNT_FIELD);

            List<AuditMasterDto> auditMasterDtoArrayList = new ArrayList<>();

            auditMasterDto.setPagination(paginationDto);
            auditMasterDtoArrayList.add(auditMasterDto);

            when(auditMasterRepository.getAllAuditWithFilters(Mockito.any(), Mockito.any())).thenReturn(list);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(auditMasterDtoArrayList);
            BaseListDto<AuditMasterDto> result = auditMasterService.getDetails(auditMasterDto);
            assertEquals(TestConstants.VALUE_FOR_SIZE_FIELD, result.getDataList().size());
            assertEquals(TestConstants.VALUE_FOR_COUNT_FIELD, result.getPagination().getCount());
        }
        catch(Exception ex){
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }

    @Test
    public void testGetAllAuditDetailsNegative() throws AuditException {
        try {
            List<AuditMasterEntity> auditMasterEntityArrayList = new ArrayList<>();
            auditMasterEntityArrayList.add(auditMasterEntity);

            PageableEntity<AuditMasterEntity> list = new PageableEntity<>();
            list.setData(auditMasterEntityArrayList);
            list.setCount(TestConstants.VALUE_FOR_COUNT_FIELD);

            List<AuditMasterDto> auditMasterDtoArrayList = new ArrayList<>();

            auditMasterDto.setPagination(paginationDto);
            auditMasterDtoArrayList.add(auditMasterDto);

            when(auditMasterRepository.getAllAuditWithFilters(Mockito.any(), Mockito.any())).thenReturn(null);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(auditMasterDtoArrayList);
            auditMasterService.getDetails(auditMasterDto);
            Assert.assertTrue(EXECUTION_WENT_THROUGH,TEST_CASE_FAILED);
        } catch (AuditException ex) {
            Assert.assertEquals(CHECKING_RIGHT_ERROR_CODE, AuditException.UNABLE_TO_RETRIEVE_AUDIT_DETAILS, ex.getCode());

        }
    }

    @Test
    public void testStringRegex() {
        try {
            Assert.assertTrue(Pattern.matches(REGEX, "17".trim().replace(" ","")));
            Assert.assertTrue(Pattern.matches(REGEX, "17,19".trim().replace(" ","")));
            Assert.assertTrue(Pattern.matches(REGEX, "17,19,20".trim().replace(" ","")));
            Assert.assertTrue(Pattern.matches(REGEX, " 17,19 ".trim().replace(" ","")));
            Assert.assertTrue(Pattern.matches(REGEX, " 17 , 19 ".trim().replace(" ","")));
            Assert.assertTrue(Pattern.matches(REGEX, "17,19,".trim().replace(" ","")));
            Assert.assertTrue(Pattern.matches(REGEX, ".17".trim().replace(" ","")));
            Assert.assertTrue(Pattern.matches(REGEX, "17,".trim().replace(" ","")));
            Assert.assertTrue(Pattern.matches(REGEX, "@@@".trim().replace(" ","")));
        }catch( AssertionError ex){
            LOG.error(EXCEPTION_OCCURRED,ex);
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }
}
