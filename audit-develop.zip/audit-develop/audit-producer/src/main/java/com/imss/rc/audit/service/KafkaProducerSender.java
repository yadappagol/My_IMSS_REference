package com.imss.rc.audit.service;


import com.imss.rc.audit.dto.AuditMasterDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
@Component
public class KafkaProducerSender {

    private static final Logger LOG = LoggerFactory.getLogger(KafkaProducerSender.class);

    @Autowired
    private KafkaTemplate<String,Object> kafkaTemplate;

   @Value("${kafka.rc.audit.log.topic}")
    private String topicName;

    public KafkaProducerSender(KafkaTemplate<String, Object> kafkaTemplate) {

        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendData(AuditMasterDto audit) {

        LOG.debug(String.format("Using topic -> %s -> Producing message -> %s", topicName, audit));

        kafkaTemplate.send(topicName, audit);

    }

}
