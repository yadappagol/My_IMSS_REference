package com.imss.rc.audit.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.audit.dto.AuditEventsDto;
import com.imss.rc.audit.dto.AuditMasterDto;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.After;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.kafka.listener.KafkaMessageListenerContainer;

import java.io.IOException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;

import static org.junit.Assert.assertThat;

public class KafkaProducerTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaProducerTest.class);

    private static String TOPIC_NAME = "auditDetails";

    @MockBean
    private KafkaProducerSender kafkaProducerSender;


    private KafkaMessageListenerContainer<String, AuditEventsDto> container;

    private BlockingQueue<ConsumerRecord<String, String>> consumerRecords;

    //@ClassRule
   // public static EmbeddedKafkaRule embeddedKafka = new EmbeddedKafkaRule(1, true, TOPIC_NAME);

    public void setUp() {
    /*    consumerRecords = new LinkedBlockingQueue<>();

        ContainerProperties containerProperties = new ContainerProperties(TOPIC_NAME);

        Map<String, Object> consumerProperties = KafkaTestUtils.consumerProps(
                "kafkaProducerSender", "false", embeddedKafka.getEmbeddedKafka());

        DefaultKafkaConsumerFactory<String, AuditEventsDto> consumer = new DefaultKafkaConsumerFactory<>(consumerProperties);

        container = new KafkaMessageListenerContainer<>(consumer, containerProperties);
        container.setupMessageListener((MessageListener<String, String>) record -> {
            LOGGER.debug("Listened message='{}'", record.toString());
            consumerRecords.add(record);
        });
        container.start();

        ContainerTestUtils.waitForAssignment(container, embeddedKafka.getEmbeddedKafka().getPartitionsPerTopic());*/
    }

    @After
    public void tearDown() {
        container.stop();
    }


    public void send_auditDetails() throws InterruptedException, IOException {
        AuditMasterDto audit = new AuditMasterDto();
        //audit.setName("AuditEvent");
        audit.setDescription("Audit Events description");
        //audit.setArchiveIn(20);
        //audit.setPurgeIn(100);
        audit.setId(1);
        kafkaProducerSender.sendData(audit);
        ConsumerRecord<String, String> received = consumerRecords.poll(20, TimeUnit.SECONDS);
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString( audit );
        assertThat(json);
       // assertThat(received, hasValue(json));
       // assertThat(received).has(key(null));
    }


}
