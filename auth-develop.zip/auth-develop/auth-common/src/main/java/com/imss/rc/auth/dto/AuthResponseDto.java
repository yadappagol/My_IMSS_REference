package com.imss.rc.auth.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.dto.UserDto;
import lombok.Data;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class AuthResponseDto  extends ResponseDto {
    private String authorizationToken;
    private String refreshToken;
    private int expiresIn;
    private int refreshExpiresIn;
    private Integer dashboardType;
    private List<MenuDto> menuDetails;
    private List<LocationLevelDto> locationFilters;
    private UserDto userDetails;
}
