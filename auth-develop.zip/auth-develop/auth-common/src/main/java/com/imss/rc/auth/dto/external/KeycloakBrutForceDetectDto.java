package com.imss.rc.auth.dto.external;

import lombok.Data;

@Data
public class KeycloakBrutForceDetectDto {
    Integer numFailures;
    Boolean disabled;
    String lastIPFailure;
    Long lastFailure;
}
