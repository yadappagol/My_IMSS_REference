package com.imss.rc.auth.enums;

public enum KeycloakHeadersEnum {
    USERNAME("username"),
    PASSWORD("password"),
    CLIENT_ID("client_id"),
    GRANT_TYPE("grant_type"),
    CLIENT_SECRET("client_secret"),
    SCOPE("scope"),
    SUBJECT_TOKEN("subject_token"),
    REQUESTED_TOKEN_TYPE("requested_token_type"),
    AUDIENCE("audience"),
    REQUESTED_SUBJECT("requested_subject"),
    REFRESH_TOKEN("refresh_token");

    private String value;

    KeycloakHeadersEnum(String value) {
        this.value = value;
    }

    public String getValue(){
        return this.value;
    }
}
