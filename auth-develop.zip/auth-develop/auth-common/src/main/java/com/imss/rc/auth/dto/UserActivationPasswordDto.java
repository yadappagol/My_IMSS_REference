package com.imss.rc.auth.dto;

import com.imss.rc.commons.dto.IdDto;
import lombok.Data;

@Data
public class UserActivationPasswordDto extends IdDto {

    private String userId;

    private String userName;

    private String email;

    private String token;

    private Short isDeleted;
}
