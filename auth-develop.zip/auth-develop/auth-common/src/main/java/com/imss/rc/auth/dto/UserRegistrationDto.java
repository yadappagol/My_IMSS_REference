package com.imss.rc.auth.dto;

import com.imss.rc.commons.dto.GenericBaseDto;
import com.imss.rc.commons.dto.PaginationDto;
import lombok.Data;

@Data
public class UserRegistrationDto extends GenericBaseDto {

    private String username;
    private String firstName;
    private String lastName;
    private String email;
    private String mobileNumber;
    private String userType;
    private String roles;
    private String password;
    private String otp;
    private String signupLocation;

    private PaginationDto pagination;
}
