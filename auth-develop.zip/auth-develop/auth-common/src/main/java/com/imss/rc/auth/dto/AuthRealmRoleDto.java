package com.imss.rc.auth.dto;

import lombok.Data;

@Data
public class AuthRealmRoleDto {
    private String id;
    private String name;
    private String description;
    private boolean composite;
    private boolean clientRole;
    private String containerId;
    private String icon;
    private String link;
    private String parent;
    private String type;
    private String displayKey;
    private String source;
    private int order;
    private int uiCategory;
}
