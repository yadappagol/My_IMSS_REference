package com.imss.rc.auth.assembler;

import com.imss.rc.auth.dto.AuthResponseRolesDto;
import com.imss.rc.auth.dto.external.KeycloakRolesDto;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
public class AuthResponseRolesAssembler {

    public AuthResponseRolesDto keyCloakToAuthResponse(KeycloakRolesDto dto){
        AuthResponseRolesDto authResponseRolesDto =  new AuthResponseRolesDto();
        authResponseRolesDto.setRoleId(dto.getId());
        authResponseRolesDto.setName(dto.getName());
        authResponseRolesDto.setRoles(dto.getRealmRoles());
        if(Objects.nonNull(dto.getAttributes())){
            if (dto.getAttributes().containsKey("description")) {
                authResponseRolesDto.setDescription(dto.getAttributes().get("description").toString().replace("[", "").replace("]", ""));
            }
        }
        return authResponseRolesDto;
    }


    public List<AuthResponseRolesDto> keyCloakListToAuthUserList(List<KeycloakRolesDto> keycloakRolesDtoList)
    {
        List<AuthResponseRolesDto> authResponseRolesDtoList= new ArrayList<>();
        for(KeycloakRolesDto keycloakRolesDto :keycloakRolesDtoList){
            AuthResponseRolesDto authResponseRolesDto=new AuthResponseRolesDto();
            authResponseRolesDto.setRoleId(keycloakRolesDto.getId());
            authResponseRolesDto.setName(keycloakRolesDto.getName());
            authResponseRolesDto.setRoles(keycloakRolesDto.getRealmRoles());
            if(Objects.nonNull(keycloakRolesDto.getAttributes())){
                if (keycloakRolesDto.getAttributes().containsKey("description")) {
                    authResponseRolesDto.setDescription(keycloakRolesDto.getAttributes().get("description").toString().replace("[", "").replace("]", ""));
                }
            }
            authResponseRolesDtoList.add(authResponseRolesDto);
        }
        return authResponseRolesDtoList;
    }

}
