package com.imss.rc.auth.dto.external;

import com.imss.rc.auth.dto.CredentialsDto;
import lombok.Data;

import java.util.ArrayList;
import java.util.Map;

@Data
public class KeycloakUserDto {
    private String id;
    private String username;
    private String firstName;
    private String lastName;
    private String email;
    private String origin;
    private Map<String, String> attributes;
    private ArrayList<CredentialsDto> credentials;
    private boolean enabled;
    private boolean emailVerified;

}
