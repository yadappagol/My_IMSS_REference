package com.imss.rc.auth.entity;

import com.imss.rc.commons.entity.IdEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

@Data
@Entity
@Table(name = "user_short_token")
public class UserShortTokenEntity extends IdEntity {
    @Column(name="user_id")
    private String userId;

    @Column(name="short_token")
    private String shortToken;

    @Column(name="original_token")
    private String originalToken;

    @Column(name = "generated_date")
    private Date generatedDate;

    @Column(name = "is_verified")
    private Short isVerified;

    @Column(name = "verified_date")
    private Date verifiedDate;

}
