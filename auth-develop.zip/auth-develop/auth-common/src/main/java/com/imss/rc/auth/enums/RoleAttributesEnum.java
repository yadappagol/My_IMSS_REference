package com.imss.rc.auth.enums;

public enum RoleAttributesEnum {

    DESCRIPTION("description");

    private String value;

    RoleAttributesEnum(String value) {
        this.value = value;
    }

    public String getValue(){
        return this.value;
    }
}
