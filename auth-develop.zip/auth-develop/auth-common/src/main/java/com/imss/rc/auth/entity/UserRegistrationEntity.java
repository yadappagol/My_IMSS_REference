package com.imss.rc.auth.entity;

import com.imss.rc.commons.entity.BaseEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "user_signup")
public class UserRegistrationEntity extends BaseEntity
{

    @Column(name="user_name")
    private String username;

    @Column(name="first_name")
    private String firstName;

    @Column(name="last_name")
    private String lastName;

    @Column(name="email")
    private String email;

    @Column(name="mobile_number")
    private String mobileNumber;

    @Column(name="otp")
    private String otp;
}
