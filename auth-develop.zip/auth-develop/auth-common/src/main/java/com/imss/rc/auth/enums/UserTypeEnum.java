package com.imss.rc.auth.enums;

public enum UserTypeEnum {
    CUSTOMER("customer"),
    MANAGEMENT("management"),
    AGENT("agent");

    private String value;

    UserTypeEnum(String value)
    {
        this.value=value;
    }

    public String getValue()
    {
        return this.value;
    }
}
