package com.imss.rc.auth.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.ArrayList;
import java.util.Comparator;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MenuDto {
    String id;
    String name;
    String displayKey;
    String displayName;
    String type;
    String link;
    String icon;
    String parent;
    int order;
    ArrayList<MenuDto> children;
    int uiCategory;


    /**
     * This method sorts the list based on the order property
     * @param list The list containing the DTOs that need to be sorted
     */
    public static void sort(ArrayList<MenuDto> list) {
        list.sort(Comparator.comparingInt(MenuDto::getOrder));
    }
}
