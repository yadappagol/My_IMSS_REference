package com.imss.rc.auth.dto.external;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.imss.rc.auth.dto.AuthRolesDto;
import com.imss.rc.commons.dto.PaginationDto;
import lombok.Data;

import java.util.ArrayList;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class KeycloakRolesDto {

    private String id;
    private String name;
    private ArrayList<AuthRolesDto> roles;
    private ArrayList<String> realmRoles;
    private  String description;
    private Integer count;
    private Map attributes;

    private PaginationDto pagination;

}
