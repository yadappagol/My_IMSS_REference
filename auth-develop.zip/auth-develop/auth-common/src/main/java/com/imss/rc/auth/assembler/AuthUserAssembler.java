package com.imss.rc.auth.assembler;

import com.imss.rc.auth.dto.AuthUserDto;
import com.imss.rc.auth.dto.external.KeycloakUserDto;
import com.imss.rc.commons.dto.UserLocationDto;
import org.springframework.stereotype.Component;


import java.util.ArrayList;
import java.util.List;

@Component
public class AuthUserAssembler {

    /**
     * Method to convert KeycloakUserDto entity object to AuthUserDto dto object
     * @param entity the entity object with the data
     * @return A new AuthUserDto object with the data from the entity object
     */
    public AuthUserDto keyCloakDtoToAuthUserDto(KeycloakUserDto entity){
        AuthUserDto authUserDto =  new AuthUserDto();
        UserLocationDto userLocationDto=new UserLocationDto();
        authUserDto.setKeyCloakId(entity.getId());
        authUserDto.setFirstName(entity.getFirstName());
        authUserDto.setLastName(entity.getLastName());
        authUserDto.setEmail(entity.getEmail());
        authUserDto.setUsername(entity.getUsername());
        if(entity.getAttributes()!=null) {
            if (entity.getAttributes().containsKey("mobileNumber")) {
                authUserDto.setMobileNumber(entity.getAttributes().get("mobileNumber").replace("[", "").replace("]", ""));
            }
            if (entity.getAttributes().containsKey("user_type")) {
                authUserDto.setUserType(Integer.valueOf(entity.getAttributes().get("user_type").replace("[", "").replace("]", "")));
            }
            if (entity.getAttributes().containsKey("loc_level1_id")) {
                userLocationDto.setLevel1Id(entity.getAttributes().get("loc_level1_id").replace("[", "").replace("]", ""));
            }
            if (entity.getAttributes().containsKey("loc_level2_id")) {
                userLocationDto.setLevel2Id(entity.getAttributes().get("loc_level2_id").replace("[", "").replace("]", ""));
            }
            if (entity.getAttributes().containsKey("loc_level3_id")) {
                userLocationDto.setLevel3Id(entity.getAttributes().get("loc_level3_id").replace("[", "").replace("]", ""));
            }
            if (entity.getAttributes().containsKey("loc_level4_id")) {
                userLocationDto.setLevel4Id(entity.getAttributes().get("loc_level4_id").replace("[", "").replace("]", ""));
            }
        }
        authUserDto.setLocationDto(userLocationDto);
        return authUserDto;
    }

    /**
     * Method to convert a list of AuditEventsDto dto objects to a list of AuditEventsEntity entity objects
     * @param keycloakUserDtoList A list of AuditEventsEntity entity objects
     * @return A new list of AuditEventsDto dto objects
     */
    public List<AuthUserDto> keyCloakListToAuthUserList(List<KeycloakUserDto> keycloakUserDtoList)
    {
        List<AuthUserDto> authUserDtoList= new ArrayList<>();
        for(KeycloakUserDto keycloakUserList :keycloakUserDtoList){
            AuthUserDto authUserDto =new AuthUserDto();
            UserLocationDto userLocationDto=new UserLocationDto();
            authUserDto.setKeyCloakId(keycloakUserList.getId());
            authUserDto.setFirstName(keycloakUserList.getFirstName());
            authUserDto.setLastName(keycloakUserList.getLastName());
            authUserDto.setEmail(keycloakUserList.getEmail());
            authUserDto.setUsername(keycloakUserList.getUsername());
            if(keycloakUserList.getAttributes()!=null) {
                if (keycloakUserList.getAttributes().containsKey("mobileNumber")) {
                    authUserDto.setMobileNumber(keycloakUserList.getAttributes().get("mobileNumber").replace("[","").replace("]",""));
                }
                if(keycloakUserList.getAttributes().containsKey("user_type")) {
                    authUserDto.setUserType(Integer.valueOf(keycloakUserList.getAttributes().get("user_type").replace("[","").replace("]","")));
                }
                if (keycloakUserList.getAttributes().containsKey("loc_level1_id")) {
                    userLocationDto.setLevel1Id(keycloakUserList.getAttributes().get("loc_level1_id").replace("[","").replace("]",""));
                }
                if (keycloakUserList.getAttributes().containsKey("loc_level2_id")) {
                    userLocationDto.setLevel2Id(keycloakUserList.getAttributes().get("loc_level2_id").replace("[","").replace("]",""));
                }
                if (keycloakUserList.getAttributes().containsKey("loc_level3_id")) {
                    userLocationDto.setLevel3Id(keycloakUserList.getAttributes().get("loc_level3_id").replace("[","").replace("]",""));
                }
                if (keycloakUserList.getAttributes().containsKey("loc_level4_id")) {
                    userLocationDto.setLevel4Id(keycloakUserList.getAttributes().get("loc_level4_id").replace("[","").replace("]",""));
                }
                if (keycloakUserList.getAttributes().containsKey("image")) {
                    authUserDto.setImage(keycloakUserList.getAttributes().get("image").replace("[","").replace("]",""));
                }
            }
            authUserDto.setLocationDto(userLocationDto);
            authUserDtoList.add(authUserDto);
        }
        return authUserDtoList;
    }



}
