package com.imss.rc.auth.dto.external;

import lombok.Data;

import java.util.Map;

@Data
public class KeyCloakGroupsDto {
    private String id;
    private String name;
    private Map attributes;
}
