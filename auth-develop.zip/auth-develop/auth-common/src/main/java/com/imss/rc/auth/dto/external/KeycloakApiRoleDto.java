package com.imss.rc.auth.dto.external;

import lombok.Data;

import java.util.Map;

@Data
public class KeycloakApiRoleDto {

    public static final String ATTRIBUTE_NAME_PATH = "path";
    public static final String ATTRIBUTE_NAME_METHODS = "methods";
    public static final String ATTRIBUTE_NAME_MODULE = "module";

    private String id;
    private String name;
    private boolean composite;
    private boolean clientRole;
    private Map<String, Object> attributes;
    private String containerId;
}
