package com.imss.rc.auth.enums;

public enum KeycloakUserAttributesEnum {
    LEVEL_1_ID("level1_id"),
    LEVEL_1_NAME("level1_name"),
    LEVEL_2_ID("level2_id"),
    LEVEL_2_NAME("level2_name"),
    LEVEL_3_ID("level3_id"),
    LEVEL_3_NAME("level3_name"),
    SP_CODE("sp_code"),
    SP_NAME("sp_name"),
    LOC_LEVEL_1_ID("loc_level1_id"),
    LOC_LEVEL_2_ID("loc_level2_id"),
    LOC_LEVEL_3_ID("loc_level3_id"),
    LOC_LEVEL_4_ID("loc_level4_id"),
    PREFERRED_USER_NAME("preferred_username"),
    FULL_NAME("name"),
    FIRST_NAME("given_name"),
    LAST_NAME("family_name"),
    EMAIL("email"),
    USER_TYPE("user_type"),
    MOBILE_NUMBER("mobileNumber"),
    USER_IMAGE("image");

    private String value;

    KeycloakUserAttributesEnum(String value) {
        this.value = value;
    }

    public String getValue(){
        return this.value;
    }
}
