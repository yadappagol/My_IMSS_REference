package com.imss.rc.auth.dto.external;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class IbkartTokenResponseDto {

    private  String respCode;

    private String respDesc;
}
