package com.imss.rc.auth.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class AuthApiRoleDto implements Serializable {
    private String name;
    private String path;
    private String methods;
    private String module;
}
