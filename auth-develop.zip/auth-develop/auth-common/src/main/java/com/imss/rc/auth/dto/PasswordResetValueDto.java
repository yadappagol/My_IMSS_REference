package com.imss.rc.auth.dto;

import lombok.Data;

@Data
public class PasswordResetValueDto {
    private String tempPassword;
    private String confirmPassword;
    private String reConfirmPassword;
    private String userName;
    private String token;
    private String otp;
    private String oldPassword;
}
