package com.imss.rc.auth.dto;

import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.PaginationDto;
import lombok.Data;

@Data
public class LocationHierarchyDto extends BaseDto {
    private String name;
    private Integer parentId;

    private PaginationDto pagination;
}
