package com.imss.rc.auth.assembler;

import com.imss.rc.auth.dto.UserResetPasswordDto;
import com.imss.rc.auth.entity.UserResetPasswordEntity;
import com.imss.rc.commons.assembler.BaseAssembler;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
public class UserResetPasswordAssembler {

    private static BaseAssembler<UserResetPasswordDto, UserResetPasswordEntity> getBaseAssembler(){
        return new BaseAssembler<>(UserResetPasswordDto::new, UserResetPasswordEntity::new);
    }

    /**
     * Method to convert UserResetPasswordEntity entity object to UserResetPasswordDto dto object
     * @param entity the entity object with the data
     * @return A new UserResetPasswordDto object with the data from the entity object
     */
    public UserResetPasswordDto entityToDto(UserResetPasswordEntity entity){
        return getBaseAssembler().entityToDto(entity);
    }

    /**
     * Method to convert UserResetPasswordDto dto object to UserResetPasswordEntity entity object
     * @param dto the dto object with the data
     * @return A new UserResetPasswordEntity entity object with the data from the dto object
     */
    public UserResetPasswordEntity dtoToEntity(UserResetPasswordDto dto){
        return getBaseAssembler().dtoToEntity(dto);
    }


    /**
     * Method to convert a list of UserResetPasswordDto dto objects to a list of UserResetPasswordEntity entity objects
     * @param entityList A list of UserResetPasswordEntity entity objects
     * @return A new list of UserResetPasswordDto dto objects
     */
    public List<UserResetPasswordDto> entityListToDtoList(List<UserResetPasswordEntity> entityList){
        return getBaseAssembler().entityListToDtoList(entityList);
    }


    /**
     * Method to convert a list of UserResetPasswordEntity entity objects to a list of UserResetPasswordDto dto objects
     * @param dtoList A list of UserResetPasswordDto dto objects
     * @return A new list of UserResetPasswordEntity entity objects
     */
    public List<UserResetPasswordEntity> dtoListToEntityList(List<UserResetPasswordDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }

}
