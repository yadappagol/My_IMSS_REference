package com.imss.rc.auth.dto;

import lombok.Data;

@Data
public class PayloadValue {
    private String temporaryPassword;
    private String email;
    private String name;
    private String link;
    private String portalName;
    private String otp;
}
