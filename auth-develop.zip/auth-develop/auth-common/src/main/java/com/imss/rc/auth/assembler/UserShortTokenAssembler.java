package com.imss.rc.auth.assembler;

import com.imss.rc.auth.dto.UserShortTokenDto;
import com.imss.rc.auth.entity.UserShortTokenEntity;
import com.imss.rc.commons.assembler.BaseAssembler;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class UserShortTokenAssembler {
    private static BaseAssembler<UserShortTokenDto, UserShortTokenEntity> getBaseAssembler(){
        return new BaseAssembler<>(UserShortTokenDto::new, UserShortTokenEntity::new);
    }

    /**
     * Method to convert UserShortTokenEntity entity object to UserShortTokenDto dto object
     * @param entity the entity object with the data
     * @return A new UserShortTokenDto object with the data from the entity object
     */
    public UserShortTokenDto entityToDto(UserShortTokenEntity entity){
        return getBaseAssembler().entityToDto(entity);
    }

    /**
     * Method to convert UserShortTokenDto dto object to UserShortTokenEntity entity object
     * @param dto the dto object with the data
     * @return A new UserShortTokenEntity entity object with the data from the dto object
     */
    public UserShortTokenEntity dtoToEntity(UserShortTokenDto dto){
        return getBaseAssembler().dtoToEntity(dto);
    }


    /**
     * Method to convert a list of UserShortTokenDto dto objects to a list of UserShortTokenEntity entity objects
     * @param entityList A list of UserShortTokenEntity entity objects
     * @return A new list of UserShortTokenDto dto objects
     */
    public List<UserShortTokenDto> entityListToDtoList(List<UserShortTokenEntity> entityList){
        return getBaseAssembler().entityListToDtoList(entityList);
    }


    /**
     * Method to convert a list of UserShortTokenEntity entity objects to a list of UserShortTokenDto dto objects
     * @param dtoList A list of UserShortTokenDto dto objects
     * @return A new list of UserShortTokenEntity entity objects
     */
    public List<UserShortTokenEntity> dtoListToEntityList(List<UserShortTokenDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }
}
