package com.imss.rc.auth.dto;

import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.UserLocationDto;
import lombok.Data;

import java.util.Base64;

@Data
public class UserDetailsDto extends BaseDto {
    private String username;
    private String firstName;
    private String lastName;
    private String email;
    private String mobileNumber;
    private UserLocationDto userLocation;
    private String image;
    private PaginationDto pagination;
}

