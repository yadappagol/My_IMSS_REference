package com.imss.rc.auth.dto;

import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.PaginationDto;
import lombok.Data;

import java.util.ArrayList;

@Data
public class AuthResponseRolesDto extends BaseDto {

    private String roleId;
    private String name;
    private ArrayList<String> roles;
    private String  description;

    private PaginationDto pagination;
}
