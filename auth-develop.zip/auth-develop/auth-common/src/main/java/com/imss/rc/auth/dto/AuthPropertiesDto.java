package com.imss.rc.auth.dto;

import com.imss.rc.commons.dto.IdDto;
import lombok.Data;

import java.io.Serializable;

/**
 * This dto is used to send the properties that is configured in the core
 * to the auth secure via the kafka. So only the properties that are required
 * for auth secure are declared here and sent
 */
@Data
public class AuthPropertiesDto extends IdDto implements Serializable {

    private String keycloakBasePath;
    private String keycloakUserInfoUri;
    private String keycloakClientName;
}
