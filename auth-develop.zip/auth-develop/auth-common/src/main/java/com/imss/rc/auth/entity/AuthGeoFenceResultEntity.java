package com.imss.rc.auth.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import java.sql.Timestamp;
import com.imss.rc.commons.entity.IdEntity;
import static com.imss.rc.auth.entity.AuthGeoFenceResultEntity.*;

@NamedStoredProcedureQuery(
        name = PROCEDURE_GET_IS_SIGNUP_LOCATION_IN_GEO_FENCE,
        procedureName = PROCEDURE_GET_IS_SIGNUP_LOCATION_IN_GEO_FENCE,
        resultClasses = AuthGeoFenceResultEntity.class,
        parameters = {
                @StoredProcedureParameter(name = PROCEDURE_IN_SIGNUP_LOCATION_LONG, type = String.class, mode = ParameterMode.IN),
                @StoredProcedureParameter(name = PROCEDURE_IN_SIGNUP_LOCATION_LAT, type = String.class, mode = ParameterMode.IN),
                @StoredProcedureParameter(name = PROCEDURE_IN_GEO_FENCE, type = String.class, mode = ParameterMode.IN)
        }
)
@Entity
@Data
public class AuthGeoFenceResultEntity extends IdEntity {

    public static final String PROCEDURE_GET_IS_SIGNUP_LOCATION_IN_GEO_FENCE ="usp_get_is_signup_location_in_geo_fence";

    public static final String PROCEDURE_IN_SIGNUP_LOCATION_LAT ="i_signup_location_lat";
    public static final String PROCEDURE_IN_SIGNUP_LOCATION_LONG ="i_signup_location_long";
    public static final String PROCEDURE_IN_GEO_FENCE ="i_geo_fence";
    @Column(name="is_inside")
    private String isInside;

}
