package com.imss.rc.auth.enums;

import io.swagger.models.auth.In;

public enum DashboardTypeEnum {
    AGENT_DASHBOARD(0,"ipp-101-dashboard-agent",3),
    MANAGER_DASHBOARD(1,"ipp-102-dashboard-manager",2),
    USER_DASHBOARD(2,"2",4),
    ADMIN_DASHBOARD(3,"3",1);

    private Integer value;
    private String menuName;
    private Integer priority;

    DashboardTypeEnum(Integer value,String menuNameValue,Integer priorityValue) {
        this.value = value;
        this.menuName = menuNameValue;
        this.priority = priorityValue;
    }

    public Integer getValue(){
        return this.value;
    }

    public String getMenuName(){
        return this.menuName;
    }

    public Integer getPriority(){
        return this.priority;
    }
}
