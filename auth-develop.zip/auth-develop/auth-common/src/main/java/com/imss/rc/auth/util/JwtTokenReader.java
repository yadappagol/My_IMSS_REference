package com.imss.rc.auth.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.auth.exception.AuthException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

public class JwtTokenReader {

    private static final Logger LOG = LoggerFactory.getLogger(JwtTokenReader.class);

    private Map<String, Object> data ;

    public JwtTokenReader(String tokenVal){
        try {

            tokenVal = tokenVal.replace("Bearer", "");

            String base64EncodedHeader;
            String base64EncodedBody;
            String base64EncodedSignature;

            String[] split_string = tokenVal.split("\\.");

            base64EncodedHeader = split_string[0];
            base64EncodedBody = split_string[1];
            base64EncodedSignature = split_string[2];


            Base64.Decoder base64Url = Base64.getUrlDecoder();
            String decodedBody = new String(base64Url.decode(base64EncodedBody));

            ObjectMapper mapper = new ObjectMapper();
            this.data = mapper.readValue(decodedBody, new TypeReference<Map<String, Object>>() {
            });
        } catch (Exception ex){
            LOG.error("Exception while initializing JWT Token Reader", ex);
            throw new AuthException(AuthException.ERROR_DURING_JWT_TOKEN_READING, HttpStatus.UNAUTHORIZED);
        }

    }

    public String getValueFromTokenBody(String key){
        return (String)data.get(key);
    }

    public HashMap<String,Object> getMapFromTokenBody(String key){
        return (HashMap)data.get(key);
    }

}
