package com.imss.rc.auth.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.imss.rc.commons.dto.GenericBaseDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.UserLocationDto;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class AuthUserDto extends GenericBaseDto {

    private String keyCloakId;
    private String username;
    private String firstName;
    private String lastName;
    private String email;
    private String mobileNumber;
    private Integer userType;
    private String roles;
    private String password;
    private UserLocationDto locationDto;
    private String temporaryPassword;
    private String image;

    private PaginationDto pagination;

}
