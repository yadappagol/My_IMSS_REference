package com.imss.rc.auth.dto.external;

import lombok.Data;

import java.util.Map;

@Data
public class KeycloakRealmRoleDto {


    public static final String ATTRIBUTE_NAME_ICON = "icon";
    public static final String ATTRIBUTE_NAME_LINK = "link";
    public static final String ATTRIBUTE_NAME_PARENT = "parent";
    public static final String ATTRIBUTE_NAME_TYPE = "type";
    public static final String ATTRIBUTE_NAME_SOURCE = "source";
    public static final String ATTRIBUTE_NAME_DISPLAY_KEY = "display-key";
    public static final String ATTRIBUTE_NAME_ORDER = "order";
    public static final String ATTRIBUTE_NAME_UI_CATEGORY = "ui-category";

    private String id;
    private String name;
    private String description;
    private boolean composite;
    private boolean clientRole;
    private String containerId;
    private Map<String, Object> attributes;
    private int uiCategory;
}
