package com.imss.rc.auth.enums;

public enum UserEnum {

    ADMIN(20001),
    REPORTING_HEAD(20002),
    VOLUNTEERS(20003),
    USERS(20004);

    private int value;

    UserEnum( int value)
    {
        this.value = value;
    }

    public int getValue()
    {
        return value;
    }
}
