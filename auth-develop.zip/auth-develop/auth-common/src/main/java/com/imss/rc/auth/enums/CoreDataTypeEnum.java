package com.imss.rc.auth.enums;

public enum CoreDataTypeEnum {

    LOCATION_TYPE(100),
    USER_TYPE(200);

    private int value;

    CoreDataTypeEnum( int value)
    {
        this.value = value;
    }

    public int getValue()
    {
        return value;
    }
}
