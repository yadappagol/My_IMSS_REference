package com.imss.rc.auth.dto.external;

import lombok.Data;

@Data
public class KeycloakTokenDto {
    private String accessToken;
    private String refreshToken;
    private int expiresIn;
    private int refreshExpiresIn;
    private long tokenGeneratedTime;
}
