package com.imss.rc.auth.util;

public class AuthApplicationConstants {



    private AuthApplicationConstants(){
        //Hiding the default constructor
    }
    public static final String DATA_ORIGIN_IBKART = "IBKart";
    public static final String AUTH_USER_DATA_OBJECT = "objUser";
    public static final String USER_NAME = "username";

    public static final int LENGTH_ZERO = 0;
    public static final int LENGTH_FIFTY = 50;
    public static final int LENGTH_TEN = 10;
    public static final String LOC_REGEX = "\\d+";
    public static final String MOBILE_NUM_REGEX = "^[6-9]\\d{9}$";
    public static final String NAME_REGEX = "^([a-zA-Z].*)[a-zA-Z\\d!@#$%&*.-_]$";
    public static final String USER_NAME_REGEX = "^([a-zA-Z].*)[a-zA-Z\\d]$";
    public static final String EMAIL_REGEX = "^[a-zA-Z0-9]+(?:\\."+ "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z" +"A-Z]{2,7}$";
    public static final String IMAGE_REGEX = "^[A-Za-z0-9+/:;,\\r\\n]+={0,2}$";

    public static final String ROLE_MAPPING="role-mappings";
    public static final String ROLES = "roles";
    public static final String COUNT = "count";
    public static final String ROLE_ID = "roles-by-id";
    public static final String REALM = "realm";
    public static final String PAGE = "first";
    public static final String LIMIT = "max";
    public static final String REPRESENTATION = "briefRepresentation";
    public static final String SEARCH ="search" ;
    public static final String NAME = "name";

}
