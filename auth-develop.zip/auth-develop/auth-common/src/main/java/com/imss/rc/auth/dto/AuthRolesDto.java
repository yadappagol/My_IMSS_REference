package com.imss.rc.auth.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.imss.rc.commons.dto.ResponseDto;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class AuthRolesDto extends ResponseDto {
    private String id;
    private String name;
}
