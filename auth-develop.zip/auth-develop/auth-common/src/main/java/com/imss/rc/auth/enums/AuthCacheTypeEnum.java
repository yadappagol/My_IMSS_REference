package com.imss.rc.auth.enums;

public enum AuthCacheTypeEnum {
    API_ROLES("apiRoles"),
    CONFIG_PROPERTIES("config");

    private String value;

    AuthCacheTypeEnum( String value)
    {
        this.value = value;
    }

    public String getValue(){
        return this.value;
    }
}
