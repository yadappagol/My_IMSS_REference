package com.imss.rc.auth.dto;

import lombok.Data;

@Data
public class CredentialsDto {

    private String type;
    private String value;
    private boolean temporary;
}
