package com.imss.rc.auth.entity;

import com.imss.rc.commons.entity.BaseEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="location_hierarchy")
@Data
public class LocationHierarchyEntity extends BaseEntity {

    public static final String COLUMN_NAME_NAME = "name";
    public static final String COLUMN_NAME_PARENT_ID = "parentId";

    @Column(name="name")
    private String name;
    @Column(name="loc_type")
    private Integer locationType;
    @Column(name="parent_id")
    private Integer parentId;
}
