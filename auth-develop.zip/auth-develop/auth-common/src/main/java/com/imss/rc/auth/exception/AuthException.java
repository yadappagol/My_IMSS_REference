package com.imss.rc.auth.exception;

import com.imss.rc.commons.exception.IMSSException;
import org.springframework.http.HttpStatus;

public class AuthException extends IMSSException {

    public static final String MESSAGE_BUNDLE_NAME = "auth_errors_messages";
    public static final String MODULE_CODE = "AUTH";
    public static final String ERROR_CODE_PREFIX = "auth.error.";

    public static final String ERROR_OCCURRED = "1000";
    public static final String INVALID_INPUT_PARAMETERS="1002";
    public static final String INVALID_JSON_FORMAT="1003";
    public static final String TOKEN_IS_REQUIRED_TO_VALIDATE="1004";
    public static final String REFERENCE_IS_REQUIRED_TO_VALIDATE="1005";
    public static final String AUTHENTICATION_SUCCESS="1006";
    public static final String AUTHENTICATION_FAILED="1007";
    public static final String NAME_IS_REQUIRED_TO_LOGIN ="1008" ;
    public static final String PASSWORD_IS_REQUIRED_TO_LOGIN ="1009";
    public static final String UNAUTHORIZED_CLIENT ="1010" ;
    public static final String INVALID_CREDENTIALS ="1011" ;
    public static final String ERROR_RESPONSE_FROM_IBKART ="1012" ;
    public static final String UNKNOWN_ROLE_FOR_LOCATION_HIERARCHY = "1013" ;
    public static final String UNKNOWN_ROLE_FOR_DASHBOARD_TYPE ="1014" ;
    public static final String ERROR_WHEN_AUTHENTICATING_WITH_IBKART ="1015" ;
    public static final String ERROR_WHEN_GETTING_DETAILS_FROM_IBKART ="1016" ;
    public static final String ERROR_RESPONSE_WHEN_GETTING_DETAILS_FROM_IBKART ="1017" ;
    public static final String ERROR_RESPONSE_FROM_KEYCLOAK = "1018";
    public static final String ACCESS_TOKEN_FOUND_NULL_IN_KEYCLOAK_RESPONSE = "1019";
    public static final String UNKNOWN_NAME_FOR_LOCATION = "1020";
    public static final String ERROR_DURING_JWT_TOKEN_READING = "1021";
    public static final String LOCATION_ATTRIBUTE_NOT_FOUNT_FOR_USER = "1022";
    public static final String UNAUTHORIZED_NO_TOKEN = "1023";
    public static final String UNAUTHORIZED_INVALID_TOKEN = "1024";
    public static final String UNAUTHORIZED_INVALID_ACCESS = "1025";
    public static final String AUTHORIZED_USER_NOT_AVAILABLE = "1026";

    public static final String USER_NOT_AVAILABLE = "1027";
    public static final String USER_NOT_CREATED ="1028" ;
    public static final String USER_NOT_UPDATED = "1029";
    public static final String USER_NOT_DELETED = "1030";
    public static final String MANDATORY_FIELD_USER_NAME ="1031" ;
    public static final String USER_NAME_NOT_VALID ="1032" ;
    public static final String MANDATORY_FIELD_FIRST_NAME = "1033";
    public static final String FIRST_NAME_NOT_VALID = "1034";
    public static final String MANDATORY_FIELD_LAST_NAME = "1035";
    public static final String LAST_NAME_NOT_VALID = "1036";
    public static final String MANDATORY_FIELD_EMAIL = "1037";
    public static final String EMAIL_NOT_VALID = "1038";
    public static final String VALIDATION_FAILED = "1039";
    public static final String MANDATORY_FIELD_LEVEL1_ID = "1040";
    public static final String LEVEL1_ID_NOT_VALID = "1041";
    public static final String MANDATORY_FIELD_LEVEL2_ID = "1042";
    public static final String LEVEL2_ID_NOT_VALID = "1043";
    public static final String USER_NAME_ALREADY_EXISTS = "1044";
    public static final String EMAIL_ALREADY_EXISTS = "1045";
    public static final String LEVEL3_ID_NOT_VALID ="1046" ;
    public static final String MANDATORY_FIELD_LEVEl3_ID="1047";
    public static final String LEVEL4_ID_NOT_VALID ="1048" ;
    public static final String MANDATORY_FIELD_MOBILE_NUM = "1049";
    public static final String INVALID_MOBILE_NUM ="1050" ;
    public static final String MANDATORY_FIELD_PASSWORD = "1051";
    public static final String PASSWORD_NOT_VALID = "1052";
    public static final String WRONG_TEMPORARY_PASSWORD = "1053";
    public static final String INVALID_PASSWORD_VALUE = "1054";
    public static final String USER_NOT_FOUND = "1055";
    public static final String WRONG_CONFIRM_PASSWORD ="1056" ;
    public static final String FIELDS_NOT_EDITED ="1057" ;
    public static final String INVALID_PAGE ="1058" ;
    public static final String INVALID_LIMIT ="1059" ;
    public static final String ROLE_NOT_AVAILABLE = "1060";
    public static final String INVALID_REALM_ROLE_ID = "1061";
    public static final String ROLE_LIST_NOT_AVAILABLE = "1062";
    public static final String ROLE_NOT_DELETED = "1063";
    public static final String ROLE_NOT_CREATED = "1064";
    public static final String ROLE_NOT_MAPPED = "1065";
    public static final String INVALID_REALM_ROLE_NAME ="1066" ;
    public static final String MAPPED_ROLE_NOT_DELETED = "1067";
    public static final String ROLE_NOT_UPDATED = "1068";
    public static final String GROUP_NAME_NOT_VALID = "1069";
    public static final String AUTH_CACHE_NOT_LOADED_PROPERLY = "1070";
    public static final String AUTH_CACHE_TYPE_UNKNOWN = "1071";
    public static final String UNABLE_TO_LOAD_MENUS = "1072";
    public static final String UNABLE_TO_LOAD_LOCATIONS = "1073";
    public static final String TOO_MANY_INVALID_CREDENTIALS_USER_BLOCKED = "1074";
    public static final String ERROR_WHILE_VALIDATING_TOKEN = "1075";
    public static final String UNAUTHORIZED_UNKNOWN_API = "1076";
    public static final String ROLES_NOT_FOUND_FOR_MODULE = "1077";
    public static final String ROLES_NOT_FOUND_FOR_METHOD = "1078";
    public static final String DUPLICATE_ROLE_NAME = "1079";
    public static final String PASSWORD_NOT_SET ="1081" ;
    public static final String USER_NOT_ACTIVATED = "1082";
    public static final String TOKEN_NOT_GENERATED ="1083" ;
    public static final String USER_NOTIFICATION_MAIL_NOT_SENT = "1084";
    public static final String MANDATORY_SP_DETAILS = "1085";
    public static final String UNABLE_TO_GENERATE_SHORT_TOKEN = "1086";
    public static final String UNABLE_TO_VERIFY_SHORT_TOKEN = "1087";
    public static final String INVALID_SHORT_TOKEN = "1088";
    public static final String UNAUTHORIZED_INVALID_SHORT_TOKEN = "1089";
    public static final String ERROR_WHILE_VALIDATING_SHORT_TOKEN = "1090";
    public static final String MANDATORY_FIELD_ROLE = "1091";
    public static final String WRONG_OTP ="1092" ;
    public static final String USER_NOT_REGISTERED = "1093";
    public static final String USERNAME_ALREADY_REGISTERED = "1094";
    public static final String EMAIL_ALREADY_REGISTERED = "1095";
    public static final String MESSAGE_NOT_SENT = "1096";
    public static final String INVALID_USER_TYPE = "1097";
    public static final String ROLES_NOT_ASSIGNED ="1098" ;
    public static final String UNABLE_TO_UPDATE_IMAGE = "1099";
    public static final String MANDATORY_FIELD_IMAGE = "1100";
    public static final String IMAGE_NOT_VALID = "1101";
    public static final String MAX_IMAGE_SIZE_EXCEEDS = "1102";
    public static final String INVALID_OLD_PASSWORD = "1103";
    public static final String UNABLE_TO_CHANGE_PASSWORD = "1104";
    public static final String MANDATORY_FIELD_ROLE_NAME ="1105" ;
    public static final String SIGNUP_NOT_ALLOWED_IN_THIS_REGION ="1106" ;
    public static final String INVALID_SIGNUP_LOCATION_NOT_IN_RIGHT_FORMAT ="1107" ;
    public static final String INVALID_SIGNUP_LOCATION_LONG_VALUE_ERROR ="1108" ;
    public static final String INVALID_SIGNUP_LOCATION_LAT_VALUE_ERROR ="1109" ;
    public static final String INVALID_SIGNUP_LOCATION_BLANK ="1110" ;


    public AuthException(String code, Object[] args, Throwable cause, HttpStatus httpStatus ) {
        super(code, args, cause, httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }
    public AuthException(String code, Object[] args,HttpStatus httpStatus) {
        super(code, args,httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

    public AuthException(String code, Throwable cause,HttpStatus httpStatus) {
        super(code, cause, httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

    public AuthException(String code,HttpStatus httpStatus) {
        super(code,  httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);

    }

}
