package com.imss.rc.auth.entity;

import com.imss.rc.commons.entity.BaseEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "user_reset_password")
public class UserResetPasswordEntity  extends BaseEntity {
    @Column(name="user_id")
    private String userId;

    @Column(name="user_name")
    private String userName;

    @Column(name="email")
    private String email;

    @Column(name="temporary_password")
    private String temporaryPassword;
}
