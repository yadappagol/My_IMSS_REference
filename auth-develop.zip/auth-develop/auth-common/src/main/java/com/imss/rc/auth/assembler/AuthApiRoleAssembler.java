package com.imss.rc.auth.assembler;

import com.imss.rc.auth.dto.AuthApiRoleDto;
import com.imss.rc.auth.dto.external.KeycloakApiRoleDto;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class AuthApiRoleAssembler {

    public AuthApiRoleDto keyCloakDtoToAuthApiRoleDto(KeycloakApiRoleDto entity){
        AuthApiRoleDto authApiDto = new AuthApiRoleDto();

        authApiDto.setName(entity.getName());
        if (entity.getAttributes().containsKey(KeycloakApiRoleDto.ATTRIBUTE_NAME_PATH)) {
            authApiDto.setPath(entity.getAttributes().get(KeycloakApiRoleDto.ATTRIBUTE_NAME_PATH).toString().replace("[", "").replace("]", ""));
        }
        if (entity.getAttributes().containsKey(KeycloakApiRoleDto.ATTRIBUTE_NAME_METHODS)) {
            authApiDto.setMethods(entity.getAttributes().get(KeycloakApiRoleDto.ATTRIBUTE_NAME_METHODS).toString().replace("[", "").replace("]", ""));
        }
        if (entity.getAttributes().containsKey(KeycloakApiRoleDto.ATTRIBUTE_NAME_MODULE)) {
            authApiDto.setModule(entity.getAttributes().get(KeycloakApiRoleDto.ATTRIBUTE_NAME_MODULE).toString().replace("[", "").replace("]", ""));
        }

        return authApiDto;
    }

    public List<AuthApiRoleDto> keyCloakDtoListToAuthApiRoleDtoList(List<KeycloakApiRoleDto> keycloakUserDtoList)
    {
        List<AuthApiRoleDto> authApiRoleDtoList= new ArrayList<>();

        for(KeycloakApiRoleDto keycloakDto : keycloakUserDtoList){
            authApiRoleDtoList.add(keyCloakDtoToAuthApiRoleDto(keycloakDto));
        }

        return authApiRoleDtoList;
    }
}
