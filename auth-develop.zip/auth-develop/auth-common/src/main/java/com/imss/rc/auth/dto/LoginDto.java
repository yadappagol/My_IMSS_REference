package com.imss.rc.auth.dto;

import com.imss.rc.commons.dto.BaseDto;
import lombok.Data;

@Data
public class LoginDto extends BaseDto {

    private String username;

    private String password;

    private String token;
}
