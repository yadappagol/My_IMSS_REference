package com.imss.rc.auth.dto;

import com.imss.rc.commons.dto.BaseDto;
import lombok.Data;

import java.util.Date;

@Data
public class UserShortTokenDto  extends BaseDto {
    private String shortToken;
    private String originalToken;
    private Date generatedDate;
    private Short isVerified;
    private Date verifiedDate;
}
