package com.imss.rc.auth.dto;

import com.imss.rc.commons.dto.BaseDto;
import lombok.Data;

@Data
public class UserResetPasswordDto extends BaseDto {
    private String userId;
    private String userName;
    private String email;
    private String temporaryPassword;
    }
