package com.imss.rc.auth.enums;

public enum LocationTypeEnum {
    LOCATION_LEVEL_5(10001, "Country", ""),
    LOCATION_LEVEL_4(10002, "Zone", KeycloakUserAttributesEnum.LOC_LEVEL_4_ID.getValue()),
    LOCATION_LEVEL_3(10003, "State", KeycloakUserAttributesEnum.LOC_LEVEL_3_ID.getValue()),
    LOCATION_LEVEL_2(10004, "Cluster", KeycloakUserAttributesEnum.LOC_LEVEL_2_ID.getValue()),
    LOCATION_LEVEL_1(10005, "District", KeycloakUserAttributesEnum.LOC_LEVEL_1_ID.getValue());

    private Integer value;
    private String name;
    private String attributeName;

    LocationTypeEnum(Integer value, String name, String attributeName) {
        this.value = value;
        this.name = name;
        this.attributeName = attributeName;
    }

    public Integer getValue(){
        return this.value;
    }
    public String getName(){
        return this.name;
    }
    public String getAttributeName(){
        return this.attributeName;
    }
}
