package com.imss.rc.auth.assembler;

import com.imss.rc.auth.dto.AuthUserDto;
import com.imss.rc.auth.dto.external.KeycloakUserDto;
import com.imss.rc.commons.assembler.BaseAssembler;
import org.springframework.stereotype.Component;

@Component
public class KeyCloakAssembler {

    public static BaseAssembler<KeycloakUserDto, AuthUserDto> getBaseAssembler(){
        return new BaseAssembler<>(KeycloakUserDto::new, AuthUserDto::new);
    }

    /**
     * Method to convert AuthUserDto entity object to KeycloakUserDto dto object
     * @param entity the entity object with the data
     * @return A new KeycloakUserDto object with the data from the entity object
     */
    public KeycloakUserDto authUserToKeyCloakDto(AuthUserDto entity){
        return getBaseAssembler().entityToDto(entity);
    }


}
