package com.imss.rc.auth.dto.external;

import lombok.Data;

@Data
public class IbkartBdDetailsDto {

        private String bd_id;
        private String level1_id;
        private String level1_name;
        private String level2_id;
        private String level2_name;
        private String level3_id;
        private String level3_name;
        private String bd_name;
        private String state;
        private String district;
        private String mobile_number;
        private String sp_code;
        private String sp_name;
        private String respCode;
        private String respDesc;
}
