package com.imss.rc.auth.dto;

import lombok.Data;

import java.util.List;

@Data
public class UserActionsDto {

    private String redirect_uri;

    private List actions;
}
