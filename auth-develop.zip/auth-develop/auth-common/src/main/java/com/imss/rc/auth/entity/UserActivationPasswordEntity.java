package com.imss.rc.auth.entity;

import com.imss.rc.commons.entity.IdEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "user_activation_password")
public class UserActivationPasswordEntity extends IdEntity {

    @Column(name="user_id")
    private String userId;

    @Column(name="user_name")
    private String userName;

    @Column(name="email")
    private String email;

    @Column(name="token")
    private String token;

    @Column(name="is_deleted")
    private Short isDeleted;
}
