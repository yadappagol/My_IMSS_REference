package com.imss.rc.auth.assembler;

import com.imss.rc.auth.dto.AuthRealmRoleDto;
import com.imss.rc.auth.dto.external.KeycloakRealmRoleDto;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Assembler class to convert Keycloak realm role dto to Auth Realm Role Dto
 */
@Component
public class AuthRealmRoleAssembler {
    public AuthRealmRoleDto keyCloakDtoToAuthRealmRoleDto(KeycloakRealmRoleDto entity){
        AuthRealmRoleDto authRealmRoleDto = new AuthRealmRoleDto();

        authRealmRoleDto.setId(entity.getId());
        authRealmRoleDto.setName(entity.getName());
        authRealmRoleDto.setDescription(entity.getDescription());
        authRealmRoleDto.setContainerId(entity.getContainerId());
        authRealmRoleDto.setClientRole(entity.isClientRole());
        authRealmRoleDto.setComposite(entity.isComposite());

        if (entity.getAttributes().containsKey(KeycloakRealmRoleDto.ATTRIBUTE_NAME_ICON)) {
            authRealmRoleDto.setIcon(entity.getAttributes().get(KeycloakRealmRoleDto.ATTRIBUTE_NAME_ICON).toString().replace("[", "").replace("]", ""));
        }
        if (entity.getAttributes().containsKey(KeycloakRealmRoleDto.ATTRIBUTE_NAME_LINK)) {
            authRealmRoleDto.setLink(entity.getAttributes().get(KeycloakRealmRoleDto.ATTRIBUTE_NAME_LINK).toString().replace("[", "").replace("]", ""));
        }
        if (entity.getAttributes().containsKey(KeycloakRealmRoleDto.ATTRIBUTE_NAME_PARENT)) {
            authRealmRoleDto.setParent(entity.getAttributes().get(KeycloakRealmRoleDto.ATTRIBUTE_NAME_PARENT).toString().replace("[", "").replace("]", ""));
        }
        if (entity.getAttributes().containsKey(KeycloakRealmRoleDto.ATTRIBUTE_NAME_TYPE)) {
            authRealmRoleDto.setType(entity.getAttributes().get(KeycloakRealmRoleDto.ATTRIBUTE_NAME_TYPE).toString().replace("[", "").replace("]", ""));
        }
        if (entity.getAttributes().containsKey(KeycloakRealmRoleDto.ATTRIBUTE_NAME_DISPLAY_KEY)) {
            authRealmRoleDto.setDisplayKey(entity.getAttributes().get(KeycloakRealmRoleDto.ATTRIBUTE_NAME_DISPLAY_KEY).toString().replace("[", "").replace("]", ""));
        }
        if (entity.getAttributes().containsKey(KeycloakRealmRoleDto.ATTRIBUTE_NAME_SOURCE)) {
            authRealmRoleDto.setSource(entity.getAttributes().get(KeycloakRealmRoleDto.ATTRIBUTE_NAME_SOURCE).toString().replace("[", "").replace("]", ""));
        }
        if (entity.getAttributes().containsKey(KeycloakRealmRoleDto.ATTRIBUTE_NAME_ORDER) && entity.getAttributes().get(KeycloakRealmRoleDto.ATTRIBUTE_NAME_ORDER) != null) {
            authRealmRoleDto.setOrder(Integer.parseInt(entity.getAttributes().get(KeycloakRealmRoleDto.ATTRIBUTE_NAME_ORDER).toString().replace("[", "").replace("]", "")));
        }
        if (entity.getAttributes().containsKey(KeycloakRealmRoleDto.ATTRIBUTE_NAME_UI_CATEGORY) && entity.getAttributes().get(KeycloakRealmRoleDto.ATTRIBUTE_NAME_UI_CATEGORY) != null) {
            authRealmRoleDto.setUiCategory(Integer.parseInt(entity.getAttributes().get(KeycloakRealmRoleDto.ATTRIBUTE_NAME_UI_CATEGORY).toString().replace("[", "").replace("]", "")));
        }

        return authRealmRoleDto;
    }

    public List<AuthRealmRoleDto> keyCloakDtoListToAuthRealmRoleDtoList(List<KeycloakRealmRoleDto> keycloakUserDtoList)
    {
        List<AuthRealmRoleDto> authRealmRoleDtoList= new ArrayList<>();

        for(KeycloakRealmRoleDto keycloakDto : keycloakUserDtoList){
            authRealmRoleDtoList.add(keyCloakDtoToAuthRealmRoleDto(keycloakDto));
        }

        return authRealmRoleDtoList;
    }
}
