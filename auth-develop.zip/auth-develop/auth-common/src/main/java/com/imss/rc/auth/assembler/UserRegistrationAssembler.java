package com.imss.rc.auth.assembler;

import com.imss.rc.commons.assembler.BaseAssembler;
import com.imss.rc.auth.dto.UserRegistrationDto;
import com.imss.rc.auth.entity.UserRegistrationEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class UserRegistrationAssembler {
    
    private static BaseAssembler<UserRegistrationDto, UserRegistrationEntity> getBaseAssembler(){
    return new BaseAssembler<>(UserRegistrationDto::new, UserRegistrationEntity::new);
    }

        /**
         * Method to convert UserRegistrationEntity entity object to UserRegistrationDto dto object
         * @param entity the entity object with the data
         * @return A new UserRegistrationDto object with the data from the entity object
         */
        public UserRegistrationDto entityToDto(UserRegistrationEntity entity){
            return getBaseAssembler().entityToDto(entity);
        }

        /**
         * Method to convert UserRegistrationDto dto object to UserRegistrationEntity entity object
         * @param dto the dto object with the data
         * @return A new UserRegistrationEntity entity object with the data from the dto object
         */
        public UserRegistrationEntity dtoToEntity(UserRegistrationDto dto){
            return getBaseAssembler().dtoToEntity(dto);
        }


        /**
         * Method to convert a list of UserRegistrationDto dto objects to a list of UserRegistrationEntity entity objects
         * @param entityList A list of UserRegistrationEntity entity objects
         * @return A new list of UserRegistrationDto dto objects
         */
        public List<UserRegistrationDto> entityListToDtoList(List<UserRegistrationEntity> entityList){
            return getBaseAssembler().entityListToDtoList(entityList);
        }


        /**
         * Method to convert a list of UserRegistrationEntity entity objects to a list of UserRegistrationDto dto objects
         * @param dtoList A list of UserRegistrationDto dto objects
         * @return A new list of UserRegistrationEntity entity objects
         */
        public List<UserRegistrationEntity> dtoListToEntityList(List<UserRegistrationDto> dtoList){
            return getBaseAssembler().dtoListToEntityList(dtoList);
        }
}
