package com.imss.rc.auth.dto;

import lombok.Data;

@Data
public class TokenDto {

    public String token;

    public String reference;

}
