package com.imss.rc.auth.dto;

import lombok.Data;

@Data
public class RealmRolesDto {

    private String id;
    private String name;
    private String description;
    private boolean composite;
    private boolean clientRole;
    private String containerId;

}
