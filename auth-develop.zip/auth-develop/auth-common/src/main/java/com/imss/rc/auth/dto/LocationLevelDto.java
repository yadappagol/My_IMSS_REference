package com.imss.rc.auth.dto;

import com.imss.rc.commons.dto.ResponseDto;
import lombok.Data;

@Data
public class LocationLevelDto extends ResponseDto {
    private String levelName;
    private Boolean fixed;
    private Integer defaultId;
    private String defaultName;
}
