package com.imss.rc.auth.util;

public class AuthTestConstants {
    private AuthTestConstants()
    {

    }

    public static final boolean BRIEFREPRESENTATION= true;
    public static final String EMAIL = "abc@gmail.com";
    public static final Integer FIRST = 1;
    public static final String FIRST_NAME = "agent";
    public static final String LAST_NAME = "cluster";
    public static final Integer MAX = 2;
    public static final String SEARCH = "agent";
    public static final String USER_NAME = "auth";
}

