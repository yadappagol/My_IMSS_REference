package com.imss.rc.auth.cache;

import com.imss.rc.auth.dto.AuthPropertiesDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.service.external.KeycloakIntegration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class AuthCacheRequestKafkaListener {
    private static final Logger LOGGER = LoggerFactory.getLogger(AuthCacheRequestKafkaListener.class);

    /* Keycloak related properties that are to be sent*/
    @Value("${keycloak.base.path}")
    private String keycloakBasePath;
    @Value("${keycloak.user.info.uri}")
    private String keycloakUserInfoUri;
    @Value("${keycloak.client-id}")
    private String keycloakClientName;


    @KafkaListener(topics = "${kafka.rc.auth.master.request.topic}",
            groupId = "${kafka.rc.auth.master.request.group.id}",
            containerFactory="authCacheDataListenerContainerFactory")
    public void consumeSubCategoryMasterList(String request) throws AuthException {

        LOGGER.info("Data - " + request+ " - received");

        getAndSendAllMasterData();
    }

    @Autowired
    private KeycloakIntegration keycloakIntegration;

    @Autowired
    private AuthCacheDataSender authCacheDataSender;

    @PostConstruct
    public void getAndSendAllMasterData(){
        sendApiRoles();
        sendKeycloakProperties();
    }

    /**
     * Method to call the kafka sender to send out all the API Roles
     */
    public void sendApiRoles(){
        authCacheDataSender.sendApiRoleListIntoTopic( keycloakIntegration.getAllApiRoles());
    }

    public void sendKeycloakProperties(){
        AuthPropertiesDto authDto = new AuthPropertiesDto();

        authDto.setKeycloakBasePath(keycloakBasePath);
        authDto.setKeycloakUserInfoUri(keycloakUserInfoUri);
        authDto.setKeycloakClientName(keycloakClientName);

        authCacheDataSender.sendKeycloakPropertiesIntoTopic(authDto);
    }
}
