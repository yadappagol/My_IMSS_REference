package com.imss.rc.auth.repository;


import com.imss.rc.auth.assembler.LocationHierarchyAssembler;
import com.imss.rc.auth.dto.LocationHierarchyDto;
import com.imss.rc.auth.entity.LocationHierarchyEntity;
import com.imss.rc.auth.enums.LocationTypeEnum;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.util.AuthApplicationConstants;
import com.imss.rc.commons.dto.UserLocationDto;
import com.imss.rc.commons.entity.BaseEntity;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface LocationHierarchyRepository extends JpaRepository<LocationHierarchyEntity, Integer> {

    default UserLocationDto checkAndCreateLocation(String state, String district){
        UserLocationDto locDto = new UserLocationDto();

        Optional<LocationHierarchyEntity> stateEntityOptional = getLocationByNameAndType(state, LocationTypeEnum.LOCATION_LEVEL_3.getValue());
        Optional<LocationHierarchyEntity> districtEntityOptional = getLocationByNameAndType(district, LocationTypeEnum.LOCATION_LEVEL_1.getValue());
        LocationHierarchyEntity districtEntity;
        if(stateEntityOptional.isPresent()){
            locDto.setLevel4Id(String.valueOf(stateEntityOptional.get().getParentId())); //Zone Id
            locDto.setLevel3Id(String.valueOf(stateEntityOptional.get().getId())); //State Id

            if(districtEntityOptional.isPresent()){
                districtEntity = districtEntityOptional.get();
            } else {

                //Getting the default cluster for the state, if it changes, this logic need to change
                Optional<LocationHierarchyEntity> clusterEntityOptional =  getClusterForState(stateEntityOptional.get().getId(), LocationTypeEnum.LOCATION_LEVEL_2.getValue());

                //If district is not found then insert the district
                districtEntity = new LocationHierarchyEntity();

                districtEntity.setName(district);
                districtEntity.setParentId(clusterEntityOptional.get().getId());
                districtEntity.setLocationType(LocationTypeEnum.LOCATION_LEVEL_1.getValue());
                districtEntity.setCreatedBy(AuthApplicationConstants.DATA_ORIGIN_IBKART);
                districtEntity.setCreatedDate(new Date(System.currentTimeMillis()));
                districtEntity.setModifiedBy(AuthApplicationConstants.DATA_ORIGIN_IBKART);
                districtEntity.setModifiedDate(districtEntity.getCreatedDate());
                districtEntity.setIsDeleted((short) GlobalYesNoEnum.NO.getValue());
                this.save(districtEntity);
            }
            locDto.setLevel2Id(String.valueOf(districtEntity.getParentId())); //Cluster Id
            locDto.setLevel1Id(String.valueOf(districtEntity.getId()));//District Id
        } else {
            throw new AuthException(AuthException.UNKNOWN_NAME_FOR_LOCATION, new String[]{state}, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return locDto;
    }

    default UserLocationDto checkAndCreateLocationById(String state, String district){
        UserLocationDto locDto = new UserLocationDto();

        Optional<LocationHierarchyEntity> stateEntityOptional = getLocationByIdAndType(Integer.valueOf(state), LocationTypeEnum.LOCATION_LEVEL_3.getValue());
        Optional<LocationHierarchyEntity> districtEntityOptional = getLocationByIdAndType(Integer.valueOf(district), LocationTypeEnum.LOCATION_LEVEL_1.getValue());
        LocationHierarchyEntity districtEntity;
        if(stateEntityOptional.isPresent()){
            locDto.setLevel4Id(String.valueOf(stateEntityOptional.get().getParentId())); //Zone Id
            locDto.setLevel3Id(String.valueOf(stateEntityOptional.get().getId())); //State Id

            if(districtEntityOptional.isPresent()){
                districtEntity = districtEntityOptional.get();
            } else {

                //Getting the default cluster for the state, if it changes, this logic need to change
                Optional<LocationHierarchyEntity> clusterEntityOptional =  getClusterForState(stateEntityOptional.get().getId(), LocationTypeEnum.LOCATION_LEVEL_2.getValue());

                //If district is not found then insert the district
                districtEntity = new LocationHierarchyEntity();

                districtEntity.setName(district);
                districtEntity.setParentId(clusterEntityOptional.get().getId());
                districtEntity.setLocationType(LocationTypeEnum.LOCATION_LEVEL_1.getValue());
                districtEntity.setCreatedBy(AuthApplicationConstants.DATA_ORIGIN_IBKART);
                districtEntity.setCreatedDate(new Date(System.currentTimeMillis()));
                districtEntity.setModifiedBy(AuthApplicationConstants.DATA_ORIGIN_IBKART);
                districtEntity.setModifiedDate(districtEntity.getCreatedDate());
                districtEntity.setIsDeleted((short)GlobalYesNoEnum.NO.getValue());
                this.save(districtEntity);
            }
            locDto.setLevel2Id(String.valueOf(districtEntity.getParentId())); //Cluster Id
            locDto.setLevel1Id(String.valueOf(districtEntity.getId()));//District Id
        } else {
            throw new AuthException(AuthException.UNKNOWN_NAME_FOR_LOCATION, new String[]{state}, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return locDto;
    }

    @Query(value=" from LocationHierarchyEntity where isDeleted= 0 AND name = :name AND locationType = :type")
    public Optional<LocationHierarchyEntity> getLocationByNameAndType(String name, Integer type);

    @Query(value=" from LocationHierarchyEntity where isDeleted= 0 AND id = :levelId AND locationType = :type")
    public Optional<LocationHierarchyEntity> getLocationByIdAndType(Integer levelId, Integer type);


    @Query(value=" from LocationHierarchyEntity where isDeleted= 0 AND parent_id = :stateId AND locationType = :type")
    public Optional<LocationHierarchyEntity> getClusterForState(Integer stateId, Integer type );

    @Query(value=" select name from LocationHierarchyEntity where isDeleted= 0 AND id = :locId")
    public String getNameForLocationId(Integer locId);

    @Query(value=" from LocationHierarchyEntity where isDeleted= 0 AND id = :levelId")
    public LocationHierarchyEntity validateLevelId(Integer levelId);

    default PageableEntity<LocationHierarchyEntity> getAllLocationWithFilters(EntityManager em, LocationHierarchyDto dto ){
        PageableEntity<LocationHierarchyEntity> retData = new PageableEntity<>();

        List<Predicate> predicateList = new ArrayList<>();
        CriteriaBuilder criteriaBuilder ;
        Root<LocationHierarchyEntity> policyDetailsEntityRoot ;

        /** This is to get the count of records */
        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        policyDetailsEntityRoot = countQuery.from(LocationHierarchyEntity.class);

        predicateList = applySearchFilters(criteriaBuilder, predicateList, policyDetailsEntityRoot, dto);

        countQuery.select(criteriaBuilder.count(policyDetailsEntityRoot));
        countQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));
        long count = em.createQuery(countQuery).getSingleResult();
        retData.setCount(count);
        /***********************************/


        /** This is to get the list based on the page and limit *******/

        //Clear out the predicateList created using the count root
        predicateList.clear();

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<LocationHierarchyEntity> listCriteriaQuery = criteriaBuilder.createQuery(LocationHierarchyEntity.class);

        policyDetailsEntityRoot = listCriteriaQuery.from(LocationHierarchyEntity.class);

        listCriteriaQuery.select(policyDetailsEntityRoot);
        predicateList = applySearchFilters(criteriaBuilder, predicateList, policyDetailsEntityRoot, dto);

        listCriteriaQuery.where( criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));

        String sortByColumn = LocationHierarchyAssembler.getSortByColumn(dto.getPagination().getSortBy());

        Order order;
        if("asc".equals( dto.getPagination().getSortType())){
            order = criteriaBuilder.asc(policyDetailsEntityRoot.get(sortByColumn));
        } else {
            order = criteriaBuilder.desc(policyDetailsEntityRoot.get(sortByColumn));
        }

        TypedQuery<LocationHierarchyEntity> query = em.createQuery(listCriteriaQuery.orderBy(order))
                .setFirstResult((dto.getPagination().getPage() - 1) * dto.getPagination().getLimit())
                .setMaxResults(dto.getPagination().getLimit());
        retData.setData(query.getResultList());
        /***********************************/


        return retData;
    }


    default List<Predicate> applySearchFilters(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Root<LocationHierarchyEntity> policyDetailsEntityRoot, LocationHierarchyDto dto)throws AuthException {

        predicateList.add(criteriaBuilder.equal(policyDetailsEntityRoot.get(BaseEntity.COLUMN_NAME_IS_DELETED), GlobalYesNoEnum.NO.getValue()));

        predicateList.add(criteriaBuilder.equal(policyDetailsEntityRoot.get(LocationHierarchyEntity.COLUMN_NAME_PARENT_ID), dto.getParentId()));


        //Adding filter for name if present
        if (Optional.ofNullable(dto.getName()).isPresent() && !dto.getName().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.like(policyDetailsEntityRoot.get(LocationHierarchyEntity.COLUMN_NAME_NAME), "%"+dto.getName()+"%"));
        }

        return predicateList;
    }
}
