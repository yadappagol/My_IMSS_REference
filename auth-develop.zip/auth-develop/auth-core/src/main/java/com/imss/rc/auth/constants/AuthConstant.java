package com.imss.rc.auth.constants;

public class AuthConstant {
    public static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    public static final String MASK_EMAIL="(?<=.{3}).(?=[^@]*?@)";
    public static final String STAR="*";
    public static final String PASSWORD="password";
    public static final String NULL=null;
    public static final boolean FALSE=false;
    public static final Integer NULL_VALUE=null;
    public static final int ZERO=0;
    public static final int TEN=10;
    public static final boolean TRUE=true;
    public static final String SECRET_KEY ="auth";

    public static final String USER_LOGGED_IN_PWD = "User logged in using the password.";
    public static final String USER_LOGGED_IN_TOKEN = "User logged in using the iBKart token.";
    public static final String CREATED_USER = "User '%s' was created.";
    public static final String EDIT_USER = "Details of user '%s' was edited.";
    public static final String VIEW_USER_LIST = "Retrieved page %s with limit of %s records of users list sorted by %s in %s order, total of %s records were found.";
    public static final String VIEW_USER = "Details of user %s was viewed.";
    public static final String DELETED_USER = "User '%s' has been deleted successfully.";

    public static final String CREATED_ROLES = "Role '%s' was created.";
    public static final String EDITED_ROLES = "Details of role '%s' was edited";
    public static final String VIEW_ROLES_LIST = "Retrieved page %s with limit of %s records of user roles list sorted by %s in %s order, total of %s records were found.";
    public static final String VIEW_ROLE = "Details of role '%s' was viewed";
    public static final String DELETED_ROLE= "Role '%s' was deleted successfully.";
    public static final String VIEW_LOCATIONS = "Retrieved page %s with limit of %s records of locations list sorted by %s in %s order, total of %s records were found.";
    public static final String VIEW_MEMBERS ="Users retrieved for the role" ;

    public static final String SUCCESS_MESSAGE ="Temporary password sent to email successfully";
    public static final String RESET_PASSWORD_SUCCESS_MESSAGE ="Password reset successfully";
    public static final String USER_SIGNUP_SUCCESSFUL = "User Signup successful";
    public static final String UPDATE_PASSWORD_SUCCESS_MESSAGE = "Updated password successfully";
}
