package com.imss.rc.auth.controller;

import com.imss.rc.auth.dto.*;
import com.imss.rc.auth.dto.external.KeycloakTokenDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.dto.AuthResponseDto;
import com.imss.rc.auth.dto.AuthUserDto;
import com.imss.rc.auth.dto.LoginDto;
import com.imss.rc.auth.dto.TokenDto;
import com.imss.rc.commons.dto.BaseListDto;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;

public interface AuthController {

    @PostMapping(value = "/login/token", produces = "application/json")
    public @ResponseBody
    AuthResponseDto verifyToken(@RequestBody TokenDto tokenDto, HttpServletResponse response, HttpServletRequest request) throws AuthException;

    @PostMapping(value = "/login/username", produces = "application/json")
    public @ResponseBody AuthResponseDto login(@RequestBody LoginDto loginDto) throws AuthException;

    @GetMapping(value = "/token/verify", produces = "application/json")
    public @ResponseBody AuthResponseDto verifyAuthToken( HttpServletResponse response, HttpServletRequest request) throws AuthException;

    @GetMapping(value = "/login/users", produces = "application/json")
    public BaseListDto<AuthUserDto> getUserList(@RequestParam Integer page,
                                                @RequestParam Integer limit,
                                                @RequestParam(required = false) String sortBy,
                                                @RequestParam(required = false) String sortType,
                                                @RequestParam(required = false) boolean briefRepresentation,
                                                @RequestParam(required = false) String email,
                                                @RequestParam(required = false) String firstName,
                                                @RequestParam(required = false) String lastName,
                                                @RequestParam(required = false)String search,
                                                @RequestParam(required = false)String username,
                                                HttpServletRequest request) throws AuthException, MalformedURLException;

    @PutMapping(value = "/reset-password", produces = "application/json")
    public UserResetPasswordDto resetUserPassword(@RequestBody PasswordResetValueDto body, HttpServletRequest request) throws AuthException, IOException;

    @GetMapping(value = "/reset-password/{userName}", produces = "application/json")
    public UserResetPasswordDto getTemporaryPassword(@PathVariable("userName") String userName, HttpServletRequest request) throws AuthException, IOException;

    @GetMapping(value = "/my/profile", produces = "application/json")
    public UserDetailsDto getUserProfile(HttpServletRequest request) throws AuthException, IOException;

    @PostMapping(value = "/login/new/access-token", produces = "application/json")
    public KeycloakTokenDto getNewAccessToken(@RequestBody TokenDto tokenDto) throws AuthException;

    @PostMapping(value = "/short-token", produces = "application/json")
    public UserShortTokenDto getShortToken(HttpServletRequest request) throws AuthException;

    @PutMapping(value = "/short-token/verify", produces = "application/json")
    public UserShortTokenDto verifyShortToken(@RequestBody UserShortTokenDto dto,HttpServletRequest request) throws AuthException;

    @PutMapping(value = "/my/profile", produces = "application/json")
    public AuthUserDto editUserProfileImage(@RequestBody AuthUserDto dto,HttpServletRequest request) throws AuthException, IOException;

    @GetMapping(value = "/login/profile/{userName}", produces = "application/json")
    public UserDetailsDto viewUserProfile(@PathVariable("userName") String userName, HttpServletRequest request) throws AuthException;

    @PutMapping(value = "/update-password", produces = "application/json")
    public @ResponseBody UserResetPasswordDto updatePassword(@RequestBody PasswordResetValueDto body,  HttpServletRequest request) throws AuthException, IOException;


}
