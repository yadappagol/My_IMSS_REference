package com.imss.rc.auth.service;

import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.enums.AuditEnum;
import com.imss.rc.auth.assembler.LocationHierarchyAssembler;
import com.imss.rc.auth.constants.AuthConstant;
import com.imss.rc.auth.dto.LocationHierarchyDto;
import com.imss.rc.auth.entity.LocationHierarchyEntity;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.util.KafkaSendAuthMessage;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.auth.repository.LocationHierarchyRepository;
import com.imss.rc.commons.enums.ActionTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import java.util.Date;

@Service
public class LocationServiceImpl implements  LocationService{

    private static final Logger LOG = LoggerFactory.getLogger(LocationServiceImpl.class);

    @Autowired
    LocationHierarchyRepository locationHierarchyRepository;

    @Autowired
    LocationHierarchyAssembler locationHierarchyAssembler;

    @Autowired
    private EntityManager em;

    @Autowired
    KafkaSendAuthMessage kafkaSendMessage;

    public BaseListDto<LocationHierarchyDto> getLocations(LocationHierarchyDto dto ) throws AuthException {

        BaseListDto<LocationHierarchyDto> dataListDto = new BaseListDto<>();

        try{
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            Date date=new Date();
            //If the order by is blank then setting it to default by asc
            if(dto.getPagination().getSortType() == null || dto.getPagination().getSortType().isEmpty()){
                dto.getPagination().setSortType("asc");
            }

            //If the sort by is blank then set the default sort by column to name and order by asc
            if(dto.getPagination().getSortBy() == null || dto.getPagination().getSortBy().isEmpty()){
                dto.getPagination().setSortBy("name");
                dto.getPagination().setSortType("asc");
            }

            PageableEntity<LocationHierarchyEntity> data = locationHierarchyRepository.getAllLocationWithFilters(em, dto);

            PaginationDto pageDto = dto.getPagination();
            pageDto.setCount(data.getCount());

            dataListDto.setPagination(pageDto);
            dataListDto.setDataList(locationHierarchyAssembler.entityListToDtoList(data.getData()));
            dataListDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            dataListDto.setResponseCode(String.valueOf(HttpStatus.OK.value()));
            dataListDto.setAuditEventId(AuditEnum.USER_MANAGEMENT.getValue());

            //auditing the updates made
            auditMasterDto.setEventId(AuditEnum.USER_MANAGEMENT.getValue());
            auditMasterDto.setWhen(dto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(dto.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(dto.getCreatedBy());
            auditMasterDto.setDescription(String.format(AuthConstant.VIEW_LOCATIONS,
                    dataListDto.getPagination().getPage(),
                    dataListDto.getPagination().getLimit(),
                    dataListDto.getPagination().getSortBy(),
                    dataListDto.getPagination().getSortType(),
                    dataListDto.getPagination().getCount())
            );
            kafkaSendMessage.sendMessage(auditMasterDto);

        } catch (AuthException ex){
            throw ex;
        } catch (RuntimeException ex){
            LOG.error("Error while getting locations ", ex);
            throw new AuthException(AuthException.UNABLE_TO_LOAD_LOCATIONS,HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return dataListDto;
    }
}
