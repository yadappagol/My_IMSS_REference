package com.imss.rc.auth.repository;

import com.imss.rc.auth.entity.UserShortTokenEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserShortTokenRepository extends JpaRepository<UserShortTokenEntity, Integer> {

    @Query(value="from UserShortTokenEntity st where st.shortToken= :shortToken")
    public UserShortTokenEntity findByShortToken(@Param("shortToken") String shortToken);
}
