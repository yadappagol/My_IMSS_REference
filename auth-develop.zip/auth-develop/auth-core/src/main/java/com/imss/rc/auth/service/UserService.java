package com.imss.rc.auth.service;

import com.imss.rc.auth.dto.AuthUserDto;
import com.imss.rc.auth.dto.PasswordResetValueDto;
import com.imss.rc.auth.dto.UserActivationPasswordDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.dto.UserRegistrationDto;
import com.imss.rc.commons.dto.BaseListDto;

public interface UserService {

    public AuthUserDto viewUser(AuthUserDto dto) throws AuthException;

    public AuthUserDto deleteUser(AuthUserDto dto) throws AuthException;

    public AuthUserDto createUser(AuthUserDto dto) throws AuthException;

    public AuthUserDto updateUser(String id, AuthUserDto dto) throws AuthException;

    public UserActivationPasswordDto activatePassword(PasswordResetValueDto dto) throws AuthException;

    public UserRegistrationDto userRegistration(UserRegistrationDto dto)throws AuthException;

    public AuthUserDto signupUser(PasswordResetValueDto dto);

    public BaseListDto<AuthUserDto> getUsersByUserType(AuthUserDto dto) throws AuthException;

    public BaseListDto<AuthUserDto> getUsersByAttributes(AuthUserDto dto) throws AuthException;
}
