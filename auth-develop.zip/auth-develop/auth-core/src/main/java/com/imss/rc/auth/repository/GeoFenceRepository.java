package com.imss.rc.auth.repository;

import com.imss.rc.auth.entity.AuthGeoFenceResultEntity;
import com.imss.rc.auth.exception.AuthException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import java.util.List;
import static com.imss.rc.auth.entity.AuthGeoFenceResultEntity.*;

@Repository
public class GeoFenceRepository {

    private static final Logger LOGGER = LoggerFactory.getLogger(GeoFenceRepository.class);
    @PersistenceContext
    private EntityManager em;

    public boolean isSignUpLocationInGeoFence(String signupLocation, String geoFence){

        try{
            em.clear();

            StoredProcedureQuery dashboardDataQuery = em.createNamedStoredProcedureQuery(PROCEDURE_GET_IS_SIGNUP_LOCATION_IN_GEO_FENCE);

            String locationParts[] = signupLocation.split(",");

            dashboardDataQuery.setParameter(PROCEDURE_IN_SIGNUP_LOCATION_LONG, locationParts[0]);
            dashboardDataQuery.setParameter(PROCEDURE_IN_SIGNUP_LOCATION_LAT, locationParts[1]);
            dashboardDataQuery.setParameter(PROCEDURE_IN_GEO_FENCE, geoFence);

            dashboardDataQuery.execute();
            List<AuthGeoFenceResultEntity> geoFenceReuslts = dashboardDataQuery.getResultList();

            if(!geoFenceReuslts.isEmpty() && Boolean.parseBoolean(geoFenceReuslts.get(0).getIsInside()) ){
                return true;
            } else {
                return false;
            }

        } catch(Exception ex){
            LOGGER.error("Error while checking signup location in geo-fence", ex);
            throw new AuthException(AuthException.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }
}
