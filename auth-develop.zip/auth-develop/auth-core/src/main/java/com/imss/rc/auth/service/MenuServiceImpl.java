package com.imss.rc.auth.service;

import com.imss.rc.auth.cache.AuthLocalCache;
import com.imss.rc.auth.dto.AuthRealmRoleDto;
import com.imss.rc.auth.dto.MenuDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.ResponseDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class MenuServiceImpl implements MenuService{
    private static final Logger LOGGER = LoggerFactory.getLogger(MenuServiceImpl.class);

    public BaseListDto<MenuDto> getAllMenus()throws AuthException {

        BaseListDto<MenuDto> dataListDto = new BaseListDto<>();

        try{

            ArrayList<MenuDto> menuList = new ArrayList<>();
            MenuDto menuDto;

            for(AuthRealmRoleDto authRealmDto : AuthLocalCache.getAllRealmRoles()){
                if (authRealmDto.getParent() == null || authRealmDto.getParent().isEmpty()) {
                    menuDto = new MenuDto();


                    menuDto.setId(authRealmDto.getId());
                    menuDto.setName(authRealmDto.getName());
                    menuDto.setDisplayKey(authRealmDto.getDisplayKey());
                    menuDto.setType(authRealmDto.getType());
                    menuDto.setIcon(authRealmDto.getIcon());
                    menuDto.setLink(authRealmDto.getLink());
                    menuDto.setParent(authRealmDto.getParent());
                    menuDto.setOrder(authRealmDto.getOrder());
                    menuDto.setChildren(getMenusForParent(authRealmDto.getName()));
                    menuDto.setUiCategory(authRealmDto.getUiCategory());


                    //If the children is empty, then the object can be removed
                    if (menuDto.getChildren().size() == 0) {
                        menuDto.setChildren(null);
                    }

                    menuList.add(menuDto);
                }
            }

            MenuDto.sort(menuList);
            dataListDto.setDataList(menuList);
            dataListDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            dataListDto.setResponseCode(String.valueOf(HttpStatus.OK.value()));

        } catch (AuthException ex){
            throw ex;
        } catch (RuntimeException ex){
            LOGGER.error("Error while getting locations ", ex);
            throw new AuthException(AuthException.UNABLE_TO_LOAD_MENUS,HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return dataListDto;
    }

    /**
     * This is a recursive method to get all the menus and its children
     * @param parentId The parentId for which the menu details need to be retrieved
     * @return The menu details for the parent id passed
     */
    private ArrayList<MenuDto> getMenusForParent(String parentId){
        ArrayList<MenuDto> menuList = new ArrayList<>();
        MenuDto menuDto;
        for(AuthRealmRoleDto authRealmDto : AuthLocalCache.getAllRealmRoles()){
            if(authRealmDto.getParent() != null && authRealmDto.getParent().equals(parentId)){
                menuDto = new MenuDto();

                menuDto.setId(authRealmDto.getId());
                menuDto.setName(authRealmDto.getName());
                menuDto.setDisplayKey(authRealmDto.getDisplayKey());
                menuDto.setType(authRealmDto.getType());
                menuDto.setIcon(authRealmDto.getIcon());
                menuDto.setLink(authRealmDto.getLink());
                menuDto.setParent(authRealmDto.getParent());
                menuDto.setOrder(authRealmDto.getOrder());
                menuDto.setChildren(getMenusForParent(authRealmDto.getName()));
                menuDto.setUiCategory(authRealmDto.getUiCategory());
                //If the children is empty, then the object can be removed
                if(menuDto.getChildren().size() == 0){
                    menuDto.setChildren(null);
                }

                menuList.add(menuDto);
            }
        }
        MenuDto.sort(menuList);
        return menuList;
    }
}
