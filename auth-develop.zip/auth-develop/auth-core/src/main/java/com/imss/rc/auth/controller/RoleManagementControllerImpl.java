package com.imss.rc.auth.controller;

import com.imss.rc.auth.dto.AuthResponseRolesDto;
import com.imss.rc.auth.dto.AuthRolesDto;
import com.imss.rc.auth.dto.AuthUserDto;
import com.imss.rc.auth.dto.external.KeycloakRolesDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.service.RoleManagementService;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
public class RoleManagementControllerImpl implements RoleManagementController {

    @Autowired
    RoleManagementService roleManagementService;

    @Override
    public AuthResponseRolesDto getRole(String id, HttpServletRequest request) throws AuthException {
        AuthResponseRolesDto authResponseRolesDto=new AuthResponseRolesDto();
        authResponseRolesDto.setRoleId(id);
        //Loading the auth user into the dto
        UserAuthDataHandler.resolveAuthBaseData(authResponseRolesDto, request);
        return roleManagementService.getRole(id,authResponseRolesDto);
    }

    @Override
    public AuthResponseRolesDto deleteRole(String id, HttpServletRequest request) throws AuthException {
        AuthResponseRolesDto authResponseRolesDto=new AuthResponseRolesDto();
        authResponseRolesDto.setRoleId(id);
        //Loading the auth user into the dto
        UserAuthDataHandler.resolveAuthBaseData(authResponseRolesDto, request);
        return roleManagementService.deleteRole(id,authResponseRolesDto);
    }

    @Override
    public AuthResponseRolesDto createRole(KeycloakRolesDto dto, HttpServletRequest request) throws AuthException {
        AuthResponseRolesDto authResponseRolesDto=new AuthResponseRolesDto();
        //Loading the auth user into the dto
        UserAuthDataHandler.resolveAuthBaseData(authResponseRolesDto, request);
        return roleManagementService.createRole(dto,authResponseRolesDto);
    }

    @Override
    public AuthResponseRolesDto updateRole(String id, KeycloakRolesDto dto, HttpServletRequest request) throws AuthException {
        AuthResponseRolesDto authResponseRolesDto=new AuthResponseRolesDto();
        //Loading the auth user into the dto
        UserAuthDataHandler.resolveAuthBaseData(authResponseRolesDto, request);
        dto.setId(id);
        return roleManagementService.updateRole(dto,authResponseRolesDto);
    }

    @Override
    public BaseListDto<AuthResponseRolesDto> getAllRoles(Integer page, Integer limit, String roleName, String sortBy, String sortType, HttpServletRequest request) throws AuthException {
        KeycloakRolesDto dto=new KeycloakRolesDto();
        PaginationDto pageDto = new PaginationDto();
        if(page< GlobalYesNoEnum.YES.getValue()){
            throw new AuthException(AuthException.INVALID_PAGE, HttpStatus.BAD_REQUEST);
        }
        if(limit< GlobalYesNoEnum.YES.getValue()){
            throw new AuthException(AuthException.INVALID_LIMIT, HttpStatus.BAD_REQUEST);
        }
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);
        dto.setPagination(pageDto);
        if(roleName!=null){
            dto.setName(roleName);
        }
        AuthResponseRolesDto authResponseRolesDto=new AuthResponseRolesDto();
        //Loading the auth user into the dto
        UserAuthDataHandler.resolveAuthBaseData(authResponseRolesDto, request);
        return roleManagementService.getAllRoles(dto,authResponseRolesDto);
    }

    @Override
    public BaseListDto<AuthRolesDto> getRealmRoleMap(String id , HttpServletRequest request) throws AuthException {
        return roleManagementService.getRealmRoleMap(id);
    }

    @Override
    public BaseListDto<AuthUserDto> getRoleUsers(String id, HttpServletRequest request) throws AuthException {
        AuthUserDto authUserDto=new AuthUserDto();
        //Loading the auth user into the dto
        UserAuthDataHandler.resolveAuthBaseData(authUserDto, request);
        return roleManagementService.getRoleUsers(id,authUserDto);
    }

}
