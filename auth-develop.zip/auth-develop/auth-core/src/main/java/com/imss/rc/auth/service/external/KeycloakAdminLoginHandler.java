package com.imss.rc.auth.service.external;

import com.imss.rc.auth.dto.external.KeycloakTokenDto;

/**
 * This class is used to handle the call to get the admin token for making the API calls to keycloak
 * Made it as a separate class so that it is static and the same is used by all the objects so as to
 * avoid the re-login multiple times
 */
public class KeycloakAdminLoginHandler {
    private KeycloakAdminLoginHandler (){

    }
    private static String adminUserName;
    private static String adminPassword;
    private static KeycloakIntegration keycloakIntegration;
    private static boolean isInit = false;
    private static KeycloakTokenDto adminTokenDto ;
    public static void init(String adminUserNameVal, String adminPasswordVal, KeycloakIntegration keycloakIntegrationObj){
        if(!isInit) {
            adminUserName = adminUserNameVal;
            adminPassword = adminPasswordVal;
            keycloakIntegration = keycloakIntegrationObj;
            isInit = true;
        }
    }

    public static String getAdminToken(){
        if(adminTokenDto == null) {
            //If the dto is not available do a login process to get the token dto
            adminTokenDto = keycloakIntegration.validateUserAndGetToken(adminUserName, adminPassword, false);
        } else if((adminTokenDto.getTokenGeneratedTime()+adminTokenDto.getExpiresIn()*1000) < System.currentTimeMillis() ){
            //If the token is expired then do the login again
            adminTokenDto = keycloakIntegration.validateUserAndGetToken(adminUserName, adminPassword, false);
        }

        return adminTokenDto.getAccessToken();
    }

}
