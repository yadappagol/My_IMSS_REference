package com.imss.rc.auth.service;

import com.imss.rc.auth.dto.LocationHierarchyDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.commons.dto.BaseListDto;

public interface LocationService {
    BaseListDto<LocationHierarchyDto> getLocations(LocationHierarchyDto dto ) throws AuthException;
}
