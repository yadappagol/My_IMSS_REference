package com.imss.rc.auth.controller;

import com.imss.rc.auth.dto.AuthResponseRolesDto;
import com.imss.rc.auth.dto.AuthRolesDto;
import com.imss.rc.auth.dto.AuthUserDto;
import com.imss.rc.auth.dto.external.KeycloakRolesDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.commons.dto.BaseListDto;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

public interface RoleManagementController {

    @GetMapping(value = "/login/roles/{id}", produces = "application/json")
    public @ResponseBody AuthResponseRolesDto getRole(@PathVariable("id")  String id, HttpServletRequest request)throws AuthException;

    @DeleteMapping(value = "/login/roles/{id}", produces = "application/json")
    public @ResponseBody AuthResponseRolesDto deleteRole(@PathVariable("id")  String id, HttpServletRequest request)throws AuthException;

    @PostMapping(value = "/login/roles", produces = "application/json")
    public @ResponseBody AuthResponseRolesDto createRole(@RequestBody KeycloakRolesDto dto, HttpServletRequest request)throws AuthException;

    @PutMapping(value = "/login/roles/{id}", produces = "application/json")
    public @ResponseBody AuthResponseRolesDto updateRole(@PathVariable("id")  String id, @RequestBody KeycloakRolesDto dto, HttpServletRequest request)throws AuthException;

    @GetMapping(value = "/login/roles", produces = "application/json")
    public BaseListDto<AuthResponseRolesDto> getAllRoles(@RequestParam Integer page,
                                                          @RequestParam Integer limit,
                                                          @RequestParam(required = false)String roleName,
                                                          @RequestParam(required = false) String sortBy,
                                                          @RequestParam(required = false) String sortType,
                                                          HttpServletRequest request)throws AuthException;


    @GetMapping(value = "/login/rolesMap/{groupId}", produces = "application/json")
    public @ResponseBody BaseListDto<AuthRolesDto> getRealmRoleMap(@PathVariable("groupId")  String id, HttpServletRequest request)throws AuthException;

    @GetMapping(value = "/login/roles/members/{groupId}", produces = "application/json")
    public @ResponseBody BaseListDto<AuthUserDto> getRoleUsers(@PathVariable("groupId")  String id, HttpServletRequest request)throws AuthException;

}


