package com.imss.rc.auth.service;

import com.imss.rc.auth.dto.*;
import com.imss.rc.auth.dto.external.KeycloakTokenDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.dto.AuthResponseDto;
import com.imss.rc.auth.dto.AuthUserDto;
import com.imss.rc.auth.dto.LoginDto;
import com.imss.rc.auth.dto.TokenDto;
import com.imss.rc.commons.dto.BaseListDto;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

public interface AuthService {

    public AuthResponseDto verifyToken(TokenDto tokenDto) throws AuthException;

    public AuthResponseDto login(LoginDto loginDto)  throws AuthException;

    public AuthResponseDto verifyAuthToken(LoginDto loginDto)  throws AuthException;

    public BaseListDto<AuthUserDto> getUserList(AuthUserDto dto, boolean briefRepresentation, String email, String firstName, String lastName, String search, String username)throws AuthException;

    public UserResetPasswordDto resetUserPassword(PasswordResetValueDto body) throws IOException;

   public UserResetPasswordDto getTemporaryPassword(String userName) throws IOException;

    public UserDetailsDto getUserProfile(HttpServletRequest request);

    public KeycloakTokenDto getNewAccessToken(TokenDto tokenDto) throws AuthException;

    public UserShortTokenDto getShortToken(UserShortTokenDto shortTokenDto) throws AuthException;

    public UserShortTokenDto verifyShortToken(UserShortTokenDto shortTokenDto) throws AuthException;

    public AuthUserDto editUserProfileImage(AuthUserDto dto, HttpServletRequest request);

    public UserDetailsDto viewUserProfile(String userName,HttpServletRequest httpServletRequest);

    public UserResetPasswordDto updatePassword(PasswordResetValueDto body, HttpServletRequest request);
}
