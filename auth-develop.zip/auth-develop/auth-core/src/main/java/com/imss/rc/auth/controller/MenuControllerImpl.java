package com.imss.rc.auth.controller;

import com.imss.rc.auth.dto.MenuDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.service.MenuService;
import com.imss.rc.commons.dto.BaseListDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RestController
public class MenuControllerImpl implements MenuController{

    @Autowired
    MenuService menuService;

    public BaseListDto<MenuDto> getAllMenus(HttpServletResponse response, HttpServletRequest request) throws AuthException {

        return menuService.getAllMenus();
    }

}
