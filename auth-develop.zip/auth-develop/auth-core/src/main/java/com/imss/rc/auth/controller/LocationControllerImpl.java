package com.imss.rc.auth.controller;

import com.imss.rc.auth.dto.LocationHierarchyDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.service.LocationService;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
public class LocationControllerImpl implements LocationController{


    @Autowired
    LocationService locationService;

    public BaseListDto<LocationHierarchyDto> getLocations(Integer page, Integer limit,
                                                          Integer parentId , String sortBy,
                                                          String sortType, String name, HttpServletRequest request) throws AuthException {

        LocationHierarchyDto dto = new LocationHierarchyDto();

        dto.setParentId(parentId);
        dto.setName(name);

        PaginationDto pageDto = new PaginationDto();
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);

        dto.setPagination(pageDto);

        //Loading the auth user into the dto
        UserAuthDataHandler.resolveAuthBaseData(dto, request);

        return  locationService.getLocations(dto);
    }
}
