package com.imss.rc.auth.service.external;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.auth.dto.*;
import com.imss.rc.auth.dto.external.*;
import com.imss.rc.auth.enums.*;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.util.AuthApplicationConstants;
import com.imss.rc.auth.assembler.AuthResponseRolesAssembler;
import com.imss.rc.auth.constants.AuthConstant;
import com.imss.rc.auth.assembler.AuthApiRoleAssembler;
import com.imss.rc.auth.assembler.AuthRealmRoleAssembler;
import com.imss.rc.auth.assembler.AuthUserAssembler;
import com.imss.rc.auth.assembler.KeyCloakAssembler;
import com.imss.rc.auth.repository.LocationHierarchyRepository;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.dto.UserLocationDto;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.*;


@Component
public class KeycloakIntegration {
    private static final Logger LOG = LoggerFactory.getLogger(KeycloakIntegration.class);

    /* Keycloak related properties */
    @Value("${keycloak.base.path}")
    private String keycloakBasePath;
    @Value("${keycloak.token-uri}")
    private String keycloakTokenUri;
    @Value("${keycloak.create.user.uri}")
    private String keycloakUserUri;
    @Value("${keycloak.client-id}")
    private String clientId;
    @Value("${keycloak.authorization-grant-type}")
    private String grantType;

    @Value("${keycloak.refreshToken-grant-type}")
    private String refreshGrantType;
    @Value("${keycloak.realm.brut.force.check.uri}")
    private String bruteForceCheckUri;
    @Value("${keycloak.client-secret}")
    private String clientSecret;
    @Value("${keycloak.scope}")
    private String scope;
    @Value("${keycloak.admin.username}")
    private String adminUser;
    @Value("${keycloak.admin.password}")
    private String adminPassword;
    @Value("${keycloak.create.roles.uri}")
    private String keycloakRoleUri;
    @Value("${keycloak.master.token-uri}")
    private String keycloakMasterTokenUri;
    @Value("${keycloak.master.client-id}")
    private String masterClientId;
    @Value("${keycloak.create.groups.uri}")
    private String keycloakGroupUri;
    @Value("${keycloak.client.roles.uri}")
    private String keycloakClientRolesUri;
    @Value("${keycloak.realm.roles.uri}")
    private String keycloakRealmRolesUri;
    @Value("${keycloak.menu.source}")
    private String keycloakMenuSource;
    @Value("${user.default.signup.role}")
    private String userSignupRole;
    @Value("${user.default.usertype}")
    private String userType;
    @Value("${keycloak.custom.search.user.uri}")
    private String keycloakCustomSearch;
    @Value("${keycloak.user.attribute.filter.uri}")
    private String keycloakAttributeFilter;


    @Autowired
    LocationHierarchyRepository locationHierarchyRepository;

    @Autowired
    @Qualifier("authCoreRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    KeyCloakAssembler keyCloakAssembler;

    @Autowired
    AuthUserAssembler authUserAssembler;

    @Autowired
    AuthResponseRolesAssembler authResponseRolesAssembler;

    @Autowired
    AuthApiRoleAssembler authApiRoleAssembler;

    @Autowired
    AuthRealmRoleAssembler authRealmRoleAssembler;

    private String adminToken;

    private void initAdminToken(){
        KeycloakAdminLoginHandler.init(adminUser, adminPassword,this);
        adminToken = KeycloakAdminLoginHandler.getAdminToken();
    }

    /**
     * This method does the following
     * 1. Creates the district in location hierarchy table if not already present
     * 2. Resolves the location ids
     * 3. Creates the user in Keycloak if not already present
     * 4. GEts the access token for that user using the exchange token option of Keycloak
     *
     * @param dto The user details as received from IBKart
     * @return The access token of the user if all the steps went well else AuthException will be thrown
     */
    public String checkAndCreateUserAndGetToken(IbkartBdDetailsDto dto) {

        /*
         * Get the token for the admin user which will be used for
         * creating the user and also for generating the exchange token
         */
        initAdminToken();
        String userName = String.valueOf(dto.getBd_id());

        if (!checkIfUserExistsInKeycloak(userName, adminToken)) {
            LOG.debug("User does not exist in key cloak... Going to create the user");

            //User does not exist in keycloak hence need to be created

            KeycloakUserDto userDto = new KeycloakUserDto();

            UserLocationDto locDto = locationHierarchyRepository.checkAndCreateLocation(dto.getState(), dto.getDistrict());

            Map<String, String> attributes = new HashMap<>();

            attributes.put(KeycloakUserAttributesEnum.LEVEL_1_ID.getValue(), dto.getLevel1_id());
            attributes.put(KeycloakUserAttributesEnum.LEVEL_1_NAME.getValue(), dto.getLevel1_name());
            attributes.put(KeycloakUserAttributesEnum.LEVEL_2_ID.getValue(), dto.getLevel2_id());
            attributes.put(KeycloakUserAttributesEnum.LEVEL_2_NAME.getValue(),dto.getLevel2_name());
            attributes.put(KeycloakUserAttributesEnum.LEVEL_3_ID.getValue(), dto.getLevel3_id());
            attributes.put(KeycloakUserAttributesEnum.LEVEL_3_NAME.getValue(),dto.getLevel3_name());
            attributes.put(KeycloakUserAttributesEnum.SP_CODE.getValue(), dto.getSp_code());
            attributes.put(KeycloakUserAttributesEnum.SP_NAME.getValue(), dto.getSp_name());
            attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_1_ID.getValue(), String.valueOf(locDto.getLevel1Id()));
            attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_2_ID.getValue(), String.valueOf(locDto.getLevel2Id()));
            attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_3_ID.getValue(), String.valueOf(locDto.getLevel3Id()));
            attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_4_ID.getValue(), String.valueOf(locDto.getLevel4Id()));

            userDto.setUsername(dto.getBd_id());
            userDto.setFirstName(dto.getBd_name());
            userDto.setAttributes(attributes);
            userDto.setOrigin(AuthApplicationConstants.DATA_ORIGIN_IBKART);


            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
            httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

            HttpEntity<KeycloakUserDto> request = new HttpEntity<>(userDto, httpHeaders);

            //Call to create new user
            //Map resMap = restTemplate.postForObject(keycloakBasePath+keycloakCreateUserUri, request, Map.class);

            //Call to create new user
            ResponseEntity<Map> out = restTemplate.exchange(keycloakBasePath + keycloakUserUri,
                    HttpMethod.POST, request, Map.class);

            Map resMap = out.getBody();

            if (!out.getStatusCode().is2xxSuccessful()) {
                throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, new String[]{getErrorStringFromMap(resMap)}, HttpStatus.BAD_REQUEST);
            }

            LOG.debug("User created successfully in keycloak");
        } else {
            LOG.debug("User already exists in keycloak... Going to update the user");
            //User already exist in keycloak hence need to be updated
            //TODO: Write code to update user
        }

        return getExchangeTokenBasedOnUser(userName, adminToken);
    }

    /**
     * This method calls the Keycloak REST API to check if the user exists based on the user name
     *
     * @param username   The user name which is used to check
     * @param adminToken The admin token to access the REST API
     * @return true if the user already exists, false otherwise, Throws AuthException if any error occured
     */
    private boolean checkIfUserExistsInKeycloak(String username, String adminToken) {

        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakUserUri);
        uriBuilder.append("?exact=true&username=").append(username);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

        HttpEntity<KeycloakUserDto> request = new HttpEntity<>(httpHeaders);

        ResponseEntity<List> out = restTemplate.exchange(uriBuilder.toString(), HttpMethod.GET, request, List.class);
        List resMap = out.getBody();

        if (out.getStatusCode().is2xxSuccessful()) {
            if (resMap != null && resMap.size() == 1) {
                return true;
            } else {
                return false;
            }
        } else {
            throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, new String[]{""}, HttpStatus.BAD_REQUEST);
        }
    }

    public List<AuthUserDto> userList(AuthUserDto dto, boolean briefRepresentation, String email, String firstName, String lastName, String search, String username) {
        initAdminToken();

        ModelMapper mapper = new ModelMapper();
        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakUserUri);

        MultiValueMap<String,String> multiValueMap=new LinkedMultiValueMap();
        if(briefRepresentation)
            multiValueMap.add("briefRepresentation", "true");
        else
            multiValueMap.add("briefRepresentation", "false");
        if(email!=null)
            multiValueMap.add("email", email);
        if(dto.getPagination()!=null) {
            int page = dto.getPagination().getPage();
            int limit = dto.getPagination().getLimit();
            int first = ((page - 1) * limit);
            multiValueMap.add("first", String.valueOf(first));
            multiValueMap.add("max", String.valueOf(limit));
        }
        if(firstName!=null)
            multiValueMap.add("firstName", firstName);
        if(lastName!=null)
            multiValueMap.add("lastName", lastName);
        if(search!=null)
            multiValueMap.add("search", search);
        if(username!=null)
            multiValueMap.add("username", username);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString()).queryParams(multiValueMap);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

        HttpEntity<KeycloakUserDto> request = new HttpEntity<>(httpHeaders);
        ResponseEntity<List<Object>> out = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request, new ParameterizedTypeReference<List<Object>>() {
        });
        List<Object> key = out.getBody();
        List<KeycloakUserDto> userDto = mapper.map(key, new TypeToken<List<KeycloakUserDto>>() {}.getType());
        List<AuthUserDto> authUserDtoList =authUserAssembler.keyCloakListToAuthUserList(userDto);
        for(AuthUserDto authUserDto:authUserDtoList){
           List<String> groupNames= viewAssignedRoleToUser(authUserDto.getKeyCloakId());
           authUserDto.setRoles(String.valueOf(groupNames).replace("[","").replace("]",""));

        }
        return authUserDtoList;
    }


    public String resetPassword(String userId, ResetPasswordBodyDto body) {
        try {
            initAdminToken();
            StringBuilder uriBuilder = new StringBuilder();
            uriBuilder.append(keycloakBasePath);
            uriBuilder.append(keycloakUserUri);
            uriBuilder.append("/").append(userId);
            uriBuilder.append("/reset-password");
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
            httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);
            JSONObject json = new JSONObject(body);
            String payload = json.toString();
            HttpEntity<String> request = new HttpEntity<>(payload, httpHeaders);
            ResponseEntity<String> response = restTemplate.exchange(uriBuilder.toString(), HttpMethod.PUT, request, String.class);
            String resMap = response.getBody();
            if (response.getStatusCode().is2xxSuccessful()) {
                return resMap;
            } else {
                throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, new String[]{""}, HttpStatus.BAD_REQUEST);
            }
        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(), e);
            throw new AuthException(AuthException.PASSWORD_NOT_SET, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private String getErrorStringFromMap(Map respMap) {
        if (respMap.get("error_description") != null) {
            return (String) respMap.get("error_description");
        } else if (respMap.get("error") != null) {
            return (String) respMap.get("error");
        } else {
            return "";
        }
    }

    /**
     * @param userName for which getting keycloak exchange token for IBKart user
     * @param adminToken  for which getting keycloak exchange token for IBKart user
     * @return String
     */
    private String getExchangeTokenBasedOnUser(String userName, String adminToken) {

        LOG.debug("Getting keycloak exchange token for IBKart user {}", userName);

        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();

        map.add(KeycloakHeadersEnum.CLIENT_ID.getValue(), clientId);
        map.add(KeycloakHeadersEnum.GRANT_TYPE.getValue(), "urn:ietf:params:oauth:grant-type:token-exchange");
        map.add(KeycloakHeadersEnum.CLIENT_SECRET.getValue(), clientSecret);
        map.add(KeycloakHeadersEnum.SCOPE.getValue(), scope);
        map.add(KeycloakHeadersEnum.SUBJECT_TOKEN.getValue(), adminToken);
        map.add(KeycloakHeadersEnum.REQUESTED_TOKEN_TYPE.getValue(), "urn:ietf:params:oauth:token-type:access_token");
        map.add(KeycloakHeadersEnum.AUDIENCE.getValue(), clientId);
        map.add(KeycloakHeadersEnum.REQUESTED_SUBJECT.getValue(), userName);

        return callForToken(map, true).getAccessToken();
    }

    /**
     * This method will validate with Keycloak based on the user name and password
     * and return the access token if successful
     * @param username The user name to use to validate
     * @param password The password to use to validate
     * @param isApplicationLogin boolean value indicating if the call is during an application login event or not
     * @return The access token if the credentials were correct
     */
    public KeycloakTokenDto validateUserAndGetToken(String username, String password, boolean isApplicationLogin) {

        LOG.debug("Getting keycloak token for user {}", username);

        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add(KeycloakHeadersEnum.USERNAME.getValue(), username);
        map.add(KeycloakHeadersEnum.PASSWORD.getValue(), password);
        map.add(KeycloakHeadersEnum.CLIENT_ID.getValue(), clientId);
        map.add(KeycloakHeadersEnum.GRANT_TYPE.getValue(), grantType);
        map.add(KeycloakHeadersEnum.CLIENT_SECRET.getValue(), clientSecret);
        map.add(KeycloakHeadersEnum.SCOPE.getValue(), scope);

        return callForToken(map, isApplicationLogin);
    }

    /**
     *
     * @param map The map containing the data that needs to be submitted.
     * @param isApplicationLogin boolean value indicating if the call is during an application login event or not
     * @return
     */
    private KeycloakTokenDto callForToken(MultiValueMap<String, String> map, boolean isApplicationLogin) {
        try {

            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, new HttpHeaders());

            String retVal = restTemplate.postForObject(keycloakBasePath + keycloakTokenUri, request, String.class);

            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> responseData = mapper.readValue(retVal, Map.class);

            if (responseData.get("error") == null) {
                //If error keyword error is not found then get the access token and return it
                KeycloakTokenDto keycloakTokenDto = new KeycloakTokenDto();
                keycloakTokenDto.setTokenGeneratedTime(System.currentTimeMillis());
                String token = (String) responseData.get("access_token");
                String refreshToken = (String) responseData.get("refresh_token");
                if (token == null) {
                    throw new AuthException(AuthException.ACCESS_TOKEN_FOUND_NULL_IN_KEYCLOAK_RESPONSE, HttpStatus.INTERNAL_SERVER_ERROR);
                } else {
                    keycloakTokenDto.setAccessToken(token);
                    keycloakTokenDto.setRefreshToken(refreshToken);
                    keycloakTokenDto.setExpiresIn((int)responseData.get("expires_in"));
                    keycloakTokenDto.setRefreshExpiresIn((int)responseData.get("refresh_expires_in"));

                    LOG.debug("Keycloak auth token generated successfully");
                    return keycloakTokenDto;
                }
            } else {
                LOG.error("Error response from Keycloak : {} ({})", responseData.get("error"), responseData.get("error_description"));
                throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, new String[]{(String) responseData.get("error_description")}, HttpStatus.BAD_REQUEST);
            }

        } catch (HttpClientErrorException ex) {

            if((ex.getStatusCode() == HttpStatus.UNAUTHORIZED)){
                //If it was un authorized then it is invalid credentials so check if the user is temporarily blocked for a login action
                if(isApplicationLogin && isTempBlock(map.get(KeycloakHeadersEnum.USERNAME.getValue()).get(0) )) {
                    throw new AuthException(AuthException.TOO_MANY_INVALID_CREDENTIALS_USER_BLOCKED, new String[] {map.get(KeycloakHeadersEnum.USERNAME.getValue()).get(0)}, HttpStatus.BAD_REQUEST);
                } else {
                    throw new AuthException(AuthException.INVALID_CREDENTIALS, HttpStatus.BAD_REQUEST);
                }
            } else {
                LOG.error("exception : {} ", ex.getMessage(), ex);
                throw new AuthException(AuthException.ERROR_OCCURRED, HttpStatus.BAD_REQUEST);
            }

        } catch (RestClientException e) {
            LOG.error("exception : {} ", e.getMessage(), e);
            throw new AuthException(AuthException.UNAUTHORIZED_CLIENT, HttpStatus.BAD_REQUEST);
        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(), e);
            throw new AuthException(AuthException.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * This method makes a call to keycloak to check if the user is blocked
     * due to a brute force attack
     * @param username The user name for which the check needs to be done
     * @return true if the user is blocked, false otherwise
     */
    private boolean isTempBlock(String username){
        initAdminToken();

        //First need to get the user details based on the user name as the id is required
        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakUserUri);
        uriBuilder.append("?exact=true&username=").append(username);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

        HttpEntity<KeycloakUserDto> request = new HttpEntity<>(httpHeaders);

        ResponseEntity<List> out = restTemplate.exchange(uriBuilder.toString(), HttpMethod.GET, request, List.class);
        List resMap = out.getBody();

        if (out.getStatusCode().is2xxSuccessful()) {
            if (resMap != null && resMap.size() == 1) {
                ModelMapper mapper = new ModelMapper();
                List<Object> key = out.getBody();
                List<KeycloakUserDto> userDto = mapper.map(key, new TypeToken<List<KeycloakUserDto>>() {}.getType());

                //Now call the brut force check url to see the number of login attempts and blocked status
                uriBuilder.delete(0,uriBuilder.length());
                uriBuilder.append(keycloakBasePath);
                uriBuilder.append(bruteForceCheckUri).append(userDto.get(0).getId());

                HttpEntity<KeycloakBrutForceDetectDto> request2 = new HttpEntity<>(httpHeaders);

                ResponseEntity<Object> out2 = restTemplate.exchange(uriBuilder.toString(), HttpMethod.GET, request2, Object.class);
                Object key2 = out2.getBody();
                KeycloakBrutForceDetectDto bfDto = mapper.map(key2, KeycloakBrutForceDetectDto.class);

                return bfDto.getDisabled() != null && bfDto.getDisabled().booleanValue();

            } else {
                return false;
            }
        } else {
            throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, new String[]{""}, HttpStatus.BAD_REQUEST);
        }

    }


    /**
     * This method calls the Keycloak REST API to check if the user exists based on the user name
     *
     * @param email The user name which is used to check
     * @param adminToken The admin token to access the REST API
     * @return true if the user already exists, false otherwise, Throws AuthException if any error occured
     */
    private boolean checkIfEmailExistsInKeycloak(String email, String adminToken) {

        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakUserUri);
        uriBuilder.append("?exact=true&email=").append(email);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

        HttpEntity<KeycloakUserDto> request = new HttpEntity<>(httpHeaders);

        ResponseEntity<List> out = restTemplate.exchange(uriBuilder.toString(), HttpMethod.GET, request, List.class);
        List resMap = out.getBody();

        if (out.getStatusCode().is2xxSuccessful()) {
            if (resMap != null && resMap.size() == GlobalYesNoEnum.YES.getValue()) {
                return true;
            } else {
                return false;
            }
        } else {
            throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, new String[]{""}, HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * This method calls the Keycloak REST API to view the user based on the user id
     * @param id The user id which is used to view the user
     * @return AuthUserDto if the user exists else , Throws AuthException if any error occurred
     */
    public AuthUserDto viewUser(String id) {
        try{
            initAdminToken();

            ModelMapper mapper = new ModelMapper();
            StringBuilder uriBuilder = new StringBuilder();
            uriBuilder.append(keycloakBasePath);
            uriBuilder.append(keycloakUserUri);
            uriBuilder.append("/").append(id);

            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
            httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

            HttpEntity<KeycloakUserDto> request = new HttpEntity<>(httpHeaders);

            ResponseEntity<Object> keycloakUserDto = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request, Object.class);
            Object key = keycloakUserDto.getBody();
            ArrayList<String> roleNames = viewAssignedRoleToUser(id);
            KeycloakUserDto userDto = mapper.map(key, KeycloakUserDto.class);
            AuthUserDto authUserDto = authUserAssembler.keyCloakDtoToAuthUserDto(userDto);
            authUserDto.setRoles(String.valueOf(roleNames).replace("[", "").replace("]", ""));
            authUserDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            authUserDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            return authUserDto;
        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.USER_NOT_AVAILABLE, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * This method calls the Keycloak REST API to delete the user based on the user id
     * @param id The user id which is used to delete the user
     * @return AuthUserDto if the user exists else , Throws AuthException if any error occurred
     */
    public AuthUserDto deleteUser(String id) {
        initAdminToken();
        viewUser(id);
        AuthUserDto authUserDto = new AuthUserDto();

        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakUserUri);
        uriBuilder.append("/").append(id);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

        HttpEntity<KeycloakUserDto> request = new HttpEntity<>(httpHeaders);


        ResponseEntity<Object> result = restTemplate.exchange(builder.toUriString(), HttpMethod.DELETE, request, Object.class);

        if (!result.getStatusCode().is2xxSuccessful()) {
            throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, HttpStatus.BAD_REQUEST);
        }
        LOG.debug("User Deleted successfully in keycloak");
        authUserDto.setKeyCloakId(id);
        return authUserDto;

    }

    /**
     * This method calls the Keycloak REST API to create the user
     * @param dto contains the details of the user required to create the user
     * @return AuthUserDto if the user created successfully
     * @throws AuthException if any error occurred
     */
    public AuthUserDto createUser(AuthUserDto dto) throws AuthException {
        try {
            initAdminToken();

            Map<String, String> attributes = new HashMap<>();
            String email = dto.getEmail();
            String userName = dto.getUsername();
            if (!checkIfUserExistsInKeycloak(userName, adminToken)) {
                if (checkIfEmailExistsInKeycloak(email, adminToken)) {
                    LOG.error("Error response from Keycloak :");
                    throw new AuthException(AuthException.EMAIL_ALREADY_EXISTS, HttpStatus.BAD_REQUEST);
                }

                if(Objects.nonNull(dto.getLocationDto())) {
                    if (!StringUtils.isEmpty(dto.getLocationDto().getLevel1Id()) && !StringUtils.isEmpty(dto.getLocationDto().getLevel3Id())) {
                        UserLocationDto locDto = locationHierarchyRepository.checkAndCreateLocationById(dto.getLocationDto().getLevel3Id(), dto.getLocationDto().getLevel1Id());
                        attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_1_ID.getValue(), String.valueOf(locDto.getLevel1Id()));
                        attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_2_ID.getValue(), String.valueOf(locDto.getLevel2Id()));
                        attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_3_ID.getValue(), String.valueOf(locDto.getLevel3Id()));
                        attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_4_ID.getValue(), String.valueOf(locDto.getLevel4Id()));
                    } else
                        attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_1_ID.getValue(), dto.getLocationDto().getLevel1Id());
                        attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_2_ID.getValue(), dto.getLocationDto().getLevel2Id());
                }
                if(Objects.nonNull(dto.getUserType())) {
                    attributes.put(KeycloakUserAttributesEnum.USER_TYPE.getValue(), String.valueOf(dto.getUserType()));
                }
                else {
                    attributes.put(KeycloakUserAttributesEnum.USER_TYPE.getValue(), String.valueOf(UserEnum.USERS.getValue()));
                }
                attributes.put(KeycloakUserAttributesEnum.MOBILE_NUMBER.getValue(), String.valueOf(dto.getMobileNumber()));

                KeycloakUserDto keycloakUserDto = keyCloakAssembler.authUserToKeyCloakDto(dto);
                keycloakUserDto.setAttributes(attributes);
                keycloakUserDto.setEnabled(AuthConstant.TRUE);
                keycloakUserDto.setEmailVerified(AuthConstant.TRUE);
                StringBuilder uriBuilder = new StringBuilder();
                uriBuilder.append(keycloakBasePath);
                uriBuilder.append(keycloakUserUri);

                UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
                HttpHeaders httpHeaders = new HttpHeaders();
                httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
                httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

                HttpEntity<KeycloakUserDto> request = new HttpEntity<>(keycloakUserDto, httpHeaders);

                ResponseEntity<String> out = restTemplate.exchange(builder.toUriString(), HttpMethod.POST, request, String.class);
                String resMap = out.getBody();

                if (!out.getStatusCode().is2xxSuccessful()) {
                    throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, new String[]{resMap}, HttpStatus.BAD_REQUEST);
                }
                String headers = Objects.requireNonNull(out.getHeaders().getLocation()).toString();
                String id = headers.substring(headers.lastIndexOf("/") + 1);

                if(Objects.nonNull(dto.getRoles())) {
                    String[] roles = dto.getRoles().split(",");
                    for (String role : roles) {
                        AuthResponseRolesDto authResponseRolesDto = getRole(role);
                        if (Objects.nonNull(authResponseRolesDto)) {
                            assignRole(id, role);
                        } else
                            throw new AuthException(AuthException.ROLE_NOT_AVAILABLE, new String[]{dto.getRoles()}, HttpStatus.BAD_REQUEST);
                    }
                }
                AuthUserDto authUserDto=viewUser(id);
                authUserDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                authUserDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                return authUserDto;
            } else {
                LOG.error("Error response from Keycloak :");
                throw new AuthException(AuthException.USER_NAME_ALREADY_EXISTS, HttpStatus.BAD_REQUEST);
            }
        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(), e);
            throw new AuthException(AuthException.USER_NOT_CREATED, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * This method calls the Keycloak REST API to assign the roles to the user based on the user id and roleId
     * @param userId of the user for whom roleId roles to be assigned
     * @throws AuthException if any error occurred
     */
    public void assignRole(String userId, String groupId) {
    try{
        initAdminToken();

        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakUserUri);
        uriBuilder.append("/").append(userId);
        uriBuilder.append("/groups");
        uriBuilder.append("/").append(groupId);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer "+adminToken);

        HttpEntity<String> request = new HttpEntity<>(httpHeaders);

        ResponseEntity<String> response = restTemplate.exchange(uriBuilder.toString(), HttpMethod.PUT, request, String.class);
        if(!response.getStatusCode().is2xxSuccessful()) {
            throw new AuthException(AuthException.ROLES_NOT_ASSIGNED, new String[]{""}, HttpStatus.BAD_REQUEST);
        }
    } catch (AuthException ex) {
        throw ex;
    } catch (Exception e) {
        LOG.error("exception : {} ", e.getMessage(), e);
        throw new AuthException(AuthException.ROLES_NOT_ASSIGNED, HttpStatus.NOT_FOUND);
    }
    }

    public ArrayList<String> viewAssignedRoleToUser(String userId){
        initAdminToken();

        ModelMapper mapper= new ModelMapper();
        ArrayList<String> mappedGroupNames=new ArrayList<>();
        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakUserUri);
        uriBuilder.append("/").append(userId);
        uriBuilder.append("/groups");
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer "+adminToken);

        HttpEntity<String> request = new HttpEntity<>(httpHeaders);

        ResponseEntity<List<Object>> out = restTemplate.exchange(uriBuilder.toString(), HttpMethod.GET, request, new ParameterizedTypeReference<List<Object>>() {});
        List<Object> key = out.getBody();
        List<KeyCloakGroupsDto> keyCloakGroupsDtoList = mapper.map(key, new TypeToken<List<KeyCloakGroupsDto>>() {}.getType());
        for(KeyCloakGroupsDto keyCloakGroupsDto:keyCloakGroupsDtoList){

            mappedGroupNames.add(keyCloakGroupsDto.getId());
        }
      return mappedGroupNames;
    }

    public String deleteAssignedRole(String userId, String groupId) {
        initAdminToken();

        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakUserUri);
        uriBuilder.append("/").append(userId);
        uriBuilder.append("/groups");
        uriBuilder.append("/").append(groupId);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer "+adminToken);

        HttpEntity<String> request = new HttpEntity<>(httpHeaders);

        ResponseEntity<String> response = restTemplate.exchange(uriBuilder.toString(), HttpMethod.DELETE, request, String.class);
        String resMap = response.getBody();
        if(response.getStatusCode().is2xxSuccessful()) {
            return resMap;
        } else {
            throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, new String[]{""}, HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * This method calls the Keycloak REST API to update the user based on the user id
     * @param dto contains the details of the user required to update the user
     * @return AuthUserDto if the user updated successfully
     * @throws AuthException if any error occurred
     */
    public AuthUserDto updateUser(String id, AuthUserDto dto) {
        try {
            initAdminToken();
            viewUser(id);
            Map<String, String> attributes = new HashMap<>();
            if(Objects.nonNull(dto.getLocationDto())) {

                if (dto.getLocationDto().getLevel1Id() != null && dto.getLocationDto().getLevel3Id() != null) {
                    UserLocationDto locDto = locationHierarchyRepository.checkAndCreateLocationById(dto.getLocationDto().getLevel3Id(), dto.getLocationDto().getLevel1Id());
                    attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_1_ID.getValue(), String.valueOf(locDto.getLevel1Id()));
                    attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_2_ID.getValue(), String.valueOf(locDto.getLevel2Id()));
                    attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_3_ID.getValue(), String.valueOf(locDto.getLevel3Id()));
                    attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_4_ID.getValue(), String.valueOf(locDto.getLevel4Id()));
                } else

                    attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_1_ID.getValue(), dto.getLocationDto().getLevel1Id());
                attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_2_ID.getValue(), dto.getLocationDto().getLevel2Id());
            }
            if(Objects.nonNull(dto.getUserType())) {
                attributes.put(KeycloakUserAttributesEnum.USER_TYPE.getValue(), String.valueOf(dto.getUserType()));
            }
            attributes.put(KeycloakUserAttributesEnum.MOBILE_NUMBER.getValue(), String.valueOf(dto.getMobileNumber()));

            KeycloakUserDto keycloakUserDto = keyCloakAssembler.authUserToKeyCloakDto(dto);
            keycloakUserDto.setAttributes(attributes);
            keycloakUserDto.setEnabled(true);
            StringBuilder uriBuilder = new StringBuilder();
            uriBuilder.append(keycloakBasePath);
            uriBuilder.append(keycloakUserUri);
            uriBuilder.append("/").append(id);

            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
            httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

            HttpEntity<KeycloakUserDto> request = new HttpEntity<>(keycloakUserDto, httpHeaders);
            ResponseEntity<String> out = restTemplate.exchange(builder.toUriString(), HttpMethod.PUT, request, String.class);
            String resMap = out.getBody();

            if (!out.getStatusCode().is2xxSuccessful()) {
                throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, new String[]{resMap}, HttpStatus.BAD_REQUEST);
            }

            if(Objects.nonNull(dto.getRoles())) {
                ArrayList<String> groups=viewAssignedRoleToUser(id);
                if(Objects.nonNull(groups)) {
                    for (String group : groups) {
                        deleteAssignedRole(id, group);
                    }
                }
                String[] roles = dto.getRoles().split(",");
                for (String role : roles) {
                    AuthResponseRolesDto authResponseRolesDto = getRole(role);
                    if (Objects.nonNull(authResponseRolesDto)) {
                        assignRole(id, role);
                    } else
                        throw new AuthException(AuthException.ROLE_NOT_AVAILABLE, new String[]{dto.getRoles()}, HttpStatus.BAD_REQUEST);
                }
            }
            LOG.debug("User updated successfully in keycloak");
            AuthUserDto authUserDto=viewUser(id);
            authUserDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            authUserDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            return authUserDto;
        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(), e);
            throw new AuthException(AuthException.USER_NOT_UPDATED, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * This method will call the Keycloak APIs to count the number of users
     * @return a Integer
     */
    public Integer countUsers() {
        initAdminToken();

        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakUserUri);
        uriBuilder.append("/").append(AuthApplicationConstants.COUNT);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

        HttpEntity<KeycloakUserDto> request = new HttpEntity<>(httpHeaders);


        ResponseEntity<Integer> result = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request, Integer.class);

        return result.getBody();

    }

    /**
     * This method calls the Keycloak REST API to check if the realm role exists based on the realm role name
     * @param name The realm role name which is used to check
     * @return true if the realm role already exists, false otherwise, Throws AuthException if any error occurred
     */
    public boolean getRealmRoleByName(String name) {
        try {
            initAdminToken();

            StringBuilder uriBuilder = new StringBuilder();
            uriBuilder.append(keycloakBasePath);
            uriBuilder.append(keycloakRoleUri);
            uriBuilder.append("/").append(AuthApplicationConstants.ROLES);
            uriBuilder.append("/").append(name);

            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
            httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

            HttpEntity<AuthRolesDto> request = new HttpEntity<>(httpHeaders);

            ResponseEntity<Object> responseEntity = restTemplate.exchange(uriBuilder.toString(), HttpMethod.GET, request, Object.class);

            if (!responseEntity.getStatusCode().is2xxSuccessful()) {
                throw new AuthException(AuthException.INVALID_REALM_ROLE_NAME, new String[]{""}, HttpStatus.BAD_REQUEST);

            } else
                return true;
        }
        catch(AuthException ex){
            throw ex;
        } catch (Exception e) {
        LOG.error("exception : {} ", e.getMessage(),e);
        throw new AuthException(AuthException.INVALID_REALM_ROLE_NAME,new String[]{String.valueOf(name)}, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * This method calls the Keycloak REST API to check if the realm role exists based on the realm role id
     * @param id The realm role id which is used to check
     * @return true if the realm role already exists, false otherwise, Throws AuthException if any error occurred
     */
    public boolean getRealmRoleById(String id) {
    try{
        initAdminToken();

        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakRoleUri);
        uriBuilder.append("/").append(AuthApplicationConstants.ROLE_ID);
        uriBuilder.append("/").append(id);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

        HttpEntity<AuthRolesDto> request = new HttpEntity<>(httpHeaders);

        ResponseEntity<Object> responseEntity = restTemplate.exchange(uriBuilder.toString(), HttpMethod.GET, request, Object.class);

        if (!responseEntity.getStatusCode().is2xxSuccessful()) {
            throw new AuthException(AuthException.INVALID_REALM_ROLE_ID, new String[]{""}, HttpStatus.BAD_REQUEST);

        } else
            return true;
        } catch(AuthException ex){
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.INVALID_REALM_ROLE_ID,new String[]{String.valueOf(id)}, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * This method calls the Keycloak REST API to create the roles
     * @param dto contains the details of the roles required to create the role
     * @return AuthResponseRolesDto if the role created successfully
     * @throws AuthException if any error occurred
     */
    public AuthResponseRolesDto createRole(KeycloakRolesDto dto) {
        initAdminToken();

        Map attributes = new HashMap<>();
        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakGroupUri);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

        List description= Collections.singletonList(dto.getDescription());
        attributes.put(RoleAttributesEnum.DESCRIPTION.getValue(),description);

        KeyCloakGroupsDto keyCloakGroupsDto =new KeyCloakGroupsDto();
        keyCloakGroupsDto.setName(dto.getName());
        keyCloakGroupsDto.setAttributes(attributes);

        HttpEntity<KeyCloakGroupsDto> request = new HttpEntity<>(keyCloakGroupsDto,httpHeaders);

        ResponseEntity<String> out = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request, String.class);

        String resMap = out.getBody();
        if (!out.getStatusCode().is2xxSuccessful()) {
            throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, new String[]{resMap}, HttpStatus.BAD_REQUEST);
        }
        String headers = out.getHeaders().getLocation().toString();
        String id = headers.substring(headers.lastIndexOf("/") + 1);
        if(Objects.nonNull(dto.getRoles())) {
            boolean flag= false;
            for(AuthRolesDto authRolesDto:dto.getRoles()){
               if(getRealmRoleById(authRolesDto.getId()) &&
                getRealmRoleByName(authRolesDto.getName())){
                    flag = true;
                }
            }
            if(flag) {
                assignRealmRoles(id, dto.getRoles());
            }
            else
                throw new AuthException(AuthException.ROLE_NOT_AVAILABLE, new String[]{""}, HttpStatus.BAD_REQUEST);
        }
            AuthResponseRolesDto authResponseRolesDto=getRole(id);
            authResponseRolesDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            authResponseRolesDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
        return authResponseRolesDto;
    }

    /**
     * This method calls the Keycloak REST API to update the roles based on the roleId
     * @param dto contains the details of the roles required to update the role
     * @return AuthResponseRolesDto if the role updated successfully
     * @throws AuthException if any error occurred
     */
    public AuthResponseRolesDto updateRole(KeycloakRolesDto dto) {
        initAdminToken();
        getRole(dto.getId());
        Map attributes = new HashMap<>();
            StringBuilder uriBuilder = new StringBuilder();
            uriBuilder.append(keycloakBasePath);
            uriBuilder.append(keycloakGroupUri);
            uriBuilder.append("/").append(dto.getId());

            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
            httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);
            List description= Collections.singletonList(dto.getDescription());
            attributes.put(RoleAttributesEnum.DESCRIPTION.getValue(), description);

            KeyCloakGroupsDto keyCloakGroupsDto =new KeyCloakGroupsDto();
            keyCloakGroupsDto.setName(dto.getName());
            keyCloakGroupsDto.setId(dto.getId());
            keyCloakGroupsDto.setAttributes(attributes);

            HttpEntity<KeyCloakGroupsDto> request = new HttpEntity<>(keyCloakGroupsDto,httpHeaders);

            ResponseEntity<String> out = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.PUT, request, String.class);

            String resMap = out.getBody();
            if (!out.getStatusCode().is2xxSuccessful()) {
                throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, new String[]{resMap}, HttpStatus.BAD_REQUEST);
            }
            String id=dto.getId();
            if(Objects.nonNull(dto.getRoles())) {
                boolean flag= false;
                for(AuthRolesDto authRolesDto:dto.getRoles()){
                    if(getRealmRoleById(authRolesDto.getId()) &&
                            getRealmRoleByName(authRolesDto.getName())){
                        flag = true;
                    }
                }
                if(flag){
                    ArrayList<AuthRolesDto> rolesDtoList= getAssignedRealmRole(id);
                    deleteAssignedRealmRole(id,rolesDtoList);
                    assignRealmRoles(id,dto.getRoles());
                }
                else
                    throw new AuthException(AuthException.ROLE_NOT_AVAILABLE, new String[]{""}, HttpStatus.BAD_REQUEST);
            }
            AuthResponseRolesDto authResponseRolesDto=getRole(id);
            authResponseRolesDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            authResponseRolesDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            return authResponseRolesDto;
    }

    /**
     * This method will call the Keycloak APIs to view the list of groups
     * @param dto of group for which the list of group need to be deleted
     * @return An List of object of AuthResponseRolesDto
     */
    public List<AuthResponseRolesDto> getAllRoles(KeycloakRolesDto dto) {
        initAdminToken();

        ModelMapper mapper = new ModelMapper();
        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakGroupUri);

        MultiValueMap<String,String> multiValueMap=new LinkedMultiValueMap<>();
        multiValueMap.add(AuthApplicationConstants.REPRESENTATION, String.valueOf(false));
        if(dto.getPagination()!=null) {
            int page = dto.getPagination().getPage();
            int limit = dto.getPagination().getLimit();
            int first = ((page - 1) * limit);
            multiValueMap.add(AuthApplicationConstants.PAGE, String.valueOf(first));
            multiValueMap.add(AuthApplicationConstants.LIMIT,String.valueOf(limit));
        }
        if(dto.getName()!=null) {
            multiValueMap.add("search",dto.getName());
        }
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString()).queryParams(multiValueMap);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

        HttpEntity<KeycloakRolesDto> request = new HttpEntity<>(dto,httpHeaders);
        ResponseEntity<List<Object>> out = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.GET, request, new ParameterizedTypeReference<List<Object>>() {});
        List<Object> key = out.getBody();
        List<KeycloakRolesDto> keycloakRolesDtoList = mapper.map(key, new TypeToken<List<KeycloakRolesDto>>() {}.getType());
        return authResponseRolesAssembler.keyCloakListToAuthUserList(keycloakRolesDtoList);
    }

    /**
     * This method will call the Keycloak APIs to view the group
     * @param id of group for which the group need to be retrieved
     * @return An object of AuthResponseRolesDto
     */
    public AuthResponseRolesDto getRole(String id) {
        try {
            initAdminToken();

            ModelMapper mapper = new ModelMapper();
            StringBuilder uriBuilder = new StringBuilder();
            uriBuilder.append(keycloakBasePath);
            uriBuilder.append(keycloakGroupUri);
            uriBuilder.append("/").append(id);


            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
            httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

            HttpEntity<KeycloakRolesDto> request = new HttpEntity<>(httpHeaders);

            ResponseEntity<Object> authGroupDto = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request, Object.class);
            if (!authGroupDto.getStatusCode().is2xxSuccessful()) {
                throw new AuthException(AuthException.ROLE_NOT_AVAILABLE, new String[]{""}, HttpStatus.BAD_REQUEST);
            }
            Object key = authGroupDto.getBody();
            KeycloakRolesDto keycloakRolesDto = mapper.map(key, KeycloakRolesDto.class);
            AuthResponseRolesDto authResponseRolesDto = authResponseRolesAssembler.keyCloakToAuthResponse(keycloakRolesDto);
            authResponseRolesDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            authResponseRolesDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            return authResponseRolesDto;
        }catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.ROLE_NOT_AVAILABLE,new String[]{id}, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * This method will call the Keycloak APIs to delete the group
     * @param id of group for which the group need to be deleted
     * @return An object of AuthResponseRolesDto
     */
    public AuthResponseRolesDto deleteRole(String id) {
        initAdminToken();

        AuthResponseRolesDto dto = getRole(id);
        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakGroupUri);
        uriBuilder.append("/").append(id);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

        HttpEntity<KeycloakRolesDto> request = new HttpEntity<>(httpHeaders);

        ResponseEntity<Object> result = restTemplate.exchange(builder.toUriString(), HttpMethod.DELETE, request, Object.class);

        if (!result.getStatusCode().is2xxSuccessful()) {
            throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, HttpStatus.BAD_REQUEST);
        }
        LOG.debug("Role Deleted successfully in keycloak");
        dto.setRoleId(id);
        return dto;
    }

    /**
     * This method will call the Keycloak APIs to count the number of group in a realm
     * @return a count
     */
    public Integer countRoles(KeycloakRolesDto dto) {
        initAdminToken();

        ModelMapper mapper=new ModelMapper();
        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakGroupUri);
        uriBuilder.append("/").append(AuthApplicationConstants.COUNT);
        if(dto.getName()!=null) {
            uriBuilder.append("?search=").append(dto.getName());
        }

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

        HttpEntity<KeycloakRolesDto> request = new HttpEntity<>(dto,httpHeaders);
        ResponseEntity<Object> result = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.GET, request, Object.class);
        Object key = result.getBody();
        KeycloakRolesDto keycloakRolesDto = mapper.map(key, KeycloakRolesDto.class);
        return keycloakRolesDto.getCount();
    }

    /**
     * This method will call the Keycloak APIs to retrieve the list of users
     * which are mapped to Group
     * @param id of group for which the list of realm roles need to be retrieved
     * @return An object of ArrayList of type AuthUserDto
     */
    public ArrayList<AuthUserDto> viewRoleMembers(String id) {
        initAdminToken();
        getRole(id);
        ModelMapper mapper = new ModelMapper();
        ArrayList<AuthUserDto> groupMembers= new ArrayList<>();
        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakGroupUri);
        uriBuilder.append("/").append(id);
        uriBuilder.append("/").append("members");

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

        HttpEntity<KeycloakRolesDto> request = new HttpEntity<>(httpHeaders);

        ResponseEntity<List<Object>> responseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request, new ParameterizedTypeReference<List<Object>>() {});
        if(!responseEntity.getStatusCode().is2xxSuccessful()){
            throw new AuthException(AuthException.USER_NOT_AVAILABLE, new String[]{""}, HttpStatus.BAD_REQUEST);
        }
        List<Object> key = responseEntity.getBody();
        List<KeycloakUserDto> keycloakUserDtoList = mapper.map(key, new TypeToken<List<KeycloakUserDto>>() {}.getType());
        for(KeycloakUserDto keycloakUserDto:keycloakUserDtoList){
            AuthUserDto authUserDto= new AuthUserDto();
            authUserDto.setKeyCloakId(keycloakUserDto.getId());
            authUserDto.setUsername(keycloakUserDto.getUsername());
            groupMembers.add(authUserDto);
        }

        return groupMembers;
    }

    /**
     * This method will call the Keycloak APIs to map the list of realm roles to the group
     * @param id of group for which the list of realm roles need to be mapped
     * @return An object of type AuthRolesDto
     */
    public AuthRolesDto assignRealmRoles(String id, ArrayList<AuthRolesDto> dtoList) {
        try {
            initAdminToken();

            AuthRolesDto authRolesDto = new AuthRolesDto();
            StringBuilder uriBuilder = new StringBuilder();
            uriBuilder.append(keycloakBasePath);
            uriBuilder.append(keycloakGroupUri);
            uriBuilder.append("/").append(id);
            uriBuilder.append("/").append(AuthApplicationConstants.ROLE_MAPPING);
            uriBuilder.append("/").append(AuthApplicationConstants.REALM);

            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
            httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);
            HttpEntity<ArrayList<AuthRolesDto>> request = new HttpEntity<>(dtoList, httpHeaders);
            ResponseEntity<String> out = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST, request, String.class);

            String resMap = out.getBody();
            if (!out.getStatusCode().is2xxSuccessful()) {
                throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, new String[]{resMap}, HttpStatus.BAD_REQUEST);
            }
            authRolesDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            authRolesDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            return authRolesDto;
        }  catch(AuthException ex){
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.ROLE_NOT_MAPPED, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * This method will call the Keycloak APIs to retrieve the list of realm roles
     * which are mapped to Group
     * @param id of group for which the list of realm roles need to be retrieved
     * @return An object of ArrayList of type AuthRolesDto
     */
    public ArrayList<AuthRolesDto> getAssignedRealmRole(String id) {
        initAdminToken();

        ModelMapper mapper = new ModelMapper();

        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakGroupUri);
        uriBuilder.append("/").append(id);
        uriBuilder.append("/").append(AuthApplicationConstants.ROLE_MAPPING);
        uriBuilder.append("/").append(AuthApplicationConstants.REALM);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);
        HttpEntity<AuthRolesDto> request = new HttpEntity<>(httpHeaders);

        ResponseEntity<List<Object>> out = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request, new ParameterizedTypeReference<List<Object>>() {});
        if(!out.getStatusCode().is2xxSuccessful()){
            throw new AuthException(AuthException.ROLE_NOT_AVAILABLE, new String[]{""}, HttpStatus.BAD_REQUEST);
        }
        List<Object> key = out.getBody();
        return mapper.map(key, new TypeToken<ArrayList<AuthRolesDto>>() {}.getType());
    }

    /**
     * This method will call the Keycloak APIs to delete the list of realm roles
     * which are mapped to Group
     * @param id of group for which the list of realm roles need to be deleted
     * @return An id of ArrayList of type AuthRolesDto
     */
    public ArrayList<AuthRolesDto> deleteAssignedRealmRole(String id, ArrayList<AuthRolesDto> dtoList) {
        try {
            ArrayList<AuthRolesDto> dtoArrayList = new ArrayList<>();
            boolean flag = false;
            if (Objects.nonNull(dtoList)) {
                ArrayList<AuthRolesDto> authRolesDtoList=getAssignedRealmRole(id);
                for (AuthRolesDto authRolesDto : dtoList) {
                    if (authRolesDtoList.contains(authRolesDto)) {
                        flag = true;
                    } else
                        flag = false;
                }
            }
            if (flag) {
                initAdminToken();
                AuthRolesDto authRolesDto = new AuthRolesDto();

                StringBuilder uriBuilder = new StringBuilder();
                uriBuilder.append(keycloakBasePath);
                uriBuilder.append(keycloakGroupUri);
                uriBuilder.append("/").append(id);
                uriBuilder.append("/").append(AuthApplicationConstants.ROLE_MAPPING);
                uriBuilder.append("/").append(AuthApplicationConstants.REALM);

                UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
                HttpHeaders httpHeaders = new HttpHeaders();
                httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
                httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);
                HttpEntity<ArrayList<AuthRolesDto>> request = new HttpEntity<>(dtoList, httpHeaders);

                ResponseEntity<String> out = restTemplate.exchange(builder.toUriString(), HttpMethod.DELETE, request, String.class);

                String resMap = out.getBody();
                if (!out.getStatusCode().is2xxSuccessful()) {
                    throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, new String[]{resMap}, HttpStatus.BAD_REQUEST);
                }
                for (AuthRolesDto rolesDto : dtoList) {
                    authRolesDto.setId(rolesDto.getId());
                    dtoArrayList.add(authRolesDto);
                }
                return dtoArrayList;
            } else
                throw new AuthException(AuthException.ROLE_NOT_AVAILABLE, new String[]{""}, HttpStatus.BAD_REQUEST);
        }catch(AuthException ex){
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.MAPPED_ROLE_NOT_DELETED, HttpStatus.NOT_FOUND);
        }

    }


    /**
     * This method will call the Keycloak APIs to retrieve the list of roles
     * and for each of those roles again retrieve the attributes and provide a list
     * of all the ApiRoles
     * @return An object of {@link BaseListDto} of type AuthApiRoleDto
     */
    public BaseListDto<AuthApiRoleDto> getAllApiRoles(){
        initAdminToken();
        ModelMapper mapper = new ModelMapper();
        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakClientRolesUri);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

        HttpEntity<KeycloakUserDto> request = new HttpEntity<>(httpHeaders);
        ResponseEntity<List<Object>> out = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request, new ParameterizedTypeReference<List<Object>>() {
        });
        List<Object> key = out.getBody();
        List<KeycloakApiRoleDto> userDtoList = mapper.map(key, new TypeToken<List<KeycloakApiRoleDto>>() {}.getType());

        /** For each of the roles retrieved, the details attributes need to be retrieved **/
        BaseListDto<AuthApiRoleDto> baseListDto = new BaseListDto<>();
        ArrayList<AuthApiRoleDto> apiRoleDtoList = new ArrayList<>();

        uriBuilder.append("/");
        builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());

        ResponseEntity<KeycloakApiRoleDto> response;
        for(KeycloakApiRoleDto keycloakApiRoleDto : userDtoList){

            builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString()+keycloakApiRoleDto.getName());
            response = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request, KeycloakApiRoleDto.class);

            apiRoleDtoList.add(authApiRoleAssembler.keyCloakDtoToAuthApiRoleDto(response.getBody()));
        }

        baseListDto.setDataList(apiRoleDtoList);

        return baseListDto;
    }
    /**
     * This method will call the Keycloak APIs to retrieve the list of realm roles
     * and for each of those roles again retrieve the attributes and provide a list
     * of all the Realm Roles (Menus)
     * @return An object of {@link BaseListDto} of type AuthRealmRoleDto
     */
    public BaseListDto<AuthRealmRoleDto> getAllRealmRoles(){
        initAdminToken();

        ModelMapper mapper = new ModelMapper();
        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakRealmRolesUri);


        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
        httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

        HttpEntity<KeycloakUserDto> request = new HttpEntity<>(httpHeaders);
        ResponseEntity<List<Object>> out = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request, new ParameterizedTypeReference<List<Object>>() {});
        List<Object> key = out.getBody();
        List<KeycloakRealmRoleDto> userDtoList = mapper.map(key, new TypeToken<List<KeycloakRealmRoleDto>>() {}.getType());

        /** For each of the roles retrieved, the details attributes need to be retrieved **/
        BaseListDto<AuthRealmRoleDto> baseListDto = new BaseListDto<>();
        ArrayList<AuthRealmRoleDto> realmRoleDtoList = new ArrayList<>();
        AuthRealmRoleDto authRealmRoleDto;

        uriBuilder.append("/");

        ResponseEntity<KeycloakRealmRoleDto> response;
        for(KeycloakRealmRoleDto keycloakApiRoleDto : userDtoList){

            builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString()+keycloakApiRoleDto.getName());
            response = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request, KeycloakRealmRoleDto.class);

            authRealmRoleDto = authRealmRoleAssembler.keyCloakDtoToAuthRealmRoleDto(response.getBody());

            //Only if the source is ipp it needs to be added
            //else it some default role from keycloak
            if(keycloakMenuSource.equals(authRealmRoleDto.getSource())) {
                realmRoleDtoList.add(authRealmRoleDto);
            }
        }

        baseListDto.setDataList(realmRoleDtoList);

        return baseListDto;
    }

    public KeycloakTokenDto GetAccessTokenBasedOnRefreshToken(String token) {
        LOG.debug("Getting new Access token through refresh token");

        MultiValueMap<String, String> multiMap = new LinkedMultiValueMap<>();
        multiMap.add(KeycloakHeadersEnum.CLIENT_ID.getValue(), clientId);
        multiMap.add(KeycloakHeadersEnum.GRANT_TYPE.getValue(), refreshGrantType);
        multiMap.add(KeycloakHeadersEnum.CLIENT_SECRET.getValue(), clientSecret);
        multiMap.add(KeycloakHeadersEnum.REFRESH_TOKEN.getValue(), token);
        return callForToken(multiMap, true);

    }

    /**
     * This method calls the Keycloak REST API to register the user
     * @param dto contains the details of the user required to create the user
     * @return AuthUserDto if the user registered successfully
     * @throws AuthException if any error occurred
     */
    public AuthUserDto signupUser(AuthUserDto dto) throws AuthException {
        try {
            initAdminToken();
            Map<String, String> attributes = new HashMap<>();
                attributes.put(KeycloakUserAttributesEnum.USER_TYPE.getValue(), userType);
                if(Objects.nonNull(dto.getMobileNumber())) {
                    attributes.put(KeycloakUserAttributesEnum.MOBILE_NUMBER.getValue(), String.valueOf(dto.getMobileNumber()));
                }
                KeycloakUserDto keycloakUserDto = keyCloakAssembler.authUserToKeyCloakDto(dto);
                keycloakUserDto.setAttributes(attributes);
                keycloakUserDto.setEnabled(AuthConstant.TRUE);
                keycloakUserDto.setEmailVerified(AuthConstant.TRUE);
                StringBuilder uriBuilder = new StringBuilder();
                uriBuilder.append(keycloakBasePath);
                uriBuilder.append(keycloakUserUri);

                UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
                HttpHeaders httpHeaders = new HttpHeaders();
                httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
                httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

                HttpEntity<KeycloakUserDto> request = new HttpEntity<>(keycloakUserDto, httpHeaders);

                ResponseEntity<String> out = restTemplate.exchange(builder.toUriString(), HttpMethod.POST, request, String.class);
                String resMap = out.getBody();

                if (!out.getStatusCode().is2xxSuccessful()) {
                    throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, new String[]{resMap}, HttpStatus.BAD_REQUEST);
                }
                String headers = Objects.requireNonNull(out.getHeaders().getLocation()).toString();
                String id = headers.substring(headers.lastIndexOf("/") + 1);
                assignRole(id,userSignupRole);

                AuthUserDto authUserDto=viewUser(id);
                authUserDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                authUserDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                return authUserDto;

        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(), e);
            throw new AuthException(AuthException.USER_NOT_REGISTERED, HttpStatus.NOT_FOUND);
        }
    }

    public List<AuthUserDto> getUsersByUserType(AuthUserDto dto) {
        ModelMapper mapper = new ModelMapper();
        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakCustomSearch);

        MultiValueMap<String,String> multiValueMap=new LinkedMultiValueMap<>();
        if(dto.getUserType()!=null) {
            multiValueMap.add("attr","user_type");
            multiValueMap.add("value", String.valueOf(dto.getUserType()));
        }

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString()).queryParams(multiValueMap);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");

        HttpEntity<KeycloakUserDto> request = new HttpEntity<>(httpHeaders);
        ResponseEntity<List<Object>> out = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request, new ParameterizedTypeReference<List<Object>>() {
        });
        List<Object> key = out.getBody();
        List<KeycloakUserDto> userDto = mapper.map(key, new TypeToken<List<KeycloakUserDto>>() {}.getType());
        List<AuthUserDto> authUserDtoList =authUserAssembler.keyCloakListToAuthUserList(userDto);
        for(AuthUserDto authUserDto:authUserDtoList){
            List<String> groupNames= viewAssignedRoleToUser(authUserDto.getKeyCloakId());
            authUserDto.setRoles(String.valueOf(groupNames).replace("[","").replace("]",""));

        }
        return authUserDtoList;
    }

    public AuthUserDto editUserProfileImage(AuthUserDto dto) {
        try {
            initAdminToken();
            Map<String, String> attributes = new HashMap<>();
            if(Objects.nonNull(dto.getImage())){
                attributes.put(KeycloakUserAttributesEnum.USER_IMAGE.getValue(), dto.getImage());
            }
            if(Objects.nonNull(dto.getLocationDto())) {
                if (!StringUtils.isEmpty(dto.getLocationDto().getLevel1Id()) && !StringUtils.isEmpty(dto.getLocationDto().getLevel3Id())) {
                    UserLocationDto locDto = locationHierarchyRepository.checkAndCreateLocationById(dto.getLocationDto().getLevel3Id(), dto.getLocationDto().getLevel1Id());
                    attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_1_ID.getValue(), String.valueOf(locDto.getLevel1Id()));
                    attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_2_ID.getValue(), String.valueOf(locDto.getLevel2Id()));
                    attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_3_ID.getValue(), String.valueOf(locDto.getLevel3Id()));
                    attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_4_ID.getValue(), String.valueOf(locDto.getLevel4Id()));
                } else
                    attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_1_ID.getValue(), dto.getLocationDto().getLevel1Id());
                attributes.put(KeycloakUserAttributesEnum.LOC_LEVEL_2_ID.getValue(), dto.getLocationDto().getLevel2Id());
            }
            attributes.put(KeycloakUserAttributesEnum.MOBILE_NUMBER.getValue(), String.valueOf(dto.getMobileNumber()));

            KeycloakUserDto keycloakUserDto = keyCloakAssembler.authUserToKeyCloakDto(dto);
            keycloakUserDto.setAttributes(attributes);
            keycloakUserDto.setEnabled(true);
            StringBuilder uriBuilder = new StringBuilder();
            uriBuilder.append(keycloakBasePath);
            uriBuilder.append(keycloakUserUri);
            uriBuilder.append("/").append(dto.getKeyCloakId());

            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString());
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
            httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + adminToken);

            HttpEntity<KeycloakUserDto> request = new HttpEntity<>(keycloakUserDto, httpHeaders);
            ResponseEntity<String> out = restTemplate.exchange(builder.toUriString(), HttpMethod.PUT, request, String.class);
            String resMap = out.getBody();

            if (!out.getStatusCode().is2xxSuccessful()) {
                throw new AuthException(AuthException.ERROR_RESPONSE_FROM_KEYCLOAK, new String[]{resMap}, HttpStatus.BAD_REQUEST);
            }

            LOG.debug("User profile pic updated successfully in keycloak");

            dto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            dto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            return dto;
        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(), e);
            throw new AuthException(AuthException.USER_NOT_UPDATED, HttpStatus.NOT_FOUND);
        }
    }

    public List<AuthUserDto> getUsersByAttributes(AuthUserDto dto) {
        ModelMapper mapper = new ModelMapper();
        StringBuilder uriBuilder = new StringBuilder();
        uriBuilder.append(keycloakBasePath);
        uriBuilder.append(keycloakAttributeFilter);

        MultiValueMap<String,String> multiValueMap=new LinkedMultiValueMap<>();
        if(dto.getUserType()!=null) {
            multiValueMap.add("userType", String.valueOf(dto.getUserType()));
        }
        if(dto.getLocationDto()!=null) {
            if (dto.getLocationDto().getLevel1Id() != null) {
                multiValueMap.add("level1Id", String.valueOf(dto.getLocationDto().getLevel1Id()));
            }
            if (dto.getLocationDto().getLevel2Id() != null) {
                multiValueMap.add("level2Id", String.valueOf(dto.getLocationDto().getLevel2Id()));
            }
            if (dto.getLocationDto().getLevel3Id() != null) {
                multiValueMap.add("level3Id", String.valueOf(dto.getLocationDto().getLevel3Id()));
            }
            if (dto.getLocationDto().getLevel4Id() != null) {
                multiValueMap.add("level4Id", String.valueOf(dto.getLocationDto().getLevel4Id()));
            }
        }

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(uriBuilder.toString()).queryParams(multiValueMap);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");

        HttpEntity<KeycloakUserDto> request = new HttpEntity<>(httpHeaders);
        ResponseEntity<List<Object>> out = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request, new ParameterizedTypeReference<List<Object>>() {
        });
        List<Object> key = out.getBody();
        List<KeycloakUserDto> userDto = mapper.map(key, new TypeToken<List<KeycloakUserDto>>() {}.getType());
        List<AuthUserDto> authUserDtoList =authUserAssembler.keyCloakListToAuthUserList(userDto);
        for(AuthUserDto authUserDto:authUserDtoList){
            List<String> groupNames= viewAssignedRoleToUser(authUserDto.getKeyCloakId());
            authUserDto.setRoles(String.valueOf(groupNames).replace("[","").replace("]",""));

        }
        return authUserDtoList;
    }
}
