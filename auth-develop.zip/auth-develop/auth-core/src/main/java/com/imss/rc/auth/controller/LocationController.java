package com.imss.rc.auth.controller;

import com.imss.rc.auth.dto.LocationHierarchyDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.commons.dto.BaseListDto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;


public interface LocationController {
    @GetMapping(value = "/locations", produces = "application/json")
    public @ResponseBody
    BaseListDto<LocationHierarchyDto> getLocations(@RequestParam Integer page,
                                                   @RequestParam Integer limit,
                                                   @RequestParam Integer parentId ,
                                                   @RequestParam(required = false) String sortBy,
                                                   @RequestParam(required = false) String sortType,
                                                   @RequestParam(required = false) String name, HttpServletRequest request) throws AuthException;

}
