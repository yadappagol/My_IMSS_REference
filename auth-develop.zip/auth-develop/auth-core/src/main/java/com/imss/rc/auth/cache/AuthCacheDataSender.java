package com.imss.rc.auth.cache;

import com.imss.rc.auth.dto.AuthApiRoleDto;
import com.imss.rc.auth.dto.AuthPropertiesDto;
import com.imss.rc.auth.enums.AuthCacheTypeEnum;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.enums.CacheOperationEnum;
import com.imss.rc.commons.kafka.KafkaDataSender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class AuthCacheDataSender extends KafkaDataSender {
    private static final Logger LOGGER = LoggerFactory.getLogger(AuthCacheDataSender.class);


    @Autowired
    @Qualifier("authCacheData")
    public KafkaTemplate<String, Object> kafkaTemplate;

    @Value("${kafka.rc.auth.master.response.topic}")
    private String topicName;

    @Value("${auth.cache.max.list.size.api.role}")
    public int MAX_LIST_SIZE_FOR_API_ROLE;

    public void sendApiRoleListIntoTopic(BaseListDto<AuthApiRoleDto> authApiRoleDtoList){

        super.processListData(topicName,
                AuthCacheTypeEnum.API_ROLES.getValue(),
                MAX_LIST_SIZE_FOR_API_ROLE,
                authApiRoleDtoList,
                kafkaTemplate);
    }

    public void sendKeycloakPropertiesIntoTopic(AuthPropertiesDto authDto){

        super.processIndividualData(topicName,
                AuthCacheTypeEnum.CONFIG_PROPERTIES.getValue(),
                CacheOperationEnum.ADD.getValue(),
                authDto,
                kafkaTemplate);
    }
}
