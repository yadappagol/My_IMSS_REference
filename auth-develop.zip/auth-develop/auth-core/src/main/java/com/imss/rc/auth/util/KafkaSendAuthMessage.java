package com.imss.rc.auth.util;

import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.service.KafkaProducerSender;
import com.imss.rc.auth.exception.AuthException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class KafkaSendAuthMessage
{

    @Autowired
    KafkaProducerSender kafkaProducerSender;

    private static final Logger LOG = LoggerFactory.getLogger(KafkaSendAuthMessage.class);

    public void sendMessage(AuditMasterDto auditMasterDto)
    {
        try {
            kafkaProducerSender.sendData(auditMasterDto);
            }
        catch (Exception e) {
            LOG.error(AuthException.MESSAGE_NOT_SENT);
        }
    }
}
