package com.imss.rc.auth.service.external;

import com.imss.rc.auth.dto.TokenDto;
import com.imss.rc.auth.dto.external.IbkartBdDetailsDto;
import com.imss.rc.auth.dto.external.IbkartTokenResponseDto;
import com.imss.rc.auth.exception.AuthException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import javax.net.ssl.*;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

@Component
public class IbkartIntegration {

    private static final Logger LOG = LoggerFactory.getLogger(IbkartIntegration.class);


    @Autowired
    @Qualifier("authCoreRestTemplate")
    private RestTemplate restTemplate;

    /* IBKart related properties */
    @Value("${ibkart.auth.uri}")
    private String verifyTokenUri;
    @Value("${ibkart.bd.details.uri}")
    private String bdDetailsUri;
    @Value("${ibkart.truststore.file}")
    private String trustStoreFile;
    @Value("${ibkart.truststore.password}")
    private String trustStorePassword;
    @Value("${ibkart.truststore.disable.verification}")
    private boolean disableSSLCertVerification;



    public boolean verifyReferenceToken(TokenDto tokenDto){
        try {
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set("Content-Type", "application/json");

            HttpEntity<TokenDto> request = new HttpEntity<>(tokenDto, httpHeaders);

            System.setProperty("javax.net.ssl.trustStore", trustStoreFile);
            System.setProperty("javax.net.ssl.trustStorePassword", trustStorePassword);

            IbkartTokenResponseDto ibkartTokenResponseDto = restTemplate.postForObject(verifyTokenUri, request, IbkartTokenResponseDto.class);

            LOG.debug("Response from IBKart {} ({})", ibkartTokenResponseDto.getRespCode(), ibkartTokenResponseDto.getRespDesc());

            if("AUTHENTICATION_SUCCESS".equals(ibkartTokenResponseDto.getRespCode())) {
                return true;
            } else if("AUTHENTICATION_FAILED".equals(ibkartTokenResponseDto.getRespCode())) {
                throw new AuthException(AuthException.INVALID_CREDENTIALS,HttpStatus.BAD_REQUEST);
            } else {
                LOG.error("Error response from IBKart :"+ ibkartTokenResponseDto.getRespCode());
                throw new AuthException(AuthException.ERROR_RESPONSE_FROM_IBKART,HttpStatus.BAD_REQUEST);
            }

        } catch (AuthException e) {
            throw e;
        } catch (Exception e) {
            LOG.error("Exception during verifying token with Ibkart : {} ", e.getMessage(), e);
            throw new AuthException(AuthException.ERROR_WHEN_AUTHENTICATING_WITH_IBKART, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * This method disables the SSL verification
     */
    @PostConstruct
    private void disableSslVerification() {
        try
        {
            if(disableSSLCertVerification) {

                // Create a trust manager that does not validate certificate chains
                TrustManager[] trustAllCerts = new TrustManager[]{ new X509TrustManager() {

                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        @Override
                        public void checkClientTrusted(X509Certificate[] certs, String authType) {
                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] certs, String authType) {
                        }
                    }
                };

                // Install the all-trusting trust manager
                SSLContext sc = SSLContext.getInstance("SSL");
                sc.init(null, trustAllCerts, new java.security.SecureRandom());
                HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

                // Create all-trusting host name verifier
                HostnameVerifier allHostsValid = new HostnameVerifier() {
                    public boolean verify(String hostname, SSLSession session) {
                        return true;
                    }
                };

                // Install the all-trusting host verifier
                HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);

            }
        } catch (NoSuchAlgorithmException | KeyManagementException e) {
            LOG.error("Error while disabling SSL verification",e);
        }
    }


    public IbkartBdDetailsDto getUserDataOnReference(String reference){

        try{

            //This is to ensure that if the URL is given without the trailing slash
            if(bdDetailsUri.charAt(bdDetailsUri.length()-1) != '/'){
                bdDetailsUri += '/';
            }

            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set("Content-Type", "application/json");

            HttpEntity<TokenDto> request = new HttpEntity<>(httpHeaders);

            System.setProperty("javax.net.ssl.trustStore", trustStoreFile);
            System.setProperty("javax.net.ssl.trustStorePassword", trustStorePassword);

            IbkartBdDetailsDto ibkartBdDetailsDto = restTemplate.getForObject(bdDetailsUri+reference, IbkartBdDetailsDto.class, request);


            LOG.debug("Response from IBKart {} ({})", ibkartBdDetailsDto.getRespCode(), ibkartBdDetailsDto.getRespDesc());

            if(ibkartBdDetailsDto.getRespCode().equals("SUCCESS")){
                return ibkartBdDetailsDto;
            } else {
                throw new AuthException(AuthException.ERROR_RESPONSE_WHEN_GETTING_DETAILS_FROM_IBKART, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (AuthException e) {
            throw e;
        } catch (Exception e) {
            LOG.error("Exception when retrieving details from IbKart: {} ", e.getMessage(), e);
            throw new AuthException(AuthException.ERROR_WHEN_GETTING_DETAILS_FROM_IBKART, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
