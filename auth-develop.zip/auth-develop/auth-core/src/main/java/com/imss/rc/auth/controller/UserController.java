package com.imss.rc.auth.controller;

import com.imss.rc.auth.dto.AuthUserDto;
import com.imss.rc.auth.dto.PasswordResetValueDto;
import com.imss.rc.auth.dto.UserActivationPasswordDto;
import com.imss.rc.auth.dto.UserRegistrationDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.commons.dto.BaseListDto;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

public interface UserController {

    @GetMapping(value = "/login/users/{id}", produces = "application/json")
    public @ResponseBody
    AuthUserDto viewUsers(@PathVariable("id")  String id, HttpServletRequest request)throws AuthException;

    @DeleteMapping(value = "/login/users/{id}", produces = "application/json")
    public @ResponseBody AuthUserDto deleteUser(@PathVariable("id")  String id, HttpServletRequest request)throws AuthException;

    @PostMapping(value = "/login/users", produces = "application/json")
    public @ResponseBody AuthUserDto createUser(@RequestBody AuthUserDto dto, HttpServletRequest request)throws AuthException;

    @PutMapping(value = "/login/users/{id}", produces = "application/json")
    public @ResponseBody AuthUserDto updateUser(@PathVariable("id")  String id,@RequestBody AuthUserDto dto, HttpServletRequest request)throws AuthException;

    @PutMapping(value = "/activate-password",produces = "application/json")
    public UserActivationPasswordDto activatePassword(@RequestParam("token") String token, @RequestParam("userName") String userName, @RequestBody PasswordResetValueDto dto, HttpServletRequest request) throws AuthException;

    @PostMapping(value = "/signup/register",produces = "application/json")
    public UserRegistrationDto userRegistration(@RequestBody UserRegistrationDto dto, HttpServletRequest request) throws AuthException;

    @PostMapping(value = "/signup/activate",produces = "application/json")
    public AuthUserDto signupUser(@RequestBody PasswordResetValueDto dto, HttpServletRequest request) throws AuthException;

    @GetMapping(value = "/users/filter/usertype", produces = "application/json")
    public BaseListDto<AuthUserDto> getUsersByUserType(@RequestParam Integer page,
                                                       @RequestParam Integer limit,
                                                       @RequestParam(required = false) String sortBy,
                                                       @RequestParam(required = false) String sortType,
                                                       @RequestParam String userType,
                                                       HttpServletRequest request) throws AuthException;

    @GetMapping(value = "/users-search", produces = "application/json")
    public BaseListDto<AuthUserDto> getUsersByAttributes(@RequestParam(required = false) String userType,
                                                         @RequestParam(required = false) String level1Id,
                                                         @RequestParam(required = false) String level2Id,
                                                         @RequestParam(required = false) String level3Id,
                                                         @RequestParam(required = false) String level4Id,
                                                         @RequestParam Integer page,
                                                         @RequestParam Integer limit,
                                                         @RequestParam(required = false) String sortBy,
                                                         @RequestParam(required = false) String sortType,
                                                         HttpServletRequest request) throws AuthException;

}
