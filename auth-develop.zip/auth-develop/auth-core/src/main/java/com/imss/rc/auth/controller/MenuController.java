package com.imss.rc.auth.controller;

import com.imss.rc.auth.dto.MenuDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.commons.dto.BaseListDto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface MenuController {

    /**
     * API to retrieve all the menu details of the application
     * @param response The response object
     * @param request the http request object
     * @return Returns an object of {@link BaseListDto} with the menu details
     * @throws AuthException
     */
    @GetMapping(value = "/menus", produces = "application/json")
    public @ResponseBody
    BaseListDto<MenuDto> getAllMenus(HttpServletResponse response, HttpServletRequest request) throws AuthException;

}
