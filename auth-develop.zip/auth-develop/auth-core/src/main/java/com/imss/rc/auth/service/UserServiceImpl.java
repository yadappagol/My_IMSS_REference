package com.imss.rc.auth.service;


import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.enums.AuditEnum;
import com.imss.rc.auth.assembler.UserRegistrationAssembler;
import com.imss.rc.auth.dto.*;
import com.imss.rc.auth.entity.UserActivationPasswordEntity;
import com.imss.rc.auth.entity.UserRegistrationEntity;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.repository.GeoFenceRepository;
import com.imss.rc.auth.repository.UserActivationPasswordRepository;
import com.imss.rc.auth.repository.UserRegistrationRepository;
import com.imss.rc.auth.service.external.KeycloakIntegration;
import com.imss.rc.auth.util.AuthApplicationConstants;
import com.imss.rc.auth.util.KafkaSendAuthMessage;
import com.imss.rc.auth.validation.AuthValidation;
import com.imss.rc.commons.constants.SortTypeConstants;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.enums.ActionTypeEnum;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import com.imss.rc.commons.util.OtpGenerator;
import com.imss.rc.config.enums.ConfigurationTypeEnum;
import com.imss.rc.config.service.ConfigCache;
import com.imss.rc.notify.dto.NotificationRequestsDto;
import com.imss.rc.notify.enums.NotifyRequestModeTypeEnum;
import com.imss.rc.notify.service.KafkaSender;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.security.Key;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import static com.imss.rc.auth.constants.AuthConstant.*;

@Service
public class UserServiceImpl implements UserService {

    private static final Logger LOG = LoggerFactory.getLogger(AuthServiceImpl.class);

    @Autowired
    private KeycloakIntegration keycloakIntegration;

    @Autowired
    private AuthValidation authValidation;

    @Autowired
    KafkaSender sender;

    @Autowired
    UserActivationPasswordRepository userActivationPasswordRepository;

    @Autowired
    UserRegistrationRepository userRegistrationRepository;

    @Autowired
    UserRegistrationAssembler userRegistrationAssembler;

    @Value("${user.notify.event.id}")
    private String notifyEventId;

    @Value("${reset.password.uri}")
    private String resetPasswordLink;

    @Value("${user.register.notify.event.id}")
    private String userEventId;

    @Value("${user.signup.check.geofence}")
    private String checkGeoFenceOnSignUp;

    @Autowired
    private GeoFenceRepository geoFenceRepository;

    @Autowired
    KafkaSendAuthMessage kafkaSendMessage;

    @Override
    public AuthUserDto viewUser(AuthUserDto dto) throws AuthException {
        try{
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            Date date=new Date();
            AuthUserDto authUserDto= keycloakIntegration.viewUser(dto.getKeyCloakId());

            //auditing the updates made
            auditMasterDto.setEventId(AuditEnum.USER_MANAGEMENT.getValue());
            auditMasterDto.setWhen(date);
            auditMasterDto.setReferenceId(String.valueOf(dto.getKeyCloakId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(dto.getAuthUserData().getUsername());
            auditMasterDto.setDescription(String.format(VIEW_USER,dto.getUsername()));
            kafkaSendMessage.sendMessage(auditMasterDto);
            return authUserDto;

        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.USER_NOT_AVAILABLE, HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public AuthUserDto deleteUser( AuthUserDto dto) throws AuthException {
        try{
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            Date date=new Date();
            AuthUserDto authUserDto= keycloakIntegration.deleteUser(dto.getKeyCloakId());

            //auditing the updates made
            auditMasterDto.setEventId(AuditEnum.USER_MANAGEMENT.getValue());
            auditMasterDto.setWhen(date);
            auditMasterDto.setReferenceId(String.valueOf(dto.getKeyCloakId()));
            auditMasterDto.setActionType(ActionTypeEnum.DELETE.getValue());
            auditMasterDto.setWho(dto.getAuthUserData().getUsername());
            auditMasterDto.setDescription(String.format(DELETED_USER,dto.getUsername()));
            kafkaSendMessage.sendMessage(auditMasterDto);
            return authUserDto;

        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.USER_NOT_DELETED, HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public AuthUserDto createUser(AuthUserDto dto) throws AuthException {
        try{
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            Date date= new Date();
            if(authValidation.validateUsername(dto.getUsername()) &&
                    authValidation.validateFirstname(dto.getFirstName()) &&
                    authValidation.validateLastname(dto.getLastName()) &&
                    authValidation.validateEmail(dto.getEmail()) &&
                    authValidation.validateMobileNum(dto.getMobileNumber())&&
                    authValidation.validateRoles(dto.getRoles())){
                if(Objects.nonNull(dto.getLocationDto())){
                    authValidation.validateLevel1Id(dto.getLocationDto().getLevel1Id());
                    authValidation.validateLevel2Id(dto.getLocationDto().getLevel2Id(),dto.getLocationDto().getLevel1Id());
                    authValidation.validateLevel3Id(dto.getLocationDto().getLevel3Id(),dto.getLocationDto().getLevel2Id(),dto.getLocationDto().getLevel1Id());
                    authValidation.validateLevel4Id(dto.getLocationDto().getLevel4Id(),dto.getLocationDto().getLevel3Id(),dto.getLocationDto().getLevel2Id(),dto.getLocationDto().getLevel1Id());
                }
                 if(Objects.nonNull(dto.getUserType())){
                    authValidation.validateUserType(dto.getUserType());
                }
                AuthUserDto authUserDto=keycloakIntegration.createUser(dto);

                sendNotificationMail(authUserDto);


                //auditing the updates made
                auditMasterDto.setEventId(AuditEnum.USER_MANAGEMENT.getValue());
                auditMasterDto.setWhen(date);
                auditMasterDto.setReferenceId(String.valueOf(authUserDto.getKeyCloakId()));
                auditMasterDto.setActionType(ActionTypeEnum.ADD.getValue());
                auditMasterDto.setWho(dto.getAuthUserData().getUsername());
                auditMasterDto.setDescription(String.format(CREATED_USER,authUserDto.getUsername()));
                kafkaSendMessage.sendMessage(auditMasterDto);

                return authUserDto ;
            }
            else{
                throw new AuthException(AuthException.VALIDATION_FAILED, HttpStatus.BAD_REQUEST);
            }
        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.USER_NOT_CREATED, HttpStatus.NOT_FOUND);
        }
    }

    private void sendNotificationMail(AuthUserDto authUserDto) {
        try{
            PayloadValue payloadDto = new PayloadValue();
            NotificationRequestsDto notifyRequestsDto = new NotificationRequestsDto();
            UserActivationPasswordEntity userActivationPasswordEntity=new UserActivationPasswordEntity();
            String tokenExpire= ConfigCache.getConfigValue(ConfigurationTypeEnum.GENERAL_PASSWORD_TOKEN_EXPIRY.getKey());
            String baseUri= ConfigCache.getConfigValue(ConfigurationTypeEnum.GENERAL_UI_BASE_URL.getKey());
            String token=generateToken(authUserDto.getKeyCloakId(),authUserDto.getUsername(),authUserDto.getEmail(), Long.parseLong(tokenExpire));
            StringBuilder uriBuilder = new StringBuilder();
            uriBuilder.append(baseUri).append(resetPasswordLink);
            //uriBuilder.append(resetPasswordLink);
            uriBuilder.append("?token=").append(token);
            uriBuilder.append("&username=").append(authUserDto.getUsername());

            userActivationPasswordEntity.setToken(token);
            userActivationPasswordEntity.setUserId(authUserDto.getKeyCloakId());
            userActivationPasswordEntity.setUserName(authUserDto.getUsername());
            userActivationPasswordEntity.setEmail(authUserDto.getEmail());
            userActivationPasswordEntity.setIsDeleted((short)GlobalYesNoEnum.NO.getValue());
            userActivationPasswordRepository.save(userActivationPasswordEntity);

            payloadDto.setName(authUserDto.getUsername());
            payloadDto.setEmail(authUserDto.getEmail());
            payloadDto.setLink(uriBuilder.toString());

            JSONObject jsonPayload = new JSONObject(payloadDto);

            notifyRequestsDto.setPayload(jsonPayload.toString());
            notifyRequestsDto.setReceivedDate(new Date());
            notifyRequestsDto.setRequestModeType(NotifyRequestModeTypeEnum.EVENT.getValue());
            notifyRequestsDto.setEventId(Integer.parseInt(notifyEventId));
            sender.sendData(notifyRequestsDto);

        } catch (Exception e) {
            LOG.error(AuthException.USER_NOTIFICATION_MAIL_NOT_SENT);
        }
    }

    private String generateToken(String id, String issuer, String subject, long ttlMillis) {
        try{
            //The JWT signature algorithm we will be using to sign the token
            SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;

            long nowMillis = System.currentTimeMillis();
            Date now = new Date(nowMillis);

            //We will sign our JWT with our ApiKey secret
            byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(SECRET_KEY);
            Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());

            //Let's set the JWT Claims
            JwtBuilder builder = Jwts.builder().setId(id)
                    .setIssuedAt(now)
                    .setSubject(subject)
                    .setIssuer(issuer)
                    .signWith(signatureAlgorithm, signingKey);

            //if it has been specified, let's add the expiration
            if (ttlMillis >= 0) {
                long expMillis = nowMillis + ttlMillis;
                Date exp = new Date(expMillis);
                builder.setExpiration(exp);
            }

            //Builds the JWT and serializes it to a compact, URL-safe string
            return builder.compact();
        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.TOKEN_NOT_GENERATED, HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public AuthUserDto updateUser(String id, AuthUserDto dto) throws AuthException {
        try{
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            Date date = new Date();
            if(authValidation.validateFirstname(dto.getFirstName()) &&
                    authValidation.validateLastname(dto.getLastName()) &&
                    authValidation.validateEmail(dto.getEmail()) &&
                    authValidation.validateMobileNum(dto.getMobileNumber())){
                if(Objects.nonNull(dto.getLocationDto())){
                    authValidation.validateLevel1Id(dto.getLocationDto().getLevel1Id());
                    authValidation.validateLevel2Id(dto.getLocationDto().getLevel2Id(),dto.getLocationDto().getLevel1Id());
                    authValidation.validateLevel3Id(dto.getLocationDto().getLevel3Id(),dto.getLocationDto().getLevel2Id(),dto.getLocationDto().getLevel1Id());
                    authValidation.validateLevel4Id(dto.getLocationDto().getLevel4Id(),dto.getLocationDto().getLevel3Id(),dto.getLocationDto().getLevel2Id(),dto.getLocationDto().getLevel1Id());
                }
                if(Objects.nonNull(dto.getUserType())){
                    authValidation.validateUserType(dto.getUserType());
                }

                AuthUserDto authUserDto= keycloakIntegration.updateUser(id,dto);
                //auditing the updates made
                auditMasterDto.setEventId(AuditEnum.USER_MANAGEMENT.getValue());
                auditMasterDto.setWhen(date);
                auditMasterDto.setReferenceId(String.valueOf(authUserDto.getKeyCloakId()));
                auditMasterDto.setActionType(ActionTypeEnum.UPDATE.getValue());
                auditMasterDto.setWho(dto.getAuthUserData().getUsername());
                auditMasterDto.setDescription(String.format(EDIT_USER,authUserDto.getUsername()));
                kafkaSendMessage.sendMessage(auditMasterDto);
                return authUserDto;
            }
            else{
                throw new AuthException(AuthException.VALIDATION_FAILED, HttpStatus.BAD_REQUEST);
            }
        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.USER_NOT_CREATED, HttpStatus.NOT_FOUND);
        }

    }

    @Override
    public UserActivationPasswordDto activatePassword(PasswordResetValueDto dto) throws AuthException {
        try {
            UserActivationPasswordDto userActivationPasswordDto = new UserActivationPasswordDto();
            UserActivationPasswordEntity userActivationPasswordEntity = userActivationPasswordRepository.findByUsername(dto.getUserName());
            if (Objects.isNull(userActivationPasswordEntity)) {
                throw new AuthException(AuthException.USER_NOT_FOUND, HttpStatus.INTERNAL_SERVER_ERROR);
            }
            if (!dto.getToken().equals(userActivationPasswordEntity.getToken())) {
                throw new AuthException(AuthException.UNAUTHORIZED_INVALID_ACCESS, HttpStatus.INTERNAL_SERVER_ERROR);
            }
            if (dto.getConfirmPassword().equals(dto.getReConfirmPassword())) {
                if (authValidation.passwordValidation(dto.getConfirmPassword())) {
                    ResetPasswordBodyDto resetPasswordBodyDto = new ResetPasswordBodyDto();
                    resetPasswordBodyDto.setType(PASSWORD);
                    resetPasswordBodyDto.setValue(dto.getConfirmPassword());
                    resetPasswordBodyDto.setTemporary(FALSE);
                    keycloakIntegration.resetPassword(userActivationPasswordEntity.getUserId(), resetPasswordBodyDto);
                    userActivationPasswordEntity.setIsDeleted((short)GlobalYesNoEnum.YES.getValue());
                    userActivationPasswordRepository.save(userActivationPasswordEntity);
                    userActivationPasswordDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                    userActivationPasswordDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                    userActivationPasswordDto.setResponseMessage(RESET_PASSWORD_SUCCESS_MESSAGE);
                   return userActivationPasswordDto;
                } else {
                    throw new AuthException(AuthException.PASSWORD_NOT_VALID, HttpStatus.INTERNAL_SERVER_ERROR);
                }
            } else {
                throw new AuthException(AuthException.WRONG_CONFIRM_PASSWORD, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(), e);
            throw new AuthException(AuthException.USER_NOT_ACTIVATED, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public UserRegistrationDto userRegistration(UserRegistrationDto dto) throws AuthException {
        try {

            if(Boolean.parseBoolean(checkGeoFenceOnSignUp)){
                //This means that signup is allowed only in the pre-configured geo fence that is in the configuration
                LOG.debug("Geo fence check is enabled");

                if(authValidation.isSignupLocationValid(dto.getSignupLocation())) {
                    String geoFence = ConfigCache.getConfigValue(ConfigurationTypeEnum.AUTH_SIGNUP_GEO_FENCE.getKey());

                    LOG.debug("Going to check if signup location {} is in the geo-fence {}", dto.getSignupLocation(), geoFence);

                    if (!geoFenceRepository.isSignUpLocationInGeoFence(dto.getSignupLocation(), geoFence)) {
                        throw new AuthException(AuthException.SIGNUP_NOT_ALLOWED_IN_THIS_REGION, HttpStatus.BAD_REQUEST);
                    }

                    LOG.debug("Geo-fence validated successfully, proceeding with signup");
                }
            }

            boolean briefRepresentation = false;
            String username = NULL, email = NULL, firstName = NULL, lastName = NULL, search = NULL;
            PayloadValue payloadDto = new PayloadValue();
            NotificationRequestsDto notifyRequestsDto = new NotificationRequestsDto();
            AuthUserDto authUserDto = new AuthUserDto();
            if(Objects.nonNull(userRegistrationRepository.findByUsername(dto.getUsername()))){
                throw new AuthException(AuthException.USERNAME_ALREADY_REGISTERED, new String[]{dto.getUsername()}, HttpStatus.INTERNAL_SERVER_ERROR);
            }
            if(Objects.nonNull(userRegistrationRepository.findByEmail(dto.getEmail()))){
                throw new AuthException(AuthException.EMAIL_ALREADY_REGISTERED,  new String[]{dto.getEmail()},HttpStatus.INTERNAL_SERVER_ERROR);
            }
            List<AuthUserDto> authUserDtoList = keycloakIntegration.userList(authUserDto, briefRepresentation, email, firstName, lastName, search, dto.getUsername());
            List<AuthUserDto> authUserList = keycloakIntegration.userList(authUserDto, briefRepresentation, dto.getEmail(), firstName, lastName, search, username);
            if (Objects.nonNull(authUserDtoList) && authUserDtoList.size()>GlobalYesNoEnum.NO.getValue()&&authUserDtoList.get(ZERO).getUsername().equals(dto.getUsername())) {
                    throw new AuthException(AuthException.USER_NAME_ALREADY_EXISTS, HttpStatus.INTERNAL_SERVER_ERROR);
            }if(Objects.nonNull(authUserList)&& authUserList.size()>GlobalYesNoEnum.NO.getValue() &&authUserList.get(ZERO).getEmail().equals(dto.getEmail())) {
                    throw new AuthException(AuthException.EMAIL_ALREADY_EXISTS, HttpStatus.INTERNAL_SERVER_ERROR);
            }
            else {
                if (authValidation.validateUsername(dto.getUsername()) &&
                    authValidation.validateFirstname(dto.getFirstName()) &&
                    authValidation.validateLastname(dto.getLastName()) &&
                    authValidation.validateEmail(dto.getEmail())) {
                    if(Objects.nonNull(dto.getMobileNumber())) {
                        authValidation.validateMobileNum(dto.getMobileNumber());
                    }
                UserRegistrationEntity userRegistrationEntity = userRegistrationAssembler.dtoToEntity(dto);
                userRegistrationEntity.setOtp(OtpGenerator.generateOtp());
                userRegistrationEntity.setIsDeleted((short) GlobalYesNoEnum.NO.getValue());
                userRegistrationRepository.save(userRegistrationEntity);

                payloadDto.setName(dto.getUsername());
                payloadDto.setEmail(dto.getEmail());
                payloadDto.setOtp(userRegistrationEntity.getOtp());
                payloadDto.setPortalName(ConfigCache.getConfigValue(ConfigurationTypeEnum.GENERAL_PORTAL_NAME.getKey()));

                JSONObject jsonPayload = new JSONObject(payloadDto);

                notifyRequestsDto.setPayload(jsonPayload.toString());
                notifyRequestsDto.setReceivedDate(userRegistrationEntity.getCreatedDate());
                notifyRequestsDto.setRequestModeType(NotifyRequestModeTypeEnum.EVENT.getValue());
                notifyRequestsDto.setEventId(Integer.parseInt(userEventId));

                dto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                dto.setResponseMessage(SUCCESS_MESSAGE);
                dto.setEmail(dto.getEmail().replaceAll(MASK_EMAIL, STAR));
                dto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                sender.sendData(notifyRequestsDto);
                return dto;
                } else {
                    throw new AuthException(AuthException.VALIDATION_FAILED, HttpStatus.INTERNAL_SERVER_ERROR);
                }
            }
        }catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(), e);
            throw new AuthException(AuthException.USER_NOT_REGISTERED, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public AuthUserDto signupUser(PasswordResetValueDto dto) {
        UserRegistrationEntity userRegistrationEntity=userRegistrationRepository.findByOtp(dto.getOtp());
        if(userRegistrationEntity==null){
            throw new AuthException(AuthException.WRONG_OTP, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        AuthUserDto authUserDto=new AuthUserDto();
        authUserDto.setUsername(userRegistrationEntity.getUsername());
        authUserDto.setFirstName(userRegistrationEntity.getFirstName());
        authUserDto.setLastName(userRegistrationEntity.getLastName());
        authUserDto.setEmail(userRegistrationEntity.getEmail());
        if(Objects.nonNull(userRegistrationEntity.getMobileNumber())){
            authUserDto.setMobileNumber(userRegistrationEntity.getMobileNumber());
        }
        if(dto.getConfirmPassword().equals(dto.getReConfirmPassword())) {
            if (authValidation.passwordValidation(dto.getConfirmPassword())) {
                authUserDto=keycloakIntegration.signupUser(authUserDto);
                ResetPasswordBodyDto resetPasswordBodyDto = new ResetPasswordBodyDto();
                resetPasswordBodyDto.setType(PASSWORD);
                resetPasswordBodyDto.setValue(dto.getConfirmPassword());
                resetPasswordBodyDto.setTemporary(FALSE);
                keycloakIntegration.resetPassword(authUserDto.getKeyCloakId(), resetPasswordBodyDto);
                authUserDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                authUserDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                authUserDto.setResponseMessage(USER_SIGNUP_SUCCESSFUL);
                userRegistrationRepository.delete(userRegistrationEntity);
                return authUserDto;
            } else {
                throw new AuthException(AuthException.PASSWORD_NOT_VALID, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }else{
            throw new AuthException(AuthException.WRONG_CONFIRM_PASSWORD, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public BaseListDto<AuthUserDto> getUsersByUserType(AuthUserDto dto) throws AuthException {
        try{
            BaseListDto<AuthUserDto> authUserDtoBaseListDto = new  BaseListDto();
            if(dto.getPagination().getSortType() == null || dto.getPagination().getSortType().isEmpty()){
                dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }

            //If the sort by is blank then set the default sort by column to name and order by asc
            if(dto.getPagination().getSortBy() == null || dto.getPagination().getSortBy().isEmpty()){
                dto.getPagination().setSortBy(AuthApplicationConstants.USER_NAME);
                dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }
            List<AuthUserDto> data= keycloakIntegration.getUsersByUserType(dto);
            PaginationDto pageDto = dto.getPagination();
            int fromIndex = (dto.getPagination().getPage() - 1) * dto.getPagination().getLimit();
            if(data == null || data.size() <= fromIndex){
                authUserDtoBaseListDto.setPagination(pageDto);
                assert data != null;
                authUserDtoBaseListDto.getPagination().setCount(data.size());
                authUserDtoBaseListDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                authUserDtoBaseListDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                return  authUserDtoBaseListDto;
            }

            data=data.subList(fromIndex, Math.min(fromIndex + dto.getPagination().getLimit(), data.size()));
            authUserDtoBaseListDto.setPagination(pageDto);
            authUserDtoBaseListDto.getPagination().setCount(data.size());
            authUserDtoBaseListDto.setDataList(data);
            authUserDtoBaseListDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            authUserDtoBaseListDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);

            return authUserDtoBaseListDto;

        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.USER_NOT_AVAILABLE, HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public BaseListDto<AuthUserDto> getUsersByAttributes(AuthUserDto dto) throws AuthException {
        try{
            BaseListDto<AuthUserDto> authUserDtoBaseListDto = new  BaseListDto();
            if(dto.getPagination().getSortType() == null || dto.getPagination().getSortType().isEmpty()){
                dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }

            //If the sort by is blank then set the default sort by column to name and order by asc
            if(dto.getPagination().getSortBy() == null || dto.getPagination().getSortBy().isEmpty()){
                dto.getPagination().setSortBy(AuthApplicationConstants.USER_NAME);
                dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }
            List<AuthUserDto> data= keycloakIntegration.getUsersByAttributes(dto);
            PaginationDto pageDto = dto.getPagination();
            int fromIndex = (dto.getPagination().getPage() - 1) * dto.getPagination().getLimit();
            if(data == null || data.size() <= fromIndex){
                authUserDtoBaseListDto.setPagination(pageDto);
                assert data != null;
                authUserDtoBaseListDto.getPagination().setCount(data.size());
                authUserDtoBaseListDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                authUserDtoBaseListDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                return  authUserDtoBaseListDto;
            }

            data=data.subList(fromIndex, Math.min(fromIndex + dto.getPagination().getLimit(), data.size()));
            authUserDtoBaseListDto.setPagination(pageDto);
            authUserDtoBaseListDto.getPagination().setCount(data.size());
            authUserDtoBaseListDto.setDataList(data);
            authUserDtoBaseListDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            authUserDtoBaseListDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);

            return authUserDtoBaseListDto;

        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.USER_NOT_AVAILABLE, HttpStatus.NOT_FOUND);
        }
    }
}
