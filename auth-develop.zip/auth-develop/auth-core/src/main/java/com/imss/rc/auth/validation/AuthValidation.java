package com.imss.rc.auth.validation;

import com.imss.rc.auth.entity.LocationHierarchyEntity;
import com.imss.rc.auth.enums.CoreDataTypeEnum;
import com.imss.rc.auth.enums.LocationTypeEnum;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.repository.LocationHierarchyRepository;
import com.imss.rc.auth.util.AuthApplicationConstants;
import com.imss.rc.cdh.entity.CoreDataDetailsEntity;
import com.imss.rc.cdh.repository.CoreDataDetailsRepository;
import com.imss.rc.commons.dto.UserLocationDto;
import com.imss.rc.config.enums.ConfigurationTypeEnum;
import com.imss.rc.config.service.ConfigCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.nio.charset.StandardCharsets;
import java.util.Objects;


@Component
public class AuthValidation {

    @Autowired
    LocationHierarchyRepository locationHierarchyRepository;

    @Autowired
    private CoreDataDetailsRepository coreDataDetailsRepository;


    public boolean validateUsername(String username){
        if(StringUtils.isEmpty(username)) {
            throw new AuthException(AuthException.MANDATORY_FIELD_USER_NAME, HttpStatus.BAD_REQUEST);
        }
        if (username.length()> AuthApplicationConstants.LENGTH_ZERO && username.length()<=AuthApplicationConstants.LENGTH_FIFTY&& username.trim().replace(" ","").matches(AuthApplicationConstants.NAME_REGEX)) {
            return true;
        }
        else{
            throw new AuthException(AuthException.USER_NAME_NOT_VALID,  HttpStatus.BAD_REQUEST);
        }
    }

    public boolean validateFirstname(String firstName){
        if(StringUtils.isEmpty(firstName)) {
            throw new AuthException(AuthException.MANDATORY_FIELD_FIRST_NAME, HttpStatus.BAD_REQUEST);
        }
        if (firstName.length()> AuthApplicationConstants.LENGTH_ZERO && firstName.length()<=AuthApplicationConstants.LENGTH_FIFTY && firstName.trim().replace(" ","").matches(AuthApplicationConstants.USER_NAME_REGEX)) {
            return true;
        }
        else{
            throw new AuthException(AuthException.FIRST_NAME_NOT_VALID,  HttpStatus.BAD_REQUEST);
        }
    }

    public boolean validateLastname(String lastName){
        if(StringUtils.isEmpty(lastName)) {
            throw new AuthException(AuthException.MANDATORY_FIELD_LAST_NAME, HttpStatus.BAD_REQUEST);
        }
        if (lastName.length()> AuthApplicationConstants.LENGTH_ZERO && lastName.length()<=AuthApplicationConstants.LENGTH_FIFTY && lastName.trim().replace(" ","").matches(AuthApplicationConstants.USER_NAME_REGEX)) {
            return true;
        }
        else{
            throw new AuthException(AuthException.LAST_NAME_NOT_VALID,  HttpStatus.BAD_REQUEST);
        }
    }

    public boolean validateEmail(String email){
        if(StringUtils.isEmpty(email)) {
            throw new AuthException(AuthException.MANDATORY_FIELD_EMAIL, HttpStatus.BAD_REQUEST);
        }
        if (email.length()> AuthApplicationConstants.LENGTH_ZERO && email.length()<=AuthApplicationConstants.LENGTH_FIFTY && email.trim().replace(" ","").matches(AuthApplicationConstants.EMAIL_REGEX)) {
            return true;
        }
        else{
            throw new AuthException(AuthException.EMAIL_NOT_VALID,  HttpStatus.BAD_REQUEST);
        }
    }

    public boolean validateMobileNum(String mobileNum){
        if(StringUtils.isEmpty(mobileNum)) {
            throw new AuthException(AuthException.MANDATORY_FIELD_MOBILE_NUM, HttpStatus.BAD_REQUEST);
        }
        if (mobileNum.length()> AuthApplicationConstants.LENGTH_ZERO && mobileNum.length()<=AuthApplicationConstants.LENGTH_TEN && mobileNum.trim().replace(" ","").matches(AuthApplicationConstants.MOBILE_NUM_REGEX)) {
            return true;
        }
        else{
            throw new AuthException(AuthException.INVALID_MOBILE_NUM,  HttpStatus.BAD_REQUEST);
        }
    }

    public boolean validateLevel1Id(String levelId){
        if(!StringUtils.isEmpty(levelId)) {
            if (levelId.length() > AuthApplicationConstants.LENGTH_ZERO && levelId.length() <= AuthApplicationConstants.LENGTH_FIFTY) {
                LocationHierarchyEntity entity = locationHierarchyRepository.validateLevelId(Integer.valueOf(levelId));
                if (Objects.nonNull(entity) && entity.getLocationType().equals(LocationTypeEnum.LOCATION_LEVEL_1.getValue())) {
                    return true;
                } else
                    throw new AuthException(AuthException.LEVEL1_ID_NOT_VALID, HttpStatus.BAD_REQUEST);
            }
            throw new AuthException(AuthException.LEVEL1_ID_NOT_VALID, HttpStatus.BAD_REQUEST);
        }
        else
            return true;
    }

    public boolean validateLevel2Id(String level2Id,String level1Id){
        if(!StringUtils.isEmpty(level2Id)) {
            if (Objects.isNull(level1Id) || StringUtils.isEmpty(level1Id)) {
                throw new AuthException(AuthException.MANDATORY_FIELD_LEVEL1_ID, HttpStatus.BAD_REQUEST);
            }

            if (level2Id.length() > AuthApplicationConstants.LENGTH_ZERO && level2Id.length() <= AuthApplicationConstants.LENGTH_FIFTY) {
                LocationHierarchyEntity entity = locationHierarchyRepository.validateLevelId(Integer.valueOf(level1Id));
                if (Objects.nonNull(entity) && entity.getParentId().equals(Integer.parseInt(level2Id))) {
                    return true;
                }
                throw new AuthException(AuthException.LEVEL2_ID_NOT_VALID, HttpStatus.BAD_REQUEST);
            }
            throw new AuthException(AuthException.LEVEL2_ID_NOT_VALID, HttpStatus.BAD_REQUEST);
        }
        else
            return true;
    }

    public boolean validateLevel3Id(String level3Id,String level2Id,String level1Id){
        if(!StringUtils.isEmpty(level3Id)) {
            if (Objects.isNull(level1Id) || StringUtils.isEmpty(level1Id)) {
                throw new AuthException(AuthException.MANDATORY_FIELD_LEVEL1_ID, HttpStatus.BAD_REQUEST);
            }
            if (Objects.isNull(level2Id) || StringUtils.isEmpty(level2Id)) {
                throw new AuthException(AuthException.MANDATORY_FIELD_LEVEL2_ID, HttpStatus.BAD_REQUEST);
            }
            if (level3Id.length() > AuthApplicationConstants.LENGTH_ZERO && level3Id.length() <= AuthApplicationConstants.LENGTH_FIFTY && level3Id.matches(AuthApplicationConstants.LOC_REGEX)) {
                return true;
            } else {
                throw new AuthException(AuthException.LEVEL3_ID_NOT_VALID, HttpStatus.BAD_REQUEST);
            }
        }
        else
            return true;
    }

    public boolean validateLevel4Id(String level4Id,String level3Id,String level2Id,String level1Id){
        if(!StringUtils.isEmpty(level4Id)) {
            if (Objects.isNull(level1Id) || StringUtils.isEmpty(level1Id)) {
                throw new AuthException(AuthException.MANDATORY_FIELD_LEVEL1_ID, HttpStatus.BAD_REQUEST);
            }
            if (Objects.isNull(level2Id) || StringUtils.isEmpty(level2Id)) {
                throw new AuthException(AuthException.MANDATORY_FIELD_LEVEL2_ID, HttpStatus.BAD_REQUEST);
            }
            if (Objects.isNull(level3Id) || StringUtils.isEmpty(level3Id)) {
                throw new AuthException(AuthException.MANDATORY_FIELD_LEVEl3_ID, HttpStatus.BAD_REQUEST);
            }
            if (level4Id.length() > AuthApplicationConstants.LENGTH_ZERO && level4Id.length() <= AuthApplicationConstants.LENGTH_FIFTY && level3Id.matches(AuthApplicationConstants.LOC_REGEX)) {
                return true;
            } else {
                throw new AuthException(AuthException.LEVEL4_ID_NOT_VALID, HttpStatus.BAD_REQUEST);
            }
        }
        else
            return true;
    }

    public boolean validateRoles(String role){
        if(StringUtils.isEmpty(role)) {
            throw new AuthException(AuthException.MANDATORY_FIELD_ROLE, HttpStatus.BAD_REQUEST);
        }
        else{
            return true;
        }
    }

    public boolean passwordValidation(String password){
       String pwd= ConfigCache.getConfigValue(ConfigurationTypeEnum.GENERAL_PASSWORD_POLICY_EXPRESSION.getKey());
        String passwordRegex=pwd.replace("/","");
        if(Objects.nonNull(password) && password.matches(passwordRegex) ) {
            return true;
        }else{
            throw new AuthException(AuthException.INVALID_PASSWORD_VALUE, HttpStatus.BAD_REQUEST);
        }
    }

    public boolean validateGroupName(String roleName){
        if(StringUtils.isEmpty(roleName)) {
            throw new AuthException(AuthException.MANDATORY_FIELD_ROLE_NAME, HttpStatus.BAD_REQUEST);
        }
        if (roleName.length()> AuthApplicationConstants.LENGTH_ZERO && roleName.length()<=AuthApplicationConstants.LENGTH_FIFTY && roleName.trim().replace(" ","").matches(AuthApplicationConstants.NAME_REGEX)) {
            return true;
        }
        else{
            throw new AuthException(AuthException.GROUP_NAME_NOT_VALID,  HttpStatus.BAD_REQUEST);
        }
    }

     public boolean validateUserType(Integer userType) {
        CoreDataDetailsEntity coreDataDetailsEntity = coreDataDetailsRepository.findByUserId(userType, CoreDataTypeEnum.USER_TYPE.getValue());
        if (Objects.isNull(coreDataDetailsEntity)) {
            throw new AuthException(AuthException.INVALID_USER_TYPE, new String[]{String.valueOf(userType)}, HttpStatus.BAD_REQUEST);
        }
        else
            return true;
    }

    public boolean isValidImage(String image) {
        if(Objects.isNull(image) || image.isEmpty())
        {
            throw new AuthException(AuthException.MANDATORY_FIELD_IMAGE, HttpStatus.BAD_REQUEST);
        }
        //The : ; , are required as it is in the beginning else it is really not part of the base64 encoded charset
        if (image.trim().replace(" ","").matches(AuthApplicationConstants.IMAGE_REGEX)) {
            double stringLength = image.length() - "data:image/png;base64,".length();
            double sizeInBytes = 4 * Math.ceil((stringLength / 3))*0.5624896334383812;
            int imageSizeInKb= (int) (sizeInBytes/1000);
            String size = ConfigCache.getConfigValue(ConfigurationTypeEnum.GENERAL_PROFILE_IMAGE_MAX_SIZE.getKey());
            int configFileSize= Integer.parseInt(size);
            if(imageSizeInKb>configFileSize) {
                throw new AuthException(AuthException.MAX_IMAGE_SIZE_EXCEEDS,new String[]{String.valueOf(configFileSize)}, HttpStatus.BAD_REQUEST);
            }
            return true;
        }
        else{
            throw new AuthException(AuthException.IMAGE_NOT_VALID,  HttpStatus.BAD_REQUEST);
        }
    }

    public boolean processLocation(UserLocationDto agentLocationDto, UserLocationDto usersLocationDto){
        boolean flag= false;
        if(Objects.nonNull(agentLocationDto.getLevel1Id()) &&Objects.nonNull(usersLocationDto.getLevel1Id())) {
            if(agentLocationDto.getLevel1Id().equals(usersLocationDto.getLevel1Id())){
                flag=true;
                return flag;
            }
        }
        if(Objects.nonNull(agentLocationDto.getLevel2Id()) &&Objects.nonNull(usersLocationDto.getLevel2Id())){
            if (agentLocationDto.getLevel2Id().equals(usersLocationDto.getLevel2Id())) {
                flag=true;
                return flag;
            }
        }

        if(Objects.nonNull(agentLocationDto.getLevel3Id()) &&Objects.nonNull(usersLocationDto.getLevel3Id())) {
            if (agentLocationDto.getLevel3Id().equals(usersLocationDto.getLevel3Id())) {
                flag=true;
                return flag;
            }
        }

        if (Objects.nonNull(agentLocationDto.getLevel4Id()) &&Objects.nonNull(usersLocationDto.getLevel4Id())) {
            if (agentLocationDto.getLevel4Id().equals(usersLocationDto.getLevel4Id())) {
                flag=true;
                return flag;
            }
        }
        return flag;
    }

    /**
     * This method validates the value sent in the signup location.
     * It has to be a comma saperated value of exactly 2 elements and both of them needs to be of double precision
     * @param signupLocation The value to be validated
     * @return true if the value is valid, throws and exception if it is invalid
     */
    public boolean isSignupLocationValid(String signupLocation) {

        if(signupLocation == null || signupLocation.trim().isEmpty()){
            throw new AuthException(AuthException.INVALID_SIGNUP_LOCATION_BLANK, HttpStatus.BAD_REQUEST);

        }
        String locationParts[] = signupLocation.split(",");

        if(locationParts.length != 2){
            //must have exactly 2 parts
            throw new AuthException(AuthException.INVALID_SIGNUP_LOCATION_NOT_IN_RIGHT_FORMAT, HttpStatus.BAD_REQUEST);
        } else {
            try {
                //Checking if it is a double value
                Double.parseDouble(locationParts[0]);
            } catch (Exception ex){
                throw new AuthException(AuthException.INVALID_SIGNUP_LOCATION_LONG_VALUE_ERROR, new String[]{locationParts[0]}, HttpStatus.BAD_REQUEST);
            }

            try {
                //Checking if it is a double value
                Double.parseDouble(locationParts[1]);
            } catch (Exception ex){
                throw new AuthException(AuthException.INVALID_SIGNUP_LOCATION_LAT_VALUE_ERROR, new String[]{locationParts[1]}, HttpStatus.BAD_REQUEST);
            }
        }

        return true;
    }

}
