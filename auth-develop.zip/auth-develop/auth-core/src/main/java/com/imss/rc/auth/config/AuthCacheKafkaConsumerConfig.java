package com.imss.rc.auth.config;

import com.imss.rc.commons.dto.BaseListDto;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class AuthCacheKafkaConsumerConfig {
    @Value("${kafka.rc.auth.boot.server}")
    private String kafkaServer;

    @Value("${kafka.rc.auth.master.request.group.id}")
    private String kafkaGroupId;

    private ConsumerFactory<String, BaseListDto<Object>> authCacheConfig() {
        Map<String, Object> config = new HashMap<>();
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaServer);
        config.put(ConsumerConfig.GROUP_ID_CONFIG, kafkaGroupId);
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
        config.put(JsonDeserializer.TRUSTED_PACKAGES, "com.imss.rc.*");
        return new DefaultKafkaConsumerFactory<>(config);
    }

    @Bean
    public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, BaseListDto<Object>>> authCacheDataListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String,BaseListDto<Object>> listener = new ConcurrentKafkaListenerContainerFactory<>();
        listener.setConsumerFactory(authCacheConfig());
        return listener;
    }
}
