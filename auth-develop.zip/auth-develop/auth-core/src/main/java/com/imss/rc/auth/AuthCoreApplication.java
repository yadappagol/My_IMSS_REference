package com.imss.rc.auth;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;


@SpringBootApplication
@EnableAutoConfiguration
@Configuration
@EnableJpaAuditing
@EnableJpaRepositories({"com.imss.rc.auth","com.imss.rc.cdh"})
@EntityScan({"com.imss.rc.auth","com.imss.rc.commons","com.imss.rc.cdh"})
@ComponentScan({"com.imss.rc.auth","com.imss.rc.commons","com.imss.rc.notify","com.imss.rc.config","com.imss.rc.audit","com.imss.rc.cdh"})
@EnableAsync
@EnableEncryptableProperties
public class AuthCoreApplication extends SpringBootServletInitializer {

    /**
     * The main method that's being called first on application load.
     * @param args the arguments that are to be provided to the spring application run method
     * @author Sandeep
     */
    public static void main(String[] args) {

        SpringApplication.run(AuthCoreApplication.class, args);

    }

}
