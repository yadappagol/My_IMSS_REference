package com.imss.rc.auth.controller;

import com.imss.rc.auth.dto.AuthUserDto;
import com.imss.rc.auth.dto.PasswordResetValueDto;
import com.imss.rc.auth.dto.UserActivationPasswordDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.service.UserService;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.auth.dto.UserRegistrationDto;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.UserLocationDto;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Objects;

@RestController
public class UserControllerImpl  implements UserController{

    @Autowired
    UserService userService;

    @Override
    public  @ResponseBody
    AuthUserDto viewUsers(String id, HttpServletRequest request) throws AuthException {
        AuthUserDto dto =new AuthUserDto();
        dto.setKeyCloakId(id);
        //Loading the auth user into the dto
        UserAuthDataHandler.resolveAuthBaseData(dto, request);
        return userService.viewUser(dto);

    }

    @Override
    public @ResponseBody AuthUserDto deleteUser(String id, HttpServletRequest request) throws AuthException {
        AuthUserDto dto =new AuthUserDto();
        dto.setKeyCloakId(id);
        //Loading the auth user into the dto
        UserAuthDataHandler.resolveAuthBaseData(dto, request);
        return userService.deleteUser(dto);
    }

    @Override
    public @ResponseBody AuthUserDto createUser(AuthUserDto dto, HttpServletRequest request) throws AuthException {
        //Loading the auth user into the dto
        UserAuthDataHandler.resolveAuthBaseData(dto, request);
        return userService.createUser(dto);
    }

    @Override
    public AuthUserDto updateUser(String id, AuthUserDto dto, HttpServletRequest request) throws AuthException {
        if(Objects.nonNull(dto.getUsername())||Objects.nonNull(dto.getPassword())){
            throw new AuthException(AuthException.FIELDS_NOT_EDITED, HttpStatus.BAD_REQUEST);
        }
        //Loading the auth user into the dto
        UserAuthDataHandler.resolveAuthBaseData(dto, request);
        return userService.updateUser(id,dto);
    }

    @Override
    public UserActivationPasswordDto activatePassword(String token , String userName, PasswordResetValueDto dto, HttpServletRequest request) throws AuthException {
        dto.setToken(token);
        dto.setUserName(userName);
        if(Objects.isNull(dto.getConfirmPassword())||Objects.isNull(dto.getReConfirmPassword())){
            throw new AuthException(AuthException.MANDATORY_FIELD_PASSWORD, HttpStatus.BAD_REQUEST);
        }
       return userService.activatePassword(dto);
    }

    @Override
    public UserRegistrationDto userRegistration(UserRegistrationDto dto, HttpServletRequest request) throws AuthException {
        return userService.userRegistration(dto);
    }

    @Override
    public AuthUserDto signupUser(PasswordResetValueDto dto, HttpServletRequest request) throws AuthException {
        return userService.signupUser(dto);
    }

    @Override
    public BaseListDto<AuthUserDto> getUsersByUserType(Integer page, Integer limit, String sortBy, String sortType, String userType, HttpServletRequest request) throws AuthException {
        AuthUserDto dto = new AuthUserDto();
        PaginationDto pageDto = new PaginationDto();
        if(page< GlobalYesNoEnum.YES.getValue()){
            throw new AuthException(AuthException.INVALID_PAGE, HttpStatus.BAD_REQUEST);
        }
        if(limit< GlobalYesNoEnum.YES.getValue()){
            throw new AuthException(AuthException.INVALID_LIMIT, HttpStatus.BAD_REQUEST);
        }
        dto.setUserType(Integer.valueOf(userType));
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);
        dto.setPagination(pageDto);
        //Loading the auth user into the dto
        UserAuthDataHandler.resolveAuthBaseData(dto, request);
        return userService.getUsersByUserType(dto);
    }

    @Override
    public BaseListDto<AuthUserDto> getUsersByAttributes(String userType, String level1Id, String level2Id, String level3Id, String level4Id, Integer page, Integer limit, String sortBy, String sortType, HttpServletRequest request) throws AuthException {
        AuthUserDto dto = new AuthUserDto();
        PaginationDto pageDto = new PaginationDto();
        if(page< GlobalYesNoEnum.YES.getValue()){
            throw new AuthException(AuthException.INVALID_PAGE, HttpStatus.BAD_REQUEST);
        }
        if(limit< GlobalYesNoEnum.YES.getValue()){
            throw new AuthException(AuthException.INVALID_LIMIT, HttpStatus.BAD_REQUEST);
        }
        UserLocationDto locDtoFilter = new UserLocationDto();

        if(Objects.nonNull(level1Id)) {
            locDtoFilter.setLevel1Id(level1Id);
        }
        if(Objects.nonNull(level2Id)) {
            locDtoFilter.setLevel2Id(level2Id);
        }
        if(Objects.nonNull(level3Id)) {
            locDtoFilter.setLevel3Id(level3Id);
        }
        if(Objects.nonNull(level4Id)) {
            locDtoFilter.setLevel4Id(level4Id);
        }
        if(Objects.nonNull(userType)) {
            dto.setUserType(Integer.valueOf(userType));
        }
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);
        dto.setPagination(pageDto);
        //Loading the auth user into the dto
        UserAuthDataHandler.resolveAuthBaseData(dto, request);

        dto.setLocationDto(locDtoFilter);
        return userService.getUsersByAttributes(dto);
    }

}
