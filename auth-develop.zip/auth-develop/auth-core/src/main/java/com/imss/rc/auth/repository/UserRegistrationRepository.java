package com.imss.rc.auth.repository;

import com.imss.rc.auth.entity.UserRegistrationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRegistrationRepository extends JpaRepository<UserRegistrationEntity, Integer> {

    @Query(value="from UserRegistrationEntity ure where ure.isDeleted=0 and ure.otp= :otp")
    public UserRegistrationEntity findByOtp(@Param("otp") String otp);

    @Query(value="from UserRegistrationEntity ure where ure.isDeleted=0 and ure.username= :username")
    public UserRegistrationEntity findByUsername(@Param("username") String username);

    @Query(value="from UserRegistrationEntity ure where ure.isDeleted=0 and ure.email= :email")
    public UserRegistrationEntity findByEmail(@Param("email")String email);
}
