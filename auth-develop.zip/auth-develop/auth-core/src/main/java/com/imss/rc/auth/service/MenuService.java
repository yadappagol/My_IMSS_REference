package com.imss.rc.auth.service;

import com.imss.rc.auth.dto.MenuDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.commons.dto.BaseListDto;

public interface MenuService {

    public BaseListDto<MenuDto> getAllMenus()throws AuthException;

}
