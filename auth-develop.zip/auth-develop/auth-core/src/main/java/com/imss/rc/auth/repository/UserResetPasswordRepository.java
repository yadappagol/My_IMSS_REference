package com.imss.rc.auth.repository;

import com.imss.rc.auth.entity.UserResetPasswordEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserResetPasswordRepository  extends JpaRepository<UserResetPasswordEntity, Integer> {
    @Query(value="from UserResetPasswordEntity rp where rp.isDeleted=0 and rp.temporaryPassword= :temporaryPassword")
   public UserResetPasswordEntity getByTemporaryPassword(@Param("temporaryPassword") String temporaryPassword);
}
