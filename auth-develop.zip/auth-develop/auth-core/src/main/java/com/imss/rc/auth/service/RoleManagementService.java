package com.imss.rc.auth.service;

import com.imss.rc.auth.dto.AuthResponseRolesDto;
import com.imss.rc.auth.dto.AuthRolesDto;
import com.imss.rc.auth.dto.AuthUserDto;
import com.imss.rc.auth.dto.external.KeycloakRolesDto;
import com.imss.rc.commons.dto.BaseListDto;

public interface RoleManagementService {

    public AuthResponseRolesDto getRole(String id, AuthResponseRolesDto authResponseRolesDto);

    public AuthResponseRolesDto deleteRole(String id, AuthResponseRolesDto authResponseRolesDto);

    public AuthResponseRolesDto createRole(KeycloakRolesDto dto, AuthResponseRolesDto authResponseRolesDto);

    public AuthResponseRolesDto updateRole(KeycloakRolesDto dto, AuthResponseRolesDto authResponseRolesDto);

    public BaseListDto<AuthResponseRolesDto> getAllRoles(KeycloakRolesDto dto, AuthResponseRolesDto authResponseRolesDto);

    public BaseListDto<AuthRolesDto> getRealmRoleMap(String id);

    public BaseListDto<AuthUserDto> getRoleUsers(String id, AuthUserDto authUserDto);
}
