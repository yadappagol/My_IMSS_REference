package com.imss.rc.auth.controller;

import com.imss.rc.auth.dto.*;
import com.imss.rc.auth.dto.external.KeycloakTokenDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.service.AuthService;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.auth.dto.AuthResponseDto;
import com.imss.rc.auth.dto.AuthUserDto;
import com.imss.rc.auth.dto.LoginDto;
import com.imss.rc.auth.dto.TokenDto;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Objects;

@RestController
public class AuthControllerImpl implements AuthController{

    private static final Logger LOG = LoggerFactory.getLogger(AuthControllerImpl.class);

    @Autowired
    AuthService authService;

    @Override
    public @ResponseBody
    AuthResponseDto verifyToken(TokenDto tokenDto, HttpServletResponse response, HttpServletRequest request) throws AuthException {
        LOG.info("verifyToken: Received request: ");

        if(tokenDto.getToken()==null){
            throw new AuthException(AuthException.TOKEN_IS_REQUIRED_TO_VALIDATE, HttpStatus.BAD_REQUEST);
        }
        if(tokenDto.getReference()==null){
            throw new AuthException(AuthException.REFERENCE_IS_REQUIRED_TO_VALIDATE, HttpStatus.BAD_REQUEST);
        }
        return authService.verifyToken(tokenDto);
    }

    @Override
    public AuthResponseDto login(LoginDto loginDto) throws AuthException {
        LOG.info("login: Received request: ");
        if(loginDto.getUsername()==null){
            throw new AuthException(AuthException.NAME_IS_REQUIRED_TO_LOGIN, HttpStatus.BAD_REQUEST);
        }
        if(loginDto.getPassword()==null){
            throw new AuthException(AuthException.PASSWORD_IS_REQUIRED_TO_LOGIN, HttpStatus.BAD_REQUEST);
        }
        return authService.login(loginDto);
    }


    @Override
    public AuthResponseDto verifyAuthToken(HttpServletResponse response, HttpServletRequest request) throws AuthException {

        //If the control has reached here, it means the token is already verified hence just need to call service to get the menu details
        LoginDto loginDto = new LoginDto();

        UserAuthDataHandler.resolveAuthBaseData(loginDto, request);

        loginDto.setToken(request.getHeader(HttpHeaders.AUTHORIZATION).replace("Bearer", "").trim());

        return authService.verifyAuthToken(loginDto);
    }

    @Override
    public BaseListDto<AuthUserDto> getUserList(Integer page, Integer limit, String sortBy, String sortType, boolean briefRepresentation, String email, String firstName, String lastName, String search, String username, HttpServletRequest request) throws AuthException, MalformedURLException {
        AuthUserDto dto = new AuthUserDto();
        PaginationDto pageDto = new PaginationDto();
        if(page< GlobalYesNoEnum.YES.getValue()){
            throw new AuthException(AuthException.INVALID_PAGE, HttpStatus.BAD_REQUEST);
        }
        if(limit< GlobalYesNoEnum.YES.getValue()){
            throw new AuthException(AuthException.INVALID_LIMIT, HttpStatus.BAD_REQUEST);
        }
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);
        dto.setPagination(pageDto);
        //Loading the auth user into the dto
        UserAuthDataHandler.resolveAuthBaseData(dto, request);
        return authService.getUserList(dto,briefRepresentation,email,firstName,lastName,search,username);
    }

    @Override
    public UserResetPasswordDto resetUserPassword(PasswordResetValueDto body, HttpServletRequest request) throws AuthException, IOException {
        return authService.resetUserPassword(body);
    }

    @Override
    public UserResetPasswordDto getTemporaryPassword(String userName, HttpServletRequest request) throws AuthException, IOException {
        return authService.getTemporaryPassword(userName);
    }

    @Override
    public UserDetailsDto getUserProfile(HttpServletRequest request) throws AuthException, IOException {
        return authService.getUserProfile(request);
    }

    @Override
    public KeycloakTokenDto getNewAccessToken(TokenDto tokenDto) throws AuthException {
        return authService.getNewAccessToken(tokenDto);
    }


    @Override
    public UserShortTokenDto getShortToken(HttpServletRequest request) throws AuthException {
        UserShortTokenDto dto = new UserShortTokenDto();

        String origToken = request.getHeader(HttpHeaders.AUTHORIZATION);
        origToken = origToken.replace("Bearer", "").trim();

        UserAuthDataHandler.resolveAuthBaseData(dto, request);

        dto.setOriginalToken(origToken);

        return authService.getShortToken(dto);
    }

    @Override
    public UserShortTokenDto verifyShortToken(UserShortTokenDto dto, HttpServletRequest request) throws AuthException {

        return authService.verifyShortToken(dto);
    }

    @Override
    public AuthUserDto editUserProfileImage(AuthUserDto dto,HttpServletRequest request) throws AuthException, IOException {
        if(Objects.nonNull(dto.getUsername())||Objects.nonNull(dto.getEmail())){
            throw new AuthException(AuthException.FIELDS_NOT_EDITED, HttpStatus.BAD_REQUEST);
        }
        return authService.editUserProfileImage(dto,request);
    }

    @Override
    public UserDetailsDto viewUserProfile(String userName, HttpServletRequest request) throws AuthException {
        return authService.viewUserProfile(userName,request);
    }

    @Override
    public UserResetPasswordDto updatePassword(PasswordResetValueDto body, HttpServletRequest request) throws AuthException, IOException {
        return authService.updatePassword(body,request);
    }
}
