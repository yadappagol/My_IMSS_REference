package com.imss.rc.auth.service;

import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.auth.dto.AuthResponseRolesDto;
import com.imss.rc.auth.dto.AuthRolesDto;
import com.imss.rc.auth.dto.AuthUserDto;
import com.imss.rc.auth.dto.external.KeycloakRolesDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.service.external.KeycloakIntegration;
import com.imss.rc.auth.util.AuthApplicationConstants;
import com.imss.rc.auth.util.KafkaSendAuthMessage;
import com.imss.rc.audit.enums.AuditEnum;
import com.imss.rc.auth.constants.AuthConstant;
import com.imss.rc.auth.validation.AuthValidation;
import com.imss.rc.commons.constants.SortTypeConstants;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.enums.ActionTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
public class RoleManagementServiceImpl implements RoleManagementService {

    private static final Logger LOG = LoggerFactory.getLogger(RoleManagementServiceImpl.class);

    @Autowired
    KeycloakIntegration keycloakIntegration;

    @Autowired
    AuthValidation authValidation;

    @Autowired
    KafkaSendAuthMessage kafkaSendMessage;

    @Override
    public AuthResponseRolesDto getRole(String id, AuthResponseRolesDto authResponseRolesDto) {
        try{
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            AuthResponseRolesDto dto= keycloakIntegration.getRole(id);

            //auditing the updates made
            auditMasterDto.setEventId(AuditEnum.ROLE_MANAGEMENT.getValue());
            auditMasterDto.setWhen(authResponseRolesDto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(dto.getRoleId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(authResponseRolesDto.getCreatedBy());
            auditMasterDto.setDescription(String.format(AuthConstant.VIEW_ROLE,dto.getName()));
            kafkaSendMessage.sendMessage(auditMasterDto);
            return dto;
        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.ROLE_NOT_AVAILABLE, HttpStatus.NOT_FOUND);
        }

    }

    @Override
    public AuthResponseRolesDto deleteRole(String id,AuthResponseRolesDto authResponseRolesDto) {
        try{
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            AuthResponseRolesDto dto= keycloakIntegration.deleteRole(id);

            //auditing the updates made
            auditMasterDto.setEventId(AuditEnum.ROLE_MANAGEMENT.getValue());
            auditMasterDto.setWhen(authResponseRolesDto.getModifiedDate());
            auditMasterDto.setReferenceId(String.valueOf(dto.getRoleId()));
            auditMasterDto.setActionType(ActionTypeEnum.DELETE.getValue());
            auditMasterDto.setWho(authResponseRolesDto.getModifiedBy());
            auditMasterDto.setDescription(String.format(AuthConstant.DELETED_ROLE,dto.getName()));
            kafkaSendMessage.sendMessage(auditMasterDto);
            return dto;
        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.ROLE_NOT_DELETED, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public AuthResponseRolesDto createRole(KeycloakRolesDto dto, AuthResponseRolesDto authResponseRolesDto) {
        try{
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            if(authValidation.validateGroupName(dto.getName())
            ){
                List<AuthResponseRolesDto> authResponseRolesDtoList=keycloakIntegration.getAllRoles(dto);
                   if(!authResponseRolesDtoList.isEmpty()){
                        throw new AuthException(AuthException.DUPLICATE_ROLE_NAME, new String[]{dto.getName()}, HttpStatus.BAD_REQUEST);
                    }
                AuthResponseRolesDto responseRolesDto= keycloakIntegration.createRole(dto);

                //auditing the updates made
                auditMasterDto.setEventId(AuditEnum.ROLE_MANAGEMENT.getValue());
                auditMasterDto.setWhen(authResponseRolesDto.getCreatedDate());
                auditMasterDto.setReferenceId(String.valueOf(responseRolesDto.getRoleId()));
                auditMasterDto.setActionType(ActionTypeEnum.ADD.getValue());
                auditMasterDto.setWho(authResponseRolesDto.getCreatedBy());
                auditMasterDto.setDescription(String.format(AuthConstant.CREATED_ROLES,dto.getName()));
                kafkaSendMessage.sendMessage(auditMasterDto);
                return responseRolesDto;
            }
            else{
                throw new AuthException(AuthException.VALIDATION_FAILED, HttpStatus.BAD_REQUEST);
            }
        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.ROLE_NOT_CREATED, HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public AuthResponseRolesDto updateRole(KeycloakRolesDto dto, AuthResponseRolesDto authResponseRolesDto) {
        try{
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            if(Objects.nonNull(dto.getName())) {
                authValidation.validateGroupName(dto.getName());
            }
            AuthResponseRolesDto responseRolesDto= keycloakIntegration.updateRole(dto);

            //auditing the updates made
            auditMasterDto.setEventId(AuditEnum.ROLE_MANAGEMENT.getValue());
            auditMasterDto.setWhen(authResponseRolesDto.getModifiedDate());
            auditMasterDto.setReferenceId(String.valueOf(responseRolesDto.getRoleId()));
            auditMasterDto.setActionType(ActionTypeEnum.UPDATE.getValue());
            auditMasterDto.setWho(authResponseRolesDto.getModifiedBy());
            auditMasterDto.setDescription(String.format(AuthConstant.EDITED_ROLES,dto.getName()));
            kafkaSendMessage.sendMessage(auditMasterDto);
            return responseRolesDto;
        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.ROLE_NOT_UPDATED, HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public BaseListDto<AuthResponseRolesDto> getAllRoles(KeycloakRolesDto dto, AuthResponseRolesDto authResponseRolesDto) {
        try{
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        BaseListDto<AuthResponseRolesDto> authGroupsListDto = new  BaseListDto<>();
        if(Objects.isNull(dto.getPagination().getSortType()) || dto.getPagination().getSortType().isEmpty()){
            dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
        }

        //If the sort by is blank then set the default sort by column to name and order by asc
        if(Objects.isNull(dto.getPagination().getSortBy()) || dto.getPagination().getSortBy().isEmpty()){
            dto.getPagination().setSortBy(AuthApplicationConstants.NAME);
            dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
        }
        List<AuthResponseRolesDto> authResponseRolesDtoList= keycloakIntegration.getAllRoles(dto);
        authGroupsListDto.setDataList(authResponseRolesDtoList);
        Integer count= keycloakIntegration.countRoles(dto);

        PaginationDto pageDto = dto.getPagination();
        pageDto.setCount(count);

        authGroupsListDto.setPagination(pageDto);
        authGroupsListDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
        authGroupsListDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
        authGroupsListDto.setAuditEventId(AuditEnum.ROLE_MANAGEMENT.getValue());

            //auditing the updates made
            auditMasterDto.setEventId(AuditEnum.ROLE_MANAGEMENT.getValue());
            auditMasterDto.setWhen(authResponseRolesDto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(authResponseRolesDto.getRoleId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(authResponseRolesDto.getCreatedBy());
            auditMasterDto.setDescription(String.format(AuthConstant.VIEW_ROLES_LIST,
                    authGroupsListDto.getPagination().getPage(),
                    authGroupsListDto.getPagination().getLimit(),
                    authGroupsListDto.getPagination().getSortBy(),
                    authGroupsListDto.getPagination().getSortType(),
                    authGroupsListDto.getPagination().getCount())
            );
            kafkaSendMessage.sendMessage(auditMasterDto);
        return authGroupsListDto;

    } catch (AuthException ex) {
        throw ex;
    } catch (Exception e) {
        LOG.error("exception : {} ", e.getMessage(),e);
        throw new AuthException(AuthException.ROLE_NOT_AVAILABLE, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    }

    @Override
    public BaseListDto<AuthRolesDto> getRealmRoleMap(String id) {
        try{
            BaseListDto<AuthRolesDto> baseListDto = new  BaseListDto<>();
            List<AuthRolesDto> authRolesDtoList= keycloakIntegration.getAssignedRealmRole(id);
            baseListDto.setDataList(authRolesDtoList);
            baseListDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            baseListDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            return baseListDto;
        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.ROLE_NOT_AVAILABLE, HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public BaseListDto<AuthUserDto> getRoleUsers(String id, AuthUserDto authUserDto) {
        try{
            AuditMasterDto auditMasterDto= new AuditMasterDto();
            Date date =new Date();
            BaseListDto<AuthUserDto> baseListDto = new  BaseListDto<>();
            List<AuthUserDto> groupMembers=keycloakIntegration.viewRoleMembers(id);
            baseListDto.setDataList(groupMembers);
            baseListDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            baseListDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);

            //auditing the updates made
            auditMasterDto.setEventId(AuditEnum.ROLE_MANAGEMENT.getValue());
            auditMasterDto.setWhen(date);
            auditMasterDto.setReferenceId(String.valueOf(id));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(authUserDto.getAuthUserData().getUsername());
            auditMasterDto.setDescription(String.format(AuthConstant.VIEW_MEMBERS));
            kafkaSendMessage.sendMessage(auditMasterDto);
            return baseListDto;

        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.ROLE_NOT_AVAILABLE, HttpStatus.NOT_FOUND);
        }
    }
}
