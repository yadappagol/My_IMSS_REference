package com.imss.rc.auth.repository;

import com.imss.rc.auth.entity.UserActivationPasswordEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserActivationPasswordRepository extends JpaRepository<UserActivationPasswordEntity, Integer> {

    @Query(value="from UserActivationPasswordEntity upe where upe.userName= :userName and upe.isDeleted=0")
    public  UserActivationPasswordEntity findByUsername(@Param("userName") String userName);
}
