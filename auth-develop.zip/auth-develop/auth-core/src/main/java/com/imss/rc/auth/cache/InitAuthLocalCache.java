package com.imss.rc.auth.cache;

import com.imss.rc.auth.service.external.KeycloakIntegration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * This class initializes the auth local cache
 */
@Component
public class InitAuthLocalCache {

    @Autowired
    KeycloakIntegration keycloakIntegration;

    @PostConstruct
    public void loadAllLocalCache(){
        AuthLocalCache.setAllRealmRoles( keycloakIntegration.getAllRealmRoles().getDataList());
    }
}
