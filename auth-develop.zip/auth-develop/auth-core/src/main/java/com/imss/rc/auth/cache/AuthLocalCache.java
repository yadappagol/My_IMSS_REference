package com.imss.rc.auth.cache;

import com.imss.rc.auth.dto.AuthRealmRoleDto;

import java.util.List;

/**
 * This class is used to cache certain details from keycloak that is used for its own local usage
 * within the micro service.
 *
 * This cache is initialized by he {@link InitAuthLocalCache} class
 */
public class AuthLocalCache {

    private static List<AuthRealmRoleDto> cacheOfAllRealmRoles;

    public static void  setAllRealmRoles(List<AuthRealmRoleDto> data){
        cacheOfAllRealmRoles = data;
    }

    public static List<AuthRealmRoleDto>  getAllRealmRoles(){
        return cacheOfAllRealmRoles;
    }
}
