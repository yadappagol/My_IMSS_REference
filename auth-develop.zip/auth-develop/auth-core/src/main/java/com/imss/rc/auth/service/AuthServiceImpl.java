package com.imss.rc.auth.service;


import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.enums.AuditEnum;
import com.imss.rc.auth.assembler.UserResetPasswordAssembler;
import com.imss.rc.auth.assembler.UserShortTokenAssembler;
import com.imss.rc.auth.cache.AuthLocalCache;
import com.imss.rc.auth.dto.*;
import com.imss.rc.auth.dto.external.IbkartBdDetailsDto;
import com.imss.rc.auth.dto.external.KeycloakTokenDto;
import com.imss.rc.auth.entity.UserResetPasswordEntity;
import com.imss.rc.auth.entity.UserShortTokenEntity;
import com.imss.rc.auth.enums.KeycloakUserAttributesEnum;
import com.imss.rc.auth.enums.LocationTypeEnum;
import com.imss.rc.auth.enums.UserTypeEnum;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.repository.LocationHierarchyRepository;
import com.imss.rc.auth.repository.UserResetPasswordRepository;
import com.imss.rc.auth.repository.UserShortTokenRepository;
import com.imss.rc.auth.service.external.IbkartIntegration;
import com.imss.rc.auth.service.external.KeycloakIntegration;
import com.imss.rc.auth.util.AuthApplicationConstants;
import com.imss.rc.auth.util.JwtTokenReader;
import com.imss.rc.auth.util.KafkaSendAuthMessage;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.auth.validation.AuthValidation;
import com.imss.rc.commons.constants.SortTypeConstants;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.enums.ActionTypeEnum;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import com.imss.rc.commons.exception.IMSSException;
import com.imss.rc.config.enums.ConfigurationTypeEnum;
import com.imss.rc.config.service.ConfigCache;
import com.imss.rc.notify.dto.NotificationRequestsDto;
import com.imss.rc.notify.enums.NotifyRequestModeTypeEnum;
import com.imss.rc.notify.service.KafkaSender;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.*;

import static com.imss.rc.auth.constants.AuthConstant.*;

@Service
public class AuthServiceImpl implements AuthService {

    private static final Logger LOG = LoggerFactory.getLogger(AuthServiceImpl.class);

    @Autowired
    private KeycloakIntegration keycloakIntegration;

    @Autowired
    private IbkartIntegration ibkartIntegration;
    @Autowired
    private UserResetPasswordAssembler userResetPasswordAssembler;
    @Autowired
    private UserResetPasswordRepository userResetPasswordRepository;
    @Autowired
    private UserShortTokenRepository userShortTokenRepository;
    @Autowired
    private UserShortTokenAssembler userShortTokenAssembler;
    @Autowired
    KafkaSender sender;

    @Value("${notify.event.id}")
    private String notifyEventId;

    @Autowired
    private LocationHierarchyRepository locationHierarchyRepository;

    @Autowired
    @Qualifier("authCoreRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private AuthValidation authValidation;

    @Autowired
    KafkaSendAuthMessage kafkaSendMessage;

    /**
     * This method is used to verify the to token sent from IBKart and then if found successful,
     * create the user in keycloak and initiate the session.
     * @param tokenDto for which the token is verified
     * @return AuthResponseDto
     * @throws AuthException is thrown
     */
    @Override
    public AuthResponseDto verifyToken(TokenDto tokenDto) throws AuthException {

        try {

            if(ibkartIntegration.verifyReferenceToken(tokenDto)){

                //Once verified, get the BD details based on the reference number from IBKart
                IbkartBdDetailsDto dto = ibkartIntegration.getUserDataOnReference(tokenDto.getReference());

                if(dto.getSp_name()== null || dto.getSp_code()==null)
                {
                    throw new AuthException(AuthException.MANDATORY_SP_DETAILS, HttpStatus.BAD_REQUEST);
                }

                //Check and create the user in Keycloak as required
                String accessToken = keycloakIntegration.checkAndCreateUserAndGetToken(dto);


                //auditing the login action
                AuditMasterDto auditMasterDto=new AuditMasterDto();
                auditMasterDto.setEventId(AuditEnum.LOGIN_LOGOUT.getValue());
                auditMasterDto.setWhen(new Date(System.currentTimeMillis()));
                auditMasterDto.setActionType(ActionTypeEnum.UPDATE.getValue());
                auditMasterDto.setWho(tokenDto.getReference());
                auditMasterDto.setDescription(USER_LOGGED_IN_TOKEN);
                kafkaSendMessage.sendMessage(auditMasterDto);

                return prepareAuthResponse(accessToken, UserTypeEnum.AGENT.getValue());

            } else {
                throw new AuthException(AuthException.ERROR_WHEN_AUTHENTICATING_WITH_IBKART, HttpStatus.INTERNAL_SERVER_ERROR);
            }

        } catch (AuthException e) {
            throw e;
        } catch (Exception e) {
            LOG.error("token is not valid, exception : {} ", e.getMessage(), e);
            throw new AuthException(AuthException.INVALID_INPUT_PARAMETERS, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



    @Override
    public AuthResponseDto login(LoginDto loginDto) throws AuthException{
        try{
           // String accessToken = keycloakIntegration.validateUserAndGetToken(loginDto.getUsername(),loginDto.getPassword(), true).getAccessToken();
            KeycloakTokenDto keycloakTokenDto=keycloakIntegration.validateUserAndGetToken(loginDto.getUsername(),loginDto.getPassword(), true);
            //auditing the login action
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            auditMasterDto.setEventId(AuditEnum.LOGIN_LOGOUT.getValue());
            auditMasterDto.setWhen(new Date(System.currentTimeMillis()));
            auditMasterDto.setActionType(ActionTypeEnum.UPDATE.getValue());
            auditMasterDto.setWho(loginDto.getUsername());
            auditMasterDto.setDescription(USER_LOGGED_IN_PWD);
            kafkaSendMessage.sendMessage(auditMasterDto);

            AuthResponseDto authResponseDto= prepareAuthResponse(keycloakTokenDto.getAccessToken(), loginDto.getUsername());
            authResponseDto.setExpiresIn(keycloakTokenDto.getExpiresIn());
            authResponseDto.setRefreshToken(keycloakTokenDto.getRefreshToken());
            authResponseDto.setRefreshExpiresIn(keycloakTokenDto.getRefreshExpiresIn());
            return authResponseDto;

        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @Override
    public AuthResponseDto verifyAuthToken(LoginDto loginDto) throws AuthException{
        try{

            /**
             * If the control has come here then it has passed thru the auth interceptor
             * and already validated the token hence just need to prepare the response and
             * send back
             **/

            return prepareAuthResponse(loginDto.getToken(), loginDto.getAuthUserData().getUsername());

        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public BaseListDto<AuthUserDto> getUserList(AuthUserDto dto, boolean briefRepresentation, String email, /*Integer first, */String firstName, String lastName, /*Integer max, */String search, String username/*,String userType, String value*/) throws AuthException{
      try{
          AuditMasterDto auditMasterDto=new AuditMasterDto();
          Date date =new Date();
          BaseListDto<AuthUserDto> auditDtoList = new  BaseListDto();
          if(dto.getPagination().getSortType() == null || dto.getPagination().getSortType().isEmpty()){
              dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
          }

          //If the sort by is blank then set the default sort by column to name and order by asc
          if(dto.getPagination().getSortBy() == null || dto.getPagination().getSortBy().isEmpty()){
              dto.getPagination().setSortBy(AuthApplicationConstants.USER_NAME);
              dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
          }
          List<AuthUserDto>  data= keycloakIntegration.userList(dto,briefRepresentation,email,firstName,lastName,search,username);
          Integer count= keycloakIntegration.countUsers();

          PaginationDto pageDto = dto.getPagination();
          if(data.isEmpty()) {
              pageDto.setCount(data.stream().count());
          }else if(Objects.isNull(email) && Objects.isNull(firstName) && Objects.isNull(lastName) && Objects.isNull(search) && Objects.isNull(username)) {
              pageDto.setCount(count);
          }else{
              pageDto.setCount(data.stream().count());
          }

          auditDtoList.setPagination(pageDto);
          auditDtoList.setDataList(data);
          auditDtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
          auditDtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
          auditDtoList.setAuditEventId(AuditEnum.USER_MANAGEMENT.getValue());

          //auditing the updates made
          auditMasterDto.setEventId(AuditEnum.USER_MANAGEMENT.getValue());
          auditMasterDto.setWhen(date);
          auditMasterDto.setReferenceId(String.valueOf(dto.getKeyCloakId()));
          auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
          auditMasterDto.setWho(dto.getAuthUserData().getUsername());
          auditMasterDto.setDescription(String.format(VIEW_USER_LIST,
                  auditDtoList.getPagination().getPage(),
                  auditDtoList.getPagination().getLimit(),
                  auditDtoList.getPagination().getSortBy(),
                  auditDtoList.getPagination().getSortType(),
                  auditDtoList.getPagination().getCount())
          );
          kafkaSendMessage.sendMessage(auditMasterDto);
          return auditDtoList;

      } catch (AuthException ex) {
          throw ex;
      } catch (Exception e) {
          LOG.error("exception : {} ", e.getMessage(),e);
          throw new AuthException(AuthException.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR);
      }
    }

    @Override
    public UserResetPasswordDto resetUserPassword(PasswordResetValueDto body) throws IOException {
        UserResetPasswordDto userResetPassword=new UserResetPasswordDto();
        UserResetPasswordEntity userResetPasswordEntity=userResetPasswordRepository.getByTemporaryPassword(body.getTempPassword());
        if(userResetPasswordEntity==null){
            throw new AuthException(AuthException.WRONG_TEMPORARY_PASSWORD, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        if(body.getConfirmPassword().equals(body.getReConfirmPassword())) {

            if (userResetPasswordEntity.getUserName().equals(body.getUserName()) &&
                    authValidation.passwordValidation(body.getConfirmPassword())) {
                ResetPasswordBodyDto resetPasswordBodyDto = new ResetPasswordBodyDto();
                resetPasswordBodyDto.setType(PASSWORD);
                resetPasswordBodyDto.setValue(body.getConfirmPassword());
                resetPasswordBodyDto.setTemporary(FALSE);
                keycloakIntegration.resetPassword(userResetPasswordEntity.getUserId(), resetPasswordBodyDto);
                userResetPassword.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                userResetPassword.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                userResetPassword.setResponseMessage(RESET_PASSWORD_SUCCESS_MESSAGE);
                return userResetPassword;
            } else {
                throw new AuthException(AuthException.USER_NOT_FOUND, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }else{
            throw new AuthException(AuthException.WRONG_CONFIRM_PASSWORD, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public UserResetPasswordDto getTemporaryPassword(String username) throws IOException {

        boolean briefRepresentation=FALSE;String email=NULL,firstName=NULL,lastName=NULL,search=NULL;Integer first=NULL_VALUE,max=NULL_VALUE;
        PayloadValue payloadDto = new PayloadValue();
        NotificationRequestsDto notifyRequestsDto = new NotificationRequestsDto();
        UserResetPasswordDto userResetPassword=new UserResetPasswordDto();
        UserResetPasswordDto userResetPasswordDto=new UserResetPasswordDto();
        UserResetPasswordEntity userResetPasswordEntity=new UserResetPasswordEntity();
        AuthUserDto authUserDto=new AuthUserDto();

        List<AuthUserDto> authUserDtos=keycloakIntegration.userList(authUserDto,briefRepresentation,email,firstName,lastName,search,username);
       if(authUserDtos.size()==ZERO || !authUserDtos.get(ZERO).getUsername().equals(username)) {
           throw new AuthException(AuthException.USER_NOT_FOUND, HttpStatus.INTERNAL_SERVER_ERROR);
       }
           userResetPasswordEntity = userResetPasswordAssembler.dtoToEntity(userResetPasswordDto);
           userResetPasswordEntity.setTemporaryPassword(randomAlphaNumeric(TEN));
           userResetPasswordEntity.setUserId(authUserDtos.get(ZERO).getKeyCloakId());
           userResetPasswordEntity.setUserName(authUserDtos.get(ZERO).getUsername());
           userResetPasswordEntity.setEmail(authUserDtos.get(ZERO).getEmail());
           UserAuthDataHandler.resolveEntityBaseData(userResetPasswordDto, userResetPasswordEntity);
           userResetPasswordEntity.setIsDeleted((short) GlobalYesNoEnum.NO.getValue());
           userResetPasswordEntity = userResetPasswordRepository.save(userResetPasswordEntity);
           userResetPasswordDto = userResetPasswordAssembler.entityToDto(userResetPasswordEntity);

           payloadDto.setName(userResetPasswordDto.getUserName());
           payloadDto.setEmail(userResetPasswordDto.getEmail());
           payloadDto.setPortalName(ConfigCache.getConfigValue(ConfigurationTypeEnum.GENERAL_PORTAL_NAME.getKey()));
           payloadDto.setTemporaryPassword(userResetPasswordDto.getTemporaryPassword());

           JSONObject jsonPayload = new JSONObject(payloadDto);

           notifyRequestsDto.setPayload(jsonPayload.toString());
           notifyRequestsDto.setReceivedDate(userResetPasswordEntity.getCreatedDate());
           notifyRequestsDto.setRequestModeType(NotifyRequestModeTypeEnum.EVENT.getValue());
           notifyRequestsDto.setEventId(Integer.parseInt(notifyEventId));

           userResetPassword.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
           userResetPassword.setResponseMessage(SUCCESS_MESSAGE);
           userResetPassword.setEmail(userResetPasswordDto.getEmail().replaceAll(MASK_EMAIL, STAR));
           userResetPassword.setResponseStatus(ResponseDto.STATUS_SUCCESS);
           sender.sendData(notifyRequestsDto);
           return userResetPassword;

    }

    @Override
    public UserDetailsDto getUserProfile(HttpServletRequest httpServletRequest) {

        UserDetailsDto userDetailsDto=new UserDetailsDto();
        AuthUserDto authUserDto=new AuthUserDto();
        boolean briefRepresentation=FALSE;String email=NULL,firstName=NULL,lastName=NULL,search=NULL;Integer first=NULL_VALUE,max=NULL_VALUE;
        String token = httpServletRequest.getHeader(HttpHeaders.AUTHORIZATION).replace("Bearer", "").trim();
        JwtTokenReader jwt = new JwtTokenReader(token);
        String userName=jwt.getValueFromTokenBody(KeycloakUserAttributesEnum.PREFERRED_USER_NAME.getValue());
        List<AuthUserDto> authUserDtos=keycloakIntegration.userList(authUserDto,briefRepresentation,email,firstName,lastName,search,userName);
        userDetailsDto.setFirstName(authUserDtos.get(ZERO).getFirstName());
        userDetailsDto.setLastName(authUserDtos.get(ZERO).getLastName());
        userDetailsDto.setEmail(authUserDtos.get(ZERO).getEmail());
        userDetailsDto.setMobileNumber(authUserDtos.get(ZERO).getMobileNumber());
        userDetailsDto.setUserLocation(authUserDtos.get(ZERO).getLocationDto());
        userDetailsDto.setUsername(authUserDtos.get(ZERO).getUsername());
        userDetailsDto.setImage(authUserDtos.get(ZERO).getImage());
        return userDetailsDto;
    }

    @Override
    public KeycloakTokenDto getNewAccessToken(TokenDto tokenDto) throws AuthException {
        try{

            return keycloakIntegration.GetAccessTokenBasedOnRefreshToken(tokenDto.getToken());

        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public static String randomAlphaNumeric(int count) {
        StringBuilder builder = new StringBuilder();
        while (count-- != ZERO) {
            int character = (int)(Math.random()*ALPHA_NUMERIC_STRING.length());
            builder.append(ALPHA_NUMERIC_STRING.charAt(character));
        }
        return builder.toString();
    }

    private AuthResponseDto prepareAuthResponse(String accessToken, String userName){
        AuthResponseDto responseDto = new AuthResponseDto();

        JwtTokenReader tknReader = new JwtTokenReader(accessToken);

        responseDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
        responseDto.setAuthorizationToken(accessToken);
        responseDto.setMenuDetails(getMenuDetails(tknReader));
        responseDto.setLocationFilters(getLocationFilters(userName, accessToken));
        responseDto.setUserDetails(UserAuthDataHandler.getUserObjectOnToken(accessToken));

        return responseDto;
    }


    /**
     * This method loads the menu from from the realm roles and based on what is allowed to the
     * used from the token
     * @return A list of MenuDto objects constituting the menu
     */
    private List<MenuDto> getMenuDetails(JwtTokenReader jwt){

        HashMap<String, Object> resource =  jwt.getMapFromTokenBody("realm_access");
        ArrayList<String> allowedRealmRoleList = (ArrayList)resource.get("roles") ;

        ArrayList<MenuDto> menuList = new ArrayList<>();
        MenuDto menuDto;

        for(AuthRealmRoleDto authRealmDto : AuthLocalCache.getAllRealmRoles()){
            //Picking all the first level menus where parent is blank only if it is in the allowed realm role list
            if (allowedRealmRoleList.contains(authRealmDto.getName())
                    && (authRealmDto.getParent() == null || authRealmDto.getParent().isEmpty())) {
                menuDto = new MenuDto();


                menuDto.setDisplayKey(authRealmDto.getDisplayKey());
                menuDto.setType(authRealmDto.getType());
                menuDto.setIcon(authRealmDto.getIcon());
                menuDto.setLink(authRealmDto.getLink());
                menuDto.setOrder(authRealmDto.getOrder());
                menuDto.setChildren(getMenusForParent(authRealmDto.getName(), allowedRealmRoleList));
                menuDto.setUiCategory(authRealmDto.getUiCategory());

                //If the children is empty, then the object can be removed
                if (menuDto.getChildren().size() == 0) {
                    menuDto.setChildren(null);
                }

                menuList.add(menuDto);
            }
        }

        MenuDto.sort(menuList);
        return menuList;
    }

    /**
     * This is a recursive method to get all the menus and its children
     * @param parentId The parentId for which the menu details need to be retrieved
     * @return The menu details for the parent id passed
     */
    private ArrayList<MenuDto> getMenusForParent(String parentId,ArrayList<String> allowedRealmRoleList){
        ArrayList<MenuDto> menuList = new ArrayList<>();
        MenuDto menuDto;
        for(AuthRealmRoleDto authRealmDto : AuthLocalCache.getAllRealmRoles()){
            if(allowedRealmRoleList.contains(authRealmDto.getName())
                    && (authRealmDto.getParent() != null && authRealmDto.getParent().equals(parentId))){
                menuDto = new MenuDto();

                menuDto.setDisplayKey(authRealmDto.getDisplayKey());
                menuDto.setType(authRealmDto.getType());
                menuDto.setIcon(authRealmDto.getIcon());
                menuDto.setLink(authRealmDto.getLink());
                menuDto.setOrder(authRealmDto.getOrder());
                menuDto.setChildren(getMenusForParent(authRealmDto.getName(), allowedRealmRoleList));
                menuDto.setUiCategory(authRealmDto.getUiCategory());
                //If the children is empty, then the object can be removed
                if(menuDto.getChildren().size() == 0){
                    menuDto.setChildren(null);
                }

                menuList.add(menuDto);
            }
        }

        MenuDto.sort(menuList);
        return menuList;
    }



    private List<LocationLevelDto> getLocationFilters(String userName, String accessToken){
        List<LocationLevelDto> locList = new ArrayList<>();

        JwtTokenReader tokenReader = new JwtTokenReader(accessToken);

        locList.add(getLocation(LocationTypeEnum.LOCATION_LEVEL_1, tokenReader));
        locList.add(getLocation(LocationTypeEnum.LOCATION_LEVEL_2, tokenReader));
        locList.add(getLocation(LocationTypeEnum.LOCATION_LEVEL_3, tokenReader));
        locList.add(getLocation(LocationTypeEnum.LOCATION_LEVEL_4, tokenReader));

        return locList;
    }

    private LocationLevelDto getLocation(LocationTypeEnum locType, JwtTokenReader tokenReader) {

        LocationLevelDto dto = new LocationLevelDto();

        dto.setLevelName(locType.getName());

        //Get the location attribute from the JWT Token to set it as default id
        String id = tokenReader.getValueFromTokenBody(locType.getAttributeName());
        if (id == null) {
            dto.setFixed(false);
        } else {
            dto.setDefaultId(Integer.parseInt(id));
            dto.setDefaultName(locationHierarchyRepository.getNameForLocationId(dto.getDefaultId()));
            dto.setFixed(true);
        }

        return dto;
    }



    @Override
    public UserShortTokenDto getShortToken(UserShortTokenDto shortTokenDto) throws IMSSException {
        try{

            int shortTokenLength = Integer.parseInt(ConfigCache.getConfigValue(ConfigurationTypeEnum.AUTH_SHORT_TOKEN_LENGTH.getKey()));
            UserShortTokenEntity userShortTokenEntity = new UserShortTokenEntity();

            userShortTokenEntity.setUserId(shortTokenDto.getAuthUserData().getUsername());
            userShortTokenEntity.setOriginalToken(shortTokenDto.getOriginalToken());
            userShortTokenEntity.setShortToken(randomAlphaNumeric(shortTokenLength));
            userShortTokenEntity.setGeneratedDate(new Date(System.currentTimeMillis()));
            userShortTokenEntity.setIsVerified((short)GlobalYesNoEnum.NO.getValue());

            userShortTokenRepository.save(userShortTokenEntity);

            return userShortTokenAssembler.entityToDto(userShortTokenEntity);

        } catch (IMSSException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.UNABLE_TO_GENERATE_SHORT_TOKEN, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public UserShortTokenDto verifyShortToken(UserShortTokenDto shortTokenDto) throws IMSSException {
        try{

            int tokenExpiryInSeconds = Integer.parseInt(ConfigCache.getConfigValue(ConfigurationTypeEnum.AUTH_SHORT_TOKEN_EXPIRY.getKey()));
            UserShortTokenEntity userShortTokenEntity =  userShortTokenRepository.findByShortToken(shortTokenDto.getShortToken());

            //If token not found or it was generated more than token validity time then it is an invalid token
            if(userShortTokenEntity == null ||
                    (System.currentTimeMillis() - userShortTokenEntity.getGeneratedDate().getTime()) > (tokenExpiryInSeconds*1000)
                ) {
                throw new AuthException(AuthException.INVALID_SHORT_TOKEN, HttpStatus.INTERNAL_SERVER_ERROR);
            }

            userShortTokenEntity.setIsVerified((short)GlobalYesNoEnum.YES.getValue());
            userShortTokenEntity.setVerifiedDate(new Date(System.currentTimeMillis()));

            //Setting the data in to the dto before making the original token blank
            shortTokenDto = userShortTokenAssembler.entityToDto(userShortTokenEntity);

            //userShortTokenEntity.setOriginalToken("");//Once verified, making the original token blank

            userShortTokenRepository.save(userShortTokenEntity);

            shortTokenDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);

            return shortTokenDto;

        } catch (IMSSException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.UNABLE_TO_VERIFY_SHORT_TOKEN, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public AuthUserDto editUserProfileImage(AuthUserDto dto, HttpServletRequest request) {
        try{
            AuthUserDto authUserDto=new AuthUserDto();
            boolean briefRepresentation=FALSE;String email=NULL,firstName=NULL,lastName=NULL,search=NULL;Integer first=NULL_VALUE,max=NULL_VALUE;
            if(authValidation.isValidImage(dto.getImage()) &&
                    authValidation.validateFirstname(dto.getFirstName()) &&
                    authValidation.validateLastname(dto.getLastName()) &&
                    authValidation.validateMobileNum(dto.getMobileNumber())){
                String token = request.getHeader(HttpHeaders.AUTHORIZATION).replace("Bearer", "").trim();
                JwtTokenReader jwt = new JwtTokenReader(token);
                String userName=jwt.getValueFromTokenBody(KeycloakUserAttributesEnum.PREFERRED_USER_NAME.getValue());

                List<AuthUserDto> authUserDtoList =keycloakIntegration.userList(authUserDto,briefRepresentation,email,firstName,lastName,search,userName);
                dto.setKeyCloakId(authUserDtoList.get(ZERO).getKeyCloakId());
                dto.setLocationDto(authUserDtoList.get(ZERO).getLocationDto());
                return keycloakIntegration.editUserProfileImage(dto);
            }
            else{
                throw new AuthException(AuthException.VALIDATION_FAILED, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (IMSSException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.UNABLE_TO_UPDATE_IMAGE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public UserDetailsDto viewUserProfile(String userName,HttpServletRequest httpServletRequest) {
        try{
            UserDetailsDto userDetailsDto=new UserDetailsDto();
            AuthUserDto authUserDto=new AuthUserDto();
            boolean briefRepresentation=FALSE;String email=NULL,firstName=NULL,lastName=NULL,search=NULL;Integer first=NULL_VALUE,max=NULL_VALUE;
            String token = httpServletRequest.getHeader(HttpHeaders.AUTHORIZATION).replace("Bearer", "").trim();
            JwtTokenReader jwt = new JwtTokenReader(token);
            String loggedUserName=jwt.getValueFromTokenBody(KeycloakUserAttributesEnum.PREFERRED_USER_NAME.getValue());
          
            List<AuthUserDto> authUserDtoList=keycloakIntegration.userList(authUserDto,briefRepresentation,email,firstName,lastName,search,loggedUserName);

            List<AuthUserDto> authUserList=keycloakIntegration.userList(authUserDto,briefRepresentation,email,firstName,lastName,search,userName);
            if(Objects.isNull(authUserList)||authUserList.isEmpty()){
                throw new AuthException(AuthException.USER_NOT_AVAILABLE, HttpStatus.INTERNAL_SERVER_ERROR);
            }
            if(authValidation.processLocation(authUserList.get(ZERO).getLocationDto(),authUserDtoList.get(ZERO).getLocationDto())){
                    userDetailsDto.setFirstName(authUserList.get(ZERO).getFirstName());
                    userDetailsDto.setLastName(authUserList.get(ZERO).getLastName());
                    userDetailsDto.setEmail(authUserList.get(ZERO).getEmail());
                    userDetailsDto.setMobileNumber(authUserList.get(ZERO).getMobileNumber());
                    userDetailsDto.setUserLocation(authUserList.get(ZERO).getLocationDto());
                    userDetailsDto.setUsername(authUserList.get(ZERO).getUsername());
                    userDetailsDto.setImage(authUserList.get(ZERO).getImage());
                    return userDetailsDto;
                }
                else{
                throw new AuthException(AuthException.UNAUTHORIZED_INVALID_ACCESS, HttpStatus.INTERNAL_SERVER_ERROR);
            }

        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.ERROR_OCCURRED, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public UserResetPasswordDto updatePassword(PasswordResetValueDto body, HttpServletRequest request) {
    try {
        UserResetPasswordDto userResetPassword=new UserResetPasswordDto();
        AuthUserDto authUserDto=new AuthUserDto();
        boolean briefRepresentation=FALSE;String email=NULL,firstName=NULL,lastName=NULL,search=NULL;Integer first=NULL_VALUE,max=NULL_VALUE;
        String token = request.getHeader(HttpHeaders.AUTHORIZATION).replace("Bearer", "").trim();
        JwtTokenReader jwt = new JwtTokenReader(token);
        String userName=jwt.getValueFromTokenBody(KeycloakUserAttributesEnum.PREFERRED_USER_NAME.getValue());

        List<AuthUserDto> authUserDtoList=keycloakIntegration.userList(authUserDto,briefRepresentation,email,firstName,lastName,search,userName);
        if(Objects.isNull(authUserDtoList)||authUserDtoList.size()<GlobalYesNoEnum.YES.getValue()){
            throw new AuthException(AuthException.USER_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
        if(Objects.isNull(body.getConfirmPassword())||Objects.isNull(body.getReConfirmPassword())||Objects.isNull(body.getOldPassword())){
            throw new AuthException(AuthException.MANDATORY_FIELD_PASSWORD, HttpStatus.NOT_FOUND);
        }
        try {
            keycloakIntegration.validateUserAndGetToken(userName, body.getOldPassword(), true);
        }
        catch (AuthException exception) {
            throw new AuthException(AuthException.INVALID_OLD_PASSWORD, HttpStatus.BAD_REQUEST);
        }
            if(body.getConfirmPassword().equals(body.getReConfirmPassword())) {
            if (authValidation.passwordValidation(body.getConfirmPassword())) {
                ResetPasswordBodyDto resetPasswordBodyDto = new ResetPasswordBodyDto();
                resetPasswordBodyDto.setType(PASSWORD);
                resetPasswordBodyDto.setValue(body.getConfirmPassword());
                resetPasswordBodyDto.setTemporary(FALSE);
                keycloakIntegration.resetPassword(authUserDtoList.get(0).getKeyCloakId(), resetPasswordBodyDto);
                userResetPassword.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                userResetPassword.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                userResetPassword.setResponseMessage(UPDATE_PASSWORD_SUCCESS_MESSAGE);
                return userResetPassword;
            } else {
                throw new AuthException(AuthException.INVALID_PASSWORD_VALUE, HttpStatus.BAD_REQUEST);
            }
            }else{
                throw new AuthException(AuthException.WRONG_CONFIRM_PASSWORD, HttpStatus.BAD_REQUEST);
            }
        } catch (AuthException ex) {
            throw ex;
        } catch (Exception e) {
            LOG.error("exception : {} ", e.getMessage(),e);
            throw new AuthException(AuthException.UNABLE_TO_CHANGE_PASSWORD, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
