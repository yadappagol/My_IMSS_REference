#!/bin/bash
if [ $# != 6 ]
then
        echo 'USAGE : run_script.sh <iscreatedb> <istestdatarequired> <username> <password> <db> <host>' 
        echo 'example : run_script.sh true false test_user test123 testdb 172.16.2.22' 
else

        if [ $1 == true ]
        then
	    echo 'Dropping all tables and constriants'
         echo `mysql -u $3 -p$4 -h $6 $5< 99_auth_drop_all_tables.sql`
                
            echo 'Creating table structures'
            echo `mysql -u $3 -p$4 -h $6 $5 < 01_auth_base_scripts.sql`

            echo 'Creating all constraints'
         echo `mysql -u $3 -p$4 -h $6 $5 < 02_auth_base_constraints.sql`

            echo 'Inserting all default data'
        echo `mysql -u $3 -p$4 -h $6 $5 < 03_auth_defaut_data.sql`


            if [ $2 == true ]
            then

              echo 'Inserting test data'
              echo `mysql -u $3 -p$4 -h $6 $5  < 98_auth_test_data.sql`
            else
              echo 'Skipping test data insertion'
            fi

        else
                echo 'Skipping creation of database'
        fi
fi
