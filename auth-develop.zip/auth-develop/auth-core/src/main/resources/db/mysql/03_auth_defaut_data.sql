insert into core_data_types (pk_id, core_key, name, description, additional_data, is_visible)
values (100,'location.hierarchy.types','Location Hierarchy Types', 'The location hierarchy types', '',1);

insert into core_data_details (pk_id, type_id, name, description, is_editable,is_deleted,created_by,created_date,modified_by,modified_date,row_version)
values (10001, 100, 'Country', 'Hierarchy name for country', 0, 0, 'system',now(),'system',now(),1),
(10002, 100, 'Zone', 'Hierarchy name for zone', 0, 0, 'system',now(),'system',now(),1),
(10003, 100, 'State', 'Hierarchy name for state', 0, 0, 'system',now(),'system',now(),1),
(10004, 100, 'Cluster', 'Hierarchy name for cluster', 0, 0, 'system',now(),'system',now(),1),
(10005, 100, 'District', 'Hierarchy name for cluster', 0, 0, 'system',now(),'system',now(),1);

insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version)
values(1, 'India',  null, 10001,  0, 'system',now(),'system',now(),1);


insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version)
values(2, 'North',  1, 10002, 0, 'system',now(),'system',now(),1),
(3, 'South',  1, 10002, 0, 'system',now(),'system',now(),1),
(4, 'East',  1, 10002, 0, 'system',now(),'system',now(),1),
(5, 'West',  1, 10002, 0, 'system',now(),'system',now(),1),
(6, 'Central', 1, 10002, 0, 'system',now(),'system',now(),1),
(7, 'North East', 1, 10002, 0, 'system',now(),'system',now(),1);


insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version) values
(8, 'Andhra Pradesh',  3, 10003, 0, 'system',now(),'system',now(),1),
(9, 'Arunachal Pradesh',  7, 10003, 0, 'system',now(),'system',now(),1),
(10, 'Assam',  7, 10003, 0, 'system',now(),'system',now(),1),
(11, 'Bihar',  4, 10003, 0, 'system',now(),'system',now(),1),
(12, 'Chhattisgarh',  6, 10003, 0, 'system',now(),'system',now(),1),
(13, 'Goa',  5, 10003, 0, 'system',now(),'system',now(),1),
(14, 'Gujarat',  5, 10003, 0, 'system',now(),'system',now(),1),
(15, 'Haryana',  2, 10003, 0, 'system',now(),'system',now(),1),
(16, 'Himachal Pradesh',  2, 10003, 0, 'system',now(),'system',now(),1),
(17, 'Jharkhand',  4, 10003, 0, 'system',now(),'system',now(),1),
(18, 'Karnataka',  3, 10003, 0, 'system',now(),'system',now(),1),
(19, 'Kerala',  3, 10003, 0, 'system',now(),'system',now(),1),
(20, 'Madhya Pradesh',  6, 10003, 0, 'system',now(),'system',now(),1),
(21, 'Maharashtra',  5, 10003, 0, 'system',now(),'system',now(),1),
(22, 'Manipur',  7, 10003, 0, 'system',now(),'system',now(),1),
(23, 'Meghalaya',  7, 10003, 0, 'system',now(),'system',now(),1),
(24, 'Mizoram',  7, 10003, 0, 'system',now(),'system',now(),1),
(25, 'Nagaland',  7, 10003, 0, 'system',now(),'system',now(),1),
(26, 'Odisha',  4, 10003, 0, 'system',now(),'system',now(),1),
(27, 'Punjab',  2, 10003, 0, 'system',now(),'system',now(),1),
(28, 'Rajasthan',  2, 10003, 0, 'system',now(),'system',now(),1),
(29, 'Sikkim',  7, 10003, 0, 'system',now(),'system',now(),1),
(30, 'Tamil Nadu',  3, 10003, 0, 'system',now(),'system',now(),1),
(31, 'Telangana',  3, 10003, 0, 'system',now(),'system',now(),1),
(32, 'Tripura',  7, 10003, 0, 'system',now(),'system',now(),1),
(33, 'Uttar Pradesh',  6, 10003, 0, 'system',now(),'system',now(),1),
(34, 'Uttarakhand',  6, 10003, 0, 'system',now(),'system',now(),1),
(35, 'West Bengal',  4, 10003, 0, 'system',now(),'system',now(),1),
(36, 'Andaman and Nicobar Islands',  3, 10003, 0, 'system',now(),'system',now(),1),
(37, 'Chandigarh',  2, 10003, 0, 'system',now(),'system',now(),1),
(38, 'Daman and Diu',  5, 10003, 0, 'system',now(),'system',now(),1),
(39, 'Delhi',  2, 10003, 0, 'system',now(),'system',now(),1),
(40, 'Jammu and Kashmir',  2, 10003, 0, 'system',now(),'system',now(),1),
(41, 'Ladakh',  2, 10003, 0, 'system',now(),'system',now(),1),
(42, 'Lakshadweep',  3, 10003, 0, 'system',now(),'system',now(),1),
(43, 'Puducherry',  3, 10003, 0, 'system',now(),'system',now(),1);



-- For each state and UT creating one default cluster
insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version) values
(101, 'AP-Default Cluster',  8, 10004, 0, 'system',now(),'system',now(),1),
(102, 'AR-Default Cluster',  9, 10004, 0, 'system',now(),'system',now(),1),
(103, 'AS-Default Cluster',  10, 10004, 0, 'system',now(),'system',now(),1),
(104, 'BR-Default Cluster',  11, 10004, 0, 'system',now(),'system',now(),1),
(105, 'CG-Default Cluster',  12, 10004, 0, 'system',now(),'system',now(),1),
(106, 'GA-Default Cluster',  13, 10004, 0, 'system',now(),'system',now(),1),
(107, 'GJ-Default Cluster',  14, 10004, 0, 'system',now(),'system',now(),1),
(108, 'HR-Default Cluster',  15, 10004, 0, 'system',now(),'system',now(),1),
(109, 'HP-Default Cluster',  16, 10004, 0, 'system',now(),'system',now(),1),
(110, 'JH-Default Cluster',  17, 10004, 0, 'system',now(),'system',now(),1),
(111, 'KA-Default Cluster',  18, 10004, 0, 'system',now(),'system',now(),1),
(112, 'KL-Default Cluster',  19, 10004, 0, 'system',now(),'system',now(),1),
(113, 'MP-Default Cluster',  20, 10004, 0, 'system',now(),'system',now(),1),
(114, 'MH-Default Cluster',  21, 10004, 0, 'system',now(),'system',now(),1),
(115, 'MN-Default Cluster',  22, 10004, 0, 'system',now(),'system',now(),1),
(116, 'ML-Default Cluster',  23, 10004, 0, 'system',now(),'system',now(),1),
(117, 'MZ-Default Cluster',  24, 10004, 0, 'system',now(),'system',now(),1),
(118, 'NL-Default Cluster',  25, 10004, 0, 'system',now(),'system',now(),1),
(119, 'OD-Default Cluster',  26, 10004, 0, 'system',now(),'system',now(),1),
(120, 'PB-Default Cluster',  27, 10004, 0, 'system',now(),'system',now(),1),
(121, 'RJ-Default Cluster',  28, 10004, 0, 'system',now(),'system',now(),1),
(122, 'SK-Default Cluster',  29, 10004, 0, 'system',now(),'system',now(),1),
(123, 'TN-Default Cluster',  30, 10004, 0, 'system',now(),'system',now(),1),
(124, 'TS-Default Cluster',  31, 10004, 0, 'system',now(),'system',now(),1),
(125, 'TR-Default Cluster',  32, 10004, 0, 'system',now(),'system',now(),1),
(126, 'UP-Default Cluster',  33, 10004, 0, 'system',now(),'system',now(),1),
(127, 'UK-Default Cluster',  34, 10004, 0, 'system',now(),'system',now(),1),
(128, 'WB-Default Cluster',  35, 10004, 0, 'system',now(),'system',now(),1),
(129, 'AN-Default Cluster',  36, 10004, 0, 'system',now(),'system',now(),1),
(130, 'CH-Default Cluster',  37, 10004, 0, 'system',now(),'system',now(),1),
(131, 'DD-Default Cluster',  38, 10004, 0, 'system',now(),'system',now(),1),
(132, 'DL-Default Cluster',  39, 10004, 0, 'system',now(),'system',now(),1),
(133, 'JK-Default Cluster',  40, 10004, 0, 'system',now(),'system',now(),1),
(134, 'LA-Default Cluster',  41, 10004, 0, 'system',now(),'system',now(),1),
(135, 'LD-Default Cluster',  42, 10004, 0, 'system',now(),'system',now(),1),
(136, 'PY-Default Cluster',  43, 10004, 0, 'system',now(),'system',now(),1);

insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version) values
(1004, 'Shimoga',  111, 10005, 0, 'system',now(),'system',now(),1),
(1005, 'Bangalore Rural',  111, 10005, 0, 'system',now(),'system',now(),1),
(1006, 'Mangalore',  111, 10005, 0, 'system',now(),'system',now(),1),
(1007, 'Hassan',  111, 10005, 0, 'system',now(),'system',now(),1),
(1008, 'Chikmanglur',  111, 10005, 0, 'system',now(),'system',now(),1),
(1009, 'Madikeri',  111, 10005, 0, 'system',now(),'system',now(),1),
(1010, 'Mysore',  111, 10005, 0, 'system',now(),'system',now(),1),
(1011, 'Sarjapur',  111, 10005, 0, 'system',now(),'system',now(),1),
(1012, 'Karkala',  111, 10005, 0, 'system',now(),'system',now(),1);




insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version) values
(1013, 'Dehradun',  128, 10005, 0, 'system',now(),'system',now(),1),
(1014, 'Haridwar',  128, 10005, 0, 'system',now(),'system',now(),1),
(1015, 'Chamoli',  128, 10005, 0, 'system',now(),'system',now(),1),
(1016, 'Rudraprayag',  128, 10005, 0, 'system',now(),'system',now(),1);

insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version) values
(1017, 'Araria',  104, 10005, 0, 'system',now(),'system',now(),1),
(1018, 'Arwal',  104, 10005, 0, 'system',now(),'system',now(),1);

insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version) values
(1019, 'Bokaro',  110, 10005, 0, 'system',now(),'system',now(),1),
(1020, 'Chatra',  110, 10005, 0, 'system',now(),'system',now(),1);


insert into user_reset_password (pk_id, user_id, user_name, email, temporary_password,is_deleted,created_by,created_date,modified_by,modified_date,row_version) values
(1001, '49ff9d2a-e586-4470-9170-092062fad4a0', 'admin', 'admin@gmail.com', 'RGYWPRXM8R', 0, 'system',now(),'system',now(),1);

insert into user_activation_password (pk_id, user_id, user_name, email,token,is_deleted) values
(1001, '49ff9d2a-e586-4470-9170-092062fad4a0', 'admin', 'admin@gmail.com','eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiIyZjdiZjY4OC05YTY3LTQ3NjUtYmYyNi0zMThhZTI0ODI2OWYiLCJpYXQiOjE2MjY0NTc4NTgsInN1YiI6InRlc3R1c2VyNkBpbXNzLmNvLmluIiwiaXNzIjoidGVhdHVzZXI2IiwiZXhwIjoxNjI2NTQ0MjU4fQ.2x8OTx6ZEH6Fhc7NwF3IyPazHMI4cJ-yvbUpDw8rR3U',0);
