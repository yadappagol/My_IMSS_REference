-- ALTER TABLE ONLY location_hierarchy DROP PRIMARY KEY;
	
-- ALTER TABLE ONLY user_reset_password DROP PRIMARY KEY;

-- ALTER TABLE ONLY user_activation_password DROP PRIMARY KEY;


drop table location_hierarchy;
drop table user_reset_password;
drop table user_activation_password;
drop table user_short_token;
drop table user_signup;
