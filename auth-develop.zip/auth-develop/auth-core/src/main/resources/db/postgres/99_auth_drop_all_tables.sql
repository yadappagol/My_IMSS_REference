ALTER TABLE ONLY location_hierarchy
    DROP CONSTRAINT location_hierarchy_pkey;
	
ALTER TABLE ONLY user_reset_password
    DROP CONSTRAINT user_reset_password_pkey;

ALTER TABLE ONLY user_activation_password
    DROP CONSTRAINT user_activation_password_pkey;

drop table location_hierarchy;
drop table user_reset_password;
drop table user_activation_password;
drop table user_short_token;
drop table user_signup;