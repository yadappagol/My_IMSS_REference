ALTER TABLE location_hierarchy
    ADD CONSTRAINT location_hierarchy_loc_type_fkey 
		FOREIGN KEY(loc_type) 
			REFERENCES core_data_details(pk_id);