insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version)
values(900, 'Cluster Two',  18, 10004, 0, 'system',now(),'system',now(),1);
insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version)
values(901, 'Cluster Three',  18, 10004, 0, 'system',now(),'system',now(),1);
insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version)
values(902, 'Cluster Two',  19, 10004, 0, 'system',now(),'system',now(),1);
insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version)
values(903, 'Cluster Three',  19, 10004, 0, 'system',now(),'system',now(),1);



insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version)
values(9000, 'District 1',  900, 10005, 0, 'system',now(),'system',now(),1);
insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version)
values(9001, 'District 2',  900, 10005, 0, 'system',now(),'system',now(),1);
insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version)
values(9002, 'District 3',  901, 10005, 0, 'system',now(),'system',now(),1);
insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version)
values(9003, 'District 4',  901, 10005, 0, 'system',now(),'system',now(),1);
insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version)
values(9004, 'District 5',  902, 10005, 0, 'system',now(),'system',now(),1);
insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version)
values(9005, 'District 6',  902, 10005, 0, 'system',now(),'system',now(),1);
insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version)
values(9006, 'District 7',  903, 10005, 0, 'system',now(),'system',now(),1);
insert into location_hierarchy(pk_id, name, parent_id, loc_type, is_deleted,created_by,created_date,modified_by,modified_date,row_version)
values(9007, 'District 8',  903, 10005, 0, 'system',now(),'system',now(),1);