CREATE OR REPLACE FUNCTION usp_get_is_signup_location_in_geo_fence
(
    IN i_signup_location_lat varchar,
    IN i_signup_location_long varchar,
	IN i_geo_fence varchar

) RETURNS TABLE ( pk_id bigint,  is_inside varchar)
AS $$
DECLARE
    val_policy_type_new integer;
BEGIN
    RETURN QUERY
        select
            ROW_NUMBER() OVER (ORDER BY 1)  as pk_id,
            cast (st_intersects(geometry(ST_Point(cast(i_signup_location_lat as numeric(10,2)), cast(i_signup_location_long as numeric(10,2)) )),
                ST_MakePolygon(
                    ST_GeomFromText(
                        concat('LINESTRING (',i_geo_fence,')')
                    )
                )
            ) as varchar) as is_inside ;
END;
$$

LANGUAGE 'plpgsql';
