#!/bin/sh

function login() {
  # This command is to login and create a session
  sh $1/kcadm.sh config credentials --server $2/auth --realm $3 --user $4 --client admin-cli --password $5
}

menuList=$(jq -r '.menu_details'  $1)
commonClientRolesList=$(jq -r '.common_client_roles'  $1)

for row in $(echo "${menuList}" | jq -r '.[] | @base64'); do

    #Need to login frequently as the token gets invalidated
    login $KEYCLOAK_BIN $KEYCLOAK_SERVER $REALM_ID $USER_NAME $PASSWORD
    _jq()
    {
     echo ${row} | base64 --decode | jq -r ${1}
    }

    sh $KEYCLOAK_BIN/kcadm.sh create roles -r $REALM_ID -s name="$(_jq '.name')" -s description="$(_jq '.desc')"

    sh $KEYCLOAK_BIN/kcadm.sh update roles/$(_jq '.name') -r $REALM_ID  -s attributes="{\"display-key\":[\"$(_jq '.display_key')\"], \"icon\":[\"$(_jq '.icon')\"], \"link\":[\"$(_jq '.link')\"], \"type\":[\"$(_jq '.type')\"], \"parent\":[\"$(_jq '.parent')\"], \"order\":[\"$(_jq '.order')\"], \"source\":[\"ipp\"]}"

    clientRoleList=$(_jq '.client_roles')
    # echo "LIST: ${clientRoleList}"
    #Adding the API client roles to the realm roles
    for clientRole in $(echo "${clientRoleList}" | jq -r '.[] '); do
      echo "    Client role:  $clientRole being added to $(_jq '.name')"

      sh $KEYCLOAK_BIN/kcadm.sh add-roles --rname=$(_jq '.name') --cclientid $CLIENT_NAME --rolename $clientRole
    done

    for commonClintRole in $(echo "${commonClientRolesList}" | jq -r '.[] '); do
      echo "    Common Client role:  $commonClintRole being added to $(_jq '.name')"
      sh $KEYCLOAK_BIN/kcadm.sh add-roles --rname=$(_jq '.name') --cclientid $CLIENT_NAME --rolename $commonClintRole
    done
done