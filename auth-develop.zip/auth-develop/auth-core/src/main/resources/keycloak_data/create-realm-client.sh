#!/bin/sh

function login() {
  # This command is to login and create a session
  sh $1/kcadm.sh config credentials --server $2/auth --realm master --user $4 --client admin-cli --password $5
}

login $KEYCLOAK_BIN $KEYCLOAK_SERVER $REALM_ID $USER_NAME $PASSWORD

sed -i s/_REALM_ID_TO_BE_REPLACED_/"$REALM_ID"/g data/realm_details.json
sed -i s/_CLIENT_NAME_TO_BE_REPLACED_/"$CLIENT_NAME"/g data/realm_client_details.json

echo "    Deleting realm ${REALM_ID} if already present"
sh $KEYCLOAK_BIN/kcadm.sh delete realms/$REALM_ID

echo "    Creating realm ${REALM_ID}"
sh $KEYCLOAK_BIN/kcadm.sh create realms -f data/realm_details.json

#CID=$(sh $KEYCLOAK_BIN/kcadm.sh create clients -r $REALM_ID -s clientId=ipp-auth-client -s 'redirectUris=["http://localhost:8980/myapp/*"]' -i)

echo "    Creating client ${CLIENT_NAME}"
sh $KEYCLOAK_BIN/kcadm.sh create clients -r $REALM_ID -f data/realm_client_details.json
