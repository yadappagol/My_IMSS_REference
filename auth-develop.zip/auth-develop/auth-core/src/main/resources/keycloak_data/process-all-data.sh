# This script file is used to create the required client roles(api roles) and the realm roles(Menus)

#!/bin/sh

if [ $# != 9 ]
then
        echo 'USAGE : process-all-data.sh <isReCreateRealm> <isCreateClientRoles> <isCreateRealmRoles> <username> <password> <keycloakURL> <keycloakBin> <realmId> <client-name>'
        echo 'example : process-all-data.sh true true true admin admin http://localhost:7070 ../keycloak-12.0.3/bin/ Insurance-Portal ipp-auth-clint-2'
else

        export USER_NAME=$4
        export PASSWORD=$5
        export KEYCLOAK_SERVER=$6
        export KEYCLOAK_BIN=$7
        export REALM_ID=$8
        export CLIENT_NAME=$9

        login $KEYCLOAK_BIN $KEYCLOAK_SERVER $REALM_ID $USER_NAME $PASSWORD

        if [ $1 == true ]
        then
            echo '################################################################'
            echo 'Re-creating the realm , client and all configurations of client'
            echo '################################################################'
            sh create-realm-client.sh
        fi

        export CLIENT_ID=$( sh $KEYCLOAK_BIN/kcadm.sh get clients?clientId=$CLIENT_NAME -r $REALM_ID | jq -r '.[0].id')
        echo "Resolved id of client to ${CLIENT_ID}"

        if [ $2 == true ]
        then
            echo '#####################################'
            echo 'Creating Client Roles (API-roles)'
            echo '#####################################'

            echo '## Creating audit api roles'
            sh create-client-roles.sh ./data/api_roles_audit.json

            echo '## Creating auth api roles'
            sh create-client-roles.sh ./data/api_roles_auth.json

            echo '## Creating commission api roles'
            sh create-client-roles.sh ./data/api_roles_commission.json

            echo '## Creating config api roles'
            sh create-client-roles.sh ./data/api_roles_config.json

            echo '## Creating docs api roles'
            sh create-client-roles.sh ./data/api_roles_docs.json

            echo '## Creating imd api roles'
            sh create-client-roles.sh ./data/api_roles_imd.json

            echo '## Creating notify api roles'
            sh create-client-roles.sh ./data/api_roles_notify.json

            echo '## Creating tpi api roles'
            sh create-client-roles.sh ./data/api_roles_tpi.json

            echo '## Creating txn api roles'
            sh create-client-roles.sh ./data/api_roles_txn.json
        fi


        if [ $3 == true ]
        then
            echo '#####################################'
            echo 'Creating Realm Roles (Menus)'
            echo '#####################################'
            sh create-realm-roles.sh ./data/menu_details.json
        fi

        echo "#####################################"
        echo "PROCESS COMPLETED "
        echo "Realm         : $REALM_ID"
        echo "Client Name   : $CLIENT_NAME"
        echo "Client Id     : $CLIENT_ID"
        echo "#####################################"
fi