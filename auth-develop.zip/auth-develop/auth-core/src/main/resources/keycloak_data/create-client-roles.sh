#!/bin/sh

function login() {
  # This command is to login and create a session
  sh $1/kcadm.sh config credentials --server $2/auth --realm $3 --user $4 --client admin-cli --password $5
}

cnt=0
max=10
module=$(jq -r '.module' $1)
jsonlist=$(jq -r '.api_roles'  $1)
# inside the loop, you cant use the fuction _jq() to get values from each object.
login $KEYCLOAK_BIN $KEYCLOAK_SERVER $REALM_ID $USER_NAME $PASSWORD
for row in $(echo "${jsonlist}" | jq -r '.[] | @base64'); do

    if [[ "$cnt" -gt 10 ]];
    then
      #Need to login frequently as the token gets invalidated
      login $KEYCLOAK_BIN $KEYCLOAK_SERVER $REALM_ID $USER_NAME $PASSWORD
      cnt=0
    fi

    _jq()
    {
     echo ${row} | base64 --decode | jq -r ${1}
    }

    sh $KEYCLOAK_BIN/kcadm.sh create clients/$CLIENT_ID/roles -r $REALM_ID -s name="$(_jq '.name')" -s description="$(_jq '.desc')"
    sh $KEYCLOAK_BIN/kcadm.sh update clients/$CLIENT_ID/roles/$(_jq '.name') -r $REALM_ID -s attributes="{\"path\":[\"$(_jq '.api')\"], \"module\":[\"$module\"], \"methods\":[\"$(_jq '.methods')\"], \"source\":[\"ipp\"]}"
    cnt=$cnt+1
    #echo "Name: $(_jq '.name')"
    #echo "Desc: $(_jq '.desc')"
done
