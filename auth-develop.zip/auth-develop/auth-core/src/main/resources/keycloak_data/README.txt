Run the process-all-data.sh command too create all the client roles (API roles) and the Realm roles (Menus).

The following need to be installed for the script file to work

* sudo yum install jq
* sudo yum install dos2unix

when you copy the files into the linux system, run the command 'dos2unix *' in all the folders

if you get "null [unknown_error]"" as the error message then it is at permission issue and the user being used to run the admin-cli should have the manage-realms role for realm-management client.