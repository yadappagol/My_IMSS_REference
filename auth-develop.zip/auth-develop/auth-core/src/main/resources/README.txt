If the certificate of the ibkart auth url is changed or need to be updated when deploying to production, do the following steps
1. Download the certificate into a local folder
2. Verify that the certificate path is valid by opening the locally saved certificate
3. Create a jks file using the keytool command as shown below
    cmd: keytool -import -alias <alias name> -keystore <keystore file> -storepass <keystore password> -trustcacerts -file <certifcate file>
    ex: keytool -import -alias ibkart-ca -keystore ipp-auth-trust-store.jks -storepass IppAuth@123 -trustcacerts -file ipp.cer
4. Update the jks file name and the password if any changes in the property file

