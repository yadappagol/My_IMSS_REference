package com.imss.rc.auth.controller;

import com.imss.rc.auth.dto.AuthResponseDto;
import com.imss.rc.auth.exception.AuthException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface TestController {
    @GetMapping(value = "/auth/test", produces = "application/json")
    public @ResponseBody
    AuthResponseDto testCall(@RequestParam String inp1, HttpServletResponse response, HttpServletRequest request) throws AuthException;
}
