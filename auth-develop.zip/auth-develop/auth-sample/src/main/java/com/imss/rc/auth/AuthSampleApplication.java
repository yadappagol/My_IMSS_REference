package com.imss.rc.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.scheduling.annotation.EnableAsync;


@SpringBootApplication
@EnableAutoConfiguration
@Configuration
@EnableJpaAuditing
@ComponentScan({"com.imss.rc.auth","com.imss.rc.commons"})
@EntityScan({"com.imss.rc.auth","com.imss.rc.commons"})
@EnableAsync
public class AuthSampleApplication extends SpringBootServletInitializer {

    /**
     * The main method that's being called first on application load.
     * @param args the arguments that are to be provided to the spring application run method
     * @author
     */
    public static void main(String[] args) {

        ConfigurableApplicationContext ctx = SpringApplication.run(AuthSampleApplication.class, args);

    }

}