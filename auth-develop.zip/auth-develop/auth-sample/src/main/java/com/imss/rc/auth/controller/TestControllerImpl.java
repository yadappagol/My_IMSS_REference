package com.imss.rc.auth.controller;

import com.imss.rc.auth.dto.AuthResponseDto;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.ResponseDto;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RestController
public class TestControllerImpl implements TestController{

    @Override
    public @ResponseBody
    AuthResponseDto testCall(String inp1, HttpServletResponse response, HttpServletRequest request) throws AuthException {


        AuthResponseDto dto = new AuthResponseDto();

        UserAuthDataHandler.resolveAuthBaseData(new BaseDto(),request);

        dto.setResponseStatus(ResponseDto.STATUS_SUCCESS);

        return dto;

    }

}
