This microservice will have the code for the authentication and authorization related functionality.

This will also integrate with Keycloak as required