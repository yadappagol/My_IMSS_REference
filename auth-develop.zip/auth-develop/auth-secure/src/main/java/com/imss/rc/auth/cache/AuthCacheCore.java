package com.imss.rc.auth.cache;

import com.imss.rc.auth.dto.AuthPropertiesDto;

import java.util.HashMap;
import java.util.Map;

public class AuthCacheCore {
    public static final String API_ROLES_TYPE = "apiRoles";
    public static final String CONFIG_PROPERTIES = "config";

    protected static HashMap<String, Map<String,Object>> cache=new HashMap<>();

    /**
     * Method to put the role name into the cache.
     * @param module The module for which the role is being added
     * @param method The key that is used to define the role name This is <method>@<uri path>
     * @param roleName the role name
     */
    protected static void putApiRole(String module, String method, String path, String roleName){
        cache.computeIfAbsent(API_ROLES_TYPE, k -> new HashMap<>());

        //Create an empty map for the module if not present
        cache.get(API_ROLES_TYPE).computeIfAbsent(module.trim(), k -> new HashMap<String, Object>());

        //Create an empty map for the method if not present
        ((HashMap<String,Object>)cache.get(API_ROLES_TYPE).get(module.trim())).computeIfAbsent(method.toLowerCase().trim(), k -> new HashMap<String, Object>());


        //Put the role into the map of methods
        ((HashMap<String,Object>)((HashMap<String,Object>)cache.get(API_ROLES_TYPE).get(module.trim())).get(method.toLowerCase().trim())).put(path.trim(), roleName);

    }


    protected static void removeApiRole(String module, String method, String path){
        cache.computeIfAbsent(API_ROLES_TYPE, k -> new HashMap<>());

        //Create an empty map for the module if not present
        cache.get(API_ROLES_TYPE).computeIfAbsent(module.trim(), k -> new HashMap<String, Object>());

        //Create an empty map for the method if not present
        ((HashMap<String,Object>)cache.get(API_ROLES_TYPE).get(module.trim())).computeIfAbsent(method.toLowerCase().trim(), k -> new HashMap<String, Object>());


        //Put the role into the map of methods
        ((HashMap<String,Object>)((HashMap<String,Object>)cache.get(API_ROLES_TYPE).get(module.trim())).get(method.toLowerCase().trim())).remove(path.trim());
    }

    protected static void putConfigProperties(AuthPropertiesDto authPropertiesDto){
        cache.computeIfAbsent(CONFIG_PROPERTIES, k -> new HashMap<String, Object>());

        cache.get(CONFIG_PROPERTIES).put(CONFIG_PROPERTIES, authPropertiesDto);
    }

    protected static void resetApiRole(){
        cache.put(API_ROLES_TYPE, new HashMap<String, Object>());
    }
}
