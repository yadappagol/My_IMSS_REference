package com.imss.rc.auth.util;

import com.imss.rc.auth.interceptor.TokenAuthenticateInterceptor;
import com.imss.rc.auth.cache.AuthCache;
import com.imss.rc.auth.dto.external.KeycloakUserDto;
import com.imss.rc.auth.enums.KeycloakUserAttributesEnum;
import com.imss.rc.auth.enums.LocationTypeEnum;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.GenericBaseDto;
import com.imss.rc.commons.dto.UserDto;
import com.imss.rc.commons.dto.UserLocationDto;
import com.imss.rc.commons.entity.BaseEntity;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Component
public class UserAuthDataHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserAuthDataHandler.class);


    //Hiding the default constructor
    private UserAuthDataHandler(){

    }


    /**
     * The methods picks the user object from the request that is set in the interceptor
     * and set the the base data
     * @param dto The dto object which is a child of {@link BaseDto} class
     * @param request The HttpServletRequest object to resolve the data
     * @see TokenAuthenticateInterceptor
     */
    public static void resolveAuthBaseData(BaseDto dto, HttpServletRequest request) throws AuthException{

        //This attribute is set in TokenAuthenticateInterceptor
        UserDto userDto = (UserDto) request.getAttribute(AuthApplicationConstants.AUTH_USER_DATA_OBJECT);

        if(userDto != null) {
            dto.setCreatedDate(new Date(System.currentTimeMillis()));
            dto.setCreatedBy(userDto.getUsername());
            dto.setModifiedDate(dto.getCreatedDate());
            dto.setModifiedBy(userDto.getUsername());
            dto.setAuthUserData(userDto);
        } else {
            throw new AuthException(AuthException.AUTHORIZED_USER_NOT_AVAILABLE, HttpStatus.UNAUTHORIZED);
        }
    }

    public static void resolveAuthBaseData(GenericBaseDto dto, HttpServletRequest request) throws AuthException{
        UserDto userDto = (UserDto) request.getAttribute(AuthApplicationConstants.AUTH_USER_DATA_OBJECT);

        if(userDto != null) {
            dto.setAuthUserData(userDto);
        } else {
            throw new AuthException(AuthException.AUTHORIZED_USER_NOT_AVAILABLE, HttpStatus.UNAUTHORIZED);
        }
    }

    public static void resolveEntityBaseData(BaseDto dto, BaseEntity entity) throws AuthException{
        entity.setCreatedBy(dto.getCreatedBy());
        entity.setCreatedDate(new Date(System.currentTimeMillis()));
        entity.setModifiedBy(dto.getModifiedBy());
        entity.setModifiedDate(entity.getCreatedDate());
    }

    public static UserDto getUserObjectOnToken(String token){


        token = token.replace("Bearer", "").trim();

        JwtTokenReader jwt = new JwtTokenReader(token);

        UserLocationDto userLocDto = new UserLocationDto();
        userLocDto.setLevel1Id(jwt.getValueFromTokenBody(LocationTypeEnum.LOCATION_LEVEL_1.getAttributeName()));
        userLocDto.setLevel2Id(jwt.getValueFromTokenBody(LocationTypeEnum.LOCATION_LEVEL_2.getAttributeName()));
        userLocDto.setLevel3Id(jwt.getValueFromTokenBody(LocationTypeEnum.LOCATION_LEVEL_3.getAttributeName()));
        userLocDto.setLevel4Id(jwt.getValueFromTokenBody(LocationTypeEnum.LOCATION_LEVEL_4.getAttributeName()));


        UserDto userDto = new UserDto();

        userDto.setLocationDto(userLocDto);
        userDto.setUsername(jwt.getValueFromTokenBody(KeycloakUserAttributesEnum.PREFERRED_USER_NAME.getValue()));
        userDto.setFullName(jwt.getValueFromTokenBody(KeycloakUserAttributesEnum.FULL_NAME.getValue()));
        userDto.setEmail(jwt.getValueFromTokenBody(KeycloakUserAttributesEnum.EMAIL.getValue()));
        userDto.setLastName(jwt.getValueFromTokenBody(KeycloakUserAttributesEnum.LAST_NAME.getValue()));
        userDto.setFirstName(jwt.getValueFromTokenBody(KeycloakUserAttributesEnum.FIRST_NAME.getValue()));
        userDto.setSpCode(jwt.getValueFromTokenBody(KeycloakUserAttributesEnum.SP_CODE.getValue()));
        userDto.setSpName(jwt.getValueFromTokenBody(KeycloakUserAttributesEnum.SP_NAME.getValue()));

        return userDto;

    }


    /**
     * This method compares the location data as in the auth and if present that particular
     * location filter is overwritten with the auth value of the location
     * @param request The http request based on which the user's location data is verified
     * @param filterLocDto The location dto as received in the filters
     */
    public static void processLocationFilters(HttpServletRequest request, UserLocationDto filterLocDto){

        //This attribute is set in TokenAuthenticateInterceptor
        UserDto userDto = (UserDto) request.getAttribute(AuthApplicationConstants.AUTH_USER_DATA_OBJECT);

        UserLocationDto authLocDto = userDto.getLocationDto();

        if(authLocDto.getLevel1Id() != null && !authLocDto.getLevel1Id().isEmpty()){
            filterLocDto.setLevel1Id(authLocDto.getLevel1Id());
        }

        if(authLocDto.getLevel2Id() != null && !authLocDto.getLevel2Id().isEmpty()){
            filterLocDto.setLevel2Id(authLocDto.getLevel2Id());
        }

        if(authLocDto.getLevel3Id() != null && !authLocDto.getLevel3Id().isEmpty()){
            filterLocDto.setLevel3Id(authLocDto.getLevel3Id());
        }

        if(authLocDto.getLevel4Id() != null && !authLocDto.getLevel4Id().isEmpty()){
            filterLocDto.setLevel4Id(authLocDto.getLevel4Id());
        }

    }

    /**
     * This method checks if the action is allowed based on the token that is passed
     * @param token The access token as received in the request header
     * @param moduleName The module where this auth secure is included, This will be from the property file
     * @param apiPath The API URL that is being accessed
     * @param method The http method for which the access is being checked
     * @return Returns true if the action is allowed, false otherwise
     */
    public static boolean isActionAllowed(String token,String moduleName, String apiPath, String method){

        StringBuilder finalKey = new StringBuilder("");

        finalKey.append(method.toLowerCase()).append("@");
        finalKey.append(apiPath).append("-");

        String apiRole = AuthCache.getApiRoleForPath(moduleName, method, apiPath);

        if(apiRole == null ){
            throw new AuthException(AuthException.UNAUTHORIZED_UNKNOWN_API,new String[]{moduleName, method, apiPath}, HttpStatus.UNAUTHORIZED);
        }

        LOGGER.debug("API role for {} - {} of module {} is {}",method.toUpperCase(), apiPath, moduleName, apiRole);

        token = token.replace("Bearer", "").trim();

        JwtTokenReader jwt = new JwtTokenReader(token);

        HashMap<String, Object> resource =  jwt.getMapFromTokenBody("resource_access");
        HashMap<String, Object> authClient =  (HashMap<String, Object>)resource.get(AuthCache.getKeycloakClientName());
        if(authClient == null){
            return false;
        }
        ArrayList<String> roleList = (ArrayList)authClient.get("roles");

        return roleList.contains(apiRole);

    }

    /**
     * Method to validate if the access token is valid or not.
     * Currently the call is being made to keycloak to check the validity of the token
     * in terms of verifying the signature as well as the time out
     *
     * @param token The access token which needs to be validated
     * @param keycloakBasePath The keycloak base path
     * @param keycloakUserInfoUri The keycloak uri to get the userinfo based on the token
     * @param restTemplate The rest template to make the REST calls
     *
     * @return Returns true if the token is valid, false otherwise
     */
    public static boolean isTokenValid(String token, String keycloakBasePath, String keycloakUserInfoUri, RestTemplate restTemplate){

        try {
            StringBuilder uriBuilder = new StringBuilder();
            uriBuilder.append(keycloakBasePath);
            uriBuilder.append(keycloakUserInfoUri);

            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/x-www-form-urlencoded");
            httpHeaders.set(HttpHeaders.AUTHORIZATION, "bearer " + token);

            HttpEntity<KeycloakUserDto> request = new HttpEntity<>(httpHeaders);

            ResponseEntity<Map> out = restTemplate.exchange(uriBuilder.toString(), HttpMethod.GET, request, Map.class);
            Map resMap = out.getBody();

            return out.getStatusCode().is2xxSuccessful();
        } catch (HttpClientErrorException ex) {
            if ((ex.getStatusCode() == HttpStatus.UNAUTHORIZED)) {
                throw new AuthException(AuthException.UNAUTHORIZED_INVALID_TOKEN, HttpStatus.UNAUTHORIZED);
            } else {
                LOGGER.error("Exception when validating token with keycloak", ex);
                throw new AuthException(AuthException.ERROR_WHILE_VALIDATING_TOKEN, HttpStatus.UNAUTHORIZED);
            }
        } catch(Exception ex){
            LOGGER.error("Exception when validating token with keycloak", ex);
            throw new AuthException(AuthException.ERROR_WHILE_VALIDATING_TOKEN, HttpStatus.UNAUTHORIZED);
        }
    }

    /**
     * Method to validate if the short token is valid or not.
     * Currently the call is being made to the auth module to check the validity of the token
     *
     * @param token The access token which needs to be validated
     * @param authBasePath The auth module base path
     * @param authVerifyTokenUri The auth verify short token uri
     * @param restTemplate The rest template to make the REST calls
     *
     * @return Returns the original token if the token is valid, null otherwise
     */
    public static String isShortTokenValid(String token, String authBasePath,  String authVerifyTokenUri,  RestTemplate restTemplate){

        try {
            StringBuilder uriBuilder = new StringBuilder();
            uriBuilder.append(authBasePath);
            uriBuilder.append(authVerifyTokenUri);

            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON.toString());

            JSONObject tokenJsonObject = new JSONObject();
            tokenJsonObject.put("shortToken", token);

            HttpEntity<String> request = new HttpEntity<>(tokenJsonObject.toString(), httpHeaders);

            ResponseEntity<Map> out = restTemplate.exchange(uriBuilder.toString(), HttpMethod.PUT, request, Map.class);
            Map resMap = out.getBody();

            if(out.getStatusCode().is2xxSuccessful()) {
                String originalToken = (String)resMap.get("originalToken");
                return originalToken;
            } else {
                return null;
            }
        } catch (HttpClientErrorException ex) {
            if ((ex.getStatusCode() == HttpStatus.UNAUTHORIZED)) {
                throw new AuthException(AuthException.UNAUTHORIZED_INVALID_SHORT_TOKEN, HttpStatus.UNAUTHORIZED);
            } else {
                LOGGER.error("Exception when validating short token with auth module", ex);
                throw new AuthException(AuthException.ERROR_WHILE_VALIDATING_SHORT_TOKEN, HttpStatus.UNAUTHORIZED);
            }
        } catch(Exception ex){
            LOGGER.error("Exception when validating short token with auth module", ex);
            throw new AuthException(AuthException.ERROR_WHILE_VALIDATING_SHORT_TOKEN, HttpStatus.UNAUTHORIZED);
        }
    }
}
