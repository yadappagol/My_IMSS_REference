package com.imss.rc.auth.controller;

import com.imss.rc.auth.dto.AuthResponseDto;
import com.imss.rc.auth.exception.AuthException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


public interface InterceptorController {

    @RequestMapping (value = "/auth/error/custom-message", produces = "application/json")public @ResponseBody
    AuthResponseDto customMessage(@RequestParam Integer errorCode, @RequestParam(required = false) String[] params) throws AuthException;
}
