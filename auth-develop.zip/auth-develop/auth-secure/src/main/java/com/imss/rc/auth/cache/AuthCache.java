package com.imss.rc.auth.cache;

import com.imss.rc.auth.dto.AuthApiRoleDto;
import com.imss.rc.auth.dto.AuthPropertiesDto;
import com.imss.rc.auth.exception.AuthException;
import org.springframework.http.HttpStatus;

import java.util.Collection;
import java.util.HashMap;
import java.util.Set;
import java.util.StringTokenizer;

public class AuthCache extends AuthCacheCore {
    public static Collection<AuthApiRoleDto> getAllApiRoles(){
        checkForEmptyCache();

        return (Collection) cache.get(API_ROLES_TYPE).values();
    }

    public static String getApiRoleForPath(String module, String method, String path){
        checkForEmptyCache();

        HashMap<String, Object> moduleMap = (HashMap<String, Object>)cache.get(API_ROLES_TYPE).get(module.toLowerCase());
        if(moduleMap == null){
            throw new AuthException(AuthException.ROLES_NOT_FOUND_FOR_MODULE, new String[]{module}, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        HashMap<String, Object> methodMap = (HashMap<String, Object>)moduleMap.get(method.toLowerCase().trim());
        if(methodMap == null){
            throw new AuthException(AuthException.ROLES_NOT_FOUND_FOR_METHOD,  new String[]{module, method}, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        Set<String> keySet = methodMap.keySet();
        StringTokenizer roleApiTok ;
        StringTokenizer inputApiTok = new StringTokenizer(path , "/");
        boolean isDifferent = false;
        String inputApiPart;
        String roleApiPart;
        for(String api : keySet){

            inputApiTok = new StringTokenizer(path , "/");

            if(api.indexOf("{") > 0) {
                //If the api has a path variable then need to split it and compare it
                roleApiTok = new StringTokenizer(api, "/");

                if (inputApiTok.countTokens() == roleApiTok.countTokens()) { //The token count should be the same first to compare the rest
                    isDifferent = false;
                    while (roleApiTok.hasMoreTokens() && inputApiTok.hasMoreTokens()) {
                        inputApiPart = inputApiTok.nextToken();
                        roleApiPart = roleApiTok.nextToken();
                        if (roleApiPart.contains("{")) {
                            //If it has a { it means it is a placeholder for a path variable
                            //Hence need not compare that part
                            continue;
                        } else if (!inputApiPart.equals(roleApiPart)) {
                            //If the values are not equal
                            isDifferent = true;
                            break;
                        }
                    }

                    //If it has reached here and there were no difference in the split tokens then return that role
                    if(!isDifferent) {
                        return (String) methodMap.get(api);
                    }
                }
            } else if(api.equals(path)){
                //If it does not have a path variable then directly check if it is the same as the requesting path
                return (String) methodMap.get(path);
            }
        }

        return  null;
    }

    public static String getKeycloakBasePath(){
        checkForEmptyCache();

        return  ((AuthPropertiesDto)cache.get(CONFIG_PROPERTIES).get(CONFIG_PROPERTIES)).getKeycloakBasePath();
    }
    public static String getKeycloakUserInfoUri(){
        checkForEmptyCache();

        return  ((AuthPropertiesDto)cache.get(CONFIG_PROPERTIES).get(CONFIG_PROPERTIES)).getKeycloakUserInfoUri();
    }

    public static String getKeycloakClientName(){
        checkForEmptyCache();

        return  ((AuthPropertiesDto)cache.get(CONFIG_PROPERTIES).get(CONFIG_PROPERTIES)).getKeycloakClientName();
    }

    /**
     * Method to check if the cache is empty, if so an exception will be thrown
     */
    private static void checkForEmptyCache(){
        if(cache == null || cache.isEmpty()){
            throw new AuthException(AuthException.AUTH_CACHE_NOT_LOADED_PROPERLY, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
