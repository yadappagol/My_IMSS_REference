package com.imss.rc.auth.controller;

import com.imss.rc.auth.dto.AuthResponseDto;
import com.imss.rc.auth.exception.AuthException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class InterceptorControllerImpl implements InterceptorController{

    @Override
    public AuthResponseDto customMessage(Integer errorCode, String[] params) throws AuthException {
        throw new AuthException(errorCode.toString(), params, HttpStatus.UNAUTHORIZED);
    }
}
