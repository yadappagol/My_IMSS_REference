package com.imss.rc.auth.cache;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class AuthCacheRequestSender {
    private static final Logger LOGGER = LoggerFactory.getLogger(AuthCacheRequestSender.class);


    @Autowired
    @Qualifier("authCacheRequestDataTemplate")
    public KafkaTemplate<String, Object> authCacheRequestDataTemplate;

    @Value("${kafka.rc.auth.master.request.topic}")
    private String topicName;

    @PostConstruct
    public void requestForAllCacheData() {
        LOGGER.info("Sending request to load auth cache on topic {}", topicName);
        authCacheRequestDataTemplate.send(topicName,"getAllData");
        LOGGER.info("Request to load auth cache data sent successfully");

    }
}
