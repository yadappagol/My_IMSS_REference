package com.imss.rc.auth.cache;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.auth.dto.AuthPropertiesDto;
import com.imss.rc.auth.dto.AuthApiRoleDto;
import com.imss.rc.auth.enums.AuthCacheTypeEnum;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.commons.enums.CacheDataKeysEnum;
import com.imss.rc.commons.enums.CacheIsListEnum;
import com.imss.rc.commons.enums.CacheOperationEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

@Component
public class AuthCacheKafkaListener {


    @Value("${kafka.rc.auth.secure.module.name}")
    private String moduleName;

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthCacheKafkaListener.class);

    @KafkaListener(topics = "${kafka.rc.auth.master.response.topic}", containerFactory = "authCacheKafkaListenerContainerFactory")
    public void consumeData(Map<String, Object> data) throws JsonProcessingException {

        if(data.get(CacheDataKeysEnum.IS_LIST.getValue()).equals(CacheIsListEnum.YES.getValue())){
            consumeListData(data);
            LOGGER.debug("#AUTH-CACHE : Loaded list cache successfully");
        } else if(data.get(CacheDataKeysEnum.IS_LIST.getValue()).equals(CacheIsListEnum.NO.getValue())){
            consumeIndividualData(data);
            LOGGER.debug("#AUTH-CACHE : Loaded individual cache successfully");
        } else {
            throw new AuthException(AuthException.AUTH_CACHE_TYPE_UNKNOWN, new String[] {(String)data.get(CacheDataKeysEnum.TYPE.getValue())}, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private boolean consumeIndividualData(Map<String, Object> data){
        if(data.get(CacheDataKeysEnum.TYPE.getValue()).equals(AuthCacheTypeEnum.API_ROLES.getValue())) {
            if(CacheOperationEnum.ADD.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                AuthApiRoleDto authApiRoleDto = (AuthApiRoleDto)data.get(CacheDataKeysEnum.DATA.getValue());

                //Only if the module matches then proceed else ignore the object
                if(moduleName.equalsIgnoreCase(authApiRoleDto.getModule())) {
                    processAuthApiRoleDtoIntoCache(authApiRoleDto, true);
                }
            } else if(CacheOperationEnum.REMOVE.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                AuthApiRoleDto authApiRoleDto = (AuthApiRoleDto)data.get(CacheDataKeysEnum.DATA.getValue());

                //Only if the module matches then proceed else ignore the object
                if(moduleName.equalsIgnoreCase(authApiRoleDto.getModule())) {
                    processAuthApiRoleDtoIntoCache(authApiRoleDto, false);
                }
            } else if (CacheOperationEnum.RESET.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                AuthCache.resetApiRole();
                LOGGER.info("#AUTH-CACHE : Reset api roles cache successfully");
            }
            return true;
        } else if(data.get(CacheDataKeysEnum.TYPE.getValue()).equals(AuthCacheTypeEnum.CONFIG_PROPERTIES.getValue())) {
            //This is always only one object so don't need to handle the remove and reset
            if(CacheOperationEnum.ADD.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                ObjectMapper mapper = new ObjectMapper();

                AuthPropertiesDto authPropertiesDto =mapper.convertValue(data.get(CacheDataKeysEnum.DATA.getValue()), new TypeReference<AuthPropertiesDto>() {});
                processConfigPropertiesIntoCache(authPropertiesDto);
            }
            return true;
        }

            return false;
    }

    private boolean consumeListData(Map<String, Object> data) {

        if (data.get(CacheDataKeysEnum.TYPE.getValue()).equals(AuthCacheTypeEnum.API_ROLES.getValue())) {
            List<AuthApiRoleDto> authApiRoleDtoList;

            ObjectMapper mapper = new ObjectMapper();
            authApiRoleDtoList = mapper.convertValue(data.get(CacheDataKeysEnum.DATA.getValue()), new TypeReference<List<AuthApiRoleDto>>() {});

            for (AuthApiRoleDto authApiRoleDto : authApiRoleDtoList) {

                //Only if the module matches then proceed else ignore the object
                if(moduleName.equalsIgnoreCase(authApiRoleDto.getModule())) {
                    processAuthApiRoleDtoIntoCache(authApiRoleDto, true);
                }
            }
            LOGGER.info("#AUTH-CACHE : Loaded {} records of API roles into cache, Current total records is {}", authApiRoleDtoList.size(), AuthCache.getAllApiRoles().size());
            return true;
        }
        return false;
    }

    /**
     * This method processes the dto object into the cache by creating the key by concatinating
     * the path, method and module fields. Since the method can be a coma separated value, it will split it
     * and add them accordingly. For example if the path was '/tst/api' and the methods wah 'PUT,POST,DELETE' and module imd then
     * 3 entries are added into the map 'with the key imd-PUT-/tst/api', 'imd-POST-/tst/api' and 'imd-DELETE-/tst/api'
     *
     * @param authApiRoleDto The dto object which contains the details if the API role that is to be added
     * @param isAdd Flag indicating if the entity needs to be removed or added
     */
    private void processAuthApiRoleDtoIntoCache(AuthApiRoleDto authApiRoleDto, boolean isAdd){

        StringTokenizer tokPath = new StringTokenizer(authApiRoleDto.getPath(), ",");
        StringTokenizer  tokMethod;
        String path;
        String method;
        while(tokPath.hasMoreTokens()) {
            path = tokPath.nextToken();
            tokMethod = new StringTokenizer(authApiRoleDto.getMethods(), ",");
            while (tokMethod.hasMoreTokens()) {
                method = tokMethod.nextToken();

                if (isAdd) {
                    AuthCache.putApiRole(authApiRoleDto.getModule(), method.toLowerCase(), path, authApiRoleDto.getName());
                } else {
                    AuthCache.removeApiRole(authApiRoleDto.getModule(),  method.toLowerCase(), path);
                }

            }
        }

    }

    private void processConfigPropertiesIntoCache(AuthPropertiesDto authPropertiesDto){
        AuthCache.putConfigProperties(authPropertiesDto);
    }

    private boolean consumeResetData(Map<String, Object> data) {
        if (data.get(CacheDataKeysEnum.TYPE.getValue()).equals(AuthCacheTypeEnum.API_ROLES.getValue())) {
            AuthCache.resetApiRole();
            LOGGER.info("#AUTH-CACHE : Reset API Role cache successfully");
            return true;
        }
        return false;
    }
}
