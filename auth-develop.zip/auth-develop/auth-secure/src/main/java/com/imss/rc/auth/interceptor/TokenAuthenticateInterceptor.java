package com.imss.rc.auth.interceptor;

import com.imss.rc.auth.cache.AuthCache;
import com.imss.rc.auth.exception.AuthException;
import com.imss.rc.auth.util.AuthApplicationConstants;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.commons.exception.IMSSException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.Map;

@Component
public class TokenAuthenticateInterceptor implements HandlerInterceptor {

    private static final Logger LOGGER = LoggerFactory.getLogger(TokenAuthenticateInterceptor.class);

    @Autowired
    @Qualifier("authSecureRestTemplate")
    private RestTemplate restTemplate;

    @Value("${kafka.rc.auth.secure.module.name}")
    private String moduleName;

    @Value("${auth.verification}")
    private String authVerify;

    /**
     * This method cannot throw exception because if it does, it returns a 500 error back and does not go to the Exception handler
     * Hence all the error messages are done as a redirect to the controller where the exception is thrown
     *
     * @param request The request object
     * @param response The response object
     * @param handler
     * @return returns true if everything was validated properly
     * @throws Exception
     */
    @Override
    public boolean preHandle(
            HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        /**
         * If the call is to the error just return without any validations
         * This is put back though the below code to check on the properties is present because
         * if not all who include auth secure should include this path in the exception list
         */
        if (request.getRequestURI().startsWith("/auth/error") || request.getRequestURI().startsWith("/error") ){
            return true;
        }

        /**
         * This below code is to overrode the auth check for specific APIs if any
         * that will be required by each module. The paths will be supplied by a comma
         * separated value
         */
        if(authVerify != null & !authVerify.isEmpty()) {
            String[] token = authVerify.split(",");
            for (String word : token) {
                if (request.getRequestURI().startsWith(word)) {
                    return true;
                }
            }
        }

        String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
        if(authHeader == null || authHeader.isEmpty()){
            //If token is found null or empty then throw exception
            throw new AuthException(AuthException.UNAUTHORIZED_NO_TOKEN, HttpStatus.UNAUTHORIZED);
        } else {
            try {

                final Map<String, String> pathVariables = (Map<String, String>) request
                        .getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
                authHeader = authHeader.replace("Bearer", "").trim();

                //Call to check if the token is valid
                if(UserAuthDataHandler.isTokenValid(authHeader, AuthCache.getKeycloakBasePath(), AuthCache.getKeycloakUserInfoUri(), restTemplate)) {

                    //Call to check if the api requested is allowed or not
                    if (UserAuthDataHandler.isActionAllowed(authHeader, moduleName, request.getRequestURI(),  request.getMethod().toUpperCase())) {

                        //If all validations passed then set the user details as an attribute and return true
                        request.setAttribute(AuthApplicationConstants.AUTH_USER_DATA_OBJECT, UserAuthDataHandler.getUserObjectOnToken(authHeader));
                        return true;

                    } else {
                        throw new AuthException(AuthException.UNAUTHORIZED_INVALID_ACCESS, HttpStatus.UNAUTHORIZED);
                    }
                } else {
                    throw new AuthException(AuthException.UNAUTHORIZED_INVALID_TOKEN, HttpStatus.UNAUTHORIZED);
                }
            } catch (IMSSException ex){
                /**
                 * Cannot throw an exception here because then it will throw a 500 error
                 * Hence will need to redirect to the error page where the exception code
                 * along with the required parameters will be present
                 */
                request.getRequestDispatcher(getDispatchUrl(ex)).forward(request, response);
                return false;
            } catch (Exception ex){
                LOGGER.error("Exception when validating", ex);
                request.getRequestDispatcher(getDispatchUrl(new AuthException(AuthException.ERROR_WHILE_VALIDATING_TOKEN, HttpStatus.UNAUTHORIZED))).forward(request, response);
                return false;
            }
        }
    }

    /**
     * Method to get the URL to dispatch when an exception occurs.
     * This will construct the URL along with the error code and error args
     * if present as parameters
     *
     * @param ex The exception object that will contain the error code and the error parameteres if any
     * @return Returns the constructed url to be redirected to.
     */
    private String getDispatchUrl(IMSSException ex){
        StringBuilder dispatchUri = new StringBuilder("/auth/error/custom-message?errorCode=" + ex.getCode());
        if(ex.getArgs() != null && ex.getArgs().length > 0){
            dispatchUri.append("&params=").append(Arrays.toString(ex.getArgs()));
        }
        return dispatchUri.toString();
    }


    @Override
    public void postHandle(
            HttpServletRequest request, HttpServletResponse response, Object handler,
            ModelAndView modelAndView) throws Exception {

        String authToken = request.getHeader(HttpHeaders.AUTHORIZATION);

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
                                Object handler, Exception exception) throws Exception {

    }
}
