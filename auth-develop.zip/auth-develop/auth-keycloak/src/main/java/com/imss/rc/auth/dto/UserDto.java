package com.imss.rc.auth.dto;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class UserDto {
    
   private String userName;
    private String firstName;
    private String lastName;
    private String id;
    private String email;
    private String userType;
    private String keyCloakId;
    private String username;
    private String mobileNumber;
    private String level1Id;
    private String level2Id;
    private String level3Id;
    private String level4Id;
    private Map<String, List<String>> attributes;

    public UserDto(String userName, String firstName, String lastName, String id, String email, Map<String, List<String>> attributes) {
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.id = id;
        this.email = email;
        this.attributes=attributes;
  }

    public UserDto() {

    }

    public UserDto(String username, String firstName, String lastName, String id, String email) {
        this.userName = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.id = id;
        this.email = email;
    }
}
