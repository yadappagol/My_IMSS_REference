package com.imss.rc.auth.dto;

import org.keycloak.models.UserModel;

public class UserMapper {

    public  UserDto mapToUserDto(UserModel um) {
        return new UserDto(
                um.getUsername(),
                um.getFirstName(),
                um.getLastName(),
                um.getId(),
                um.getEmail(),
                um.getAttributes());
    }
}
