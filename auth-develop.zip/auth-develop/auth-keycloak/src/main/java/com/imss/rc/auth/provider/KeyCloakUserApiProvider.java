package com.imss.rc.auth.provider;

import com.imss.rc.auth.dto.UserDto;
import com.imss.rc.auth.dto.UserMapper;
import org.jboss.resteasy.annotations.cache.NoCache;
import org.keycloak.connections.jpa.JpaConnectionProvider;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.UserModel;
import org.keycloak.models.jpa.UserAdapter;
import org.keycloak.models.jpa.entities.UserEntity;
import org.keycloak.services.resource.RealmResourceProvider;
import org.keycloak.utils.MediaType;
import org.keycloak.utils.StreamsUtil;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.ws.rs.*;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.imss.rc.auth.util.KeycloakConstants.ATTRIBUTES_FILTER_QUERY;

public class KeyCloakUserApiProvider implements RealmResourceProvider {
    private final KeycloakSession session;
    private final String defaultAttr = "user_type";
    private final UserMapper userMapper;

    public KeyCloakUserApiProvider(KeycloakSession session) {
        this.session = session;
        this.userMapper = new UserMapper();
    }

    public void close() {
    }

    public Object getResource() {
        return this;
    }


    @GET
    @Path("users/search-by-attr")
    @NoCache
    @Produces({ MediaType.APPLICATION_JSON })
    @Encoded
    public List<UserDto> searchUsersByAttribute(@DefaultValue(defaultAttr) @QueryParam("attr") String attr,
                                                @QueryParam("value") String value) {
        return session.users().searchForUserByUserAttribute(attr, value, session.getContext().getRealm())
                .stream().map(userMapper::mapToUserDto).collect(Collectors.toList());
    }

    @GET
    @Path("users/filter-by-attributes")
    @NoCache
    @Produces({ MediaType.APPLICATION_JSON })
    @Encoded
    public  List<UserDto> searchUsersList(@QueryParam(value = "userType") String userType,
                                         @QueryParam(value = "level1Id") String level1Id,
                                         @QueryParam(value = "level2Id") String level2Id,
                                         @QueryParam(value = "level3Id") String level3Id,
                                         @QueryParam(value = "level4Id") String level4Id){
        EntityManager em = session.getProvider(JpaConnectionProvider.class).getEntityManager();
        Query query = em.createQuery(ATTRIBUTES_FILTER_QUERY)
                .setParameter("level1Id", level1Id)
                .setParameter("level2Id", level2Id)
                .setParameter("level3Id", level3Id)
                .setParameter("level4Id", level4Id)
                .setParameter("userType", userType);

        Stream <UserEntity> userEntityList=query .getResultStream();
        Stream <UserModel> userModelList =StreamsUtil.closing(userEntityList.map((userEntity) -> new UserAdapter(session,session.getContext().getRealm(), em, userEntity)));
        List<UserDto> userDtoList= userModelList.map(userMapper::mapToUserDto).collect(Collectors.toList());

        return userDtoList;
    }


}