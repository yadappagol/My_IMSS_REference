package com.imss.rc.auth.util;

public class KeycloakConstants {

    private KeycloakConstants(){

    }

    public static final String ATTRIBUTES_FILTER_QUERY = "select distinct  u \n" +
            "from UserEntity u join u.attributes attr\n" +
            "where\n" +
            "     exists (\n" +
            "        select 1\n" +
            "        from UserAttributeEntity attr\n" +
            "        where attr.user = u.id and attr.name = 'loc_level1_id' and (:level1Id is null or attr.value = :level1Id)\n" +
            "    )\n" +
            "    and exists (\n" +
            "      select 1 \n" +
            "        from UserAttributeEntity attr\n" +
            "        where attr.user = u.id and attr.name = 'loc_level2_id' and (:level2Id is null or attr.value = :level2Id)\n" +
            "    )\n"+
            "    and exists (\n" +
            "      select 1 \n" +
            "        from UserAttributeEntity attr\n" +
            "        where  attr.user = u.id and attr.name = 'loc_level3_id' and (:level3Id is null or attr.value = :level3Id)\n" +
            "    )\n"+
            "    and exists (\n" +
            "      select 1 \n" +
            "        from UserAttributeEntity attr\n" +
            "        where  attr.user = u.id and attr.name = 'loc_level4_id' and (:level4Id is null or attr.value = :level4Id)\n" +
            "    )\n"+
            "    and exists (\n" +
            "      select 1 \n" +
            "        from UserAttributeEntity attr\n" +
            "        where  attr.user = u.id and attr.name = 'user_type' and (:userType is null or attr.value = :userType)\n" +
            "    )\n";
}
