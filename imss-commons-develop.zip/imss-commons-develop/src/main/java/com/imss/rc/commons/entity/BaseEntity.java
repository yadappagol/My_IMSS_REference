package com.imss.rc.commons.entity;


import lombok.Data;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;
import java.io.Serializable;
import java.util.Date;



@MappedSuperclass
@Data
public class BaseEntity extends IdEntity implements Serializable {


	public static final String COLUMN_NAME_IS_DELETED = "isDeleted";
	public static final String COLUMN_NAME_CREATED_BY = "createdBy";
	public static final String COLUMN_NAME_CREATED_DATE = "createdDate";
	public static final String COLUMN_NAME_MODIFIED_BY = "modifiedBy";
	public static final String COLUMN_NAME_MODIFIED_DATE = "modifiedDate";
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name="created_by", insertable = true, updatable = false)
	private String createdBy;

	@Column(name="created_date", insertable = true, updatable = false)
	private Date createdDate;

	@Column(name="modified_by")
	private String modifiedBy;

	@Column(name="modified_date")
	private Date modifiedDate;

	@Column(name="row_version")
	@Version
	private Integer rowVersion;

	@Column(name="is_deleted")
	private Short isDeleted;


	public BaseEntity() {

	}
}
