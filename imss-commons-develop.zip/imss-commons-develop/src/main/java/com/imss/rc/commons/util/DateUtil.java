package com.imss.rc.commons.util;

import com.imss.rc.commons.exception.CommonsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

    private static final Logger LOG = (Logger) LoggerFactory.getLogger(DateUtil.class);

    //TODO: Pick this from the configuration once the config module is ready
    public static final String UI_DATE_FORMAT = "dd-MM-yyyy HH:mm:ss";

    public static Date convertUiStringToDate(String dateString, String fieldName) throws CommonsException {
        Date dtObj = null;
        try {
            if (!dateString.isEmpty()) {
                SimpleDateFormat dateFormat = new SimpleDateFormat(UI_DATE_FORMAT);
                dtObj = dateFormat.parse(dateString);
            } else {
                throw new CommonsException(CommonsException.FIELD_VALUE_MISSING, new String[]{fieldName}, HttpStatus.BAD_REQUEST);
            }
        } catch (ParseException ae) {
            LOG.error("Exception occurred at convertUiStringToDate ", ae);
            throw new CommonsException(CommonsException.INVALID_DATE_FORMAT,
                    new String[]{fieldName, UI_DATE_FORMAT}, HttpStatus.BAD_REQUEST);
        }
        return dtObj;
    }

    public static String convertDateToUiString(Date date){
        String strDate = null;

        SimpleDateFormat dateFormat = new SimpleDateFormat(UI_DATE_FORMAT);

        strDate = dateFormat.format(date);

        return strDate;
    }
}
