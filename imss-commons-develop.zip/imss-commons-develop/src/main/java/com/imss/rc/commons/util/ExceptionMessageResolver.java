package com.imss.rc.commons.util;

import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.exception.IMSSException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class ExceptionMessageResolver {
    private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionMessageResolver.class);

    private ExceptionMessageResolver(){
        //This is so that no one creates an instance of the class, methods are to be accessed statically
    }

    public static void resolveMessage(ResponseDto response, IMSSException exception, Locale locale) {
        String errorMsg = null;
        StringBuilder errorCode = new StringBuilder();
        try {
            /**
             * A separate try catch block here so that even if the message is not found,
             * it will at-least respond with an error code and the details are logged
             */
            ResourceBundle res;
            if (locale != null) {
                res = ResourceBundle.getBundle(exception.getBundleName(), locale);
            } else {
                res = ResourceBundle.getBundle(exception.getBundleName());
            }

            errorCode.append(exception.getErrorCodePrefix()).append(exception.getCode());
            errorMsg = res.getString(errorCode.toString());
        } catch(MissingResourceException ex){
            LOGGER.error("Message not found for resource {} - Args were {}",errorCode, exception.getArgs());
            errorMsg = "";
        }

        if (exception.getArgs() != null) {

            errorMsg = MessageFormat.format(errorMsg, exception.getArgs());
        }
        if (! ResponseDto.STATUS_SUCCESS.equals(response.getResponseStatus())) {
            response.setResponseStatus(ResponseDto.STATUS_FAILURE);
        }

        response.setResponseCode(exception.getCode());
        response.setResponseMessage(exception.getModuleCode()+"-"+exception.getCode()+": "+errorMsg);
    }
}
