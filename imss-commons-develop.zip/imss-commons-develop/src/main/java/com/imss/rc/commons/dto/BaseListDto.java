/**
 * COPYRIGHT: Jakkur Technoparks Pvt. Ltd. (JTPL)
 * This software is the sole property of JTPL
 * and is protected by copyright law and international
 * treaty provisions. Unauthorized reproduction or
 * redistribution of this program, or any portion of
 * it may result in severe civil and criminal penalties
 * and will be prosecuted to the maximum extent possible
 * under the law. JTPL reserves all rights not
 * expressly granted. You may not reverse engineer, decompile,
 * or disassemble the software, except and only to the
 * extent that such activity is expressly permitted
 * by applicable law notwithstanding this limitation.
 * THIS SOFTWARE IS PROVIDED TO YOU "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
 * YOU ASSUME THE ENTIRE RISK AS TO THE ACCURACY
 * AND THE USE OF THIS SOFTWARE. JTPL SHALL NOT BE LIABLE FOR
 * ANY DAMAGES WHATSOEVER ARISING OUT OF THE USE OF OR INABILITY TO
 * USE THIS SOFTWARE, EVEN IF JTPL HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/
package com.imss.rc.commons.dto;

import lombok.Data;
import java.util.ArrayList;
import java.util.List;

    /**
     * The Base list dto that deals with dataList..when you want to return a list of DTO type
     *
     * @param <T> The Type of DTO that will be stored in this Class
     * @see BaseListDto
     * @author Sandeep Solomon
     */
    @Data
    public class BaseListDto<T> extends BaseDto {
        private static final long serialVersionUID = -4220162492469524803L;
        private transient List<T> dataList;
        private PaginationDto pagination;

        /**
         * The get method to return the list of DTOs
         * @return The list of DTOs, if the value is null an empty list will be returned
         */
    public List<T> getDataList() {
        if (dataList != null) {
            return new ArrayList<>(dataList);
        } else {
            //Returning empty arraylist than a null
            return new ArrayList<>();
        }
    }

    /**
     * The set method to set the list of DTOs
     * @param dataList The DTOs as list that need to be set, cloned copy will be set to the property
     */
    public void setDataList(List<T> dataList) {
        if (dataList != null) {
            this.dataList =  new ArrayList<>(dataList);
        } else {
            this.dataList = null;
        }
    }
}

