package com.imss.rc.commons.entity;

import lombok.Data;

import java.util.List;

@Data
public class PageableEntity<T> {
    List<T> data;
    long count;
}
