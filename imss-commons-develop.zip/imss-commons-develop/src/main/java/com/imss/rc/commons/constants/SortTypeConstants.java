package com.imss.rc.commons.constants;

public class SortTypeConstants {
    public static final String SORT_TYPE_ASC = "asc";
    public static final String SORT_TYPE_DESC= "desc";

    private SortTypeConstants(){
    }

}
