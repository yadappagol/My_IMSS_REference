package com.imss.rc.commons.exception;

import org.springframework.http.HttpStatus;

public class CommonsException extends IMSSException {

    public static final String MESSAGE_BUNDLE_NAME = "imss_commons_errors_messages";
    public static final String MODULE_CODE = "COMM";
    public static final String ERROR_CODE_PREFIX = "imss.common.error.";


    public static final String ERROR_OCCURRED ="1000" ;
    public static final String INVALID_DATE_FORMAT = "1004";
    public static final String FIELD_VALUE_MISSING = "1005";
    public static final String INVALID_ORDER_BY_COLUMN = "1006";
    public static final String MESSAGE_NOT_SENT = "1007";

    public CommonsException(String code, Object[] args, Throwable cause, HttpStatus httpStatus) {
        super(code, args, cause, httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

    public CommonsException(String code, Object[] args, HttpStatus httpStatus) {
        super(code, args, httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

    public CommonsException(String code, Throwable cause, HttpStatus httpStatus) {
        super(code, cause, httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

    public CommonsException(String code, HttpStatus httpStatus) {
        super(code, httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }
}
