package com.imss.rc.commons.constants;

public final class  Constants{

        private Constants(){

        }

        public static final String PATTERN = "yyyy-MM-dd";
        public static final String UI_DATE_TIME_PATTERN = "dd-MM-yyy HH:mm:ss";
}
