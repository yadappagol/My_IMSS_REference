package com.imss.rc.commons.entity;

import lombok.Data;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;


@MappedSuperclass
@Data
public class GenericBaseEntity extends IdEntity implements Serializable  {

	private Integer rowVersion;

	@Version
	@Column(name="row_version")
	public Integer getRowVersion() {
	
		return rowVersion;
	}

	
	public void setRowVersion(Integer rowVersion) {
	
		this.rowVersion = rowVersion;
	}
	
	
}
