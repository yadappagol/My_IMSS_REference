package com.imss.rc.commons.enums;

public enum CacheIsListEnum {
    YES("Y") ,
    NO("N") ;

    private String value;

    CacheIsListEnum(String value)
    {
        this.value = value;
    }

    public String getValue(){
        return this.value;
    }
}
