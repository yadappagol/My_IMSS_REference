/**
 * COPYRIGHT: Jakkur Technoparks Pvt. Ltd. (JTPL)
 * This software is the sole property of JTPL
 * and is protected by copyright law and international
 * treaty provisions. Unauthorized reproduction or
 * redistribution of this program, or any portion of
 * it may result in severe civil and criminal penalties
 * and will be prosecuted to the maximum extent possible
 * under the law. JTPL reserves all rights not
 * expressly granted. You may not reverse engineer, decompile,
 * or disassemble the software, except and only to the
 * extent that such activity is expressly permitted
 * by applicable law notwithstanding this limitation.
 * THIS SOFTWARE IS PROVIDED TO YOU "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
 * YOU ASSUME THE ENTIRE RISK AS TO THE ACCURACY
 * AND THE USE OF THIS SOFTWARE. JTPL SHALL NOT BE LIABLE FOR
 * ANY DAMAGES WHATSOEVER ARISING OUT OF THE USE OF OR INABILITY TO
 * USE THIS SOFTWARE, EVEN IF JTPL HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/
package com.imss.rc.commons.assembler;

import com.imss.rc.commons.exception.CommonsException;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;

/**
 * The base assembler to convert Entity to Dto and vice versa,
 * All the assemblers can use these methods as long as there is an exact mapping between the entity and dto
 * If there is any difference then the individual assemblers can add in their own methods.
 *
 * The methods of this class should only be used by other assemblers and not directly by the rest of the code
 * the rest of the code should be calling the methods of the respective assemblers.
 *
 * @param <D> The Dto Type
 * @param <E> The Entity Type
 * @author Sandeep Solomon
 */
public class BaseAssembler<D, E> {

    private final Supplier<? extends D> dtoActor;
    private final Supplier<? extends E> entityActor;

    public static String getSortByColumn(String input, Map<String, String>  sortByList){
        if(sortByList.get(input) == null){
            throw new CommonsException(CommonsException.INVALID_ORDER_BY_COLUMN,new String[]{input, sortByList.keySet().toString()}, HttpStatus.BAD_REQUEST);
        }
        return sortByList.get(input);
    }


    public BaseAssembler(Supplier<? extends D> dtoActor, Supplier<? extends E> entityActor) {
        this.dtoActor = Objects.requireNonNull(dtoActor);
        this.entityActor = Objects.requireNonNull(entityActor);
    }

    /**
     * Generic method to convert an Entity object of type E to a Dto object of type D
     * @param entity object of the entity type E
     * @return A new object of the dto type D
     */
    public D entityToDto(E entity){
        D dto = dtoActor.get();

        BeanUtils.copyProperties(entity, dto);

        return dto;
    }


    /**
     * Generic method to convert a Dto object of type D to an Entity object of type E
     * @param dto object of the dto type D
     * @return A new object of the entity type E
     */
    public E dtoToEntity(D dto){

        E entity = entityActor.get();

        BeanUtils.copyProperties(dto, entity);

        return entity;
    }


    /**
     * Generic method to convert a list of Entity objects of type E to a list of Dto object of type D
     * @param entityList A list of Entity objects of type E
     * @return A new ArrayList of Dto object of type D
     */
    public List<D> entityListToDtoList(List<E> entityList){

        ArrayList<D> dtoList = new ArrayList<>();

        entityList.stream().forEach(k -> dtoList.add(entityToDto(k)));

        return dtoList;
    }

    /**
     * Generic method to convert a list of Dto object of type D to a list of Entity objects of type E
     * @param dtoList A list of Dto object of type D
     * @return A new ArrayList of Entity objects of type E
     */
    public List<E> dtoListToEntityList(List<D> dtoList){

        ArrayList<E> entityList = new ArrayList<>();

        dtoList.stream().forEach(t ->  entityList.add(dtoToEntity(t)) );

        return entityList;

    }
}
