package com.imss.rc.commons.enums;

public enum GlobalYesNoEnum {
    NO(0),
    YES(1);

    private int value;
    GlobalYesNoEnum(int value) {
        this.value = value;
    }

    public int getValue(){
        return this.value;
    }
}
