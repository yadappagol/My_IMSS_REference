package com.imss.rc.commons.validation;

import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.stereotype.Component;

@Component
public class ValidateCommons
{
    public boolean isValidFlag(Short number)
    {
        if(number==GlobalYesNoEnum.NO.getValue() || number== GlobalYesNoEnum.YES.getValue() )
        {
            return true;
        }
       
        return false;
    }
}
