package com.imss.rc.commons.enums;

public enum ActionTypeEnum
{
    ADD((short)0),
    DELETE((short)3),
    UPDATE((short)1),
    VIEW((short)2)
    ;

     private final short value;

    ActionTypeEnum(final short newValue)
    {
        this.value = newValue;
    }

    public short getValue()
    {
        return value;
    }
}

