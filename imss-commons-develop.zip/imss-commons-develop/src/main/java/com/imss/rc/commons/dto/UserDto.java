package com.imss.rc.commons.dto;

import lombok.Data;

@Data
public class UserDto {
    private String fullName;
    private String email;
    private String roleName;
    private String username;
    private String firstName;
    private String lastName;
    private String spCode;
    private String spName;
    private UserLocationDto locationDto;
}
