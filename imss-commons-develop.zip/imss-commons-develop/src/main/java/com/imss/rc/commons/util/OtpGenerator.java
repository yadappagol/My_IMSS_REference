
package com.imss.rc.commons.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Base64;
import java.util.Random;

import com.imss.rc.commons.exception.IMSSException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

public class OtpGenerator {

	private static final Logger logger =  LoggerFactory.getLogger(OtpGenerator.class);

	private static final String UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static final String LOWER = UPPER.toLowerCase();

	private OtpGenerator() {

	}

	public static String generateOtp() throws IMSSException {

		logger.info("OtpGeneratorServicsImpl::: Generate OTP Method::: ");

		String randomString = randomString(UPPER, 2) + randomString(LOWER, 2) + randomNumber(2);

		return encodeString(randomString).trim().substring(0, 6);
	}

	private static String randomString(String chars, int length) {

		Random rand = new Random();
		StringBuilder buf = new StringBuilder();
		for (int i = 0; i < length; i++) {
			buf.append(chars.charAt(rand.nextInt(chars.length())));
		}
		return buf.toString();
	}

	private static String randomNumber(int length) {

		Random rand = new Random();
		StringBuilder buf = new StringBuilder();
		for (int i = 0; i < length; i++) {
			buf.append(rand.nextInt(9));
		}
		return buf.toString();
	}

	private static String encodeString(String encodingString) throws IMSSException {

		String utfEncodedstring;
		String encodedRandomString = null;
		try {
			utfEncodedstring = URLEncoder.encode(encodingString, "UTF-8");
			encodedRandomString = Base64.getEncoder().encodeToString(utfEncodedstring.getBytes());
		} catch (UnsupportedEncodingException e) {
			logger.error("OtpGeneratorServicsImpl::: Generate OTP::: " + e);
			throw new IMSSException(IMSSException.UNABLE_TO_ENCRYPT_URL, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return encodedRandomString;

	}

}
