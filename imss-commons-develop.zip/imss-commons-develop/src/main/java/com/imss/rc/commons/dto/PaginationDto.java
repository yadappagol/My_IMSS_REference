package com.imss.rc.commons.dto;

import lombok.Data;

@Data
public class PaginationDto {
    int limit;
    int page;
    long count;
    String sortBy;
    String sortType;
}
