package com.imss.rc.commons.enums;

public enum CacheOperationEnum {
    ADD("A") ,
    REMOVE("R") ,
    RESET("T") ;

    private String value;

    CacheOperationEnum(String value)
    {
        this.value = value;
    }

    public String getValue(){
        return this.value;
    }
}
