package com.imss.rc.commons.entity;

import lombok.Data;

import java.io.Serializable;

import javax.persistence.*;


@MappedSuperclass
@Data
public class IdEntity implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="pk_id")
	private Integer id;

}
