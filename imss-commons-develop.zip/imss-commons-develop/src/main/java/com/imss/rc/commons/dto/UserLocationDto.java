package com.imss.rc.commons.dto;

import lombok.Data;

@Data
public class UserLocationDto {
    //District Id
    private String level1Id;
    //Cluster ID
    private String level2Id;
    //State Id
    private String level3Id;
    //Zone Id
    private String level4Id;
}
