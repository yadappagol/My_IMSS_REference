package com.imss.rc.commons.kafka;

import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.enums.CacheDataKeysEnum;
import com.imss.rc.commons.enums.CacheOperationEnum;
import com.imss.rc.commons.enums.CacheIsListEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class KafkaDataSender {

    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaDataSender.class);


    /**
     * This method was moved into the common as it is required by the other module's cache
     * This method first sends out the reset operation for the
     *
     * @param topicName The topic name on which it needs to be sent
     * @param dataType The data type that is being sent
     * @param length The max chunk size of the list to be sent
     * @param dataListDto The BaseListDto object that holds the list of data to be sent
     * @param kafkaTemplate The kafka template to be used to send out the data
     * @param <T> The template class to resolve the generic of BaseListDto
     */
    public <T> void processListData(String topicName, String dataType, int length, BaseListDto<T> dataListDto, KafkaTemplate<String, Object> kafkaTemplate){

        //Send the rest type first so that the list is reset in the cache
        sendData(topicName,
                dataType,
                CacheOperationEnum.RESET.getValue(),
                CacheIsListEnum.NO.getValue(),
                new BaseListDto<T>(),
                kafkaTemplate);

        //Then send the actual list in parts
        sendDataListInParts(topicName,
                dataType,
                dataListDto.getDataList(),
                length,
                kafkaTemplate);
    }

    public void processIndividualData(String topicName, String dataType, String operation, Object object, KafkaTemplate<String, Object> kafkaTemplate){

        sendData(topicName,
                dataType,
                operation,
                CacheIsListEnum.NO.getValue(),
                object,
                kafkaTemplate);
    }


    private void sendData(String topicName, String type, String operation, String isList, Object object, KafkaTemplate<String, Object> kafkaTemplate) {
        Map<String, Object> dataToSend = new HashMap<>();
        dataToSend.put(CacheDataKeysEnum.IS_LIST.getValue(), isList);
        dataToSend.put(CacheDataKeysEnum.TYPE.getValue(),type);
        dataToSend.put(CacheDataKeysEnum.OPERATION.getValue(),operation);
        dataToSend.put(CacheDataKeysEnum.DATA.getValue(), object);
        kafkaTemplate.send(topicName,dataToSend);
    }


    /**
     * This methods sends the list of data in parts based on the lenth sent
     * @param type The type of data being sent
     * @param dataList The data list that needs to be sent
     * @param length The part size based on which the list is split, pass 0 if the entire data is to be sent in one go
     * @param <T>
     */
    public <T> void sendDataListInParts(String topicName, String type, List<T> dataList, int length, KafkaTemplate<String, Object> kafkaTemplate){
        if(length != 0) {
            List<List<T>> listOfLists = chopped(dataList, length);
            for (List<T> list : listOfLists) {
                BaseListDto<T> obj = new BaseListDto<>();
                obj.setDataList(list);
                sendData(topicName,
                        type,
                        CacheOperationEnum.ADD.getValue(),
                        CacheIsListEnum.YES.getValue(),
                        list,
                        kafkaTemplate);
            }
        } else {
            BaseListDto<T> obj = new BaseListDto<>();
            obj.setDataList(dataList);
            sendData(topicName,
                    type,
                    CacheOperationEnum.ADD.getValue(),
                    CacheIsListEnum.YES.getValue(),
                    dataList,
                    kafkaTemplate);
        }
    }

    // chops a list into non-view sublists of length L
    static <T> List<List<T>> chopped(List<T> list, final int L) {
        List<List<T>> parts = new ArrayList<>();
        final int N = list.size();
        for (int i = 0; i < N; i += L) {
            parts.add(new ArrayList<T>(
                    list.subList(i, Math.min(N, i + L)))
            );
        }
        return parts;
    }

}
