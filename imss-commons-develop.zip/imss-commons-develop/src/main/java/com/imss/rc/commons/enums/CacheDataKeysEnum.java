package com.imss.rc.commons.enums;

public enum CacheDataKeysEnum {
    DATA("data") ,
    OPERATION("operation"),
    TYPE("type") ,
    IS_LIST("isList") ;

    private String value;

    CacheDataKeysEnum(String value)
    {
        this.value = value;
    }

    public String getValue(){
        return this.value;
    }
}
