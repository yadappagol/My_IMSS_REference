package com.imss.rc.commons.assembler;
import lombok.Data;


/**
 * @author Sandeep Solomon
 */
@Data
public class TestEntity {
    private String field1 ;
    private int field2;
    private float field3;
    private double field4;
    private boolean field5;
}
