package com.imss.rc.commons.assembler;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.ArrayList;

/**
 * The class BaseAssemblerTest is used for
 *
 * @author sandeekunder
 * Created on 25-11-2020 at 2101
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class BaseAssemblerTest {

    BaseAssembler<TestDto, TestEntity> baseAssembler  = new BaseAssembler<>(TestDto::new,TestEntity::new);

    @Test
    public void testA01EntityToDto() {
        TestEntity entity = getEntity();

        TestDto dto = baseAssembler.entityToDto(entity);

        Assert.assertEquals("Checking field1 is equal", entity.getField1(), dto.getField1());
        Assert.assertEquals("Checking field2 is equal", entity.getField2(), dto.getField2());
        Assert.assertEquals("Checking field3 is equal", entity.getField3(), dto.getField3(),0);
        Assert.assertEquals("Checking field4 is equal", entity.getField4(), dto.getField4(),0);
        Assert.assertEquals("Checking field5 is equal", entity.isField5(), dto.isField5());
    }

    @Test
    public void testA02DtoToEntity() {
        TestDto dto = getDto();

        TestEntity entity = baseAssembler.dtoToEntity(dto);

        Assert.assertEquals("Checking field1 is equal", entity.getField1(), dto.getField1());
        Assert.assertEquals("Checking field2 is equal", entity.getField2(), dto.getField2());
        Assert.assertEquals("Checking field3 is equal", entity.getField3(), dto.getField3(),0);
        Assert.assertEquals("Checking field4 is equal", entity.getField4(), dto.getField4(),0);
        Assert.assertEquals("Checking field5 is equal", entity.isField5(), dto.isField5());
    }

    @Test
    public void testA03DtoListToEntityList() {
        ArrayList<TestDto> dtoList = new ArrayList<>();

        dtoList.add(getDto());
        dtoList.add(getDto());
        dtoList.add(getDto());

        ArrayList<TestEntity> entityList = (ArrayList)baseAssembler.dtoListToEntityList(dtoList);

        int index= 0;
        for (TestEntity testEntity : entityList) {
            Assert.assertEquals("Checking field1 is equal", testEntity.getField1(), dtoList.get(index).getField1());
            Assert.assertEquals("Checking field2 is equal", testEntity.getField2(), dtoList.get(index).getField2());
            Assert.assertEquals("Checking field3 is equal", testEntity.getField3(), dtoList.get(index).getField3(), 0);
            Assert.assertEquals("Checking field4 is equal", testEntity.getField4(), dtoList.get(index).getField4(), 0);
            Assert.assertEquals("Checking field5 is equal", testEntity.isField5(), dtoList.get(index).isField5());

            index++;
        }
    }


    @Test
    public void testA04EntityListToDtoList() {
        ArrayList<TestEntity> entityList = new ArrayList<>();

        entityList.add(getEntity());
        entityList.add(getEntity());
        entityList.add(getEntity());

        ArrayList<TestDto> dtoList = (ArrayList)baseAssembler.entityListToDtoList(entityList);

        int index= 0;
        for (TestDto testDto : dtoList) {
            Assert.assertEquals("Checking field1 is equal", testDto.getField1(), entityList.get(index).getField1());
            Assert.assertEquals("Checking field2 is equal", testDto.getField2(), entityList.get(index).getField2());
            Assert.assertEquals("Checking field3 is equal", testDto.getField3(), entityList.get(index).getField3(), 0);
            Assert.assertEquals("Checking field4 is equal", testDto.getField4(), entityList.get(index).getField4(), 0);
            Assert.assertEquals("Checking field5 is equal", testDto.isField5(), entityList.get(index).isField5());

            index++;
        }
    }


    private TestEntity getEntity(){
        TestEntity entity = new TestEntity();

        entity.setField1("field1");
        entity.setField2(10);
        entity.setField3(12f);
        entity.setField4(100.345);
        entity.setField5(true);

        return entity;
    }


    private TestDto getDto(){
        TestDto dto = new TestDto();

        dto.setField1("field1");
        dto.setField2(10);
        dto.setField3(12f);
        dto.setField4(100.345);
        dto.setField5(true);

        return dto;
    }


}
