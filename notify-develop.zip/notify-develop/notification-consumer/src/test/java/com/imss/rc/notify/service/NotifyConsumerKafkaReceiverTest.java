package com.imss.rc.notify.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.notify.entity.*;
import com.imss.rc.notify.repository.*;
import com.imss.rc.notify.util.ResolvePlaceHolders;
import com.imss.rc.notify.assembler.NotificationRequestAssembler;
import com.imss.rc.notify.dto.NotificationRequestsDto;
import com.imss.rc.notify.dto.NotificationTemplatesDto;
import com.imss.rc.notify.dto.PreferencesDto;
import com.imss.rc.notify.enums.NotifyRequestModeTypeEnum;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.json.JSONObject;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;

import static org.mockito.Mockito.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(PowerMockRunner.class)
public class NotifyConsumerKafkaReceiverTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(ResolvePlaceHolders.class);

    @InjectMocks
    NotifiyConsumerKafkaReceiver kafkaReceiver;

    @Mock
    NotificationConsumerTemplatesRepository notificationTemplatesRepository;

    @Mock
    NotificationRequestAssembler notificationRequestAssembler;

    @Mock
    NotificationConsumerRequestRepository notificationRequestRepository;

    @Mock
    NotificationConsumerInAppRepository inAppRepository;

    @Mock
    NotificationConsumerEmailRepository emailRepository;

    @Mock
    NotificationConsumerSmsRepository smsRepository;

    @Mock
    NotificationConsumerPushRepository pushRepository;


    @Mock
    EmailNotificationSender emailNotificationSender;
    @Mock
    SMSNotificationSender smsNotificationSender;
    @Mock
    PushNotificationSender pushNotificationSender;

    public static final String EXPECTED_MESSAGE = "<beginning Data> This is the <single value> content with <new Data> that is to be replaced <This is another value> and <This is another value>";
    public static final String EXPECTED_TITLE = "Title <title content>";
    public static final String EXPECTED_EMAIL = "sandeepkunder@integramicro.com.com";
    public static final String EXPECTED_NUMBER = "7349254766";
    public static final String EXPECTED_USER_ID = "12978";

    @Test
    public void testA01() {

        NotificationRequestsDto dto = getNotificationRequestsDto();
        dto.setRequestModeType(NotifyRequestModeTypeEnum.SPECIFIC.getValue());

        ArgumentCaptor<NotificationInAppEntity> inAppEntityCaptor = ArgumentCaptor.forClass(NotificationInAppEntity.class);
        ArgumentCaptor<NotificationEmailEntity> emailEntityCaptor = ArgumentCaptor.forClass(NotificationEmailEntity.class);
        ArgumentCaptor<NotificationPushEntity> pushEntityCaptor = ArgumentCaptor.forClass(NotificationPushEntity.class);
        ArgumentCaptor<NotificationSmsEntity> smsEntityCaptor = ArgumentCaptor.forClass(NotificationSmsEntity.class);

        when(notificationTemplatesRepository.getByCode(Mockito.anyString())).thenReturn(getNotificationTemplate());
        when(notificationTemplatesRepository.getById(Mockito.anyInt())).thenReturn(getNotificationTemplate());
        when(notificationRequestAssembler.dtoToEntity(Mockito.any())).thenReturn(getNotificationRequestsEntity());
        when(notificationRequestRepository.save(Mockito.any())).thenReturn(getNotificationRequestsEntity());
        when(inAppRepository.save(Mockito.any())).thenReturn(null);
        when(emailRepository.save(Mockito.any())).thenReturn(null);
        when(smsRepository.save(Mockito.any())).thenReturn(null);
        when(pushRepository.save(Mockito.any())).thenReturn(null);

        when(emailNotificationSender.send(Mockito.any())).thenReturn(true);
        when(smsNotificationSender.send(Mockito.any())).thenReturn(true);
        when(pushNotificationSender.send(Mockito.any())).thenReturn(true);

        try {

            kafkaReceiver.consumeData(dto);

            verify(inAppRepository).save(inAppEntityCaptor.capture());
            NotificationInAppEntity inAppEntity = inAppEntityCaptor.getValue();

            verify(pushRepository, times(2)).save(pushEntityCaptor.capture());
            NotificationPushEntity pushEntity = pushEntityCaptor.getValue();

            verify(smsRepository, times(2)).save(smsEntityCaptor.capture());
            NotificationSmsEntity smsEntity = smsEntityCaptor.getValue();

            verify(emailRepository, times(2)).save(emailEntityCaptor.capture());
            NotificationEmailEntity emailEntity = emailEntityCaptor.getValue();


            Assert.assertEquals("Checking In app Message","inapp "+EXPECTED_MESSAGE , inAppEntity.getContent());
            Assert.assertEquals("Checking In app Title","inapp "+EXPECTED_TITLE , inAppEntity.getTitle());
            Assert.assertEquals("Checking In app To",EXPECTED_USER_ID , inAppEntity.getUserName());


            Assert.assertEquals("Checking Push Message","push "+EXPECTED_MESSAGE , pushEntity.getContent());
            Assert.assertEquals("Checking Push Title","push "+EXPECTED_TITLE , pushEntity.getTitle());
            Assert.assertEquals("Checking Push To",EXPECTED_NUMBER , pushEntity.getToNumber());

            Assert.assertEquals("Checking Email Message","email "+EXPECTED_MESSAGE , emailEntity.getMailBody());
            Assert.assertEquals("Checking Email Subject","email "+EXPECTED_TITLE , emailEntity.getSubjectLine());
            Assert.assertEquals("Checking Email To",EXPECTED_EMAIL , emailEntity.getToEmails());

            Assert.assertEquals("Checking Sms Message","sms "+EXPECTED_MESSAGE , smsEntity.getMessage());
            Assert.assertEquals("Checking Sms To",EXPECTED_NUMBER , smsEntity.getToNumber());

        } catch (Exception ex){
            LOGGER.error("Exception in testA01:", ex);

        }
    }


    private NotificationRequestsDto getNotificationRequestsDto(){
        NotificationRequestsDto dto = new NotificationRequestsDto();


        try (FileInputStream fi = new FileInputStream(new File(getFile("payload.json").getAbsolutePath()));){
            byte data[] = new byte[5000];


            int read = fi.read(data);
            String payload = new String(data, 0, read);
            PreferencesDto prefDto = new PreferencesDto();

            prefDto.setEmail("Y");
            prefDto.setPush("Y");
            prefDto.setInapp("Y");
            prefDto.setSms("Y");

            dto.setMode(prefDto);
            dto.setPayload(payload);
            dto.setUserName("1");
            dto.setTemplateCode("user.register.otp");


        } catch(Exception ex){
            LOGGER.error("Exception :", ex);
        }

        return dto;
    }

    private File getFile(String fileName){
        ClassLoader classLoader = getClass().getClassLoader();
        return new File(classLoader.getResource(fileName).getFile());

    }

    private NotificationRequestsEntity getNotificationRequestsEntity(){
        NotificationRequestsEntity entity = new NotificationRequestAssembler().dtoToEntity(getNotificationRequestsDto());
        entity.setId(1000);

        return entity;
    }

    private NotificationTemplatesEntity getNotificationTemplate(){
        NotificationTemplatesEntity entity = new NotificationTemplatesEntity();


        try {
            byte data[] = new byte[5000];

            FileInputStream fi = new FileInputStream(new File(getFile("template.json").getAbsolutePath()));
            int read = fi.read(data);
            String template = new String(data, 0, read);

            ObjectMapper mapper = new ObjectMapper();
            NotificationTemplatesDto dto = mapper.readValue(template, NotificationTemplatesDto.class);

            JSONObject jsonObj = new JSONObject(dto);
            entity.setCode("user.register.otp");
            entity.setTemplate(jsonObj.getString("template"));

        } catch(Exception ex){
            LOGGER.error("Exception :", ex);
        }

        return entity;
    }

}
