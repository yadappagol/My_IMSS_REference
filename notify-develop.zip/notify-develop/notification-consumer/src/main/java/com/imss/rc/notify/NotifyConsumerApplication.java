/**
 * COPYRIGHT: Jakkur Technoparks Pvt. Ltd. (JTPL)
 * This software is the sole property of JTPL
 * and is protected by copyright law and international
 * treaty provisions. Unauthorized reproduction or
 * redistribution of this program, or any portion of
 * it may result in severe civil and criminal penalties
 * and will be prosecuted to the maximum extent possible
 * under the law. JTPL reserves all rights not
 * expressly granted. You may not reverse engineer, decompile,
 * or disassemble the software, except and only to the
 * extent that such activity is expressly permitted
 * by applicable law notwithstanding this limitation.
 * THIS SOFTWARE IS PROVIDED TO YOU "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
 * YOU ASSUME THE ENTIRE RISK AS TO THE ACCURACY
 * AND THE USE OF THIS SOFTWARE. JTPL SHALL NOT BE LIABLE FOR
 * ANY DAMAGES WHATSOEVER ARISING OUT OF THE USE OF OR INABILITY TO
 * USE THIS SOFTWARE, EVEN IF JTPL HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/
package com.imss.rc.notify;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Notification Consumer Application's main class.
 *
 * @author
 */
@SpringBootApplication
@EnableAutoConfiguration
@EnableJpaAuditing
@Configuration
@EnableJpaRepositories("com.imss.rc.notify")
@ComponentScan({"com.imss.rc.config","com.imss.rc.notify"})
@EnableAsync
@EnableEncryptableProperties
@ConditionalOnProperty(prefix = "rc.notify.consumer", name = "standalone")
public class NotifyConsumerApplication extends SpringBootServletInitializer
{
    /**
     * The main method that's being called first on application load.
     * @param args the arguments that are to be provided to the spring application run method
     * @author comviva
     */
    public static void main(String[] args)
    {
        SpringApplication.run(NotifyConsumerApplication.class, args);
    }

}
