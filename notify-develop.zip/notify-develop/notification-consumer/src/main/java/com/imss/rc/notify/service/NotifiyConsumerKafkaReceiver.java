package com.imss.rc.notify.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.notify.dto.*;
import com.imss.rc.notify.entity.*;
import com.imss.rc.notify.enums.*;
import com.imss.rc.notify.repository.*;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import com.imss.rc.commons.util.ExceptionMessageResolver;
import com.imss.rc.notify.assembler.NotificationEventsAssembler;
import com.imss.rc.notify.assembler.NotificationRequestAssembler;
import com.imss.rc.notify.assembler.NotificationUserPreferenceAssembler;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.util.ResolvePlaceHolders;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;


@Service
public class NotifiyConsumerKafkaReceiver {

    private static final Logger LOGGER = LoggerFactory.getLogger(NotifiyConsumerKafkaReceiver.class);

    @Autowired
    NotificationConsumerTemplatesRepository notificationTemplatesRepository;

    @Autowired
    NotificationRequestAssembler  notificationRequestAssembler;

    @Autowired
    NotificationConsumerRequestRepository notificationRequestRepository;

    @Autowired
    NotificationConsumerEventRepository notificationConsumerEventRepository;

    @Autowired
    NotificationConsumerUserPreferenceRepository notifyUserPreferenceRepository;

    @Autowired
    NotificationEventsAssembler notifyEventsAssembler;
    @Autowired
    NotificationUserPreferenceAssembler notifyUserPrefAssembler;


    @Autowired
    NotificationConsumerInAppRepository inAppRepository;
    @Autowired
    NotificationConsumerEmailRepository emailRepository;
    @Autowired
    NotificationConsumerSmsRepository smsRepository;
    @Autowired
    NotificationConsumerPushRepository pushRepository;

    @Autowired
    EmailNotificationSender emailNotificationSender;
    @Autowired
    SMSNotificationSender smsNotificationSender;
    @Autowired
    PushNotificationSender pushNotificationSender;

    /**
     * This is the method which receives the messages from the Kafka
     * @param notifyRequestDto The message object as received from kafka
     * @throws JsonProcessingException
     */
    @KafkaListener(topics = "${kafka.rc.notify.send.topic}", groupId = "${kafka.rc.notify.send.group.id}", containerFactory="notifyKafkaListenerContainerFactory")
    public void consumeData(NotificationRequestsDto notifyRequestDto) throws JsonProcessingException {

        Date curDate = new Date(System.currentTimeMillis());
        NotificationRequestsEntity reqEntity;

        reqEntity = notificationRequestAssembler.dtoToEntity(notifyRequestDto);

        reqEntity.setStatus(NotificationRequestStatusEnum.RECEIVED.getValue());
        reqEntity.setReceivedDate(curDate);
        reqEntity.setCreatedDate(curDate);
        reqEntity.setModifiedDate(curDate);

        //Saving the notification request.
        reqEntity = notificationRequestRepository.save(reqEntity);
        notifyRequestDto.setId(reqEntity.getId());
        try{

            if (NotifyRequestModeTypeEnum.SPECIFIC.getValue().equals(notifyRequestDto.getRequestModeType())) {
                handleSpecificModeOfNotifyRequest(notifyRequestDto);
            } else if (NotifyRequestModeTypeEnum.EVENT.getValue().equals(notifyRequestDto.getRequestModeType())) {
                handleEventModeOfNotifyRequest(notifyRequestDto);
            } else {
                throw new NotifyException(NotifyException.CONSUMER_UNKNOWN_NOTIFY_REQUEST_MODE
                        , new String[]{notifyRequestDto.getRequestModeType()}
                        , HttpStatus.BAD_REQUEST);
            }


            reqEntity.setStatus(NotificationRequestStatusEnum.PROCESSED_SUCCESSFULLY.getValue());
            reqEntity.setModifiedDate(new Date(System.currentTimeMillis()));

            notificationRequestRepository.save(reqEntity);

        } catch (NotifyException ex){
            //Catching the exception here because this is a kafka receiver so nowhere to throw

            //Resolving the exception message as it needs to be save in the database.
            ExceptionMessageResolver.resolveMessage(notifyRequestDto  ,ex, null);

            reqEntity.setRemarks(notifyRequestDto.getResponseMessage());
            reqEntity.setStatus(NotificationRequestStatusEnum.PROCESSED_WITH_ERRORS.getValue());
            reqEntity.setModifiedDate(new Date(System.currentTimeMillis()));


            notificationRequestRepository.save(reqEntity);
        }

    }

    /**
     * This method is to handle the specific mode of sending out notifications. That is
     * it picks the modes to be sent out from the payload itself
     * @param notifyRequestDto The dto object that contains the mode preferences and the payload and template details
     */
    private void handleSpecificModeOfNotifyRequest(NotificationRequestsDto notifyRequestDto){

        NotificationTemplatesEntity templateEntity;

        try {

            if(notifyRequestDto.getTemplateCode() != null && !notifyRequestDto.getTemplateCode().trim().isEmpty()){

                templateEntity = notificationTemplatesRepository.getByCode(notifyRequestDto.getTemplateCode());

            } else if(notifyRequestDto.getTemplateId() != null && notifyRequestDto.getTemplateId() != 0){

                templateEntity = notificationTemplatesRepository.getById(notifyRequestDto.getTemplateId());

            } else {
                throw new NotifyException(NotifyException.CONSUMER_TEMPLATE_ID_AND_CODE_FOUND_BLANK
                        , HttpStatus.BAD_REQUEST);
            }

            if(templateEntity == null){
                throw new NotifyException(NotifyException.CONSUMER_TEMPLATE_ID_OR_CODE_NOT_FOUND
                        , new String[]{notifyRequestDto.getTemplateCode(), String.valueOf(notifyRequestDto.getTemplateId())}
                        , HttpStatus.BAD_REQUEST);
            }

            handleNotifications(notifyRequestDto.getMode(), templateEntity.getTemplate(),
                    notifyRequestDto.getPayload(), notifyRequestDto.getId());

        } catch (NotifyException ex){
            throw ex;
        } catch (Exception ex){
            LOGGER.error("Error while processing specific mode of notify request", ex);
            throw new NotifyException(NotifyException.CONSUMER_ERROR_WHILE_PROCESSING_REQUEST,HttpStatus.BAD_REQUEST);
        }

    }

    /**
     * This method is to handle the event based notification, it will decided the modes of notification
     * based on the event configuration and the preferences of the event / user as configured
     * @param notifyRequestDto The request object with the notification details
     */
    private void handleEventModeOfNotifyRequest(NotificationRequestsDto notifyRequestDto){


        try{

            if(notifyRequestDto.getEventId() == null || notifyRequestDto.getEventId() <= 0){
                throw new NotifyException(NotifyException.CONSUMER_EVENT_ID_FOUND_BLANK,HttpStatus.BAD_REQUEST);
            }

            Optional<NotificationEventsEntity> notifyeventOptional = notificationConsumerEventRepository.getById(Short.valueOf(String.valueOf(GlobalYesNoEnum.NO.getValue())),notifyRequestDto.getEventId() );

            if(!notifyeventOptional.isPresent()){
                throw new NotifyException(NotifyException.CONSUMER_INVALID_EVENT_ID,HttpStatus.BAD_REQUEST);
            }

            NotificationEventsDto notifyEventDto = notifyEventsAssembler.entityToDto(notifyeventOptional.get());


            List<NotificationTemplatesEntity> templateList = notificationTemplatesRepository.getByEventId(Short.valueOf(String.valueOf(GlobalYesNoEnum.NO.getValue())),notifyRequestDto.getEventId());

            if(templateList == null || templateList.isEmpty()){
                throw new NotifyException(NotifyException.CONSUMER_NO_TEMPLATES_FOUND_FOR_EVENT,
                        new String[]{notifyEventDto.getName(), String.valueOf(notifyEventDto.getId())},
                        HttpStatus.BAD_REQUEST);
            }

            String userName;
            PreferencesDto preferenceToUse;
            for(NotificationTemplatesEntity  templateEntity : templateList){

                //TODO:get User id from the template expression
                userName = "1";
                preferenceToUse = getPreferenceToUse(notifyEventDto, userName);

                handleNotifications(preferenceToUse, templateEntity.getTemplate(),
                        notifyRequestDto.getPayload(), notifyRequestDto.getId());

            }


        } catch (NotifyException ex){
            throw ex;
        } catch (Exception ex){
            LOGGER.error("Error while processing event mode of notify request", ex);
            throw new NotifyException(NotifyException.CONSUMER_ERROR_WHILE_PROCESSING_REQUEST,HttpStatus.BAD_REQUEST);
        }

    }

    /**
     * This method actually handles constructing the notification and sending it out.
     *
     * @param preferencesDto The preferences object to indicate what modes to be sent
     * @param template The template to be used
     * @param payload The payload to resolved the template placeholders in JSON stringify format
     * @param requestId The notification request id for updating status
     * @throws Exception
     */
    private void handleNotifications(PreferencesDto preferencesDto, String template, String payload, int requestId) throws Exception{

        ObjectMapper mapper = new ObjectMapper();
        List<Map<String, Object>> dtos = mapper.readValue(template, List.class);


        TemplateDto templateDto;
        ContentDetailsDto contentDto;
        ResolvePlaceHolders resolvePlaceHolders = new ResolvePlaceHolders(payload);

        List<String> listOfModes = new ArrayList<>();

        if(preferencesDto.getEmail().equalsIgnoreCase("Y")){
            listOfModes.add(NotifyModeEnum.EMAIL.getValue());
        }

        if(preferencesDto.getSms().equalsIgnoreCase("Y")){
            listOfModes.add(NotifyModeEnum.SMS.getValue());
        }

        if(preferencesDto.getPush().equalsIgnoreCase("Y")){
            listOfModes.add(NotifyModeEnum.PUSH.getValue());
        }

        if(preferencesDto.getInapp().equalsIgnoreCase("Y")){
            listOfModes.add(NotifyModeEnum.INAPP.getValue());
        }


        for (String mode : listOfModes) {

            templateDto = getTemplatePartForMode(dtos, mode);
            if(templateDto == null){
                throw new NotifyException(NotifyException.CONSUMER_MODE_NOT_FOUND_IN_TEMPLATE_DEFINITION, new String[]{mode}, HttpStatus.BAD_REQUEST);
            }

            String language = resolvePlaceHolders.getPreferredLanguage(templateDto.getNotifyLanguage());
            contentDto = getContentDetailsForLanguage(templateDto.getContentDetails(),language);


            if(contentDto == null){
                throw new NotifyException(NotifyException.CONSUMER_CONTENT_NOT_FOUND_FOR_LANGUAGE, new String[]{language}, HttpStatus.BAD_REQUEST);
            }

            if(NotifyModeEnum.INAPP.getValue().equals(mode)){

                NotificationInAppEntity inAppEntity = new NotificationInAppEntity();

                inAppEntity.setRequestId(requestId);
                inAppEntity.setContent(resolvePlaceHolders.processContent(contentDto.getContent()));
                inAppEntity.setTitle(resolvePlaceHolders.processContent(contentDto.getTitle()));
                inAppEntity.setStatus(NotificationStatusInAppEnum.NOT_NOTIFIED_UNREAD.getValue());
                inAppEntity.setUserName(resolvePlaceHolders.getValueForExpression(templateDto.getToExpression()));
                inAppEntity.setCreatedDate(new Date(System.currentTimeMillis()));
                inAppEntity.setModifiedDate(new Date(System.currentTimeMillis()));

                inAppRepository.save(inAppEntity);

            } else if(NotifyModeEnum.PUSH.getValue().equals(mode)){
                NotificationPushEntity pushEntity = new NotificationPushEntity();

                pushEntity.setRequestId(requestId);
                pushEntity.setContent(resolvePlaceHolders.processContent(contentDto.getContent()));
                pushEntity.setTitle(resolvePlaceHolders.processContent(contentDto.getTitle()));
                pushEntity.setStatus(NotificationStatusPushEnum.NOT_SENT.getValue());
                pushEntity.setToNumber(resolvePlaceHolders.getValueForExpression(templateDto.getToExpression()));
                pushEntity.setCreatedDate(new Date(System.currentTimeMillis()));
                pushEntity.setModifiedDate(new Date(System.currentTimeMillis()));

                pushRepository.save(pushEntity);

                if(pushNotificationSender.send(pushEntity)){
                    pushEntity.setSentDate(new Date(System.currentTimeMillis()));
                    pushEntity.setStatus(NotificationStatusEmailEnum.SENT.getValue());
                } else {
                    pushEntity.setStatus(NotificationStatusEmailEnum.ERROR_IN_SENDING.getValue());
                }

                pushEntity.setModifiedDate(new Date(System.currentTimeMillis()));
                pushRepository.save(pushEntity);

            } else if(NotifyModeEnum.EMAIL.getValue().equals(mode)){
                NotificationEmailEntity emailEntity = new NotificationEmailEntity();

                emailEntity.setRequestId(requestId);
                emailEntity.setMailBody(resolvePlaceHolders.processContent(contentDto.getContent()));
                emailEntity.setSubjectLine(resolvePlaceHolders.processContent(contentDto.getTitle()));
                emailEntity.setStatus(NotificationStatusEmailEnum.NOT_SENT.getValue());
                emailEntity.setToEmails(resolvePlaceHolders.getValueForExpression(templateDto.getToExpression()));
                emailEntity.setCreatedDate(new Date(System.currentTimeMillis()));
                emailEntity.setModifiedDate(new Date(System.currentTimeMillis()));

                emailRepository.save(emailEntity);

                if(emailNotificationSender.send(emailEntity)){
                    emailEntity.setSentDate(new Date(System.currentTimeMillis()));
                    emailEntity.setStatus(NotificationStatusEmailEnum.SENT.getValue());
                } else {
                    emailEntity.setStatus(NotificationStatusEmailEnum.ERROR_IN_SENDING.getValue());
                }

                emailEntity.setModifiedDate(new Date(System.currentTimeMillis()));
                emailRepository.save(emailEntity);

            } else if(NotifyModeEnum.SMS.getValue().equals(mode)){
                NotificationSmsEntity smsEntity = new NotificationSmsEntity();

                smsEntity.setRequestId(requestId);
                smsEntity.setMessage(resolvePlaceHolders.processContent(contentDto.getContent()));
                smsEntity.setStatus(NotificationStatusSmsEnum.NOT_SENT.getValue());
                smsEntity.setToNumber(resolvePlaceHolders.getValueForExpression(templateDto.getToExpression()));
                smsEntity.setCreatedDate(new Date(System.currentTimeMillis()));
                smsEntity.setModifiedDate(new Date(System.currentTimeMillis()));

                smsRepository.save(smsEntity);

                if(smsNotificationSender.send(smsEntity)){
                    smsEntity.setSentDate(new Date(System.currentTimeMillis()));
                    smsEntity.setStatus(NotificationStatusSmsEnum.SENT.getValue());
                } else {
                    smsEntity.setStatus(NotificationStatusSmsEnum.ERROR_IN_SENDING.getValue());
                }
                smsEntity.setModifiedDate(new Date(System.currentTimeMillis()));
                smsRepository.save(smsEntity);
            } else {
                throw new NotifyException(NotifyException.CONSUMER_INVALID_NOTIFICATION_MODE,new String[]{mode}, HttpStatus.BAD_REQUEST);
            }
        }
    }

    /**
     * This method decides which preference to be used, is it the notification event or the user based preference
     * @param notifyEventDto The notification event Dto object
     * @param userName The username for which this operation is being done
     * @return The resolved {@link PreferencesDto} object
     */
    private PreferencesDto getPreferenceToUse(NotificationEventsDto notifyEventDto, String userName){

        Optional<NotificationUserPreferenceEntity> userPrefEntity;

        if(notifyEventDto.getIsUserOverrideAllowed() == GlobalYesNoEnum.YES.getValue()){
            userPrefEntity = notifyUserPreferenceRepository.getByEventIdAndUserName(notifyEventDto.getId(),userName,(short)GlobalYesNoEnum.NO.getValue());
            if(userPrefEntity.isPresent()){
                return notifyUserPrefAssembler.entityToDto(userPrefEntity.get()).getPreferences();
            } else {
                return  notifyEventDto.getPreferences();
            }
        } else {
            return notifyEventDto.getPreferences();
        }
    }

    /**
     * Method to get the template details for the given mode.
     *
     * @param dtos The list of templates for each mode
     * @param mode The mode for which the template needs to be retrieved.
     *
     * @return The Template DTO object for the requested mode if found, null otherwise
     */
    private TemplateDto getTemplatePartForMode(List<Map<String, Object>> dtos , String mode){
        ObjectMapper mapper = new ObjectMapper();

        TemplateDto dto;

        for(Map<String, Object> map : dtos){
            dto = mapper.convertValue(map, TemplateDto.class);
            if(dto.getMode().equals(mode)){
                return dto;
            }
        }
        return null;
    }

    /**
     * Method to get the content based on the language code
     *
     * @param dtos The List of content details for all available languages
     * @param lang The language code to get the content object
     * @return
     */
    private ContentDetailsDto getContentDetailsForLanguage(List<ContentDetailsDto> dtos , String lang){
        for(ContentDetailsDto dto : dtos){
            if(dto.getLanguage().equals(lang)){
                return dto;
            }
        }
        return null;
    }
}
