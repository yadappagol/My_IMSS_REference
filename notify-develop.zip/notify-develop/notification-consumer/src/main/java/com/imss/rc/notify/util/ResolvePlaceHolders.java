package com.imss.rc.notify.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.notify.exception.NotifyException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ResolvePlaceHolders {

    private static final Logger LOGGER = LoggerFactory.getLogger(ResolvePlaceHolders.class);

    private Map<String, Object> payloadMap;

    public ResolvePlaceHolders(String payload){

        try {
            ObjectMapper mapper = new ObjectMapper();
            this.payloadMap = mapper.readValue(payload, Map.class);
        } catch(Exception ex){
            LOGGER.error("Exception in ResolvePlaceHolders:", ex);
        }
    }

    public static void main(String[] args) throws IOException {
        String content = "{at.beginning} This is the {single} content with {first.value} that is to be " +
                " replaced {with.another.value} and {yet.another.fourth.value}";
        String payload;
        FileInputStream fi=null;
        try {

            byte data[] = new byte[5000];
            fi = new FileInputStream(new File("D:\\Projects\\202009_Insurance_Portal\\fromRepository\\notify\\notification-consumer\\src\\main\\resources\\payload.txt"));
            int read = fi.read(data);
            payload = new String(data, 0, read);

            ResolvePlaceHolders resolve = new ResolvePlaceHolders(payload);

            resolve.processContent( content);

        } catch(Exception ex){
            LOGGER.error("Exception in ResolvePlaceHolders:", ex);
        }
        finally {
            fi.close();
        }

    }

    /**
     * This method parses all the place holders in the content and replaces it with the data
     * from the payload that was used to initialize this class
     *
     * @param content The content with the place holders
     * @return The resolved content
     */
    public String processContent(String content) throws NotifyException {

        LOGGER.debug("INPUT CONTENT==={}",content);
        List<String>  placeHoldersList = parseForPlaceHolders(content);

        String valueToReplace ;

        for(String placeHolder : placeHoldersList){
            //For each of the place holder
            valueToReplace = getValueForExpression(placeHolder);

            LOGGER.debug("Replacing {} --> {}",placeHolder,valueToReplace);
            content = content.replace("{"+placeHolder+"}",valueToReplace);
        }

        LOGGER.debug("FINAL CONTENT==={}",content);

        return content;
    }

    /**
     * This method parses the payload and gets the value for the expression passed
     * @param placeHolderExpression The placeHolderExpression for which the value from the payload needs to be extracted
     * @return The value based on the expression
     * @throws Exception if the expression was not found in the payload
     */
    public String getValueForExpression(String placeHolderExpression) throws NotifyException {

        Map<String, Object> mapToConsider = this.payloadMap;
        String placeHolderPath[] = placeHolderPath = placeHolderExpression.split("\\.");
        StringBuilder curPath = new StringBuilder("");

        String valueToReplace = null;
        curPath.delete(0, curPath.length());
        int cnt = 0;

        for(String pathPart: placeHolderPath){
            curPath.append(pathPart).append(".");
            if(mapToConsider.get(pathPart) != null) {
                if(cnt == (placeHolderPath.length-1)){
                    valueToReplace = (String)mapToConsider.get(pathPart);
                } else {
                    mapToConsider = (Map)mapToConsider.get(pathPart);
                }
            } else {
                throw new NotifyException(NotifyException.CONSUMER_EXPRESSION_PATH_NOT_FOUND_IN_PAYLOAD, new String[] {curPath.toString()}, HttpStatus.BAD_REQUEST);
            }
            cnt++;
        }

        return valueToReplace;
    }

    public static List<String> parseForPlaceHolders(String content){
        final Pattern pattern = Pattern.compile("\\{(.+?)\\}");
        final Matcher matcher = pattern.matcher(content);
        final List<String> list = new LinkedList<>();

        while (matcher.find()) {
            list.add(matcher.group(1));
        }

        return list;
    }


    public String getPreferredLanguage( String languageExpression){
        String strLang = null;
        try{
            strLang = getValueForExpression(languageExpression);

        } catch(NotifyException ex){
            if(NotifyException.CONSUMER_EXPRESSION_PATH_NOT_FOUND_IN_PAYLOAD.equals(ex.getCode())){
                //TODO: pick default app language from configuration
                strLang = "en";
            }
        }

        return strLang;

    }

}
