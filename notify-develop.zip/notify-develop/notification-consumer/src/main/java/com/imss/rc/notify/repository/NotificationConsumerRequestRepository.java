package com.imss.rc.notify.repository;


import com.imss.rc.notify.entity.NotificationRequestsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

@Transactional
@Repository
public interface NotificationConsumerRequestRepository extends JpaRepository<NotificationRequestsEntity, Integer> {

}
