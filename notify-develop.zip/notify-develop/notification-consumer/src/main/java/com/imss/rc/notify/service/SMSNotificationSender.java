package com.imss.rc.notify.service;

import com.imss.rc.config.enums.ConfigurationTypeEnum;
import com.imss.rc.config.service.ConfigCache;
import com.imss.rc.notify.entity.NotificationSmsEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Component
public class SMSNotificationSender {

    private static final Logger LOGGER = LoggerFactory.getLogger(SMSNotificationSender.class);


    public boolean send(NotificationSmsEntity smsEntity) {

        try {

            boolean isSuccess = false;

            String url = ConfigCache.getConfigValue(ConfigurationTypeEnum.NOTIFY_SMS_URL.getKey());
            String apiKey = ConfigCache.getConfigValue(ConfigurationTypeEnum.NOTIFY_SMS_API_KEY.getKey());
            String numberPlaceHolder = ConfigCache.getConfigValue(ConfigurationTypeEnum.NOTIFY_SMS_NUMBER_PLACEHOLDER.getKey());
            String apiPlaceHolder = ConfigCache.getConfigValue(ConfigurationTypeEnum.NOTIFY_SMS_API_PLACEHOLDER.getKey());
            String messagePlaceHolder = ConfigCache.getConfigValue(ConfigurationTypeEnum.NOTIFY_SMS_MESSAGE_PLACEHOLDER.getKey());

            url = url.replaceAll(apiPlaceHolder, apiKey);
            url = url.replaceAll(numberPlaceHolder, smsEntity.getToNumber());
            url = url.replaceAll(messagePlaceHolder, smsEntity.getMessage());

            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");

            HttpEntity<Object> request = new HttpEntity<>(httpHeaders);

            ResponseEntity<List> out = getRestTemplate().exchange(url , HttpMethod.GET, request, List.class);
            List<Map> response = out.getBody();
            for(int i = 0 ; i < response.size(); i++){
                if(response.get(i).get("responseCode") != null){
                    if("Message SuccessFully Submitted".equals(response.get(i).get("responseCode"))) {
                        isSuccess = true;
                    }
                    smsEntity.setRemarks((String)response.get(i).get("responseCode"));
                } else if(response.get(i).get("msgid") != null){
                    smsEntity.setRemarks((String)response.get(i).get("msgid"));
                }
            }

            return isSuccess;
        }
        catch (RuntimeException ex) {
            LOGGER.error("Unable to send SMS....", ex);
            return false;
        }
    }

    private RestTemplate getRestTemplate(){

        RestTemplate restTemplate = new RestTemplate();

        return restTemplate;
    }

}
