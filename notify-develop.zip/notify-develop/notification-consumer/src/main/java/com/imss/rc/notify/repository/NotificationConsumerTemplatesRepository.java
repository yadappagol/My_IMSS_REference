package com.imss.rc.notify.repository;

import com.imss.rc.notify.entity.NotificationTemplatesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Transactional
@Repository
public interface NotificationConsumerTemplatesRepository extends JpaRepository<NotificationTemplatesEntity,Integer> {

    @Query(value="from NotificationTemplatesEntity nt where nt.isDeleted=0 and nt.code= :code")
    public NotificationTemplatesEntity getByCode(@Param("code") String code);

    @Query(value="from NotificationTemplatesEntity nt where nt.isDeleted=0 and nt.id= :id")
    public NotificationTemplatesEntity getById(@Param("id") Integer id);

    @Query(value="from NotificationTemplatesEntity nt where nt.isDeleted= :isDeleted and nt.eventId= :eventId")
    public List<NotificationTemplatesEntity> getByEventId(@Param("isDeleted") Short isDeleted, @Param("eventId") Integer eventId);
}
