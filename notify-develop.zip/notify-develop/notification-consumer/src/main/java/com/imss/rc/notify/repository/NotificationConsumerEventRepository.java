package com.imss.rc.notify.repository;

import com.imss.rc.notify.entity.NotificationEventsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface NotificationConsumerEventRepository extends JpaRepository<NotificationEventsEntity, Integer> {

    @Query(value="from NotificationEventsEntity ne where ne.isDeleted= :isDeleted and ne.id= :id")
    public Optional<NotificationEventsEntity> getById(@Param("isDeleted") Short isDeleted, @Param("id") Integer id);

}
