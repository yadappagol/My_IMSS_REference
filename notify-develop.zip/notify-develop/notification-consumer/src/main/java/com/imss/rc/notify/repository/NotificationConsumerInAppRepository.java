package com.imss.rc.notify.repository;

import com.imss.rc.notify.entity.NotificationInAppEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NotificationConsumerInAppRepository extends JpaRepository<NotificationInAppEntity, Integer> {

}
