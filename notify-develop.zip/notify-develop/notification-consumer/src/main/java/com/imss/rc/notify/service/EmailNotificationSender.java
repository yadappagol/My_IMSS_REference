package com.imss.rc.notify.service;

import com.imss.rc.config.enums.ConfigurationTypeEnum;
import com.imss.rc.config.service.ConfigCache;
import com.imss.rc.notify.entity.NotificationEmailEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import java.io.UnsupportedEncodingException;
import java.util.Properties;

@Component
public class EmailNotificationSender {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmailNotificationSender.class);

    private static final String PROP_MAIL_SMTP_PORT = "mail.smtp.port";
    private static final String PROP_MAIL_SMTP_AUTH = "mail.smtp.auth";
    private static final String PROP_MAIL_SMTP_TLS_ENABLED = "mail.smtp.starttls.enable";
    private static final String PROP_MAIL_SMTP_SSL_TRUST = "mail.smtp.ssl.trust";

    public boolean send(NotificationEmailEntity emailEntity) {

        Properties mailServerProperties;
        Session getMailSession;
        MimeMessage generateMailMessage;

        try {

            LOGGER.debug("#################### NEW EMAIL METHOD "+emailEntity.getId()+"-"+emailEntity.getToEmails());

            final String USER = ConfigCache.getConfigValue(ConfigurationTypeEnum.NOTIFY_SMTP_EMAIL.getKey());
            final String PASS = ConfigCache.getConfigValue(ConfigurationTypeEnum.NOTIFY_SMTP_PASSWORD.getKey());
            final String HOST = ConfigCache.getConfigValue(ConfigurationTypeEnum.NOTIFY_SMTP_HOST.getKey());

            mailServerProperties = System.getProperties();
            mailServerProperties.put(PROP_MAIL_SMTP_PORT,
                    ConfigCache.getConfigValue(ConfigurationTypeEnum.NOTIFY_SMTP_PORT.getKey()));
            mailServerProperties.put(PROP_MAIL_SMTP_AUTH,
                    ConfigCache.getConfigValue(ConfigurationTypeEnum.NOTIFY_SMTP_IS_AUTH_ENABLED.getKey()));
            mailServerProperties.put(PROP_MAIL_SMTP_TLS_ENABLED,
                    ConfigCache.getConfigValue(ConfigurationTypeEnum.NOTIFY_SMTP_IS_SSL_ENABLED.getKey()));
            mailServerProperties.put(PROP_MAIL_SMTP_SSL_TRUST,
                    ConfigCache.getConfigValue(ConfigurationTypeEnum.NOTIFY_SMTP_HOST.getKey()));

            String content = emailEntity.getMailBody();
            String subjectPrefix = ConfigCache.getConfigValue(ConfigurationTypeEnum.NOTIFY_EMAIL_SUBJECT_PREFIX.getKey());



            getMailSession = Session.getDefaultInstance(mailServerProperties, null);
            generateMailMessage = new MimeMessage(getMailSession);

            processListOfMailIds(generateMailMessage, emailEntity.getToEmails(), Message.RecipientType.TO);

            if(emailEntity.getCcEmails() != null && !emailEntity.getCcEmails().isEmpty()){
                processListOfMailIds(generateMailMessage, emailEntity.getCcEmails(), Message.RecipientType.CC);
            }
            generateMailMessage.setSubject(subjectPrefix + emailEntity.getSubjectLine());
            generateMailMessage.setFrom(new InternetAddress(USER, ConfigCache.getConfigValue(ConfigurationTypeEnum.GENERAL_PORTAL_NAME.getKey())));

            generateMailMessage.setContent(content, "text/html");

            Transport transport = getMailSession.getTransport("smtp");

            transport.connect(HOST, USER, PASS);
            transport.sendMessage(generateMailMessage, generateMailMessage.getAllRecipients());
            transport.close();
            LOGGER.debug("#################### Sent Successfully");
            return true;
        }
        catch (MessagingException | UnsupportedEncodingException | RuntimeException ex) {
            LOGGER.error("Unable to send email....", ex);
            return false;
        }

    }


    private void processListOfMailIds(MimeMessage generateMailMessage, String mailIds, Message.RecipientType recipType) throws MessagingException{
        String[] mailIdsList = mailIds.split(";");
        for(String mailId: mailIdsList){
            if(mailId != null && !mailId.isEmpty()){
                generateMailMessage.addRecipient(recipType , new InternetAddress(mailId));
            }
        }
    }
}
