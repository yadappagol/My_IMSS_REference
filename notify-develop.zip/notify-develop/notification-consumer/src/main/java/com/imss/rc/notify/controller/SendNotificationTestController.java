package com.imss.rc.notify.controller;

import com.imss.rc.notify.service.EmailNotificationSender;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.notify.assembler.NotificationEmailAssembler;
import com.imss.rc.notify.assembler.NotificationSmsAssembler;
import com.imss.rc.notify.dto.NotificationEmailDto;
import com.imss.rc.notify.dto.NotificationSmsDto;
import com.imss.rc.notify.entity.NotificationEmailEntity;
import com.imss.rc.notify.entity.NotificationSmsEntity;
import com.imss.rc.notify.service.SMSNotificationSender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
public class SendNotificationTestController {

    @Autowired
    SMSNotificationSender smsSender;


    @Autowired
    EmailNotificationSender emailSender;

    @Autowired
    NotificationSmsAssembler smsAssembler;

    @Autowired
    NotificationEmailAssembler emailAssembler;

    @PostMapping(value = "/notify/sms/send", produces = "application/json",consumes = "application/json")
    public @ResponseBody
    NotificationSmsDto sendSms(@RequestParam String message, @RequestParam String number ,
                                      HttpServletRequest request) {

        NotificationSmsEntity smsEntity = new NotificationSmsEntity();
        smsEntity.setMessage(message);
        smsEntity.setToNumber(number);


        boolean status = smsSender.send(smsEntity);

        NotificationSmsDto dto = smsAssembler.entityToDto(smsEntity);

        if(status){
            dto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            dto.setResponseMessage("Successfully sent message");
        } else {

            dto.setResponseStatus(ResponseDto.STATUS_FAILURE);
            dto.setResponseMessage("Failed to send message");
        }

        return dto;

    }


    @PostMapping(value = "/notify/email/send", produces = "application/json",consumes = "application/json")
    public @ResponseBody
    NotificationEmailDto sendEmail(@RequestParam String message, @RequestParam String subject, @RequestParam String email ,
                                      HttpServletRequest request) {

        NotificationEmailEntity emailEntity = new NotificationEmailEntity();
        emailEntity.setMailBody(message);
        emailEntity.setToEmails(email);
        emailEntity.setSubjectLine(subject);

        boolean status = emailSender.send(emailEntity);

        NotificationEmailDto dto = emailAssembler.entityToDto(emailEntity);


        if(status){
            dto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            dto.setResponseMessage("Successfully sent email");
        } else {

            dto.setResponseStatus(ResponseDto.STATUS_FAILURE);
            dto.setResponseMessage("Failed to send email");
        }

        return dto;

    }

}
