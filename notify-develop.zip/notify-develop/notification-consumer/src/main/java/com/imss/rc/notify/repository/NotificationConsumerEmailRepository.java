package com.imss.rc.notify.repository;

import com.imss.rc.notify.entity.NotificationEmailEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NotificationConsumerEmailRepository extends JpaRepository<NotificationEmailEntity, Integer> {

}
