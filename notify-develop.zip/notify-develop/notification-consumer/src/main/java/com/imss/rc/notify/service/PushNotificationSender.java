package com.imss.rc.notify.service;

import com.imss.rc.notify.entity.NotificationPushEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class PushNotificationSender {
    private static final Logger LOGGER = LoggerFactory.getLogger(PushNotificationSender.class);


    public boolean send(NotificationPushEntity pushEntity) {

        try {

            //TODO: Need to integrate with the PUSH provider

            return false;
        }
        catch (RuntimeException ex) {
            LOGGER.error("Unable to send PUSH notification....", ex);
            return false;
        }
    }
}
