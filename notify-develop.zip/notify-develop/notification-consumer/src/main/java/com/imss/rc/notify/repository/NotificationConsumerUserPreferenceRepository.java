package com.imss.rc.notify.repository;

import com.imss.rc.notify.entity.NotificationUserPreferenceEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface NotificationConsumerUserPreferenceRepository extends JpaRepository<NotificationUserPreferenceEntity, Integer> {

    @Query(value="from NotificationUserPreferenceEntity up where up.eventId= :eventId and up.userName = :userName and up.isDeleted= :isDeleted " )
    public Optional<NotificationUserPreferenceEntity> getByEventIdAndUserName(@Param("eventId") Integer eventId, @Param("userName") String userName, @Param("isDeleted") Short isDeleted);

}
