package com.imss.rc.notify.controller;

import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.notify.dto.*;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
public class NotificationControllerImpl implements NotificationController{

    @Autowired
    private NotificationTemplateService notificationTemplateService;

    @Autowired
    private NotificationSmsService notificationSmsService;

    @Autowired
    private NotificationEmailService notificationEmailService;

    @Autowired
    private NotificationPushService notificationPushService;

    @Autowired
    private NotificationInAppService notificationInAppService;

    @Autowired
    private NotificationUserPreferenceService notificationUserPreferenceService;


    @Override
    public NotificationTemplatesDto addTemplate(NotificationTemplatesDto notificationTemplatesDto, HttpServletRequest request) throws NotifyException {
        UserAuthDataHandler.resolveAuthBaseData(notificationTemplatesDto, request);
        return notificationTemplateService.addTemplate(notificationTemplatesDto);
    }

    @Override
    public BaseListDto<NotificationTemplatesDto> getAllTemplates(Integer page, Integer limit, String sortBy, Integer eventId, Short type, String sortType, HttpServletRequest request) throws NotifyException {
        NotificationTemplatesDto dto = new NotificationTemplatesDto();
        dto.setType(type);
        if(eventId!=null) {
            dto.setEventId(eventId);

        }
        PaginationDto pageDto = new PaginationDto();
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);

        dto.setPaginationDto(pageDto);
        UserAuthDataHandler.resolveAuthBaseData(dto, request);
        return notificationTemplateService.findAll(dto);
    }


    @Override
    public NotificationTemplatesDto getTemplatesById(Integer id, HttpServletRequest request) throws NotifyException {
        NotificationTemplatesDto notificationTemplatesDto=new NotificationTemplatesDto();
        notificationTemplatesDto.setId(id);
        UserAuthDataHandler.resolveAuthBaseData(notificationTemplatesDto, request);
        return notificationTemplateService.getTemplatesById(notificationTemplatesDto);
    }

    @Override
    public NotificationTemplatesDto updateNotificationTemplate(NotificationTemplatesDto notificationTemplatesDto, Integer id, HttpServletRequest request) throws NotifyException {
        UserAuthDataHandler.resolveAuthBaseData(notificationTemplatesDto, request);
        return notificationTemplateService.updateNotificationTemplate(notificationTemplatesDto,id);

    }

    @Override
    public ResponseDto deleteTemplate(Integer id, HttpServletRequest request) throws NotifyException {
        NotificationTemplatesDto notificationTemplatesDto=new NotificationTemplatesDto();
        notificationTemplatesDto.setId(id);
        UserAuthDataHandler.resolveAuthBaseData(notificationTemplatesDto, request);
        return notificationTemplateService.deleteTemplate(notificationTemplatesDto);
    }

    @Override
    public BaseListDto<? extends BaseDto> getAllNotifications(Integer page, Integer limit, String mode, String startDate, String endDate, String sortBy, String sortType, HttpServletRequest request) throws NotifyException {

        PaginationDto pageDto = new PaginationDto();
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);

        if(mode != null && mode.equalsIgnoreCase("sms")) {
            NotificationSmsDto smsDto = new NotificationSmsDto();
            smsDto.setMode(mode);
            smsDto.setStartDate(startDate);
            smsDto.setEndDate(endDate);
            smsDto.setPaginationDto(pageDto);
            UserAuthDataHandler.resolveAuthBaseData(smsDto, request);
            return notificationSmsService.getAllSmsNotification(smsDto);
        }else if(mode != null && mode.equalsIgnoreCase("email")){
            NotificationEmailDto emalDto = new NotificationEmailDto();
            emalDto.setMode(mode);
            emalDto.setStartDate(startDate);
            emalDto.setEndDate(endDate);
            emalDto.setPaginationDto(pageDto);
            UserAuthDataHandler.resolveAuthBaseData(emalDto, request);
            return notificationEmailService.getAllEmailNotification(emalDto);

        }else if(mode != null && mode.equalsIgnoreCase("push")){
            NotificationPushDto pushDto = new NotificationPushDto();
            pushDto.setMode(mode);
            pushDto.setStartDate(startDate);
            pushDto.setEndDate(endDate);
            pushDto.setPaginationDto(pageDto);
            UserAuthDataHandler.resolveAuthBaseData(pushDto, request);
            return notificationPushService.getAllPushNotification(pushDto);

        }else if(mode != null && mode.equalsIgnoreCase("inapp")){
            NotificationInAppDto inAppDto = new NotificationInAppDto();
            inAppDto.setMode(mode);
            inAppDto.setStartDate(startDate);
            inAppDto.setEndDate(endDate);
            inAppDto.setPaginationDto(pageDto);
            UserAuthDataHandler.resolveAuthBaseData(inAppDto, request);
            return notificationInAppService.getAllInAppNotification(inAppDto);

        }else{
            throw new NotifyException(NotifyException.MODE_NOT_VALID,HttpStatus.NOT_FOUND);
        }

    }

    @Override
    public BaseListDto<NotificationUserPreferenceDto> getAllPreferencesByUserName(String userName, HttpServletRequest request) throws NotifyException {
        NotificationUserPreferenceDto notificationUserPreferenceDto=new NotificationUserPreferenceDto();
        notificationUserPreferenceDto.setUserName(userName);
        UserAuthDataHandler.resolveAuthBaseData(notificationUserPreferenceDto, request);
        return notificationUserPreferenceService.getAllPreferencesByUserName(userName);
    }

    @Override
    public NotificationUserPreferenceDto updateUserPreferences(NotificationUserPreferenceDto notificationUserPreferenceDto, String userName, Integer eventId, HttpServletRequest request) throws NotifyException {
        UserAuthDataHandler.resolveAuthBaseData(notificationUserPreferenceDto, request);
        return notificationUserPreferenceService.updateUserPreferences(notificationUserPreferenceDto,userName,eventId);
    }

    @Override
    public NotificationUserPreferenceDto getUserSpecificPreferences(String userName, Integer eventId, HttpServletRequest request) throws NotifyException {
        NotificationUserPreferenceDto notificationUserPreferenceDto=new NotificationUserPreferenceDto();
        notificationUserPreferenceDto.setUserName(userName);
        UserAuthDataHandler.resolveAuthBaseData(notificationUserPreferenceDto, request);
        return notificationUserPreferenceService.getUserSpecificPreferences( userName,  eventId);
    }

    @Override
    public NotificationInAppDto updateNotificationInApp(NotificationInAppDto notificationInAppDto, Integer id, HttpServletRequest request) throws NotifyException {
        UserAuthDataHandler.resolveAuthBaseData(notificationInAppDto, request);
        return notificationInAppService.updateNotificationInApp(notificationInAppDto,id);
    }

    @Override
    public BaseListDto<NotificationInAppDto> getUserSpecificInAppNotification(String userName, Integer page, Integer limit, String mode,Integer  status, String startDate, String endDate, String sortBy, String sortType, HttpServletRequest request) throws NotifyException {
        PaginationDto pageDto = new PaginationDto();
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);

        NotificationInAppDto inAppDto = new NotificationInAppDto();
        inAppDto.setUserName(userName);
        inAppDto.setStatus(status);
        inAppDto.setMode(mode);
        inAppDto.setStartDate(startDate);
        inAppDto.setEndDate(endDate);
        inAppDto.setPaginationDto(pageDto);
        UserAuthDataHandler.resolveAuthBaseData(inAppDto, request);
        return notificationInAppService.getUserSpecificInAppNotification(inAppDto);
    }

    @Override
    public BaseListDto<NotificationUserPreferenceDto> updateUserPreferencesByUserId(NotificationUserPreferenceDto notificationUserPreferenceDto, String userId, HttpServletRequest request) throws NotifyException {
        UserAuthDataHandler.resolveAuthBaseData(notificationUserPreferenceDto, request);
        if(!notificationUserPreferenceDto.getAuthUserData().getUsername().equalsIgnoreCase(userId)){
            throw new NotifyException(NotifyException.UNAUTHORIZED_USER_ACCESS,HttpStatus.UNAUTHORIZED);
        }
        return notificationUserPreferenceService.updateUserPreferencesByUserId(notificationUserPreferenceDto,userId);
    }

}
