package com.imss.rc.notify.service;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.notify.constants.NotifyConstant;
import com.imss.rc.notify.dto.NotificationEventsDto;
import com.imss.rc.notify.dto.PreferencesDto;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.enums.AuditEnum;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.commons.constants.SortTypeConstants;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.ActionTypeEnum;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import com.imss.rc.notify.assembler.NotificationEventsAssembler;
import com.imss.rc.notify.dto.*;
import com.imss.rc.notify.entity.NotificationEventsEntity;

import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.repository.NotificationEventsRepository;
import com.imss.rc.notify.util.KafkaNotifySendMessage;
import com.imss.rc.notify.validation.NotifyValidation;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import java.util.Objects;

@Service
public class NotificationEventsServiceImpl implements NotificationEventsService{

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationEventsServiceImpl.class);
    @Autowired
    private NotificationEventsRepository notificationEventsRepository;
    @Autowired
    private NotifyValidation notifyValidation;
    @Autowired
    private NotificationEventsAssembler notificationEventsAssembler;
    @Autowired
    private EntityManager em;
    @Autowired
    KafkaNotifySendMessage sendData;
    @Override
    public NotificationEventsEntity findById(Integer id) {
        return notificationEventsRepository.getNotificationEvent(id);
    }

    @Override
    public NotificationEventsDto addNotificationEvent(NotificationEventsDto notificationEventsDto) throws NotifyException {
        NotificationEventsEntity notificationEventsEntity = new NotificationEventsEntity();
        AuditMasterDto auditMasterDto = new AuditMasterDto();
        try{

            if(notifyValidation.isUserOverrideValid(notificationEventsDto.getIsUserOverrideAllowed()) &&
                    notifyValidation.isNotifyEventValidCode(notificationEventsDto.getCode()) &&
                    notifyValidation.ispreferencesValid(notificationEventsDto.getPreferences()) &&
                    notifyValidation.isValidName(notificationEventsDto.getName()) &&
                    notifyValidation.isCategoryValid(notificationEventsDto.getCategoryId()))
            {
                ObjectMapper mapper = new ObjectMapper();
                notificationEventsEntity = notificationEventsAssembler.dtoToEntity(notificationEventsDto);
                UserAuthDataHandler.resolveEntityBaseData(notificationEventsDto, notificationEventsEntity);
                notificationEventsEntity.setIsDeleted((short) GlobalYesNoEnum.NO.getValue());
                notificationEventsEntity = notificationEventsRepository.save(notificationEventsEntity);
                notificationEventsAssembler.entityToDto(notificationEventsEntity);
                notificationEventsDto.setId(notificationEventsEntity.getId());
                notificationEventsDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                notificationEventsDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                notificationEventsDto.setPreferences(mapper.readValue(notificationEventsEntity.getPreferences(), PreferencesDto.class));
                notificationEventsDto.setResponseMessage(NotifyConstant.NOTIFICATION_EVENT_ADD_RESPONSE);

                         auditMasterDto.setEventId(AuditEnum.NOTIFICATION_EVENT.getValue());
                         auditMasterDto.setWhen(notificationEventsDto.getCreatedDate());
                         auditMasterDto.setReferenceId(String.valueOf(notificationEventsEntity.getId()));
                         auditMasterDto.setActionType(ActionTypeEnum.ADD.getValue());
                         auditMasterDto.setWho(notificationEventsDto.getCreatedBy());
                         auditMasterDto.setDescription(String.format(NotifyConstant.ADDED_NOTIFICATION_EVENT,notificationEventsDto.getName()));

            }else{
                throw new NotifyException(NotifyException.VALIDATION_FAILD,HttpStatus.BAD_REQUEST);
            }
        } catch (NotifyException ex) {
            throw ex;
        }catch (Exception ex) {
            LOGGER.error("Exception in addTemplate:", ex);
            throw new NotifyException(NotifyException.UNABLE_TO_ADD_NOTIFICATION_EVENT, HttpStatus.INTERNAL_SERVER_ERROR);

        }

         return notificationEventsDto;
    }

    @Override
    public NotificationEventsDto updateNotificationEvent(NotificationEventsDto notificationEventsDto, Integer id) throws NotifyException {

        AuditMasterDto auditMasterDto = new AuditMasterDto();
        try{
                NotificationEventsEntity notificationEventsEntity = notificationEventsRepository.getNotificationEvent(id);
                if (Objects.isNull(notificationEventsEntity)) {
                    throw new NotifyException(NotifyException.NO_RECORDS_FOUND, HttpStatus.NOT_FOUND);
                }
                if (notifyValidation.isUserOverrideValid(notificationEventsDto.getIsUserOverrideAllowed()) &&
                        notifyValidation.isValidCodeForUpdate(notificationEventsDto.getCode(),id) &&
                        notifyValidation.ispreferencesValid(notificationEventsDto.getPreferences()) &&
                        notifyValidation.isValidName(notificationEventsDto.getName()) &&
                        notifyValidation.isValidRowVersion(notificationEventsDto.getRowVersion()) &&
                        notifyValidation.isCategoryValid(notificationEventsDto.getCategoryId())) {
                    ObjectMapper mapper = new ObjectMapper();
                    JSONObject jsonObj = new JSONObject(notificationEventsDto);
                    UserAuthDataHandler.resolveEntityBaseData(notificationEventsDto, notificationEventsEntity);

                    notificationEventsEntity.setCode(notificationEventsDto.getCode());
                    notificationEventsEntity.setDescription(notificationEventsDto.getDescription());
                    notificationEventsEntity.setIsUserOverrideAllowed(notificationEventsDto.getIsUserOverrideAllowed());
                    notificationEventsEntity.setName(notificationEventsDto.getName());
                    notificationEventsEntity.setPreferences(jsonObj.getString(NotifyConstant.NOTIFY_JSON_PREFERENCE));
                    notificationEventsEntity.setRowVersion(notificationEventsDto.getRowVersion());
                    notificationEventsEntity = notificationEventsRepository.save(notificationEventsEntity);
                    notificationEventsAssembler.entityToDto(notificationEventsEntity);
                    notificationEventsDto.setId(notificationEventsEntity.getId());
                    notificationEventsDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                    notificationEventsDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                    notificationEventsDto.setPreferences(mapper.readValue(notificationEventsEntity.getPreferences(), PreferencesDto.class));
                    notificationEventsDto.setResponseMessage(NotifyConstant.NOTIFICATION_EVENT_UPDATE_RESPONSE);

                    auditMasterDto.setEventId(AuditEnum.NOTIFICATION_EVENT.getValue());
                    auditMasterDto.setWhen(notificationEventsDto.getModifiedDate());
                    auditMasterDto.setReferenceId(String.valueOf(notificationEventsEntity.getId()));
                    auditMasterDto.setActionType(ActionTypeEnum.UPDATE.getValue());
                    auditMasterDto.setWho(notificationEventsDto.getModifiedBy());
                    auditMasterDto.setDescription(String.format(NotifyConstant.UPDATED_NOTIFICATION_EVENT,notificationEventsDto.getName()));
                    sendData.sendMessage(auditMasterDto);
                }else{
                    throw new NotifyException(NotifyException.VALIDATION_FAILD,HttpStatus.BAD_REQUEST);
                }

        } catch (NotifyException ex) {
            throw ex;
        }catch (Exception ex) {
            LOGGER.error("Exception in update Template:", ex);
            throw new NotifyException(NotifyException.UNABLE_TO_UPDATE_NOTIFICATION_EVENT, HttpStatus.INTERNAL_SERVER_ERROR);

        }

        return notificationEventsDto;
    }

    @Override
    public NotificationEventsDto getNotificationEventById(NotificationEventsDto notificationEventsDto ) throws NotifyException {
        AuditMasterDto auditMasterDto = new AuditMasterDto();
        try{
            NotificationEventsEntity notificationEventsEntity = notificationEventsRepository.getNotificationEvent(notificationEventsDto.getId());
            if(Objects.isNull(notificationEventsEntity)){
                throw new NotifyException(NotifyException.NOTIFICATION_EVENT_NOT_FOUND,HttpStatus.NOT_FOUND);
            }

            notificationEventsDto = notificationEventsAssembler.entityToDto(notificationEventsEntity);
            notificationEventsDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            notificationEventsDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);

            auditMasterDto.setEventId(AuditEnum.NOTIFICATION_EVENT.getValue());
            auditMasterDto.setWhen(notificationEventsDto.getModifiedDate());
            auditMasterDto.setReferenceId(String.valueOf(notificationEventsDto.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(notificationEventsDto.getModifiedBy());
            auditMasterDto.setDescription(String.format(NotifyConstant.VIEW_NOTIFICATION_EVENT,notificationEventsDto.getName()));
            sendData.sendMessage(auditMasterDto);
            return notificationEventsDto;
        } catch (NotifyException ex) {
            throw ex;
        }
        catch (Exception ex) {
            LOGGER.error("Exception in getNotificationEventById:", ex);
            throw new NotifyException(NotifyException.NOTIFICATION_EVENT_NOT_FOUND,HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public IdDto deleteNotificationEvent(NotificationEventsDto notificationEventsDto) throws NotifyException {
        IdDto idDto= new IdDto();
        AuditMasterDto auditMasterDto = new AuditMasterDto();
        try {
            NotificationEventsEntity notificationEventsEntity  = notificationEventsRepository.getNotificationEvent(notificationEventsDto.getId());
            if(Objects.isNull(notificationEventsEntity)){
                throw new NotifyException(NotifyException.NOTIFICATION_EVENT_NOT_FOUND,HttpStatus.NOT_FOUND);
            }
            notificationEventsEntity.setIsDeleted((short) GlobalYesNoEnum.YES.getValue());
            UserAuthDataHandler.resolveEntityBaseData(notificationEventsDto, notificationEventsEntity);
            notificationEventsRepository.save(notificationEventsEntity);
            idDto.setId(notificationEventsDto.getId());

            auditMasterDto.setEventId(AuditEnum.NOTIFICATION_EVENT.getValue());
            auditMasterDto.setWhen(notificationEventsDto.getModifiedDate());
            auditMasterDto.setReferenceId(String.valueOf(notificationEventsEntity.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.DELETE.getValue());
            auditMasterDto.setWho(notificationEventsDto.getModifiedBy());
            auditMasterDto.setDescription(String.format(NotifyConstant.DELETED_NOTIFICATION_EVENT,notificationEventsEntity.getName()));
            sendData.sendMessage(auditMasterDto);
            return idDto;
        } catch (NotifyException ex) {
            throw ex;
        }
        catch (Exception ex) {
            LOGGER.error("Exception in deleteTemplate:", ex);
            throw new NotifyException(NotifyException.NOTIFICATION_EVENT_NOT_DELETED,HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public BaseListDto<NotificationEventsDto> getAllNotificationEvents(NotificationEventsDto dto) throws NotifyException {
        BaseListDto<NotificationEventsDto> eventsDtoList = new  BaseListDto<>();
        AuditMasterDto auditMasterDto = new AuditMasterDto();
        try{
            if(Objects.isNull(dto.getPaginationDto().getSortType()) || dto.getPaginationDto().getSortType().isEmpty()){
                dto.getPaginationDto().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }

            if(Objects.isNull(dto.getPaginationDto().getSortBy()) || dto.getPaginationDto().getSortBy().isEmpty()){
                dto.getPaginationDto().setSortBy(NotifyConstant.SORT_BY_NAME);
                dto.getPaginationDto().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }
            PageableEntity<NotificationEventsEntity> data = notificationEventsRepository.getAllNotificationEventsWithFilters(em,dto);
            PaginationDto pageDto = dto.getPaginationDto();
            pageDto.setCount(data.getCount());

            eventsDtoList.setPagination(pageDto);
            eventsDtoList.setDataList(notificationEventsAssembler.entityListToDtoList(data.getData()));
            eventsDtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            eventsDtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            eventsDtoList.setAuditEventId(AuditEnum.NOTIFICATION_EVENT.getValue());

            auditMasterDto.setEventId(AuditEnum.NOTIFICATION_EVENT.getValue());
            auditMasterDto.setWhen(dto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(dto.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(dto.getCreatedBy());
            auditMasterDto.setDescription(String.format(NotifyConstant.VIEW_ALL_NOTIFICATION_EVENT,
                    eventsDtoList.getPagination().getPage(),
                    eventsDtoList.getPagination().getLimit(),
                    eventsDtoList.getPagination().getSortBy(),
                    eventsDtoList.getPagination().getSortType(),
                    eventsDtoList.getPagination().getCount()));
            sendData.sendMessage(auditMasterDto);
            return eventsDtoList;

        }catch (NotifyException ex) {
            throw ex;
        } catch (Exception ex) {
            LOGGER.error("Exception in getAllNotificationEvents:", ex);
            throw new NotifyException(NotifyException.NOTIFICATION_EVENTS_LIST_NOT_RETRIEVED, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }


}
