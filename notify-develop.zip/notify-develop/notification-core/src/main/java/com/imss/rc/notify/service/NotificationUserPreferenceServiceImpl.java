package com.imss.rc.notify.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.enums.AuditEnum;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.enums.ActionTypeEnum;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import com.imss.rc.notify.assembler.NotificationUserPreferenceAssembler;
import com.imss.rc.notify.constants.NotifyConstant;
import com.imss.rc.notify.dto.NotificationUserPreferenceDto;
import com.imss.rc.notify.dto.PreferencesDto;
import com.imss.rc.notify.entity.NotificationEventsEntity;
import com.imss.rc.notify.entity.NotificationUserPreferenceEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.repository.NotificationEventsRepository;
import com.imss.rc.notify.repository.NotificationUserPreferenceRepository;
import com.imss.rc.notify.util.AuditConstants;
import com.imss.rc.notify.util.KafkaNotifySendMessage;
import com.imss.rc.notify.validation.NotifyValidation;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class NotificationUserPreferenceServiceImpl implements NotificationUserPreferenceService{

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationUserPreferenceServiceImpl.class);

    @Autowired
    private NotificationUserPreferenceRepository notificationUserPreferenceRepository;

    @Autowired
    private NotificationEventsRepository notificationEventsRepository;

    @Autowired
    private NotificationUserPreferenceAssembler notificationUserPreferenceAssembler;

    @Autowired
    private NotifyValidation notifyValidation;

    @Autowired
    KafkaNotifySendMessage sendData;


    @Override
    public BaseListDto<NotificationUserPreferenceDto> getAllPreferencesByUserName(String userName) throws NotifyException {
        BaseListDto<NotificationUserPreferenceDto> userPreferenceDtoList = new  BaseListDto<>();
        ObjectMapper mapper = new ObjectMapper();
        try{
            List<NotificationUserPreferenceEntity> notificationUserPreferenceEntityList = notificationUserPreferenceRepository.findAllByUserName(userName);
            if(Objects.isNull(notificationUserPreferenceEntityList) || notificationUserPreferenceEntityList.isEmpty()){
                throw new NotifyException(NotifyException.USER_PREFERENCE_LIST_NOT_FOUND, HttpStatus.NOT_FOUND);
            }

            userPreferenceDtoList.setDataList(notificationUserPreferenceAssembler.entityListToDtoList(notificationUserPreferenceEntityList));
            for(int i=0; i<userPreferenceDtoList.getDataList().size(); i++){
                userPreferenceDtoList.getDataList().get(i).setPreferences(mapper.readValue(notificationUserPreferenceEntityList.get(i).getPreferences(), PreferencesDto.class));
            }
            userPreferenceDtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            userPreferenceDtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            return userPreferenceDtoList;
        } catch (NotifyException ex) {
            throw ex;
        }
        catch (Exception ex) {
            LOGGER.error("Exception in getAllPreferencesByUserName:", ex);
            throw new NotifyException(NotifyException.USER_PREFERENCE_LIST_NOT_FOUND,HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public NotificationUserPreferenceDto updateUserPreferences(NotificationUserPreferenceDto notificationUserPreferenceDto,String userName, Integer eventId) {
        ObjectMapper mapper = new ObjectMapper();
        AuditMasterDto auditMasterDto = new AuditMasterDto();
        JSONObject jsonObj = new JSONObject(notificationUserPreferenceDto);
        NotificationUserPreferenceEntity newNotificationUserPreferenceEntity = new NotificationUserPreferenceEntity();
        try{
            if(notifyValidation.ispreferencesValid(notificationUserPreferenceDto.getPreferences())) {

                NotificationUserPreferenceEntity notificationUserPreferenceEntity = notificationUserPreferenceRepository.getUser(userName,eventId);
                if (Objects.nonNull(notificationUserPreferenceEntity) && notificationUserPreferenceEntity.getIsDeleted()==GlobalYesNoEnum.NO.getValue()) {
                    UserAuthDataHandler.resolveEntityBaseData(notificationUserPreferenceDto, notificationUserPreferenceEntity);

                    notificationUserPreferenceEntity.setPreferences(jsonObj.getString(NotifyConstant.NOTIFY_JSON_PREFERENCE));
                    notificationUserPreferenceEntity = notificationUserPreferenceRepository.save(notificationUserPreferenceEntity);
                    notificationUserPreferenceAssembler.entityToDto(notificationUserPreferenceEntity);
                    notificationUserPreferenceDto.setId(notificationUserPreferenceEntity.getId());
                    notificationUserPreferenceDto.setPreferences(mapper.readValue(notificationUserPreferenceEntity.getPreferences(), PreferencesDto.class));
                    notificationUserPreferenceDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                    notificationUserPreferenceDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                    notificationUserPreferenceDto.setResponseMessage(NotifyConstant.NOTIFY_UPDATE_RESPONSE);

                    auditMasterDto.setEventId(AuditConstants.USER_PREFERENCE_NOTIFICATION);
                    auditMasterDto.setWhen(notificationUserPreferenceDto.getModifiedDate());
                    auditMasterDto.setReferenceId(String.valueOf(notificationUserPreferenceDto.getId()));
                    auditMasterDto.setActionType(ActionTypeEnum.UPDATE.getValue());
                    auditMasterDto.setWho(notificationUserPreferenceDto.getModifiedBy());
                    auditMasterDto.setDescription(String.format(NotifyConstant.UPDATED_NOTIFY_USER_PREFERENCE,notificationUserPreferenceDto.getEventName()));
                    sendData.sendMessage(auditMasterDto);
                    return notificationUserPreferenceDto;
                }else{
                    NotificationEventsEntity notificationEventsEntity = notificationEventsRepository.getNotificationEvent(eventId);
                    if(notificationEventsEntity.getIsUserOverrideAllowed()==GlobalYesNoEnum.YES.getValue()){
                        newNotificationUserPreferenceEntity.setEventId(eventId);
                        newNotificationUserPreferenceEntity.setUserName(userName);
                        newNotificationUserPreferenceEntity.setPreferences(jsonObj.getString(NotifyConstant.NOTIFY_JSON_PREFERENCE));
                        UserAuthDataHandler.resolveEntityBaseData(notificationUserPreferenceDto, newNotificationUserPreferenceEntity);

                        newNotificationUserPreferenceEntity.setIsDeleted((short) GlobalYesNoEnum.NO.getValue());
                        newNotificationUserPreferenceEntity = notificationUserPreferenceRepository.save(newNotificationUserPreferenceEntity);
                        notificationUserPreferenceAssembler.entityToDto(newNotificationUserPreferenceEntity);
                        notificationUserPreferenceDto.setPreferences(mapper.readValue(newNotificationUserPreferenceEntity.getPreferences(), PreferencesDto.class));
                        notificationUserPreferenceDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                        notificationUserPreferenceDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                        notificationUserPreferenceDto.setResponseMessage(NotifyConstant.NOTIFY_ADDED_RESPONSE);

                        auditMasterDto.setEventId(AuditEnum.USER_PREFERENCE_NOTIFICATION.getValue());
                        auditMasterDto.setWhen(notificationUserPreferenceDto.getModifiedDate());
                        auditMasterDto.setReferenceId(String.valueOf(newNotificationUserPreferenceEntity.getId()));
                        auditMasterDto.setActionType(ActionTypeEnum.UPDATE.getValue());
                        auditMasterDto.setWho(notificationUserPreferenceDto.getModifiedBy());
                        auditMasterDto.setDescription(String.format(NotifyConstant.ADDED_NOTIFY_USER_PREFERENCE,notificationUserPreferenceDto.getEventName()));
                        sendData.sendMessage(auditMasterDto);
                    }else{
                        throw new NotifyException(NotifyException.USER_OVERRIDE_NOT_ALLOWED, HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                }
            }else{
                throw new NotifyException(NotifyException.VALIDATION_FAILD,HttpStatus.BAD_REQUEST);
            }

        }catch (NotifyException ex) {
            throw ex;

        }
        catch (Exception e) {
            LOGGER.error("Exception in updateUserPreferences:", e);
            throw new NotifyException(NotifyException.USER_OVERRIDE_NOT_ALLOWED,HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return notificationUserPreferenceDto;

    }

    @Override
    public NotificationUserPreferenceDto getUserSpecificPreferences(String userName, Integer eventId) {

        NotificationUserPreferenceDto notificationUserPreferenceDto;
        ObjectMapper mapper = new ObjectMapper();
        try {
            NotificationUserPreferenceEntity notificationUserPreferenceEntity = notificationUserPreferenceRepository.getUser(userName,eventId);
            if (Objects.isNull(notificationUserPreferenceEntity) || notificationUserPreferenceEntity.getIsDeleted() == GlobalYesNoEnum.YES.getValue()) {
                throw new NotifyException(NotifyException.EVENT_SPECIFIC_USER_PREFERENCE_NOT_FOUND, HttpStatus.NOT_FOUND);
            }

            notificationUserPreferenceDto=notificationUserPreferenceAssembler.entityToDto(notificationUserPreferenceEntity);
            notificationUserPreferenceDto.setId(notificationUserPreferenceEntity.getId());
            notificationUserPreferenceDto.setPreferences(mapper.readValue(notificationUserPreferenceEntity.getPreferences(), PreferencesDto.class));
            notificationUserPreferenceDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            notificationUserPreferenceDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            return notificationUserPreferenceDto;
        } catch (NotifyException ex) {
            throw ex;
        } catch (Exception ex) {
            LOGGER.error("Exception in getUserSpecificPreferences:", ex);
            throw new NotifyException(NotifyException.EVENT_SPECIFIC_USER_PREFERENCE_NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

    @Override
    public BaseListDto<NotificationUserPreferenceDto> updateUserPreferencesByUserId(NotificationUserPreferenceDto notificationUserPreferenceDto, String userId) {
        ObjectMapper mapper = new ObjectMapper();
        AuditMasterDto auditMasterDto = new AuditMasterDto();
        BaseListDto<NotificationUserPreferenceDto> notificationUserPreferenceDtoList=new BaseListDto<>();
        List<NotificationUserPreferenceDto> userPreferenceDtoList = new ArrayList<>();
        NotificationUserPreferenceDto dto;
        try{
            List<NotificationUserPreferenceEntity> notificationUserPreferenceEntityList = notificationUserPreferenceRepository.findAllByUserName(userId);
            if (Objects.isNull(notificationUserPreferenceEntityList)||notificationUserPreferenceEntityList.size()<GlobalYesNoEnum.YES.getValue()) {
                throw new NotifyException(NotifyException.USER_PREFERENCE_LIST_NOT_FOUND,HttpStatus.BAD_REQUEST);
            }
            for(NotificationUserPreferenceEntity notificationUserPreferenceEntity:notificationUserPreferenceEntityList) {
                dto=new NotificationUserPreferenceDto();
                dto.setPreferences(mapper.readValue(notificationUserPreferenceEntity.getPreferences(), PreferencesDto.class));
                if(Objects.isNull(notificationUserPreferenceDto.getPreferences().getSms())|| StringUtils.isEmpty(notificationUserPreferenceDto.getPreferences().getSms())){
                    notificationUserPreferenceDto.getPreferences().setSms(dto.getPreferences().getSms());
                }
                if(Objects.isNull(notificationUserPreferenceDto.getPreferences().getEmail())|| StringUtils.isEmpty(notificationUserPreferenceDto.getPreferences().getEmail())){
                    notificationUserPreferenceDto.getPreferences().setEmail(dto.getPreferences().getEmail());
                }
                if(Objects.isNull(notificationUserPreferenceDto.getPreferences().getInapp())|| StringUtils.isEmpty(notificationUserPreferenceDto.getPreferences().getInapp())){
                    notificationUserPreferenceDto.getPreferences().setInapp(dto.getPreferences().getInapp());
                }
                if(Objects.isNull(notificationUserPreferenceDto.getPreferences().getPush())|| StringUtils.isEmpty(notificationUserPreferenceDto.getPreferences().getPush())){
                    notificationUserPreferenceDto.getPreferences().setPush(dto.getPreferences().getPush());
                }
                if (notifyValidation.ispreferencesValid(notificationUserPreferenceDto.getPreferences())) {
                    if(notificationUserPreferenceEntity.getEventIdObj().getIsUserOverrideAllowed()==GlobalYesNoEnum.YES.getValue()) {
                        UserAuthDataHandler.resolveEntityBaseData(notificationUserPreferenceDto, notificationUserPreferenceEntity);
                        JSONObject jsonObj = new JSONObject(notificationUserPreferenceDto);
                        notificationUserPreferenceEntity.setPreferences(jsonObj.getString(NotifyConstant.NOTIFY_JSON_PREFERENCE));
                        notificationUserPreferenceEntity = notificationUserPreferenceRepository.save(notificationUserPreferenceEntity);
                        dto=notificationUserPreferenceAssembler.entityToDto(notificationUserPreferenceEntity);
                        dto.setId(notificationUserPreferenceEntity.getId());
                        dto.setPreferences(mapper.readValue(notificationUserPreferenceEntity.getPreferences(), PreferencesDto.class));
                        userPreferenceDtoList.add(dto);
                        notificationUserPreferenceDtoList.setDataList(userPreferenceDtoList);


                        auditMasterDto.setEventId(AuditConstants.USER_PREFERENCE_NOTIFICATION);
                        auditMasterDto.setWhen(notificationUserPreferenceDto.getModifiedDate());
                        auditMasterDto.setReferenceId(String.valueOf(notificationUserPreferenceDto.getId()));
                        auditMasterDto.setActionType(ActionTypeEnum.UPDATE.getValue());
                        auditMasterDto.setWho(notificationUserPreferenceDto.getModifiedBy());
                        auditMasterDto.setDescription(String.format(NotifyConstant.UPDATED_NOTIFY_USER_PREFERENCE, notificationUserPreferenceDto.getEventName()));
                        sendData.sendMessage(auditMasterDto);
                    }

                } else {
                    throw new NotifyException(NotifyException.VALIDATION_FAILD, HttpStatus.BAD_REQUEST);
                }
            }
            notificationUserPreferenceDtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            notificationUserPreferenceDtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            notificationUserPreferenceDtoList.setResponseMessage(NotifyConstant.NOTIFY_UPDATE_RESPONSE);
            return notificationUserPreferenceDtoList;
        }catch (NotifyException ex) {
            throw ex;
        }
        catch (Exception e) {
            LOGGER.error("Exception in updateUserPreferences:", e);
            throw new NotifyException(NotifyException.USER_OVERRIDE_NOT_ALLOWED,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
