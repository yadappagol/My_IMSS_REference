package com.imss.rc.notify.constants;

public class NotifyConstant {

    public static final String SORT_BY_NAME = "name";
    public static final String NAME_REGEX = "^(?![0-9]*$)[a-zA-Z0-9]+$";
    public static final String TEMPLATE_REGEX = "^(s*[A-Za-z0-9]{1,}[.]{0,1}[A-Za-z0-9]{1,}s*)+$";
    public static final String SMS_MODE = "sms";
    public static final String INAPP_MODE = "inapp";
    public static final String PUSH_MODE = "push";
    public static final String EMAIL_MODE = "email";
    public static final String YES = "Y";
    public static final String NO = "N";
    public static final int LENGTH_ZERO = 0;
    public static final Integer ZERO =0;
    public static final int LENGTH_FIFTY = 50;
    public static final short TYPE_ZERO = 0;
    public static final short TYPE_ONE = 1;
    public static final short TYPE_THREE = 3;
    public static final String SENT = "sent";
    public static final String COUNT = "cnt";
    public static final String Detail = "det";
    public static final String SORT_BY_CREATED = "created";
    public static final String NOTIFY_JSON_PREFERENCE = "preferences";
    public static final String UPDATED_NOTIFY_USER_PREFERENCE = "Update a User preference Notification %s";
    public static final String NOTIFY_JSON_TEMPLATE = "template";
    public static final String NOTIFICATION_TEMPLATE_UPDATE_RESPONSE = "Notification Template is Updated successfully";
    public static final String DELETED_NOTIFICATION_EVENT = "Deleted Notification Events %s";
    public static final String ADDED_NOTIFY_USER_PREFERENCE = "Added a User preference Notification %s";
    public static final String ADDED_NOTIFICATION_EVENT = "Added Notification Events %s";
    public static final String DELETED_NOTIFICATION_TEMPLATE = "Deleted Notification Template %s";
    public static final String VIEW_NOTIFICATION_TEMPLATE = "View Notification Template %s";
    public static final String VIEW_ALL_NOTIFICATION_TEMPLATE = "Retrieved page %s with limit of %s records of notification templates list sorted by %s in %s order, total of %s records were found.";
    public static final String ADDED_NOTIFICATION_TEMPLATE = "Added Notification Template %s";
    public static final String UPDATED_NOTIFICATION_TEMPLATE = "Updated Notification Template %s";
    public static final String NOTIFICATION_EVENT_ADD_RESPONSE = "Notification Event is Added Successfully ";
    public static final String NOTIFICATION_TEMPLATE_ADD_RESPONSE = "Notification Template is Added Successfully ";
    public static final String NOTIFY_UPDATE_RESPONSE = "Notification User Preference is Updated successfully";
    public static final String NOTIFY_ADDED_RESPONSE = "Notification User Preference is Added successfully";
    public static final String NOTIFICATION_EVENT_UPDATE_RESPONSE = "Notification Event is Updated Successfully ";
    public static final String UPDATED_NOTIFICATION_EVENT = "Updated Notification Events %s";
    public static final String VIEW_NOTIFICATION_EVENT = "View Notification Event %s";
    public static final String VIEW_ALL_NOTIFICATION_EVENT = "Retrieved page %s with limit of %s records of notification events list sorted by %s in %s order, total of %s records were found.";
    public static final String VIEW_ALL_NOTIFICATION_INAPP_RESPONSE = "List of Notification In App Retrieved successfully";
    public static final String NOTIFICATION_INAPP_UPDATE_RESPONSE = "Notification In App Updated successfully";
    public static final String NOTIFICATION_SMS_RESPONSE = "Notification SMS Retrieved successfully";
    public static final String NOTIFICATION_EMAIL_RESPONSE = "Notification Email Retrieved successfully";
    public static final String VIEW_ALL_NOTIFICATION_EMAIL_RESPONSE = "List of Notification Email Retrieved successfully";
    public static final String UPDATED_NOTIFICATION_INAPP = "Updated Notification Events %s";
    public static final String NOTIFICATION_SENT = "Notification Sent to all user successfully";
    private  NotifyConstant(){
    }

}
