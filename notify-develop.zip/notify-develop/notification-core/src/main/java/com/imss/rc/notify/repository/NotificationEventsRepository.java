package com.imss.rc.notify.repository;

import com.imss.rc.notify.assembler.NotificationEventsAssembler;
import com.imss.rc.notify.dto.NotificationEventsDto;
import com.imss.rc.notify.entity.NotificationEventsEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.commons.entity.BaseEntity;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Transactional
@Repository
public interface NotificationEventsRepository  extends JpaRepository<NotificationEventsEntity, Integer> {

    @Query(value="from NotificationEventsEntity ne where ne.isDeleted=0 and ne.code= :code")
    public NotificationEventsEntity getByCode(@Param("code") String code);

    @Query(value="from NotificationEventsEntity ne where ne.isDeleted=0 and ne.id= :id")
    public NotificationEventsEntity getNotificationEvent(@Param("id") Integer id);

    default PageableEntity<NotificationEventsEntity> getAllNotificationEventsWithFilters(EntityManager em, NotificationEventsDto notificationEventsDto) throws NotifyException {

        PageableEntity<NotificationEventsEntity> retData = new PageableEntity<>();

        List<Predicate> predicateList = new ArrayList<>();
        CriteriaBuilder criteriaBuilder ;
        Root<NotificationEventsEntity> notificationEventsRoot ;

        /** This is to get the count of records */
        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        notificationEventsRoot = countQuery.from(NotificationEventsEntity.class);

        predicateList = applySearchFilters(criteriaBuilder, predicateList, notificationEventsRoot, notificationEventsDto);

        countQuery.select(criteriaBuilder.count(notificationEventsRoot));
        countQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));
        long count = em.createQuery(countQuery).getSingleResult();
        retData.setCount(count);
        /***********************************/


        /** This is to get the list based on the page and limit *******/

        //Clear out the predicateList created using the count root
        predicateList.clear();

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<NotificationEventsEntity> listCriteriaQuery = criteriaBuilder.createQuery(NotificationEventsEntity.class);

        notificationEventsRoot = listCriteriaQuery.from(NotificationEventsEntity.class);

        listCriteriaQuery.select(notificationEventsRoot);
        predicateList = applySearchFilters(criteriaBuilder, predicateList, notificationEventsRoot, notificationEventsDto);

        listCriteriaQuery.where( criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));

        String sortByColumn = NotificationEventsAssembler.getSortByColumn(notificationEventsDto.getPaginationDto().getSortBy());

        Order order;
        if("asc".equals( notificationEventsDto.getPaginationDto().getSortType())){
            order = criteriaBuilder.asc(notificationEventsRoot.get(sortByColumn));
        } else {
            order = criteriaBuilder.desc(notificationEventsRoot.get(sortByColumn));
        }

        TypedQuery<NotificationEventsEntity> query = em.createQuery(listCriteriaQuery.orderBy(order))
                .setFirstResult((notificationEventsDto.getPaginationDto().getPage() - 1) * notificationEventsDto.getPaginationDto().getLimit())
                .setMaxResults(notificationEventsDto.getPaginationDto().getLimit());
        retData.setData(query.getResultList());
        /***********************************/


        return retData;
    }



    default List<Predicate> applySearchFilters(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Root<NotificationEventsEntity> notificationRoot,
                                               NotificationEventsDto notificationEventsDto) throws NotifyException {


        predicateList.add(criteriaBuilder.equal(notificationRoot.get(BaseEntity.COLUMN_NAME_IS_DELETED), GlobalYesNoEnum.NO.getValue()));
        //Adding filter for Notification event name if present
        if (Optional.ofNullable(notificationEventsDto.getName()).isPresent() && !notificationEventsDto.getName().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.like(criteriaBuilder.upper(notificationRoot.get(NotificationEventsEntity.COLUMN_NAME_BY_NAME)), "%" + notificationEventsDto.getName().toUpperCase() + "%"));
        }
        //Adding filter for code if present
        if (Optional.ofNullable(notificationEventsDto.getCode()).isPresent() && !notificationEventsDto.getCode().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.like(criteriaBuilder.upper(notificationRoot.get(NotificationEventsEntity.COLUMN_NAME_CODE)), "%" + notificationEventsDto.getCode().toUpperCase() + "%"));
        }
        if (Optional.ofNullable(notificationEventsDto.getIsUserOverrideAllowed()).isPresent()) {
            predicateList.add(criteriaBuilder.equal(notificationRoot.get(NotificationEventsEntity.COLUMN_NAME_IS_USER_OVERRIDE_ALLOWED), notificationEventsDto.getIsUserOverrideAllowed()));
        }
        if (Optional.ofNullable(notificationEventsDto.getCategoryId()).isPresent() && notificationEventsDto.getCategoryId() != GlobalYesNoEnum.NO.getValue()) {
            predicateList.add(criteriaBuilder.equal(notificationRoot.get(NotificationEventsEntity.COLUMN_NAME_CATEGORY_ID), notificationEventsDto.getCategoryId()));
        }
        if (Optional.ofNullable(notificationEventsDto.getDescription()).isPresent() && !notificationEventsDto.getDescription().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.like(criteriaBuilder.upper(notificationRoot.get(NotificationEventsEntity.COLUMN_NAME_DESCRIPTION)), "%" + notificationEventsDto.getDescription().toUpperCase() + "%"));
        }

        return predicateList;
    }

}
