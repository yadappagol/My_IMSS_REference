package com.imss.rc.notify.service;

import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.notify.dto.NotificationInAppDto;
import com.imss.rc.notify.exception.NotifyException;

public interface NotificationInAppService {
   public BaseListDto<NotificationInAppDto> getAllInAppNotification(NotificationInAppDto inAppDto) throws NotifyException;

   public NotificationInAppDto updateNotificationInApp(NotificationInAppDto notificationInAppDto, Integer id);

   public BaseListDto<NotificationInAppDto> getUserSpecificInAppNotification(NotificationInAppDto dto);
}
