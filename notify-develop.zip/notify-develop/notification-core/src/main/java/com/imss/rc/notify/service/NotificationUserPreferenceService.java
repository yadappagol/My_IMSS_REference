package com.imss.rc.notify.service;

import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.notify.dto.NotificationUserPreferenceDto;
import com.imss.rc.notify.exception.NotifyException;

public interface NotificationUserPreferenceService {
    public BaseListDto<NotificationUserPreferenceDto> getAllPreferencesByUserName(String userName) throws NotifyException;

    public NotificationUserPreferenceDto updateUserPreferences(NotificationUserPreferenceDto notificationUserPreferenceDto,String userName, Integer eventId);

    public NotificationUserPreferenceDto getUserSpecificPreferences(String userName, Integer eventId);

    public BaseListDto<NotificationUserPreferenceDto> updateUserPreferencesByUserId(NotificationUserPreferenceDto notificationUserPreferenceDto, String userId);
}
