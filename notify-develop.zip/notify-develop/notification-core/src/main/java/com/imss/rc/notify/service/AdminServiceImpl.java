package com.imss.rc.notify.service;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.imss.rc.notify.constants.NotifyConstant;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.notify.dto.NotificationRequestsDto;
import com.imss.rc.notify.dto.SendNotificationDto;
import com.imss.rc.notify.enums.NotifyRequestModeTypeEnum;
import com.imss.rc.notify.exception.NotifyException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class AdminServiceImpl implements AdminService{

    private static final Logger LOGGER = LoggerFactory.getLogger(AdminServiceImpl.class);

    @Value("${admin.templatecode}")
    private String templateCode;

    @Autowired
    KafkaSender kafkaSender;

    @Override
    public ResponseDto sendNotification(SendNotificationDto sendNotificationDto) {
        ResponseDto responseDto=new ResponseDto();
        NotificationRequestsDto notificationRequestsDto=new NotificationRequestsDto();
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        SendNotificationDto sendNotificationDto1=new SendNotificationDto();

        try{

            sendNotificationDto1.setMessage(sendNotificationDto.getMessage());
            sendNotificationDto1.setSubject(sendNotificationDto.getSubject());
            sendNotificationDto1.setTitle(sendNotificationDto.getTitle());
            String json = ow.writeValueAsString(sendNotificationDto1);
            for(int i = 0; i<sendNotificationDto.getUsers().length; i++) {
                notificationRequestsDto.setUserName(sendNotificationDto.getUsers()[i]);
                notificationRequestsDto.setPayload(json);

                notificationRequestsDto.setMode(sendNotificationDto.getMode());
                notificationRequestsDto.setRequestModeType(NotifyRequestModeTypeEnum.SPECIFIC.getValue());
                notificationRequestsDto.setReceivedDate(new Date());
                notificationRequestsDto.setTemplateCode(templateCode);
                try {
                    kafkaSender.sendData(notificationRequestsDto);
                } catch (Exception e) {
                    LOGGER.error("Couldn't send message");
                }

            }
            responseDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            responseDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            responseDto.setResponseMessage(NotifyConstant.NOTIFICATION_SENT);
            return responseDto;
        } catch (NotifyException ex) {
            throw ex;
        }catch (Exception ex) {
            LOGGER.error("Exception in addTemplate:", ex);
            throw new NotifyException(NotifyException.UNABLE_TO_ADD_NOTIFICATION_EVENT, HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }
}
