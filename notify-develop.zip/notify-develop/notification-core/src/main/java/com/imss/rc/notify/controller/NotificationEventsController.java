package com.imss.rc.notify.controller;

import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.notify.dto.NotificationEventsDto;
import com.imss.rc.notify.exception.NotifyException;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

public interface NotificationEventsController {

    @PostMapping(value = "/notify/events",consumes = "application/json", produces = "application/json")
    public NotificationEventsDto addNotificationEvent(@RequestBody NotificationEventsDto notificationEventsDto, HttpServletRequest request)throws NotifyException;

    @PutMapping(value = "/notify/events/{id}",consumes = "application/json", produces = "application/json")
    public NotificationEventsDto updateNotificationEvent(@RequestBody NotificationEventsDto notificationEventsDto, @PathVariable("id") Integer id, HttpServletRequest request)throws NotifyException;

    @GetMapping(value = "/notify/events/{id}",consumes = "application/json", produces = "application/json")
    public NotificationEventsDto getNotificationEventById(@PathVariable("id") Integer id, HttpServletRequest request)throws NotifyException;

    @DeleteMapping(value = "/notify/events/{id}",consumes = "application/json", produces = "application/json")
    public IdDto deleteNotificationEvent(@PathVariable("id") Integer id, HttpServletRequest request)throws NotifyException;

    @GetMapping(value = "/notify/events",consumes = "application/json", produces = "application/json")
    public BaseListDto<NotificationEventsDto> getAllNotificationEvents(@RequestParam Integer page, @RequestParam Integer limit,
                                                                       @RequestParam(required = false) String sortBy,
                                                                       @RequestParam(required = false) String name,
                                                                       @RequestParam(required = false) String code,
                                                                       @RequestParam(required = false) Short isUserOverrideAllowed,
                                                                       @RequestParam(required = false) String sortType,
                                                                       @RequestParam(required = false) Integer categoryId,
                                                                       @RequestParam(required = false) String description,
                                                                       HttpServletRequest request)throws NotifyException;
}
