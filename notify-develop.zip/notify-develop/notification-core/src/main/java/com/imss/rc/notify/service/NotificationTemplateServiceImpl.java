package com.imss.rc.notify.service;



import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.notify.constants.NotifyConstant;
import com.imss.rc.notify.dto.NotificationTemplatesDto;
import com.imss.rc.notify.dto.TemplateDto;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.enums.AuditEnum;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.commons.constants.SortTypeConstants;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.ActionTypeEnum;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import com.imss.rc.notify.assembler.NotificationTemplatesAssembler;
import com.imss.rc.notify.dto.*;

import com.imss.rc.notify.entity.NotificationTemplatesEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.repository.NotificationTemplateRepository;

import com.imss.rc.notify.util.KafkaNotifySendMessage;
import com.imss.rc.notify.validation.NotifyValidation;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
public class NotificationTemplateServiceImpl implements NotificationTemplateService{

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationTemplateServiceImpl.class);
    @Autowired
    private NotificationTemplateRepository notificationTemplateRepository;
    @Autowired
    private NotificationEventsService notificationEventsService;
    @Autowired
    private NotificationTemplatesAssembler notificationTemplatesAssembler;
    @Autowired
    private EntityManager em;
    @Autowired
    private NotifyValidation notifyValidation;
    @Autowired
    KafkaNotifySendMessage sendData;


    @Override
    public NotificationTemplatesDto addTemplate(NotificationTemplatesDto notificationTemplatesDto) throws NotifyException{

        NotificationTemplatesEntity notificationTemplateEntity = new NotificationTemplatesEntity();
        try{
            Date date =new Date();
            AuditMasterDto auditMasterDto = new AuditMasterDto();
            if(notifyValidation.isValidEventId(notificationTemplatesDto.getEventId()) &&
                    notifyValidation.isValidCode(notificationTemplatesDto.getCode()) &&
                    notifyValidation.isValidType(notificationTemplatesDto.getType()) &&
                    notifyValidation.isValidName(notificationTemplatesDto.getName()) &&
                    notifyValidation.isValidTemplate(notificationTemplatesDto.getTemplate())) {
                ObjectMapper mapper = new ObjectMapper();
                JSONObject jsonObj = new JSONObject(notificationTemplatesDto);
                notificationTemplateEntity = notificationTemplatesAssembler.dtoToEntity(notificationTemplatesDto);
                UserAuthDataHandler.resolveEntityBaseData(notificationTemplatesDto, notificationTemplateEntity);

                notificationTemplateEntity.setIsDeleted((short) GlobalYesNoEnum.NO.getValue());
                notificationTemplateEntity.setTemplate(jsonObj.getString("template"));
                notificationTemplateEntity = notificationTemplateRepository.save(notificationTemplateEntity);
                notificationTemplatesAssembler.entityToDto(notificationTemplateEntity);
                notificationTemplatesDto.setId(notificationTemplateEntity.getId());
                notificationTemplatesDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                notificationTemplatesDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                notificationTemplatesDto.setTemplate(mapper.readValue(notificationTemplateEntity.getTemplate(), new TypeReference<List<TemplateDto>>() {}));
                notificationTemplatesDto.setResponseMessage(NotifyConstant.NOTIFICATION_TEMPLATE_ADD_RESPONSE);


                auditMasterDto.setEventId(AuditEnum.NOTIFICATION_TEMPLATE.getValue());
                auditMasterDto.setWhen(notificationTemplatesDto.getCreatedDate());
                auditMasterDto.setReferenceId(String.valueOf(notificationTemplatesDto.getId()));
                auditMasterDto.setActionType(ActionTypeEnum.ADD.getValue());
                auditMasterDto.setWho(notificationTemplatesDto.getCreatedBy());
                auditMasterDto.setDescription(String.format(NotifyConstant.ADDED_NOTIFICATION_TEMPLATE,notificationTemplatesDto.getName()));
                sendData.sendMessage(auditMasterDto);
            }else{
                throw new NotifyException(NotifyException.VALIDATION_FAILD,HttpStatus.BAD_REQUEST);
            }
        } catch (NotifyException ex) {
            throw ex;
        }catch (Exception ex) {
            LOGGER.error("Exception in addTemplate:", ex);
            throw new NotifyException(NotifyException.UNABLE_TO_ADD_NOTIFICATION_TEMPLATE,HttpStatus.INTERNAL_SERVER_ERROR);

        }

        return notificationTemplatesDto;
    }


    @Override
    public BaseListDto<NotificationTemplatesDto> findAll(NotificationTemplatesDto dto) throws NotifyException{
        BaseListDto<NotificationTemplatesDto> templatesDtoList = new  BaseListDto<>();
        AuditMasterDto auditMasterDto = new AuditMasterDto();
        ObjectMapper mapper = new ObjectMapper();
        try{
            if(Objects.isNull(dto.getPaginationDto().getSortType()) || dto.getPaginationDto().getSortType().isEmpty()){
                dto.getPaginationDto().setSortType(SortTypeConstants.SORT_TYPE_ASC);

            }

            if(Objects.isNull(dto.getPaginationDto().getSortBy()) || dto.getPaginationDto().getSortBy().isEmpty()){
                dto.getPaginationDto().setSortBy(NotifyConstant.SORT_BY_NAME);
                dto.getPaginationDto().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }
            PageableEntity<NotificationTemplatesEntity> data = notificationTemplateRepository.getAllSubCategoryWithFilters(em,dto);
            PaginationDto pageDto = dto.getPaginationDto();
            pageDto.setCount(data.getCount());

            templatesDtoList.setPagination(pageDto);
            templatesDtoList.setDataList(notificationTemplatesAssembler.entityListToDtoList(data.getData()));
            for(int i=0; i<templatesDtoList.getDataList().size(); i++){
                templatesDtoList.getDataList().get(i).setTemplate(mapper.readValue(data.getData().get(i).getTemplate(), new TypeReference<List<TemplateDto>>() {}));
            }
            templatesDtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            templatesDtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            templatesDtoList.setAuditEventId(AuditEnum.NOTIFICATION_TEMPLATE.getValue());

            auditMasterDto.setEventId(AuditEnum.NOTIFICATION_TEMPLATE.getValue());
            auditMasterDto.setWhen(dto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(dto.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(dto.getCreatedBy());
            auditMasterDto.setDescription(String.format(NotifyConstant.VIEW_ALL_NOTIFICATION_TEMPLATE,
                    templatesDtoList.getPagination().getPage(),
                    templatesDtoList.getPagination().getLimit(),
                    templatesDtoList.getPagination().getSortBy(),
                    templatesDtoList.getPagination().getSortType(),
                    templatesDtoList.getPagination().getCount()));
            sendData.sendMessage(auditMasterDto);

        }catch (NotifyException ex) {
            throw ex;
        }
        catch (Exception ex) {
            LOGGER.error("Exception in findAll:", ex);
            throw new NotifyException(NotifyException.UNABLE_TO_RETRIEVE_TEMPLATE_DETAILS,HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return templatesDtoList;

    }



    @Override
    public NotificationTemplatesDto getTemplatesById(NotificationTemplatesDto notificationTemplatesDto) throws NotifyException{
        AuditMasterDto auditMasterDto = new AuditMasterDto();
        ObjectMapper mapper = new ObjectMapper();
        try{
        NotificationTemplatesEntity notificationTemplatesEntity = notificationTemplateRepository.getById(notificationTemplatesDto.getId());
            if(Objects.isNull(notificationTemplatesEntity)){
                throw new NotifyException(NotifyException.TEMPLATE_NOT_FOUND,HttpStatus.NOT_FOUND);
            }

        notificationTemplatesDto = notificationTemplatesAssembler.entityToDto(notificationTemplatesEntity);
        notificationTemplatesDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
        notificationTemplatesDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
        notificationTemplatesDto.setTemplate(mapper.readValue(notificationTemplatesEntity.getTemplate(), new TypeReference<List<TemplateDto>>() {}));

            auditMasterDto.setEventId(AuditEnum.NOTIFICATION_TEMPLATE.getValue());
            auditMasterDto.setWhen(notificationTemplatesDto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(notificationTemplatesEntity.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(notificationTemplatesDto.getCreatedBy());
            auditMasterDto.setDescription(String.format(NotifyConstant.VIEW_NOTIFICATION_TEMPLATE,notificationTemplatesDto.getName()));
            sendData.sendMessage(auditMasterDto);
        return notificationTemplatesDto;
        } catch (NotifyException ex) {
            throw ex;
        }
        catch (Exception ex) {
            LOGGER.error("Exception in getTemplatesById:", ex);
            throw new NotifyException(NotifyException.TEMPLATE_NOT_FOUND,HttpStatus.NOT_FOUND);
        }

    }

    @Override
    public NotificationTemplatesDto updateNotificationTemplate(NotificationTemplatesDto notificationTemplatesDto, Integer id) throws NotifyException {

        try{
            AuditMasterDto auditMasterDto = new AuditMasterDto();
            NotificationTemplatesEntity notificationTemplateEntity = notificationTemplateRepository.getById(id);
            if(Objects.isNull(notificationTemplateEntity)){
                throw new NotifyException(NotifyException.NO_RECORDS_FOUND,HttpStatus.NOT_FOUND);
            }
            if(notifyValidation.isValidEventId(notificationTemplatesDto.getEventId()) &&
                    notifyValidation.isTemplateValidCodeForUpdate(notificationTemplatesDto.getCode(),id) &&
                    notifyValidation.isValidType(notificationTemplatesDto.getType()) &&
                    notifyValidation.isValidName(notificationTemplatesDto.getName()) &&
                    notifyValidation.isValidTemplate(notificationTemplatesDto.getTemplate()) &&
                    notifyValidation.isValidRowVersion(notificationTemplatesDto.getRowVersion())) {
                ObjectMapper mapper = new ObjectMapper();
                JSONObject jsonObj = new JSONObject(notificationTemplatesDto);
                notificationTemplateEntity.setEventId(notificationTemplatesDto.getEventId());
                notificationTemplateEntity.setCode(notificationTemplatesDto.getCode());
                notificationTemplateEntity.setName(notificationTemplatesDto.getName());
                notificationTemplateEntity.setType(notificationTemplatesDto.getType());
                notificationTemplateEntity.setDescription(notificationTemplatesDto.getDescription());
                notificationTemplateEntity.setTemplate(jsonObj.getString(NotifyConstant.NOTIFY_JSON_TEMPLATE));
                UserAuthDataHandler.resolveEntityBaseData(notificationTemplatesDto, notificationTemplateEntity);

                notificationTemplateEntity.setRowVersion(notificationTemplatesDto.getRowVersion());
                NotificationTemplatesEntity notificationTemplatesEntity = notificationTemplateRepository.save(notificationTemplateEntity);
                notificationTemplatesAssembler.entityToDto(notificationTemplatesEntity);
                notificationTemplatesDto.setId(notificationTemplateEntity.getId());
                notificationTemplatesDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                notificationTemplatesDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                notificationTemplatesDto.setTemplate(mapper.readValue(notificationTemplateEntity.getTemplate(), new TypeReference<List<TemplateDto>>() {}));
                notificationTemplatesDto.setResponseMessage(NotifyConstant.NOTIFICATION_TEMPLATE_UPDATE_RESPONSE);

                auditMasterDto.setEventId(AuditEnum.NOTIFICATION_TEMPLATE.getValue());
                auditMasterDto.setWhen(notificationTemplatesDto.getModifiedDate());
                auditMasterDto.setReferenceId(String.valueOf(notificationTemplateEntity.getId()));
                auditMasterDto.setActionType(ActionTypeEnum.UPDATE.getValue());
                auditMasterDto.setWho(notificationTemplatesDto.getModifiedBy());
                auditMasterDto.setDescription(String.format(NotifyConstant.UPDATED_NOTIFICATION_TEMPLATE,notificationTemplatesDto.getName()));
                sendData.sendMessage(auditMasterDto);

            }else{
                throw new NotifyException(NotifyException.VALIDATION_FAILD,HttpStatus.BAD_REQUEST);
            }

        }catch (NotifyException ex) {
            throw ex;

        }
        catch (Exception e) {
            LOGGER.error("Exception in updateNotificationTemplate:", e);
            throw new NotifyException(NotifyException.UNABLE_TO_UPDATE_NOTIFICATION_TEMPLATE,HttpStatus.INTERNAL_SERVER_ERROR);
         }
        return notificationTemplatesDto;

    }

    @Override
    public IdDto deleteTemplate(NotificationTemplatesDto notificationTemplatesDto) throws NotifyException{
        AuditMasterDto auditMasterDto = new AuditMasterDto();
        IdDto idDto= new IdDto();
        try {
            NotificationTemplatesEntity notificationTemplateEntity = notificationTemplateRepository.getById(notificationTemplatesDto.getId());
            notificationTemplateEntity.setIsDeleted((short) GlobalYesNoEnum.YES.getValue());
            UserAuthDataHandler.resolveEntityBaseData(notificationTemplatesDto, notificationTemplateEntity);

            notificationTemplateRepository.save(notificationTemplateEntity);
            idDto.setId(notificationTemplatesDto.getId());

            auditMasterDto.setEventId(AuditEnum.NOTIFICATION_TEMPLATE.getValue());
            auditMasterDto.setWhen(notificationTemplatesDto.getModifiedDate());
            auditMasterDto.setReferenceId(String.valueOf(notificationTemplateEntity.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.DELETE.getValue());
            auditMasterDto.setWho(notificationTemplatesDto.getModifiedBy());
            auditMasterDto.setDescription(String.format(NotifyConstant.DELETED_NOTIFICATION_TEMPLATE,notificationTemplateEntity.getName()));
            sendData.sendMessage(auditMasterDto);
            return idDto;
        }
        catch (Exception ex) {
        LOGGER.error("Exception in deleteTemplate:", ex);
         throw new NotifyException(NotifyException.TEMPLATE_NOT_DELETED,HttpStatus.NOT_FOUND);
    }

    }



}
