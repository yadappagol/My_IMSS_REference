package com.imss.rc.notify.repository;

import com.imss.rc.notify.assembler.NotificationTemplatesAssembler;
import com.imss.rc.notify.dto.NotificationTemplatesDto;
import com.imss.rc.notify.entity.NotificationTemplatesEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.commons.entity.BaseEntity;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Transactional
@Repository
public interface NotificationTemplateRepository extends JpaRepository<NotificationTemplatesEntity,Integer> {


    @Query(value="from NotificationTemplatesEntity nt where nt.isDeleted=0 and nt.code= :code")
    public NotificationTemplatesEntity getByCode(@Param("code") String code);

    @Query(value="from NotificationTemplatesEntity nt where nt.isDeleted=0 and nt.id= :id")
    public NotificationTemplatesEntity getById(@Param("id") Integer id);

    default PageableEntity<NotificationTemplatesEntity> getAllSubCategoryWithFilters(EntityManager em, NotificationTemplatesDto notificationTemplatesDto) throws NotifyException {

        PageableEntity<NotificationTemplatesEntity> retData = new PageableEntity<>();

        List<Predicate> predicateList = new ArrayList<>();
        CriteriaBuilder criteriaBuilder ;
        Root<NotificationTemplatesEntity> notificationTemplatesRoot ;

        /** This is to get the count of records */
        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        notificationTemplatesRoot = countQuery.from(NotificationTemplatesEntity.class);

        predicateList = applySearchFilters(criteriaBuilder, predicateList, notificationTemplatesRoot, notificationTemplatesDto);

        countQuery.select(criteriaBuilder.count(notificationTemplatesRoot));
        countQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));
        long count = em.createQuery(countQuery).getSingleResult();
        retData.setCount(count);
        /***********************************/


        /** This is to get the list based on the page and limit *******/

        //Clear out the predicateList created using the count root
        predicateList.clear();

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<NotificationTemplatesEntity> listCriteriaQuery = criteriaBuilder.createQuery(NotificationTemplatesEntity.class);

        notificationTemplatesRoot = listCriteriaQuery.from(NotificationTemplatesEntity.class);

        listCriteriaQuery.select(notificationTemplatesRoot);
        predicateList = applySearchFilters(criteriaBuilder, predicateList, notificationTemplatesRoot, notificationTemplatesDto);

        listCriteriaQuery.where( criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));

        String sortByColumn = NotificationTemplatesAssembler.getSortByColumn(notificationTemplatesDto.getPaginationDto().getSortBy());

        Order order;
        if("asc".equals( notificationTemplatesDto.getPaginationDto().getSortType())){
            order = criteriaBuilder.asc(notificationTemplatesRoot.get(sortByColumn));
        } else {
            order = criteriaBuilder.desc(notificationTemplatesRoot.get(sortByColumn));
        }

        TypedQuery<NotificationTemplatesEntity> query = em.createQuery(listCriteriaQuery.orderBy(order))
                .setFirstResult((notificationTemplatesDto.getPaginationDto().getPage() - 1) * notificationTemplatesDto.getPaginationDto().getLimit())
                .setMaxResults(notificationTemplatesDto.getPaginationDto().getLimit());
        retData.setData(query.getResultList());
        /***********************************/


        return retData;
    }



    default List<Predicate> applySearchFilters(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Root<NotificationTemplatesEntity> auditMasterRoot,
                                               NotificationTemplatesDto notificationTemplatesDto) throws NotifyException {

        predicateList.add(criteriaBuilder.equal(auditMasterRoot.get(BaseEntity.COLUMN_NAME_IS_DELETED), GlobalYesNoEnum.NO.getValue()));

        //Adding filter for event id if present
        if (Optional.ofNullable(notificationTemplatesDto.getEventId()).isPresent() && notificationTemplatesDto.getEventId()!=0 ) {
            predicateList.add(criteriaBuilder.equal(auditMasterRoot.get(NotificationTemplatesEntity.COLUMN_NAME_EVENT_ID), notificationTemplatesDto.getEventId()));
        }

        //Adding filter for type if present
        if (Optional.ofNullable(notificationTemplatesDto.getType()).isPresent()) {
            predicateList.add(criteriaBuilder.equal(auditMasterRoot.get(NotificationTemplatesEntity.COLUMN_NAME_TYPE), notificationTemplatesDto.getType()));
        }

        return predicateList;
    }


}
