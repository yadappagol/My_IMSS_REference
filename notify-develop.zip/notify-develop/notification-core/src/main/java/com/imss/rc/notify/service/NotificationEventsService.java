package com.imss.rc.notify.service;

import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.notify.dto.NotificationEventsDto;
import com.imss.rc.notify.entity.NotificationEventsEntity;
import com.imss.rc.notify.exception.NotifyException;

public interface NotificationEventsService {

    public NotificationEventsEntity findById(Integer id);

    public NotificationEventsDto addNotificationEvent(NotificationEventsDto notificationEventsDto) throws NotifyException;

    public NotificationEventsDto updateNotificationEvent(NotificationEventsDto notificationEventsDto, Integer id) throws NotifyException;


    public NotificationEventsDto getNotificationEventById(NotificationEventsDto notificationEventsDto) throws NotifyException;

    public IdDto deleteNotificationEvent(NotificationEventsDto notificationEventsDto) throws NotifyException;

    public BaseListDto<NotificationEventsDto> getAllNotificationEvents(NotificationEventsDto dto) throws NotifyException;
}
