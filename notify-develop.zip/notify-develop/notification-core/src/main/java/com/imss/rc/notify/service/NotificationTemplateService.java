package com.imss.rc.notify.service;

import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.notify.dto.NotificationTemplatesDto;
import com.imss.rc.notify.exception.NotifyException;

public interface NotificationTemplateService {
    public NotificationTemplatesDto addTemplate(NotificationTemplatesDto notificationTemplatesDto) throws NotifyException;

    public BaseListDto<NotificationTemplatesDto> findAll(NotificationTemplatesDto notificationTemplatesDto) throws NotifyException;

    public NotificationTemplatesDto getTemplatesById(NotificationTemplatesDto notificationTemplatesDto) throws NotifyException;

    public NotificationTemplatesDto updateNotificationTemplate(NotificationTemplatesDto notificationTemplatesDto, Integer id) throws NotifyException;


    public ResponseDto deleteTemplate(NotificationTemplatesDto notificationTemplatesDto) throws NotifyException;
}
