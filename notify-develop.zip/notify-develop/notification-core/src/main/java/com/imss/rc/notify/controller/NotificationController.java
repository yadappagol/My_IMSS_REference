package com.imss.rc.notify.controller;


import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.notify.dto.NotificationInAppDto;
import com.imss.rc.notify.dto.NotificationTemplatesDto;
import com.imss.rc.notify.dto.NotificationUserPreferenceDto;
import com.imss.rc.notify.exception.NotifyException;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;


public interface NotificationController {

    @PostMapping(value = "/notify/templates",consumes = "application/json", produces = "application/json")
    public NotificationTemplatesDto addTemplate(@RequestBody NotificationTemplatesDto notificationTemplatesDto, HttpServletRequest request)throws NotifyException;

    @GetMapping(value = "/notify/templates",consumes = "application/json", produces = "application/json")
    public BaseListDto<NotificationTemplatesDto> getAllTemplates(@RequestParam Integer page, @RequestParam Integer limit,
                                                                 @RequestParam(required = false) String sortBy,
                                                                 @RequestParam(required = false) Integer eventId,
                                                                 @RequestParam(required = false) Short type,
                                                                 @RequestParam(required = false) String sortType,
                                                                 HttpServletRequest request
    )throws NotifyException;

    @GetMapping(value = "/notify/templates/{id}",consumes = "application/json", produces = "application/json")
    public NotificationTemplatesDto getTemplatesById(@PathVariable("id") Integer id, HttpServletRequest request)throws NotifyException;

    @PutMapping(value = "/notify/templates/{id}",consumes = "application/json", produces = "application/json")
    public NotificationTemplatesDto updateNotificationTemplate(@RequestBody NotificationTemplatesDto notificationTemplatesDto, @PathVariable("id") Integer id, HttpServletRequest request)throws NotifyException;

    @DeleteMapping(value = "/notify/templates/{id}",consumes = "application/json", produces = "application/json")
    public ResponseDto deleteTemplate(@PathVariable("id") Integer id, HttpServletRequest request)throws NotifyException;

   @GetMapping(value = "/notify/notifications",consumes = "application/json", produces = "application/json")
   public BaseListDto<? extends BaseDto> getAllNotifications(@RequestParam Integer page,
                                                             @RequestParam Integer limit,
                                                             @RequestParam String mode,
                                                             @RequestParam(required = false)  String  startDate,
                                                             @RequestParam(required = false)  String  endDate,
                                                             @RequestParam(required = false)  String sortBy,
                                                             @RequestParam(required = false)  String sortType,
                                                             HttpServletRequest request
                                             ) throws NotifyException;

    @GetMapping(value = "/notify/preferences/{userId}",consumes = "application/json", produces = "application/json")
    public BaseListDto<NotificationUserPreferenceDto> getAllPreferencesByUserName(@PathVariable("userId") String userId, HttpServletRequest request)throws NotifyException;

    @PutMapping(value = "/notify/preferences/{userId}/{eventId}",consumes = "application/json", produces = "application/json")
    public NotificationUserPreferenceDto updateUserPreferences(@RequestBody NotificationUserPreferenceDto notificationUserPreferenceDto, @PathVariable("userId") String userId,
                                                          @PathVariable("eventId") Integer eventId, HttpServletRequest request)throws NotifyException;

    @GetMapping(value = "/notify/preferences/{userId}/{eventId}",consumes = "application/json", produces = "application/json")
    public NotificationUserPreferenceDto getUserSpecificPreferences(@PathVariable("userId") String userId,@PathVariable("eventId") Integer eventId, HttpServletRequest request)throws NotifyException;

    @PutMapping(value = "/notify/notifications/{id}",consumes = "application/json", produces = "application/json")
    public NotificationInAppDto updateNotificationInApp(@RequestBody NotificationInAppDto notificationInAppDto, @PathVariable("id") Integer id, HttpServletRequest request)throws NotifyException;

    @GetMapping(value = "/notify/notifications/user/{userId}",consumes = "application/json", produces = "application/json")
    public BaseListDto<NotificationInAppDto> getUserSpecificInAppNotification(@PathVariable("userId") String userId,
                                                                              @RequestParam Integer page, @RequestParam Integer limit,
                                                                              @RequestParam String mode,
                                                                              @RequestParam(required = false)  Integer  status,
                                                                              @RequestParam(required = false)  String  startDate,
                                                                              @RequestParam(required = false)  String  endDate,
                                                                              @RequestParam(required = false) String sortBy,
                                                                              @RequestParam(required = false) String sortType,
                                                                              HttpServletRequest request
                                                                              )throws NotifyException;

    @PutMapping(value = "/notify/preferences/{userId}",consumes = "application/json", produces = "application/json")
    public BaseListDto<NotificationUserPreferenceDto> updateUserPreferencesByUserId(@RequestBody NotificationUserPreferenceDto notificationUserPreferenceDto, @PathVariable("userId") String userId,
                                                               HttpServletRequest request)throws NotifyException;

}
