package com.imss.rc.notify.validation;

import com.imss.rc.notify.constants.NotifyConstant;
import com.imss.rc.notify.dto.ContentDetailsDto;
import com.imss.rc.notify.dto.PreferencesDto;
import com.imss.rc.notify.dto.TemplateDto;
import com.imss.rc.notify.entity.NotificationEventsEntity;
import com.imss.rc.notify.entity.NotificationTemplatesEntity;
import com.imss.rc.notify.entity.NotificationUserPreferenceEntity;
import com.imss.rc.notify.enums.NotificationStatusInAppEnum;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.cdh.entity.CoreDataDetailsEntity;
import com.imss.rc.cdh.repository.CoreDataDetailsRepository;
import com.imss.rc.notify.repository.NotificationEventsRepository;
import com.imss.rc.notify.repository.NotificationTemplateRepository;
import com.imss.rc.notify.repository.NotificationUserPreferenceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;
import java.util.Objects;

@Component
public class NotifyValidation {

    private static final String REG_EX = "^[a-zA-Z0-9._]*$" ;

    @Autowired
    private NotificationEventsRepository notificationEventsRepository;

    @Autowired
    private NotificationTemplateRepository notificationTemplateRepository;

    @Autowired
    private NotificationUserPreferenceRepository notificationUserPreferenceRepository;

    @Autowired
    CoreDataDetailsRepository coreDataDetailsRepository;

    public boolean isValidEventId(Integer id) throws NotifyException {
        if(Objects.isNull(id)){
            throw new NotifyException(NotifyException.EVENT_ID_NOT_FOUND, HttpStatus.BAD_REQUEST);
        }
        boolean flag = notificationEventsRepository.existsById(id);
        if(!flag) {
            throw new NotifyException(NotifyException.EVENTS_NOT_FOUND, HttpStatus.BAD_REQUEST);
        }
        return true;
    }


    public boolean isValidCode(String code) throws NotifyException {
        if(Objects.isNull(code)){
            throw new NotifyException(NotifyException.CODE_NOT_FOUND,HttpStatus.BAD_REQUEST);
        }
        NotificationTemplatesEntity notificationTemplatesEntity = notificationTemplateRepository.getByCode(code);
        if (Objects.isNull(notificationTemplatesEntity)  && code.matches(NotifyValidation.REG_EX) && Objects.nonNull(code) && !code.trim().isEmpty())
        {
            return true;
        }else
            throw new NotifyException(NotifyException.CODE_NOT_VALID,HttpStatus.BAD_REQUEST);

    }

    public boolean isValidType(Short type) throws NotifyException {
        if(Objects.isNull(type)){
            throw new NotifyException(NotifyException.TYPE_NOT_FOUND,HttpStatus.BAD_REQUEST);
        }

        if (type < NotifyConstant.TYPE_ZERO || type > NotifyConstant.TYPE_THREE) {
            throw new NotifyException(NotifyException.TYPE_NOT_VALID,HttpStatus.BAD_REQUEST);
        }
        return true;

    }

    public boolean isValidName(String name) throws NotifyException {
        if(Objects.isNull(name)){
            throw new NotifyException(NotifyException.NAME_NOT_FOUND,HttpStatus.BAD_REQUEST);
        }

        if (name.length()>NotifyConstant.LENGTH_ZERO && name.length()<=NotifyConstant.LENGTH_FIFTY && name.trim().replace(" ","").matches(NotifyConstant.NAME_REGEX)) {

            return true;

        } else {
            throw new NotifyException(NotifyException.NAME_NOT_VALID,HttpStatus.BAD_REQUEST);
        }

    }

    boolean isValidLocale(String value) {
        String[] locales =  Locale.getISOLanguages();
        for (String locale : locales) {
              if (value.equals(locale)) {
                return true;
            }
        }
        return false;
    }

    public boolean isValidTemplate(List<TemplateDto> template) throws NotifyException {
        boolean validationFlag=false;
        if(Objects.nonNull(template) && !template.isEmpty()) {
            for (TemplateDto templateDto : template) {
                if(Objects.nonNull(templateDto.getMode())) {
                    if (templateDto.getMode().equalsIgnoreCase(NotifyConstant.SMS_MODE)) {

                        if (Objects.nonNull(templateDto.getNotifyLanguage()) && !templateDto.getNotifyLanguage().trim().isEmpty()) {
                            if(templateDto.getNotifyLanguage().matches(NotifyConstant.TEMPLATE_REGEX)) {

                                if (Objects.nonNull(templateDto.getToExpression()) && !templateDto.getToExpression().trim().isEmpty()) {
                                    if(templateDto.getToExpression().matches(NotifyConstant.TEMPLATE_REGEX)) {

                                        if (!templateDto.getContentDetails().isEmpty()) {
                                            for (ContentDetailsDto contentDetailsDto : templateDto.getContentDetails()) {
                                                if (Objects.nonNull(contentDetailsDto.getLanguage()) && !contentDetailsDto.getLanguage().trim().isEmpty()) {
                                                    if(isValidLocale(contentDetailsDto.getLanguage())) {
                                                        validationFlag = true;
                                                    }else{
                                                        throw new NotifyException(NotifyException.SMS_MODE_LANGUAGE_NOT_VALID, HttpStatus.BAD_REQUEST);
                                                    }
                                                } else {
                                                    throw new NotifyException(NotifyException.SMS_MODE_LANGUAGE_MANDATORY, HttpStatus.BAD_REQUEST);
                                                }
                                            }
                                        } else {
                                            throw new NotifyException(NotifyException.SMS_CONTENT_DETAILS_MANDATORY, HttpStatus.BAD_REQUEST);
                                        }
                                    }else{
                                        throw new NotifyException(NotifyException.SMS_MODE_EXPRESSION_NOT_VALID, HttpStatus.BAD_REQUEST);
                                    }
                                } else {
                                    throw new NotifyException(NotifyException.SMS_MODE_EXPRESSION_MANDATORY, HttpStatus.BAD_REQUEST);
                                }
                            }else{
                                throw new NotifyException(NotifyException.SMS_MODE_NOTIFY_LANGUAGE_NOT_VALID, HttpStatus.BAD_REQUEST);
                            }
                        } else {
                            throw new NotifyException(NotifyException.SMS_MODE_NOTIFY_LANGUAGE_MANDATORY, HttpStatus.BAD_REQUEST);
                        }
                    } else if (templateDto.getMode().equalsIgnoreCase(NotifyConstant.EMAIL_MODE)) {

                        if (Objects.nonNull(templateDto.getNotifyLanguage()) && !templateDto.getNotifyLanguage().trim().isEmpty()) {
                            if (templateDto.getNotifyLanguage().matches(NotifyConstant.TEMPLATE_REGEX)) {

                                if (Objects.nonNull(templateDto.getToExpression()) && !templateDto.getToExpression().trim().isEmpty()) {
                                    if (templateDto.getToExpression().matches(NotifyConstant.TEMPLATE_REGEX)) {

                                        if (templateDto.getContentDetails().size() != 0) {
                                            for (ContentDetailsDto contentDetailsDto : templateDto.getContentDetails()) {
                                                if (Objects.nonNull(contentDetailsDto.getLanguage()) && !contentDetailsDto.getLanguage().trim().isEmpty()) {
                                                    if (isValidLocale(contentDetailsDto.getLanguage())) {
                                                        validationFlag = true;
                                                    } else {
                                                        throw new NotifyException(NotifyException.EMAIL_MODE_LANGUAGE_NOT_VALID, HttpStatus.BAD_REQUEST);
                                                    }
                                                } else {
                                                    throw new NotifyException(NotifyException.EMAIL_MODE_LANGUAGE_MANDATORY, HttpStatus.BAD_REQUEST);
                                                }
                                            }
                                        } else {
                                            throw new NotifyException(NotifyException.EMAIL_MODE_CONTENT_DETAILS_MANDATORY, HttpStatus.BAD_REQUEST);
                                        }
                                    } else {
                                        throw new NotifyException(NotifyException.EMAIL_MODE_EXPRESSION_NOT_VALID, HttpStatus.BAD_REQUEST);
                                    }
                                } else {
                                    throw new NotifyException(NotifyException.EMAIL_MODE_EXPRESSION_MANDATORY, HttpStatus.BAD_REQUEST);
                                }
                            } else {
                                throw new NotifyException(NotifyException.EMAIL_MODE_NOTIFY_LANGUAGE_NOT_VALID, HttpStatus.BAD_REQUEST);
                            }
                        } else {
                            throw new NotifyException(NotifyException.EMAIL_MODE_NOTIFY_LANGUAGE_MANDATORY, HttpStatus.BAD_REQUEST);
                        }
                    } else if (templateDto.getMode().equalsIgnoreCase(NotifyConstant.INAPP_MODE)) {

                        if (Objects.nonNull(templateDto.getNotifyLanguage()) && !templateDto.getNotifyLanguage().trim().isEmpty()) {
                            if (templateDto.getNotifyLanguage().matches(NotifyConstant.TEMPLATE_REGEX)) {

                                if (Objects.nonNull(templateDto.getToExpression()) && !templateDto.getToExpression().trim().isEmpty()) {
                                    if (templateDto.getToExpression().matches(NotifyConstant.TEMPLATE_REGEX)) {

                                        if (!templateDto.getContentDetails().isEmpty()) {
                                            for (ContentDetailsDto contentDetailsDto : templateDto.getContentDetails()) {
                                                if (Objects.nonNull(contentDetailsDto.getLanguage()) && !contentDetailsDto.getLanguage().trim().isEmpty()) {
                                                    if (isValidLocale(contentDetailsDto.getLanguage())) {
                                                        validationFlag = true;
                                                    } else {
                                                        throw new NotifyException(NotifyException.INAPP_MODE_LANGUAGE_NOT_VALID, HttpStatus.BAD_REQUEST);
                                                    }
                                                } else {
                                                    throw new NotifyException(NotifyException.INAPP_MODE_LANGUAGE_MANDATORY, HttpStatus.BAD_REQUEST);
                                                }
                                            }
                                        } else {
                                            throw new NotifyException(NotifyException.INAPP_MODE_CONTENT_DETAILS_MANDATORY, HttpStatus.BAD_REQUEST);
                                        }
                                    } else {
                                        throw new NotifyException(NotifyException.INAPP_MODE_EXPRESSION_NOT_VALID, HttpStatus.BAD_REQUEST);
                                    }
                                } else {
                                    throw new NotifyException(NotifyException.INAPP_MODE_EXPRESSION_MANDATORY, HttpStatus.BAD_REQUEST);
                                }
                            } else {
                                throw new NotifyException(NotifyException.INAPP_MODE_NOTIFY_LANGUAGE_NOT_VALID, HttpStatus.BAD_REQUEST);
                            }
                        } else {
                            throw new NotifyException(NotifyException.INAPP_MODE_NOTIFY_LANGUAGE_MANDATORY, HttpStatus.BAD_REQUEST);
                        }
                    } else if (templateDto.getMode().equalsIgnoreCase(NotifyConstant.PUSH_MODE)) {

                        if (Objects.nonNull(templateDto.getNotifyLanguage()) && !templateDto.getNotifyLanguage().trim().isEmpty()) {
                            if (templateDto.getNotifyLanguage().matches(NotifyConstant.TEMPLATE_REGEX)) {

                                if (Objects.nonNull(templateDto.getToExpression()) && !templateDto.getToExpression().trim().isEmpty()) {
                                    if (templateDto.getToExpression().matches(NotifyConstant.TEMPLATE_REGEX)) {

                                        if (!templateDto.getContentDetails().isEmpty()) {
                                            for (ContentDetailsDto contentDetailsDto : templateDto.getContentDetails()) {
                                                if (Objects.nonNull(contentDetailsDto.getLanguage()) && !contentDetailsDto.getLanguage().trim().isEmpty()) {
                                                    if (isValidLocale(contentDetailsDto.getLanguage())) {
                                                        validationFlag = true;
                                                    } else {
                                                        throw new NotifyException(NotifyException.PUSH_MODE_LANGUAGE_NOT_VALID, HttpStatus.BAD_REQUEST);
                                                    }
                                                } else {
                                                    throw new NotifyException(NotifyException.PUSH_MODE_LANGUAGE_MANDATORY, HttpStatus.BAD_REQUEST);
                                                }
                                            }
                                        } else {
                                            throw new NotifyException(NotifyException.PUSH_MODE_CONTENT_DETAILS_MANDATORY, HttpStatus.BAD_REQUEST);
                                        }
                                    } else {
                                        throw new NotifyException(NotifyException.PUSH_MODE_EXPRESSION_NOT_VALID, HttpStatus.BAD_REQUEST);
                                    }
                                } else {
                                    throw new NotifyException(NotifyException.PUSH_MODE_EXPRESSION_MANDATORY, HttpStatus.BAD_REQUEST);
                                }
                            } else {
                                throw new NotifyException(NotifyException.PUSH_MODE_NOTIFY_LANGUAGE_NOT_VALID, HttpStatus.BAD_REQUEST);
                            }
                        } else {
                            throw new NotifyException(NotifyException.PUSH_MODE_NOTIFY_LANGUAGE_MANDATORY, HttpStatus.BAD_REQUEST);
                        }
                    } else {
                        throw new NotifyException(NotifyException.MODE_NOT_VALID, HttpStatus.BAD_REQUEST);
                    }
                } else {
                    throw new NotifyException(NotifyException.MODE_MANDATORY, HttpStatus.BAD_REQUEST);
                }

            }

            return validationFlag;
        }else{
            throw new NotifyException(NotifyException.TEMPLATE_NOT_VALID, HttpStatus.BAD_REQUEST);
        }

    }

    public boolean isNotifyEventValidCode(String code) throws NotifyException {
        if(Objects.isNull(code)){
            throw new NotifyException(NotifyException.CODE_NOT_FOUND,HttpStatus.BAD_REQUEST);
        }
        NotificationEventsEntity notificationEventsEntity = notificationEventsRepository.getByCode(code);
        if (Objects.isNull(notificationEventsEntity) && code.matches(NotifyValidation.REG_EX)  && !code.trim().isEmpty())
        {
            return true;
        }else
            throw new NotifyException(NotifyException.CODE_NOT_VALID,HttpStatus.BAD_REQUEST);
    }

    public boolean isUserOverrideValid(Short isUserOverrideAllowed) throws NotifyException {
        if(Objects.nonNull(isUserOverrideAllowed)) {
            if (isUserOverrideAllowed == NotifyConstant.TYPE_ZERO || isUserOverrideAllowed == NotifyConstant.TYPE_ONE) {
                return true;
            } else
                throw new NotifyException(NotifyException.IS_OVERRIDE_NOT_VALID, HttpStatus.BAD_REQUEST);
        }else
            throw new NotifyException(NotifyException.IS_OVERRIDE_MANDATORY, HttpStatus.BAD_REQUEST);
    }

    public boolean ispreferencesValid(PreferencesDto preferences) throws NotifyException {
        if(Objects.isNull(preferences)){
            throw new NotifyException(NotifyException.PREFERENCE_NOT_FOUND,HttpStatus.BAD_REQUEST);
        }
        if((preferences.getEmail().equals(NotifyConstant.YES) || preferences.getEmail().equals(NotifyConstant.NO))
            && (preferences.getSms().equals(NotifyConstant.YES) || preferences.getSms().equals(NotifyConstant.NO))
            && (preferences.getInapp().equals(NotifyConstant.YES) || preferences.getInapp().equals(NotifyConstant.NO))
            && (preferences.getPush().equals(NotifyConstant.YES) || preferences.getPush().equals(NotifyConstant.NO))){

            return true;
        }else
            throw new NotifyException(NotifyException.PREFERENCE_NOT_VALID,HttpStatus.BAD_REQUEST);
    }

    public boolean isCategoryValid(Integer categoryId) throws NotifyException {
        if(Objects.isNull(categoryId)){
            throw new NotifyException(NotifyException.CATEGORY_NOT_FOUND,HttpStatus.BAD_REQUEST);
        }
        CoreDataDetailsEntity entity =coreDataDetailsRepository.getCategoryId(categoryId);
        if(Objects.isNull(entity)) {
            throw new NotifyException(NotifyException.INVALID_CATEGORY_ID, new String[]{String.valueOf(categoryId.intValue())}, HttpStatus.BAD_REQUEST);
        } else {
            return true;
        }
    }

    public boolean isUserAvailable(String userName,Integer eventId) throws NotifyException {
        NotificationUserPreferenceEntity notificationUserPreferenceEntity = notificationUserPreferenceRepository.getUser(userName,eventId);
        if (Objects.nonNull(notificationUserPreferenceEntity))
        {
            return true;
        }else {
            NotificationEventsEntity notificationEventsEntity = notificationEventsRepository.getOne(eventId);
            if(notificationEventsEntity.getIsUserOverrideAllowed()==NotifyConstant.TYPE_ZERO && notificationEventsEntity.getIsDeleted()==NotifyConstant.TYPE_ZERO){
                return true;
            }else{
                throw new NotifyException(NotifyException.CODE_NOT_VALID, HttpStatus.BAD_REQUEST);
            }
        }
    }

    public boolean isValidCodeForUpdate(String code,Integer id) throws NotifyException {
        if(Objects.isNull(code)){
            throw new NotifyException(NotifyException.CODE_NOT_FOUND,HttpStatus.BAD_REQUEST);
        }
        NotificationEventsEntity notificationEventsEntity = notificationEventsRepository.getByCode(code);
        if (Objects.nonNull(notificationEventsEntity) && notificationEventsEntity.getId().intValue()==id.intValue() && code.matches(NotifyValidation.REG_EX) && !code.trim().isEmpty())
        {
            return true;
        }else if(Objects.isNull(notificationEventsEntity)  && code.matches(NotifyValidation.REG_EX) && !code.trim().isEmpty()){
            return true;
        }else
            throw new NotifyException(NotifyException.CODE_NOT_VALID,HttpStatus.BAD_REQUEST);
    }

    public boolean isTemplateValidCodeForUpdate(String code,Integer id) throws NotifyException {
        if(Objects.isNull(code)){
            throw new NotifyException(NotifyException.CODE_NOT_FOUND,HttpStatus.BAD_REQUEST);
        }
        NotificationTemplatesEntity notificationTemplatesEntity = notificationTemplateRepository.getByCode(code);
        if (Objects.nonNull(notificationTemplatesEntity) && notificationTemplatesEntity.getId().intValue()==id.intValue()  && code.matches(NotifyValidation.REG_EX) && !code.trim().isEmpty())
        {
            return true;
        }else if(Objects.isNull(notificationTemplatesEntity)  && code.matches(NotifyValidation.REG_EX)  && !code.trim().isEmpty()){
            return true;
        }else
            throw new NotifyException(NotifyException.CODE_NOT_VALID,HttpStatus.BAD_REQUEST);
    }

    public boolean isValidRowVersion(Integer rowVersion) throws NotifyException {
        if(Objects.isNull(rowVersion) || rowVersion<NotifyConstant.ZERO){
            throw new NotifyException(NotifyException.MANDATORY_FIELD_ROW_VERSION_REQUIRED, HttpStatus.BAD_REQUEST);
        }
        return true;
    }

    public boolean isValidStatus(int status) throws NotifyException {

        NotificationStatusInAppEnum[] notifyStatus = NotificationStatusInAppEnum.values();
        for (NotificationStatusInAppEnum aStatus : notifyStatus) {
            if (aStatus.getValue() == status) {
                return true;
            }
        }
        throw new NotifyException(NotifyException.STATUS_NOT_VALID,HttpStatus.BAD_REQUEST);
    }
}
