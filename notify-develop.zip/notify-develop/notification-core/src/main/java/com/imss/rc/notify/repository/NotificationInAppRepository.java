package com.imss.rc.notify.repository;

import com.imss.rc.notify.assembler.NotificationInAppAssembler;
import com.imss.rc.notify.dto.NotificationInAppDto;
import com.imss.rc.notify.entity.NotificationInAppEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.util.DateUtil;
import com.imss.rc.commons.entity.PageableEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
@Transactional
@Repository
public interface NotificationInAppRepository extends JpaRepository<NotificationInAppEntity, Integer> {

    @Query(value="SELECT ni from NotificationInAppEntity ni where ni.isDeleted=0 and id = ?1 and userName = ?2")
    public NotificationInAppEntity getNotificationInApp(Integer id, String userName);


    default PageableEntity<NotificationInAppEntity> getAllInAppWithFilters(EntityManager em, NotificationInAppDto notificationInAppDto) throws NotifyException {
        PageableEntity<NotificationInAppEntity> retData = new PageableEntity<>();

        List<Predicate> predicateList = new ArrayList<>();
        CriteriaBuilder criteriaBuilder ;
        Root<NotificationInAppEntity> notificationInAppRoot ;

        /** This is to get the count of records */
        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        notificationInAppRoot = countQuery.from(NotificationInAppEntity.class);

        predicateList = applySearchFilters(criteriaBuilder, predicateList, notificationInAppRoot, notificationInAppDto);

        countQuery.select(criteriaBuilder.count(notificationInAppRoot));
        countQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));
        long count = em.createQuery(countQuery).getSingleResult();
        retData.setCount(count);
        /***********************************/


        /** This is to get the list based on the page and limit *******/

        //Clear out the predicateList created using the count root
        predicateList.clear();

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<NotificationInAppEntity> listCriteriaQuery = criteriaBuilder.createQuery(NotificationInAppEntity.class);

        notificationInAppRoot = listCriteriaQuery.from(NotificationInAppEntity.class);

        listCriteriaQuery.select(notificationInAppRoot);
        predicateList = applySearchFilters(criteriaBuilder, predicateList, notificationInAppRoot, notificationInAppDto);

        listCriteriaQuery.where( criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));

        String sortByColumn = NotificationInAppAssembler.getSortByColumn(notificationInAppDto.getPaginationDto().getSortBy());

        Order order;
        if("asc".equals( notificationInAppDto.getPaginationDto().getSortType())){
            order = criteriaBuilder.asc(notificationInAppRoot.get(sortByColumn));
        } else {
            order = criteriaBuilder.desc(notificationInAppRoot.get(sortByColumn));
        }

        TypedQuery<NotificationInAppEntity> query = em.createQuery(listCriteriaQuery.orderBy(order))
                .setFirstResult((notificationInAppDto.getPaginationDto().getPage() - 1) * notificationInAppDto.getPaginationDto().getLimit())
                .setMaxResults(notificationInAppDto.getPaginationDto().getLimit());
        retData.setData(query.getResultList());
        /***********************************/


        return retData;
    }



    default List<Predicate> applySearchFilters(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Root<NotificationInAppEntity> notificationInAppRoot,
                                               NotificationInAppDto notificationInAppDto) throws NotifyException {

        if(notificationInAppDto.getMode().equalsIgnoreCase("cnt") || notificationInAppDto.getMode().equalsIgnoreCase("det")){
            predicateList.add(criteriaBuilder.equal(notificationInAppRoot.get(NotificationInAppEntity.COLUMN_NAME_USER_NAME), notificationInAppDto.getUserName()));
            //Adding filter for Sub type id if present
            if (Optional.ofNullable(notificationInAppDto.getStatus()).isPresent()) {
                predicateList.add(criteriaBuilder.equal(notificationInAppRoot.get(NotificationInAppEntity.COLUMN_NAME_STATUS), notificationInAppDto.getStatus()));
            }
            //Adding filter for date if present
            if (Optional.ofNullable(notificationInAppDto.getStartDate()).isPresent()) {
                if (Optional.ofNullable(notificationInAppDto.getEndDate()).isPresent()) {
                    predicateList.add(criteriaBuilder.between(notificationInAppRoot.get(NotificationInAppEntity.COLUMN_NAME_CREATED_DATE),
                            DateUtil.convertUiStringToDate(notificationInAppDto.getStartDate(), "startDate"),
                            DateUtil.convertUiStringToDate(notificationInAppDto.getEndDate(), "endDate")));
                } else {
                    predicateList.add(criteriaBuilder.between(notificationInAppRoot.get(NotificationInAppEntity.COLUMN_NAME_CREATED_DATE),
                            DateUtil.convertUiStringToDate(notificationInAppDto.getStartDate(), "startDate"),
                            new Date(System.currentTimeMillis())));
                }
            }
            return predicateList;
        }else{
            //Adding filter for date if present
            if (Optional.ofNullable(notificationInAppDto.getStartDate()).isPresent()) {
                if (Optional.ofNullable(notificationInAppDto.getEndDate()).isPresent()) {
                    predicateList.add(criteriaBuilder.between(notificationInAppRoot.get(NotificationInAppEntity.COLUMN_NAME_CREATED_DATE),
                            DateUtil.convertUiStringToDate(notificationInAppDto.getStartDate(), "startDate"),
                            DateUtil.convertUiStringToDate(notificationInAppDto.getEndDate(), "endDate")));
                } else {
                    predicateList.add(criteriaBuilder.between(notificationInAppRoot.get(NotificationInAppEntity.COLUMN_NAME_CREATED_DATE),
                            DateUtil.convertUiStringToDate(notificationInAppDto.getStartDate(), "startDate"),
                            new Date(System.currentTimeMillis())));
                }
            }
            return predicateList;
        }


    }
}
