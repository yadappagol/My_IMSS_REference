package com.imss.rc.notify.controller;


import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.notify.dto.NotificationEventsDto;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.service.NotificationEventsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
public class NotificationEventsControllerImpl implements NotificationEventsController{

    @Autowired
    private NotificationEventsService notificationEventsService;

    @Override
    public NotificationEventsDto addNotificationEvent(NotificationEventsDto notificationEventsDto, HttpServletRequest request) throws NotifyException {
        UserAuthDataHandler.resolveAuthBaseData(notificationEventsDto, request);
        return notificationEventsService.addNotificationEvent(notificationEventsDto);
    }

    @Override
    public NotificationEventsDto updateNotificationEvent(NotificationEventsDto notificationEventsDto, Integer id, HttpServletRequest request) throws NotifyException {
        UserAuthDataHandler.resolveAuthBaseData(notificationEventsDto, request);
        return notificationEventsService.updateNotificationEvent(notificationEventsDto,id);
    }

    @Override
    public NotificationEventsDto getNotificationEventById(Integer id, HttpServletRequest request) throws NotifyException {
        NotificationEventsDto notificationEventsDto=new NotificationEventsDto();
        notificationEventsDto.setId(id);
        UserAuthDataHandler.resolveAuthBaseData(notificationEventsDto, request);
        return notificationEventsService.getNotificationEventById(notificationEventsDto);
    }

    @Override
    public IdDto deleteNotificationEvent(Integer id, HttpServletRequest request) throws NotifyException {
        NotificationEventsDto notificationEventsDto=new NotificationEventsDto();
        notificationEventsDto.setId(id);
        UserAuthDataHandler.resolveAuthBaseData(notificationEventsDto, request);
        return notificationEventsService.deleteNotificationEvent(notificationEventsDto);
    }

    @Override
    public BaseListDto<NotificationEventsDto> getAllNotificationEvents(Integer page, Integer limit, String sortBy, String name, String code, Short isUserOverrideAllowed, String sortType, Integer categoryId, String description, HttpServletRequest request) throws NotifyException {
        NotificationEventsDto dto = new NotificationEventsDto();
        dto.setCode(code);
        dto.setName(name);
        dto.setIsUserOverrideAllowed(isUserOverrideAllowed);
        if(categoryId != null) {
            dto.setCategoryId(categoryId.intValue());
        }
        dto.setDescription(description);
        PaginationDto pageDto = new PaginationDto();
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);

        dto.setPaginationDto(pageDto);
        UserAuthDataHandler.resolveAuthBaseData(dto, request);
        return notificationEventsService.getAllNotificationEvents(dto);
    }
}
