package com.imss.rc.notify.repository;

import com.imss.rc.notify.assembler.NotificationSmsAssembler;
import com.imss.rc.notify.dto.NotificationSmsDto;
import com.imss.rc.notify.entity.NotificationSmsEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.util.DateUtil;
import com.imss.rc.commons.entity.PageableEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface NotificationSmsRepository extends JpaRepository<NotificationSmsEntity,Integer> {
    default PageableEntity<NotificationSmsEntity> getAllSmsWithFilters(EntityManager em, NotificationSmsDto notificationSmsDto)throws NotifyException {

        PageableEntity<NotificationSmsEntity> retData = new PageableEntity<>();

        List<Predicate> predicateList = new ArrayList<>();
        CriteriaBuilder criteriaBuilder ;
        Root<NotificationSmsEntity> notificationSmsRoot ;

        /** This is to get the count of records */
        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        notificationSmsRoot = countQuery.from(NotificationSmsEntity.class);

        predicateList = applySearchFilters(criteriaBuilder, predicateList, notificationSmsRoot, notificationSmsDto);

        countQuery.select(criteriaBuilder.count(notificationSmsRoot));
        countQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));
        long count = em.createQuery(countQuery).getSingleResult();
        retData.setCount(count);
        /***********************************/


        /** This is to get the list based on the page and limit *******/

        //Clear out the predicateList created using the count root
        predicateList.clear();

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<NotificationSmsEntity> listCriteriaQuery = criteriaBuilder.createQuery(NotificationSmsEntity.class);

        notificationSmsRoot = listCriteriaQuery.from(NotificationSmsEntity.class);

        listCriteriaQuery.select(notificationSmsRoot);
        predicateList = applySearchFilters(criteriaBuilder, predicateList, notificationSmsRoot, notificationSmsDto);

        listCriteriaQuery.where( criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));

        String sortByColumn = NotificationSmsAssembler.getSortByColumn(notificationSmsDto.getPaginationDto().getSortBy());

        Order order;
        if("asc".equals( notificationSmsDto.getPaginationDto().getSortType())){
            order = criteriaBuilder.asc(notificationSmsRoot.get(sortByColumn));
        } else {
            order = criteriaBuilder.desc(notificationSmsRoot.get(sortByColumn));
        }

        TypedQuery<NotificationSmsEntity> query = em.createQuery(listCriteriaQuery.orderBy(order))
                .setFirstResult((notificationSmsDto.getPaginationDto().getPage() - 1) * notificationSmsDto.getPaginationDto().getLimit())
                .setMaxResults(notificationSmsDto.getPaginationDto().getLimit());
        retData.setData(query.getResultList());
        /***********************************/


        return retData;
    }



    default List<Predicate> applySearchFilters(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Root<NotificationSmsEntity> smsRoot,
                                               NotificationSmsDto notificationSmsDto) throws NotifyException {


        //Adding filter for date if present
        if (Optional.ofNullable(notificationSmsDto.getStartDate()).isPresent()) {
            if (Optional.ofNullable(notificationSmsDto.getEndDate()).isPresent()) {
                predicateList.add(criteriaBuilder.between(smsRoot.get(NotificationSmsEntity.COLUMN_NAME_CREATED_DATE),
                        DateUtil.convertUiStringToDate(notificationSmsDto.getStartDate(), "startDate"),
                        DateUtil.convertUiStringToDate(notificationSmsDto.getEndDate(), "endDate") ) );
            } else {
                predicateList.add(criteriaBuilder.between(smsRoot.get(NotificationSmsEntity.COLUMN_NAME_CREATED_DATE),
                        DateUtil.convertUiStringToDate(notificationSmsDto.getStartDate(),"startDate"),
                        new Date(System.currentTimeMillis())));
            }
        }


        return predicateList;
    }

}
