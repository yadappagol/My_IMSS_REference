package com.imss.rc.notify.service;

import com.imss.rc.notify.constants.NotifyConstant;
import com.imss.rc.notify.dto.NotificationInAppDto;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.commons.constants.SortTypeConstants;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.ActionTypeEnum;
import com.imss.rc.notify.assembler.NotificationInAppAssembler;
import com.imss.rc.notify.dto.*;
import com.imss.rc.notify.entity.NotificationInAppEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.repository.NotificationInAppRepository;
import com.imss.rc.notify.util.AuditConstants;
import com.imss.rc.notify.util.KafkaNotifySendMessage;
import com.imss.rc.notify.validation.NotifyValidation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import java.util.Objects;

@Service
public class NotificationInAppServiceImpl implements NotificationInAppService{

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationInAppServiceImpl.class);

    @Autowired
    private NotificationInAppRepository notificationInAppRepository;

    @Autowired
    private NotificationInAppAssembler notificationInAppAssembler;

    @Autowired
    private EntityManager em;

    @Autowired
    private NotifyValidation notifyValidation;

    @Autowired
    KafkaNotifySendMessage sendData;

    @Override
    public BaseListDto<NotificationInAppDto> getAllInAppNotification(NotificationInAppDto dto) throws NotifyException {
        BaseListDto<NotificationInAppDto> inAppDtoList = new  BaseListDto<>();
        try{
            if(Objects.isNull(dto.getPaginationDto().getSortType()) || dto.getPaginationDto().getSortType().isEmpty()){
                dto.getPaginationDto().setSortType(SortTypeConstants.SORT_TYPE_DESC);

            }

            if(Objects.isNull(dto.getPaginationDto().getSortBy()) || dto.getPaginationDto().getSortBy().isEmpty()){
                dto.getPaginationDto().setSortBy(NotifyConstant.SORT_BY_CREATED);
                dto.getPaginationDto().setSortType(SortTypeConstants.SORT_TYPE_DESC);
            }
            PageableEntity<NotificationInAppEntity> data = notificationInAppRepository.getAllInAppWithFilters(em,dto);
            PaginationDto pageDto = dto.getPaginationDto();
            pageDto.setCount(data.getCount());

            inAppDtoList.setPagination(pageDto);
            inAppDtoList.setDataList(notificationInAppAssembler.entityListToDtoList(data.getData()));
            inAppDtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            inAppDtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            inAppDtoList.setResponseMessage(NotifyConstant.VIEW_ALL_NOTIFICATION_INAPP_RESPONSE);

        }catch (NotifyException ex) {
            throw ex;
        } catch (Exception ex) {
            LOGGER.error("Exception in findAll:", ex);
            throw new NotifyException(NotifyException.UNABLE_TO_RETRIEVE_TEMPLATE_DETAILS, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return inAppDtoList;
    }

    @Override
    public NotificationInAppDto updateNotificationInApp(NotificationInAppDto notificationInAppDto, Integer id) throws NotifyException{

        try{

            AuditMasterDto auditMasterDto = new AuditMasterDto();
            NotificationInAppEntity notificationInAppEntity = notificationInAppRepository.getNotificationInApp(id,notificationInAppDto.getUserName());
            if(Objects.isNull(notificationInAppEntity)){
                throw new NotifyException(NotifyException.NO_RECORDS_FOUND,HttpStatus.NOT_FOUND);
            }
            if(notifyValidation.isValidStatus(notificationInAppDto.getStatus())) {

                notificationInAppEntity.setStatus(notificationInAppDto.getStatus());
                UserAuthDataHandler.resolveEntityBaseData(notificationInAppDto, notificationInAppEntity);

                notificationInAppEntity.setRowVersion(notificationInAppDto.getRowVersion());
                NotificationInAppEntity notificationInAppEntity1 = notificationInAppRepository.save(notificationInAppEntity);
                notificationInAppAssembler.entityToDto(notificationInAppEntity1);
                notificationInAppDto.setId(notificationInAppEntity1.getId());
                notificationInAppDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                notificationInAppDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                notificationInAppDto.setResponseMessage(NotifyConstant.NOTIFICATION_INAPP_UPDATE_RESPONSE);

                auditMasterDto.setEventId(AuditConstants.NOTIFICATION_TEMPLATE);
                auditMasterDto.setWhen(notificationInAppEntity.getModifiedDate());
                auditMasterDto.setReferenceId(String.valueOf(notificationInAppEntity.getId()));
                auditMasterDto.setActionType(ActionTypeEnum.UPDATE.getValue());
                auditMasterDto.setWho(notificationInAppDto.getModifiedBy());
                auditMasterDto.setDescription(NotifyConstant.UPDATED_NOTIFICATION_INAPP);
                sendData.sendMessage(auditMasterDto);

            }else{
                throw new NotifyException(NotifyException.VALIDATION_FAILD,HttpStatus.BAD_REQUEST);
            }

        }catch (NotifyException ex) {
            throw ex;

        }
        catch (Exception e) {
            LOGGER.error("Exception in updateNotificationInApp:", e);
            throw new NotifyException(NotifyException.UNABLE_TO_UPDATE_NOTIFICATION_IN_APP,HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return notificationInAppDto;
    }

    @Override
    public BaseListDto<NotificationInAppDto> getUserSpecificInAppNotification(NotificationInAppDto dto) {
        BaseListDto<NotificationInAppDto> inAppDtoList = new  BaseListDto<>();
        try{
            if(Objects.isNull(dto.getPaginationDto().getSortType()) || dto.getPaginationDto().getSortType().isEmpty()){
                dto.getPaginationDto().setSortType(SortTypeConstants.SORT_TYPE_ASC);

            }

            if(Objects.isNull(dto.getPaginationDto().getSortBy() ) || dto.getPaginationDto().getSortBy().isEmpty()){
                dto.getPaginationDto().setSortBy(NotifyConstant.SORT_BY_CREATED);
                dto.getPaginationDto().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }
            PageableEntity<NotificationInAppEntity> data = notificationInAppRepository.getAllInAppWithFilters(em,dto);
            PaginationDto pageDto = dto.getPaginationDto();
            pageDto.setCount(data.getCount());
            if(dto.getMode().equalsIgnoreCase(NotifyConstant.COUNT)){
                inAppDtoList.setPagination(pageDto);
                 return inAppDtoList;
            }else if(dto.getMode().equalsIgnoreCase(NotifyConstant.Detail)) {

                inAppDtoList.setPagination(pageDto);
                inAppDtoList.setDataList(notificationInAppAssembler.entityListToDtoList(data.getData()));
                inAppDtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                inAppDtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                inAppDtoList.setResponseMessage(NotifyConstant.VIEW_ALL_NOTIFICATION_INAPP_RESPONSE);
                return inAppDtoList;
            } else {
                throw new NotifyException(NotifyException.MODE_NOT_VALID,HttpStatus.BAD_REQUEST);
            }

        }catch (NotifyException ex) {
            throw ex;
        } catch (Exception ex) {
            LOGGER.error("Exception in getUserSpecificInAppNotification:", ex);
            throw new NotifyException(NotifyException.UNABLE_TO_RETRIEVE_TEMPLATE_DETAILS, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }
}
