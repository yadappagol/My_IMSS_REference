package com.imss.rc.notify.repository;

import com.imss.rc.notify.assembler.NotificationPushAssembler;
import com.imss.rc.notify.dto.NotificationPushDto;
import com.imss.rc.notify.entity.NotificationPushEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.util.DateUtil;
import com.imss.rc.commons.entity.PageableEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface NotificationPushRepository extends JpaRepository<NotificationPushEntity, Integer> {
   default PageableEntity<NotificationPushEntity> getAllPushWithFilters(EntityManager em, NotificationPushDto notificationPushDto) throws NotifyException {
       PageableEntity<NotificationPushEntity> retData = new PageableEntity<>();

       List<Predicate> predicateList = new ArrayList<>();
       CriteriaBuilder criteriaBuilder ;
       Root<NotificationPushEntity> notificationPushRoot ;

       /** This is to get the count of records */
       criteriaBuilder = em.getCriteriaBuilder();
       CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
       notificationPushRoot = countQuery.from(NotificationPushEntity.class);

       predicateList = applySearchFilters(criteriaBuilder, predicateList, notificationPushRoot, notificationPushDto);

       countQuery.select(criteriaBuilder.count(notificationPushRoot));
       countQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));
       long count = em.createQuery(countQuery).getSingleResult();
       retData.setCount(count);
       /***********************************/


       /** This is to get the list based on the page and limit *******/

       //Clear out the predicateList created using the count root
       predicateList.clear();

       criteriaBuilder = em.getCriteriaBuilder();
       CriteriaQuery<NotificationPushEntity> listCriteriaQuery = criteriaBuilder.createQuery(NotificationPushEntity.class);

       notificationPushRoot = listCriteriaQuery.from(NotificationPushEntity.class);

       listCriteriaQuery.select(notificationPushRoot);
       predicateList = applySearchFilters(criteriaBuilder, predicateList, notificationPushRoot, notificationPushDto);

       listCriteriaQuery.where( criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));

       String sortByColumn = NotificationPushAssembler.getSortByColumn(notificationPushDto.getPaginationDto().getSortBy());

       Order order;
       if("asc".equals( notificationPushDto.getPaginationDto().getSortType())){
           order = criteriaBuilder.asc(notificationPushRoot.get(sortByColumn));
       } else {
           order = criteriaBuilder.desc(notificationPushRoot.get(sortByColumn));
       }

       TypedQuery<NotificationPushEntity> query = em.createQuery(listCriteriaQuery.orderBy(order))
               .setFirstResult((notificationPushDto.getPaginationDto().getPage() - 1) * notificationPushDto.getPaginationDto().getLimit())
               .setMaxResults(notificationPushDto.getPaginationDto().getLimit());
       retData.setData(query.getResultList());
       /***********************************/


       return retData;
   }



    default List<Predicate> applySearchFilters(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Root<NotificationPushEntity> notificationPushRoot,
                                               NotificationPushDto notificationPushDto) throws NotifyException {


        //Adding filter for date if present
        if (Optional.ofNullable(notificationPushDto.getStartDate()).isPresent()) {
            if (Optional.ofNullable(notificationPushDto.getEndDate()).isPresent()) {
                predicateList.add(criteriaBuilder.between(notificationPushRoot.get(NotificationPushEntity.COLUMN_NAME_CREATED_DATE),
                        DateUtil.convertUiStringToDate(notificationPushDto.getStartDate(), "startDate"),
                        DateUtil.convertUiStringToDate(notificationPushDto.getEndDate(), "endDate") ) );
            } else {
                predicateList.add(criteriaBuilder.between(notificationPushRoot.get(NotificationPushEntity.COLUMN_NAME_CREATED_DATE),
                        DateUtil.convertUiStringToDate(notificationPushDto.getStartDate(),"startDate"),
                        new Date(System.currentTimeMillis())));
            }
        }


        return predicateList;
   }
}
