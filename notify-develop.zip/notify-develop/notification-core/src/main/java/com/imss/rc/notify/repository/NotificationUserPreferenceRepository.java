package com.imss.rc.notify.repository;


import com.imss.rc.notify.entity.NotificationUserPreferenceEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;
@Transactional
@Repository
public interface NotificationUserPreferenceRepository extends JpaRepository<NotificationUserPreferenceEntity,Integer> {

    @Query(value="from NotificationUserPreferenceEntity up where up.isDeleted=0 and up.userName= :userName")
    public List<NotificationUserPreferenceEntity> findAllByUserName(@Param("userName") String userName);

    @Query(value="SELECT ne FROM NotificationUserPreferenceEntity ne WHERE  userName = ?1 AND eventId = ?2")
    public NotificationUserPreferenceEntity getUser(String userName,Integer eventId);


}


