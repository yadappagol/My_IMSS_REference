package com.imss.rc.notify.service;


import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.notify.dto.SendNotificationDto;

public interface AdminService {
   
   public ResponseDto sendNotification(SendNotificationDto sendNotificationDto);
   
}
