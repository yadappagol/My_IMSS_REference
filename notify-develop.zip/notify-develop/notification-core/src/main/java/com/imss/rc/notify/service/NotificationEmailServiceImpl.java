package com.imss.rc.notify.service;


import com.imss.rc.notify.constants.NotifyConstant;
import com.imss.rc.notify.dto.NotificationEmailDto;
import com.imss.rc.commons.constants.SortTypeConstants;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.notify.assembler.NotificationEmailAssembler;
import com.imss.rc.notify.dto.*;
import com.imss.rc.notify.entity.NotificationEmailEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.repository.NotificationEmailRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import java.util.Objects;

@Service
public class NotificationEmailServiceImpl implements NotificationEmailService {

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationEmailServiceImpl.class);

    @Autowired
    private NotificationEmailRepository notificationEmailRepository;

    @Autowired
    private NotificationEmailAssembler notificationEmailAssembler;

    @Autowired
    private EntityManager em;

    @Override
    public BaseListDto<NotificationEmailDto> getAllEmailNotification(NotificationEmailDto dto) throws NotifyException {

            BaseListDto<NotificationEmailDto> emailDtoList = new BaseListDto<>();

            try {
                if (Objects.isNull(dto.getPaginationDto().getSortType()) || dto.getPaginationDto().getSortType().isEmpty()) {
                    dto.getPaginationDto().setSortType(SortTypeConstants.SORT_TYPE_DESC);

                }

                if (Objects.isNull(dto.getPaginationDto().getSortBy()) || dto.getPaginationDto().getSortBy().isEmpty()) {
                    dto.getPaginationDto().setSortBy(NotifyConstant.SORT_BY_CREATED);
                    dto.getPaginationDto().setSortType(SortTypeConstants.SORT_TYPE_DESC);
                }
                PageableEntity<NotificationEmailEntity> data = notificationEmailRepository.getAllEmailWithFilters(em, dto);
                PaginationDto pageDto = dto.getPaginationDto();
                pageDto.setCount(data.getCount());

                emailDtoList.setPagination(pageDto);
                emailDtoList.setDataList(notificationEmailAssembler.entityListToDtoList(data.getData()));
                emailDtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                emailDtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                emailDtoList.setResponseMessage(NotifyConstant.NOTIFICATION_EMAIL_RESPONSE);

            }catch (NotifyException ex) {
                throw ex;
            } catch (Exception ex) {
                LOGGER.error("Exception in getAllEmailNotification:", ex);
                throw new NotifyException(NotifyException.UNABLE_TO_RETRIEVE_TEMPLATE_DETAILS, HttpStatus.INTERNAL_SERVER_ERROR);
            }

            return emailDtoList;
    }
}
