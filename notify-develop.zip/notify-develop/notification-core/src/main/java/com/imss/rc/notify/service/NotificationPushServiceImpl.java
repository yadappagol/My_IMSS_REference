package com.imss.rc.notify.service;

import com.imss.rc.notify.constants.NotifyConstant;
import com.imss.rc.notify.dto.NotificationPushDto;
import com.imss.rc.commons.constants.SortTypeConstants;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.notify.assembler.NotificationPushAssembler;
import com.imss.rc.notify.dto.*;
import com.imss.rc.notify.entity.NotificationPushEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.repository.NotificationPushRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
@Service
public class  NotificationPushServiceImpl implements NotificationPushService{

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationPushServiceImpl.class);

    @Autowired
    private NotificationPushRepository notificationPushRepository;

    @Autowired
    private NotificationPushAssembler notificationPushAssembler;

    @Autowired
    private EntityManager em;
    @Override
    public BaseListDto<NotificationPushDto> getAllPushNotification(NotificationPushDto dto) throws NotifyException {

        BaseListDto<NotificationPushDto> pushDtoList = new  BaseListDto<>();
        try{
            if(dto.getPaginationDto().getSortType() == null || dto.getPaginationDto().getSortType().isEmpty()){
                dto.getPaginationDto().setSortType(SortTypeConstants.SORT_TYPE_DESC);

            }

            if(dto.getPaginationDto().getSortBy() == null || dto.getPaginationDto().getSortBy().isEmpty()){
                dto.getPaginationDto().setSortBy(NotifyConstant.SORT_BY_CREATED);
                dto.getPaginationDto().setSortType(SortTypeConstants.SORT_TYPE_DESC);
            }
            PageableEntity<NotificationPushEntity> data = notificationPushRepository.getAllPushWithFilters(em,dto);
            PaginationDto pageDto = dto.getPaginationDto();
            pageDto.setCount(data.getCount());

            pushDtoList.setPagination(pageDto);
            pushDtoList.setDataList(notificationPushAssembler.entityListToDtoList(data.getData()));
            pushDtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            pushDtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            pushDtoList.setResponseMessage("List of Notification push Retrieved successfully");


        }catch (NotifyException ex) {
            throw ex;
        } catch (Exception ex) {
            LOGGER.error("Exception in getAllPushNotification:", ex);
            throw new NotifyException(NotifyException.UNABLE_TO_RETRIEVE_TEMPLATE_DETAILS, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return pushDtoList;
    }
}
