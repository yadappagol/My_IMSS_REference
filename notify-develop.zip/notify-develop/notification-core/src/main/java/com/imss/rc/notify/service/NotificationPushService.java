package com.imss.rc.notify.service;

import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.notify.dto.NotificationPushDto;
import com.imss.rc.notify.exception.NotifyException;

public interface NotificationPushService {
   public BaseListDto<NotificationPushDto> getAllPushNotification(NotificationPushDto pushDto) throws NotifyException;
}
