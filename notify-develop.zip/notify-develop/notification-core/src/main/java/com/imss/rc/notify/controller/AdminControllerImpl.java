package com.imss.rc.notify.controller;

import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.notify.dto.SendNotificationDto;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
public class AdminControllerImpl implements AdminController{
    @Autowired
    private AdminService adminService;

    @Override
    public ResponseDto sendNotification(SendNotificationDto sendNotificationDto, HttpServletRequest request) throws NotifyException {
       return adminService.sendNotification(sendNotificationDto);
    }
}
