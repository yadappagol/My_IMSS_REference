package com.imss.rc.notify.controller;

import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.notify.dto.SendNotificationDto;
import com.imss.rc.notify.exception.NotifyException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.servlet.http.HttpServletRequest;


public interface AdminController {
    @PostMapping(value = "/notify/send",consumes = "application/json", produces = "application/json")
    public ResponseDto sendNotification(@RequestBody SendNotificationDto sendNotificationDto, HttpServletRequest request)throws NotifyException;
}
