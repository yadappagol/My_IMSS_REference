package com.imss.rc.notify.service;

import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.notify.dto.NotificationSmsDto;
import com.imss.rc.notify.exception.NotifyException;

public interface NotificationSmsService {

    public BaseListDto<NotificationSmsDto> getAllSmsNotification(NotificationSmsDto dto) throws NotifyException;

}
