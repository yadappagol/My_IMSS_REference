package com.imss.rc.notify.repository;

import com.imss.rc.notify.assembler.NotificationEmailAssembler;
import com.imss.rc.notify.dto.NotificationEmailDto;
import com.imss.rc.notify.entity.NotificationEmailEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.util.DateUtil;
import com.imss.rc.commons.entity.PageableEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface NotificationEmailRepository extends JpaRepository<NotificationEmailEntity,Integer> {

    default PageableEntity<NotificationEmailEntity> getAllEmailWithFilters(EntityManager em, NotificationEmailDto notificationEmailDto) throws NotifyException {

        PageableEntity<NotificationEmailEntity> retData = new PageableEntity<>();

        List<Predicate> predicateList = new ArrayList<>();
        CriteriaBuilder criteriaBuilder ;
        Root<NotificationEmailEntity> notificationEmailRoot ;

        /** This is to get the count of records */
        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        notificationEmailRoot = countQuery.from(NotificationEmailEntity.class);

        predicateList = applySearchFilters(criteriaBuilder, predicateList, notificationEmailRoot, notificationEmailDto);

        countQuery.select(criteriaBuilder.count(notificationEmailRoot));
        countQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));
        long count = em.createQuery(countQuery).getSingleResult();
        retData.setCount(count);
        /***********************************/


        /** This is to get the list based on the page and limit *******/

        //Clear out the predicateList created using the count root
        predicateList.clear();

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<NotificationEmailEntity> listCriteriaQuery = criteriaBuilder.createQuery(NotificationEmailEntity.class);

        notificationEmailRoot = listCriteriaQuery.from(NotificationEmailEntity.class);

        listCriteriaQuery.select(notificationEmailRoot);
        predicateList = applySearchFilters(criteriaBuilder, predicateList, notificationEmailRoot, notificationEmailDto);

        listCriteriaQuery.where( criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));

        String sortByColumn = NotificationEmailAssembler.getSortByColumn(notificationEmailDto.getPaginationDto().getSortBy());

        Order order;
        if("asc".equals( notificationEmailDto.getPaginationDto().getSortType())){
            order = criteriaBuilder.asc(notificationEmailRoot.get(sortByColumn));
        } else {
            order = criteriaBuilder.desc(notificationEmailRoot.get(sortByColumn));
        }

        TypedQuery<NotificationEmailEntity> query = em.createQuery(listCriteriaQuery.orderBy(order))
                .setFirstResult((notificationEmailDto.getPaginationDto().getPage() - 1) * notificationEmailDto.getPaginationDto().getLimit())
                .setMaxResults(notificationEmailDto.getPaginationDto().getLimit());
        retData.setData(query.getResultList());
        /***********************************/


        return retData;
    }



    default List<Predicate> applySearchFilters(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Root<NotificationEmailEntity> emailRoot,
                                               NotificationEmailDto notificationEmailDto) throws NotifyException {


        //Adding filter for date if present
        if (Optional.ofNullable(notificationEmailDto.getStartDate()).isPresent()) {
            if (Optional.ofNullable(notificationEmailDto.getEndDate()).isPresent()) {
                predicateList.add(criteriaBuilder.between(emailRoot.get(NotificationEmailEntity.COLUMN_NAME_CREATED_DATE),
                        DateUtil.convertUiStringToDate(notificationEmailDto.getStartDate(), "startDate"),
                        DateUtil.convertUiStringToDate(notificationEmailDto.getEndDate(), "endDate") ) );
            } else {
                predicateList.add(criteriaBuilder.between(emailRoot.get(NotificationEmailEntity.COLUMN_NAME_CREATED_DATE),
                        DateUtil.convertUiStringToDate(notificationEmailDto.getStartDate(),"startDate"),
                        new Date(System.currentTimeMillis())));
            }
        }


        return predicateList;
    }

}
