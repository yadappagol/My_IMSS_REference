
CREATE TABLE notification_events (
    pk_id int NOT NULL AUTO_INCREMENT,
    code varchar(50),
    name varchar(100),
    description varchar(500),
    category_id int NOT NULL,
    is_user_override_allowed smallint,
    preferences longtext,
    is_deleted smallint,
    created_by varchar(255),
    created_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_by varchar(255),
    modified_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    row_version int,
	CONSTRAINT notification_events_pkey PRIMARY KEY (pk_id)
)ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

CREATE TABLE notification_user_preference (
    pk_id int NOT NULL AUTO_INCREMENT,
	user_name varchar(100) NOT NULL,
	event_id int NOT NULL,
    preferences longtext,
    is_deleted smallint,
    created_by varchar(100),
    created_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_by varchar(100),
    modified_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    row_version int,
	CONSTRAINT notification_user_preference_pkey PRIMARY KEY (pk_id)
)ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;


CREATE TABLE notification_templates (
    pk_id int NOT NULL AUTO_INCREMENT,
	event_id int NOT NULL,
	code varchar(50),
	type smallint,
	name varchar(100),
	description varchar(500),
	template longtext,
	is_deleted smallint,
    created_by varchar(100),
    created_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_by varchar(100),
    modified_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    row_version int,
	CONSTRAINT notification_templates_pkey PRIMARY KEY (pk_id)
)ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

CREATE TABLE notification_requests (
    pk_id int NOT NULL AUTO_INCREMENT,
    template_id int,
    event_id int,
    payload longtext,
	modes varchar(100),
    received_date timestamp,
    received_from int,
	status smallint,
	remarks varchar(500),
	is_deleted smallint,
    created_by varchar(100),
    created_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    modified_by varchar(100),
    modified_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    row_version int,
	CONSTRAINT notification_requests_pkey PRIMARY KEY (pk_id)
)ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

CREATE TABLE notification_sms (
    pk_id int NOT NULL AUTO_INCREMENT,
    request_id int,
    to_number varchar(15),
    message varchar(500),
    status smallint,
    created_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	sent_date timestamp NULL DEFAULT NULL,
	remarks varchar(255),
	is_deleted smallint,
    created_by varchar(100),
    modified_by varchar(100),
    modified_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    row_version int,
	CONSTRAINT notification_sms_pkey PRIMARY KEY (pk_id)
)ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

CREATE TABLE notification_email (
    pk_id int NOT NULL AUTO_INCREMENT,
    request_id int,
    to_emails varchar(500),
    cc_emails varchar(500),
    subject_line varchar(100),
    mail_body longtext,
    status smallint,
    created_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	sent_date timestamp  NULL DEFAULT NULL,
	is_deleted smallint,
    created_by varchar(100),
    modified_by varchar(100),
    modified_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    row_version int,
	CONSTRAINT notification_email_pkey PRIMARY KEY (pk_id)
)ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

CREATE TABLE notification_in_app (
    pk_id int NOT NULL AUTO_INCREMENT,
    request_id int,
    user_name varchar(100),
    title varchar(50),
    content longtext,
    status smallint,
    is_deleted smallint,
    created_by varchar(100),
    created_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	modified_by varchar(100),
    modified_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    row_version int,
	CONSTRAINT notification_in_app_pkey PRIMARY KEY (pk_id)
)ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

CREATE TABLE notification_push (
    pk_id int NOT NULL AUTO_INCREMENT,
    request_id int,
    to_number varchar(15),
    title varchar(50),
    content varchar(255),
    status smallint,
    created_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	sent_date timestamp  NULL DEFAULT NULL,
	is_deleted smallint,
    created_by varchar(100),
    modified_by varchar(100),
    modified_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    row_version int,
	CONSTRAINT notification_push_pkey PRIMARY KEY (pk_id)
)ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;