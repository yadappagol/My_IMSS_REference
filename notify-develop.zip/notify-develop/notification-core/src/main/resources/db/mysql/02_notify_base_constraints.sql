ALTER TABLE notification_events
    ADD CONSTRAINT notification_events_category_id_fkey 
		FOREIGN KEY(category_id) 
			REFERENCES core_data_details(pk_id);
			
ALTER TABLE notification_user_preference
    ADD CONSTRAINT notification_user_preference_event_id_fkey 
		FOREIGN KEY(event_id) 
			REFERENCES notification_events(pk_id);
			
ALTER TABLE notification_templates
    ADD CONSTRAINT notification_templates_event_id_fkey 
		FOREIGN KEY(event_id) 
			REFERENCES notification_events(pk_id);
			
ALTER TABLE notification_requests
    ADD CONSTRAINT notification_requests_template_id_fkey 
		FOREIGN KEY(template_id) 
			REFERENCES notification_templates(pk_id);
			
ALTER TABLE notification_sms
    ADD CONSTRAINT notification_sms_request_id_fkey 
		FOREIGN KEY(request_id) 
			REFERENCES notification_requests(pk_id);
			
ALTER TABLE notification_email
    ADD CONSTRAINT notification_email_request_id_fkey 
		FOREIGN KEY(request_id) 
			REFERENCES notification_requests(pk_id);
			
ALTER TABLE notification_in_app
    ADD CONSTRAINT notification_in_app_request_id_fkey 
		FOREIGN KEY(request_id) 
			REFERENCES notification_requests(pk_id);
			
ALTER TABLE notification_push
    ADD CONSTRAINT notification_push_request_id_fkey 
		FOREIGN KEY(request_id) 
			REFERENCES notification_requests(pk_id);