ALTER TABLE notification_user_preference
    DROP FOREIGN KEY notification_user_preference_event_id_fkey ;

ALTER TABLE notification_events
    DROP FOREIGN KEY notification_events_category_id_fkey;
	
ALTER TABLE notification_templates
    DROP FOREIGN KEY notification_templates_event_id_fkey ;
			
ALTER TABLE notification_requests
    DROP FOREIGN KEY notification_requests_template_id_fkey ;
			
ALTER TABLE notification_sms
    DROP FOREIGN KEY notification_sms_request_id_fkey ;
			
ALTER TABLE notification_email
    DROP FOREIGN KEY notification_email_request_id_fkey ;
			
ALTER TABLE notification_in_app
    DROP FOREIGN KEY notification_in_app_request_id_fkey ;
			
ALTER TABLE notification_push
    DROP FOREIGN KEY notification_push_request_id_fkey ;
			
	
DROP TABLE notification_push;
DROP TABLE notification_in_app;
DROP TABLE notification_email;
DROP TABLE notification_sms;
DROP TABLE notification_requests;
DROP TABLE notification_templates;
DROP TABLE notification_user_preference;
DROP TABLE notification_events;