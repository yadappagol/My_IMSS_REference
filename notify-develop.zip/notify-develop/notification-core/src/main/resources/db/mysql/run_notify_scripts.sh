if [ $# != 6 ]
then
        echo 'USAGE : run_script.sh <iscreatedb> <istestdatarequired> <username> <password> <db> <host>' 
        echo 'example : run_script.sh true false test_user test123 testdb 172.16.2.22' 
else

        if [ $1 == true ]
        then
				echo 'Dropping all tables and constriants'
                mysql -u $3 -h $6 -p$4 $5 < 99_notify_drop_all_tables.sql
                
				echo 'Creating table structures'
				        mysql -u $3 -h $6 -p$4 $5 < 01_notify_base_scripts.sql
                
				echo 'Creating all constraints'
				        mysql -u $3 -h $6 -p$4 $5 < 02_notify_base_constraints.sql
                
				echo 'Inserting all default data'
				        mysql -u $3 -h $6 -p$4 $5 < 03_notify_default_data.sql
				
				echo 'Inserting all template data'
				        mysql -u $3 -h $6 -p$4 $5 < 03_notify_template_data.sql
				
				if [ $2 == true ]
				then
				
					echo 'Inserting test data'
					      mysql -u $3 -h $6 -p$4 $5 < 98_notify_test_default_data.sql
				else
					echo 'Skipping test data insertion'
				fi
        else
                echo 'Skipping creation of database'
        fi
fi
