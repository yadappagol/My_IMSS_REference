ALTER TABLE notification_user_preference
    DROP CONSTRAINT notification_user_preference_event_id_fkey ;

ALTER TABLE notification_events
    DROP CONSTRAINT notification_events_category_id_fkey ;
			
ALTER TABLE notification_templates
    DROP CONSTRAINT notification_templates_event_id_fkey ;
			
ALTER TABLE notification_requests
    DROP CONSTRAINT notification_requests_template_id_fkey ;
			
ALTER TABLE notification_sms
    DROP CONSTRAINT notification_sms_request_id_fkey ;
			
ALTER TABLE notification_email
    DROP CONSTRAINT notification_email_request_id_fkey ;
			
ALTER TABLE notification_in_app
    DROP CONSTRAINT notification_in_app_request_id_fkey ;
			
ALTER TABLE notification_push
    DROP CONSTRAINT notification_sms_request_id_fkey ;
			
	
DROP TABLE notification_push;
DROP TABLE notification_in_app;
DROP TABLE notification_email;
DROP TABLE notification_sms;
DROP TABLE notification_requests;
DROP TABLE notification_templates;
DROP TABLE notification_user_preference;
DROP TABLE notification_events;