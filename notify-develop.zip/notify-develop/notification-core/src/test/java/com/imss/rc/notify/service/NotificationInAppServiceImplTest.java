package com.imss.rc.notify.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.notify.assembler.NotificationInAppAssembler;
import com.imss.rc.notify.dto.NotificationInAppDto;
import com.imss.rc.notify.entity.NotificationInAppEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.util.KafkaNotifySendMessage;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.notify.repository.NotificationInAppRepository;
import com.imss.rc.notify.util.TestConstants;
import com.imss.rc.notify.validation.NotifyValidation;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.imss.rc.notify.util.TestConstants.EXCEPTION_OCCURRED;
import static com.imss.rc.notify.util.TestConstants.TEST_CASE_FAILED;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@SpringBootTest(classes=NotificationInAppServiceImplTest.class)
public class NotificationInAppServiceImplTest {

    @InjectMocks
    private NotificationInAppServiceImpl service;

    @Mock
    private NotificationInAppRepository repository;

    @Mock
    NotificationInAppAssembler assembler;

    @Mock
    private NotifyValidation notifyValidation;
    @Mock
    KafkaNotifySendMessage sendData;

    private NotificationInAppEntity notificationInAppEntity;
    private NotificationInAppDto notificationInAppDto;
    private AuditMasterDto auditMasterDto;
    private PaginationDto paginationDto;
    @Before
    public void init() throws IOException {
        MockitoAnnotations.initMocks(this);
        ObjectMapper mapper = new ObjectMapper();
        notificationInAppEntity=mapper.readValue(ResourceUtils.getFile("classpath:notificationDetails.json"), NotificationInAppEntity.class);
        notificationInAppDto=mapper.readValue(ResourceUtils.getFile("classpath:notificationDetails.json"), NotificationInAppDto.class);
        auditMasterDto=mapper.readValue(ResourceUtils.getFile("classpath:auditMasterDto.json"), AuditMasterDto.class);
        paginationDto=mapper.readValue(ResourceUtils.getFile("classpath:paginationDto.json"), PaginationDto.class);
    }

    @Test
    public void getAllInAppNotificationTest() throws NotifyException
    {
        try {
            List<NotificationInAppEntity> notificationInAppEntityList = new ArrayList<NotificationInAppEntity>();
            List<NotificationInAppDto> notificationInAppDtoList = new ArrayList<NotificationInAppDto>();
            notificationInAppEntityList.add(notificationInAppEntity);
            notificationInAppDtoList.add(notificationInAppDto);

            PageableEntity<NotificationInAppEntity> list = new PageableEntity<>();
            list.setData(notificationInAppEntityList);
            list.setCount(TestConstants.COUNT);

            notificationInAppDto.setPaginationDto(paginationDto);

            when(repository.getAllInAppWithFilters(Mockito.any(),Mockito.any())).thenReturn(list);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(notificationInAppDtoList);
            BaseListDto<NotificationInAppDto> result = service.getAllInAppNotification(notificationInAppDto);
            assertEquals(TestConstants.RESULT_DATA, result.getDataList().size());
            assertEquals(TestConstants.COUNT, result.getPagination().getCount());
        }
        catch(Exception e)
        {
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }

    @Test
    public void getAllInAppNotificationNegTest() throws NotifyException
    {
        try {
            List<NotificationInAppEntity> notificationInAppEntityList = new ArrayList<NotificationInAppEntity>();
            List<NotificationInAppDto> notificationInAppDtoList = new ArrayList<NotificationInAppDto>();
            notificationInAppEntityList.add(notificationInAppEntity);
            notificationInAppDtoList.add(notificationInAppDto);
            PageableEntity<NotificationInAppEntity> list = new PageableEntity<>();
            list.setData(notificationInAppEntityList);
            list.setCount(TestConstants.COUNT);

            notificationInAppDto.setPaginationDto(paginationDto);

            when(repository.getAllInAppWithFilters(Mockito.any(),Mockito.any())).thenReturn(null);
            service.getAllInAppNotification(notificationInAppDto);

        }catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.UNABLE_TO_RETRIEVE_TEMPLATE_DETAILS);
        }
    }

    @Test
    public void updateNotificationInAppTest(){
      try {
          notificationInAppDto.setStatus(TestConstants.STATUS);
          notificationInAppDto.setUserName(TestConstants.USER_NAME);
          Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
          when(repository.getNotificationInApp(Mockito.any(), Mockito.anyString())).thenReturn(notificationInAppEntity);
          when(repository.save(notificationInAppEntity)).thenReturn(notificationInAppEntity);
          when(notifyValidation.isValidStatus(notificationInAppDto.getStatus())).thenReturn(true);
          when(assembler.entityToDto(notificationInAppEntity)).thenReturn(notificationInAppDto);
          NotificationInAppDto notificationInAppDto1 = service.updateNotificationInApp(notificationInAppDto, notificationInAppDto.getId());
          Assertions.assertEquals(TestConstants.USER_NAME, notificationInAppDto1.getUserName());
      }catch(Exception e)
      {
            Assertions.assertEquals(EXCEPTION_OCCURRED,"Exception Occurred");
      }
    }

    @Test
    public void updateNotificationInAppNullTest(){
        try {
            when(repository.getNotificationInApp(Mockito.any(), Mockito.anyString())).thenReturn(null);
            service.updateNotificationInApp(notificationInAppDto, notificationInAppDto.getId());

        } catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.NO_RECORDS_FOUND);
        }
    }

    @Test
    public void updateNotificationInAppValidationTest(){
        try {
            notificationInAppDto.setStatus(TestConstants.STATUS);
            notificationInAppDto.setUserName(TestConstants.USER_NAME);
            when(repository.getNotificationInApp(Mockito.any(), Mockito.anyString())).thenReturn(notificationInAppEntity);
            when(notifyValidation.isValidStatus(notificationInAppDto.getStatus())).thenReturn(false);
            service.updateNotificationInApp(notificationInAppDto, notificationInAppDto.getId());

        } catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.VALIDATION_FAILD);
        }
    }

    @Test
    public void updateNotificationInAppExceptionTest(){
        try {
            notificationInAppDto.setStatus(TestConstants.STATUS);
            notificationInAppDto.setUserName(TestConstants.USER_NAME);
            Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
            when(repository.getNotificationInApp(Mockito.any(), Mockito.anyString())).thenReturn(notificationInAppEntity);
            when(repository.save(notificationInAppEntity)).thenThrow(new NullPointerException(TestConstants.EXCEPTION_TEST));
            when(notifyValidation.isValidStatus(notificationInAppDto.getStatus())).thenReturn(true);
            when(assembler.entityToDto(notificationInAppEntity)).thenReturn(notificationInAppDto);
            service.updateNotificationInApp(notificationInAppDto, notificationInAppDto.getId());

        }catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.UNABLE_TO_UPDATE_NOTIFICATION_IN_APP);
        }
    }

    @Test
    public void getUserSpecificInAppNotificationTest() throws NotifyException
    {
        try {
            List<NotificationInAppEntity> notificationInAppEntityList = new ArrayList<NotificationInAppEntity>();
            List<NotificationInAppDto> notificationInAppDtoList = new ArrayList<NotificationInAppDto>();
            notificationInAppEntityList.add(notificationInAppEntity);
            notificationInAppDto.setMode(TestConstants.COUNT_MODE);
            notificationInAppDtoList.add(notificationInAppDto);

            PageableEntity<NotificationInAppEntity> list = new PageableEntity<>();
            list.setData(notificationInAppEntityList);
            list.setCount(TestConstants.COUNT);

            notificationInAppDto.setPaginationDto(paginationDto);

            when(repository.getAllInAppWithFilters(Mockito.any(),Mockito.any())).thenReturn(list);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(notificationInAppDtoList);
            BaseListDto<NotificationInAppDto> result = service.getUserSpecificInAppNotification(notificationInAppDto);
            assertEquals(TestConstants.RESULT_DATA_ZERO, result.getDataList().size());
            assertEquals(TestConstants.COUNT, result.getPagination().getCount());
            notificationInAppDto.setMode(TestConstants.DETAIL_MODE);
            BaseListDto<NotificationInAppDto> result1 = service.getUserSpecificInAppNotification(notificationInAppDto);
            assertEquals(TestConstants.RESULT_DATA, result1.getDataList().size());
            assertEquals(TestConstants.COUNT, result1.getPagination().getCount());
        }
        catch(Exception e)
        {
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }

    @Test
    public void getUserSpecificInAppNotificationModeTest() throws NotifyException
    {
        try {
            List<NotificationInAppEntity> notificationInAppEntityList = new ArrayList<NotificationInAppEntity>();
            List<NotificationInAppDto> notificationInAppDtoList = new ArrayList<NotificationInAppDto>();
            notificationInAppEntityList.add(notificationInAppEntity);

            notificationInAppDto.setMode(TestConstants.FALSE_COUNT_MODE);
            notificationInAppDtoList.add(notificationInAppDto);

            PageableEntity<NotificationInAppEntity> list = new PageableEntity<>();
            list.setData(notificationInAppEntityList);
            list.setCount(TestConstants.COUNT);

            notificationInAppDto.setPaginationDto(paginationDto);
            when(repository.getAllInAppWithFilters(Mockito.any(),Mockito.any())).thenReturn(list);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(notificationInAppDtoList);
            BaseListDto<NotificationInAppDto> result = service.getUserSpecificInAppNotification(notificationInAppDto);
            assertEquals(TestConstants.RESULT_DATA_ZERO, result.getDataList().size());
            assertEquals(TestConstants.COUNT, result.getPagination().getCount());
            notificationInAppDto.setMode(TestConstants.FALSE_DETAIL_MODE);
            BaseListDto<NotificationInAppDto> result1 = service.getUserSpecificInAppNotification(notificationInAppDto);
            assertEquals(TestConstants.RESULT_DATA_ZERO, result1.getDataList().size());
            assertEquals(TestConstants.COUNT, result1.getPagination().getCount());
        }catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.MODE_NOT_VALID);
        }
    }

    @Test
    public void getUserSpecificInAppNotificationExceptionTest() throws NotifyException
    {
        try {
            notificationInAppDto.setPaginationDto(paginationDto);
            when(repository.getAllInAppWithFilters(Mockito.any(),Mockito.any())).thenThrow(new NullPointerException(TestConstants.EXCEPTION_TEST));
            service.getUserSpecificInAppNotification(notificationInAppDto);

        }catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.UNABLE_TO_RETRIEVE_TEMPLATE_DETAILS);
        }
    }
}
