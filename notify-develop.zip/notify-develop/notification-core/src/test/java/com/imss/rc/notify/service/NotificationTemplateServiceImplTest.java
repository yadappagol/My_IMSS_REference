
package com.imss.rc.notify.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.notify.assembler.NotificationTemplatesAssembler;
import com.imss.rc.notify.dto.NotificationTemplatesDto;
import com.imss.rc.notify.dto.TemplateDto;
import com.imss.rc.notify.entity.NotificationTemplatesEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.util.KafkaNotifySendMessage;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.notify.dto.*;
import com.imss.rc.notify.repository.NotificationTemplateRepository;

import com.imss.rc.notify.util.TestConstants;
import com.imss.rc.notify.validation.NotifyValidation;

import org.hibernate.HibernateException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


import static com.imss.rc.notify.util.TestConstants.EXCEPTION_OCCURRED;
import static com.imss.rc.notify.util.TestConstants.TEST_CASE_FAILED;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= NotificationTemplateServiceImplTest.class)
public class NotificationTemplateServiceImplTest {

    @InjectMocks
    private NotificationTemplateServiceImpl service;

    @Mock
    private NotificationTemplateRepository repository;

    @Mock
    private NotificationTemplatesAssembler assembler;
    @Mock
    private NotifyValidation validation;
    @Mock
    KafkaNotifySendMessage sendData;

    private NotificationTemplatesDto notificationTemplatesDto;

    private NotificationTemplatesEntity notificationTemplatesEntity;

    private AuditMasterDto auditMasterDto;

    private PaginationDto paginationDto;

    @Before
    public void init() throws IOException {

        MockitoAnnotations.initMocks(this);
        ObjectMapper mapper = new ObjectMapper();
        auditMasterDto=mapper.readValue(ResourceUtils.getFile("classpath:auditMasterDto.json"), AuditMasterDto.class);
        notificationTemplatesDto=mapper.readValue(ResourceUtils.getFile("classpath:notificationTemplatesDto.json"), NotificationTemplatesDto.class);
        notificationTemplatesEntity=mapper.readValue(ResourceUtils.getFile("classpath:notificationTemplatesEntity.json"), NotificationTemplatesEntity.class);
        paginationDto=mapper.readValue(ResourceUtils.getFile("classpath:paginationDto.json"), PaginationDto.class);
    }

    @Test
    public void addTemplateTest() throws NotifyException {
        try {

            Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
            when(repository.save(notificationTemplatesEntity)).thenReturn(notificationTemplatesEntity);
            when(assembler.entityToDto(notificationTemplatesEntity)).thenReturn(notificationTemplatesDto);
            when(assembler.dtoToEntity(notificationTemplatesDto)).thenReturn(notificationTemplatesEntity);
            when(validation.isValidEventId(notificationTemplatesDto.getEventId())).thenReturn(true);
            when(validation.isValidCode(notificationTemplatesDto.getCode())).thenReturn(true);
            when(validation.isValidType(notificationTemplatesDto.getType())).thenReturn(true);
            when(validation.isValidName(notificationTemplatesDto.getName())).thenReturn(true);
            when(validation.isValidTemplate(notificationTemplatesDto.getTemplate())).thenReturn(true);
            NotificationTemplatesDto notificationTemplatesDto1 = service.addTemplate(notificationTemplatesDto);
            Assertions.assertEquals(TestConstants.NOTIFICATION_TEMPLATE_NAME, notificationTemplatesDto1.getName());
        }
        catch(Exception e)
        {
            Assertions.assertEquals(EXCEPTION_OCCURRED,"Exception Occurred");
        }
    }

    @Test
    public void addTemplateNegTest() throws NotifyException {
        try {

            Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
            when(repository.save(notificationTemplatesEntity)).thenReturn(notificationTemplatesEntity);
            when(assembler.entityToDto(notificationTemplatesEntity)).thenReturn(notificationTemplatesDto);
            when(assembler.dtoToEntity(notificationTemplatesDto)).thenReturn(notificationTemplatesEntity);
            when(validation.isValidEventId(notificationTemplatesDto.getEventId())).thenReturn(false);
            when(validation.isValidCode(notificationTemplatesDto.getCode())).thenReturn(true);
            when(validation.isValidType(notificationTemplatesDto.getType())).thenReturn(true);
            when(validation.isValidName(notificationTemplatesDto.getName())).thenReturn(true);
            when(validation.isValidTemplate(notificationTemplatesDto.getTemplate())).thenReturn(true);
            service.addTemplate(notificationTemplatesDto);

        }
        catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.VALIDATION_FAILD);
        }
    }

    @Test
    public void addTemplateExceptionTest() throws NotifyException {
        try{

        Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
        when(repository.save(notificationTemplatesEntity)).thenThrow(new HibernateException(TestConstants.EXCEPTION_TEST));
        when(assembler.entityToDto(notificationTemplatesEntity)).thenReturn(notificationTemplatesDto);
        when(assembler.dtoToEntity(notificationTemplatesDto)).thenReturn(notificationTemplatesEntity);
        when(validation.isValidEventId(notificationTemplatesDto.getEventId())).thenReturn(true);
        when(validation.isValidCode(notificationTemplatesDto.getCode())).thenReturn(true);
        when(validation.isValidType(notificationTemplatesDto.getType())).thenReturn(true);
        when(validation.isValidName(notificationTemplatesDto.getName())).thenReturn(true);
        when(validation.isValidTemplate(notificationTemplatesDto.getTemplate())).thenReturn(true);
        service.addTemplate(notificationTemplatesDto);

    }
    catch(NotifyException e)
    {
        assertEquals(e.getCode(), NotifyException.UNABLE_TO_ADD_NOTIFICATION_TEMPLATE);
    }
    }

    @Test
    public void findAllTest() throws NotifyException
    {
        try {
            BaseListDto<NotificationTemplatesDto> templatesDtoList = new  BaseListDto<>();
            List<NotificationTemplatesEntity> notificationTemplatesEntityList = new ArrayList<NotificationTemplatesEntity>();
            notificationTemplatesEntityList.add(notificationTemplatesEntity);

            List<NotificationTemplatesDto> notificationTemplatesDtoList = new ArrayList<NotificationTemplatesDto>();
            notificationTemplatesDtoList.add(notificationTemplatesDto);

            PageableEntity<NotificationTemplatesEntity> list = new PageableEntity<>();
            list.setData(notificationTemplatesEntityList);
            list.setCount(TestConstants.COUNT);

            notificationTemplatesDto.setPaginationDto(paginationDto);
            ObjectMapper mapper = new ObjectMapper();
            templatesDtoList.setPagination(paginationDto);

            Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
            when(repository.getAllSubCategoryWithFilters(Mockito.any(),Mockito.any())).thenReturn(list);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(notificationTemplatesDtoList);
            templatesDtoList.setDataList(assembler.entityListToDtoList(list.getData()));
            for(int i=0; i<templatesDtoList.getDataList().size(); i++){
                templatesDtoList.getDataList().get(i).setTemplate(mapper.readValue(list.getData().get(i).getTemplate(), new TypeReference<List<TemplateDto>>() {}));
            }
            BaseListDto<NotificationTemplatesDto> result = service.findAll(notificationTemplatesDto);
            assertEquals(TestConstants.RESULT_DATA, result.getDataList().size());
            assertEquals(TestConstants.COUNT, result.getPagination().getCount());
        }
        catch(Exception e)
        {
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }


    @Test
    public void findAllExceptionTest() throws NotifyException{
        try {
            BaseListDto<NotificationTemplatesDto> templatesDtoList = new  BaseListDto<>();
            List<NotificationTemplatesEntity> notificationTemplatesEntityList = new ArrayList<NotificationTemplatesEntity>();
            notificationTemplatesEntityList.add(notificationTemplatesEntity);

            PaginationDto pageDto = new PaginationDto();
            List<NotificationTemplatesDto> notificationTemplatesDtoList = new ArrayList<NotificationTemplatesDto>();
            notificationTemplatesDtoList.add(notificationTemplatesDto);

            PageableEntity<NotificationTemplatesEntity> list = new PageableEntity<>();
            list.setData(notificationTemplatesEntityList);
            list.setCount(paginationDto.getCount());

            PaginationDto paginationDto = new PaginationDto();
            paginationDto.setLimit(paginationDto.getLimit());
            paginationDto.setPage(paginationDto.getPage());

            notificationTemplatesDto.setPaginationDto(paginationDto);
            templatesDtoList.setPagination(pageDto);

            Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
            when(repository.getAllSubCategoryWithFilters(Mockito.any(),Mockito.any())).thenThrow(new HibernateException(TestConstants.EXCEPTION_TEST));
            when(assembler.entityListToDtoList(list.getData())).thenReturn(notificationTemplatesDtoList);
            BaseListDto<NotificationTemplatesDto> result = service.findAll(notificationTemplatesDto);
            assertEquals(TestConstants.RESULT_DATA, result.getDataList().size());
            assertEquals(paginationDto.getCount(), result.getPagination().getCount());
        }
        catch(NotifyException e)
        {
            assertEquals(e.getCode(), NotifyException.UNABLE_TO_RETRIEVE_TEMPLATE_DETAILS);
        }
    }
    @Test
    public void deleteTemplateTest() throws NotifyException {
        try {

            Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
            when(repository.getById(Mockito.anyInt())).thenReturn(notificationTemplatesEntity);
            when(repository.save(notificationTemplatesEntity)).thenReturn(notificationTemplatesEntity);
            IdDto dto = service.deleteTemplate(notificationTemplatesDto);
            Assertions.assertEquals(TestConstants.NOTIFICATION_TEMPLATE_ID,dto.getId());
        } catch (Exception ex){
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }

    }

    @Test
    public void deleteTemplateNegTest() throws NotifyException {
        try {
            Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
            when(repository.getById(Mockito.anyInt())).thenReturn(notificationTemplatesEntity);
            when(repository.save(notificationTemplatesEntity)).thenThrow(new NullPointerException(TestConstants.EXCEPTION_TEST));
            service.deleteTemplate(notificationTemplatesDto);

        } catch(NotifyException e)
        {
            Assertions.assertEquals(NotifyException.TEMPLATE_NOT_DELETED, e.getCode());
        }

    }

    @Test
    public void getTemplatesByIdTest() throws NotifyException {
        try {

            Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
            when(repository.getById((notificationTemplatesEntity.getId()))).thenReturn(notificationTemplatesEntity);
            when(assembler.entityToDto(notificationTemplatesEntity)).thenReturn(notificationTemplatesDto);
            NotificationTemplatesDto  notificationTemplatesDto2  = service.getTemplatesById(notificationTemplatesDto);
            assertEquals(TestConstants.NOTIFICATION_TEMPLATE_NAME, notificationTemplatesDto2.getName());
        } catch (Exception ex) {
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }


    }

    @Test
    public void getTemplatesByIdNegTest() throws NotifyException {
        try {

            when(assembler.entityToDto(notificationTemplatesEntity)).thenReturn(notificationTemplatesDto);
            when(repository.getById((notificationTemplatesEntity.getId()))).thenReturn(null);
            service.getTemplatesById(notificationTemplatesDto);

        } catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.TEMPLATE_NOT_FOUND);
        }


    }

    @Test
    public void getTemplatesByIdExceptionTest() throws NotifyException {
        try {
            when(repository.getById(notificationTemplatesEntity.getId())).thenThrow(new HibernateException(TestConstants.EXCEPTION_TEST));
            when(assembler.entityToDto(notificationTemplatesEntity)).thenReturn(notificationTemplatesDto);
            NotificationTemplatesDto  notificationTemplatesDto2  = service.getTemplatesById(notificationTemplatesDto);
            System.out.println(notificationTemplatesDto2);
            assertEquals(TestConstants.NOTIFICATION_TEMPLATE_NAME, notificationTemplatesDto.getName());
        } catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.TEMPLATE_NOT_FOUND);
        }


    }

    @Test
    public void updateNotificationTemplateTest() throws NotifyException {
        try {
            Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
            when(repository.getById(notificationTemplatesDto.getId())).thenReturn(notificationTemplatesEntity);
            when(repository.save(notificationTemplatesEntity)).thenReturn(notificationTemplatesEntity);
            when(assembler.entityToDto(notificationTemplatesEntity)).thenReturn(notificationTemplatesDto);
            when(validation.isValidEventId(notificationTemplatesDto.getEventId())).thenReturn(true);
            when(validation.isTemplateValidCodeForUpdate(notificationTemplatesDto.getCode(),notificationTemplatesDto.getId())).thenReturn(true);
            when(validation.isValidType(notificationTemplatesDto.getType())).thenReturn(true);
            when(validation.isValidName(notificationTemplatesDto.getName())).thenReturn(true);
            when(validation.isValidTemplate(notificationTemplatesDto.getTemplate())).thenReturn(true);
            when(validation.isValidRowVersion(notificationTemplatesDto.getRowVersion())).thenReturn(true);
            NotificationTemplatesDto notificationTemplatesDto1 = service.updateNotificationTemplate(notificationTemplatesDto,notificationTemplatesDto.getId());
            Assertions.assertEquals(TestConstants.NOTIFICATION_TEMPLATE_NAME, notificationTemplatesDto1.getName());
        }
        catch(Exception e)
        {
            Assertions.assertEquals(EXCEPTION_OCCURRED,"Exception Occurred");
        }
    }

    @Test
    public void updateNotificationTemplateNegTest() throws NotifyException {
        try {
            when(repository.getById(notificationTemplatesDto.getId())).thenReturn(notificationTemplatesEntity);
            when(repository.save(notificationTemplatesEntity)).thenReturn(notificationTemplatesEntity);
            when(assembler.entityToDto(notificationTemplatesEntity)).thenReturn(notificationTemplatesDto);
            when(validation.isValidEventId(notificationTemplatesDto.getEventId())).thenReturn(false);
            when(validation.isTemplateValidCodeForUpdate(notificationTemplatesDto.getCode(),notificationTemplatesDto.getId())).thenReturn(true);
            when(validation.isValidType(notificationTemplatesDto.getType())).thenReturn(true);
            when(validation.isValidName(notificationTemplatesDto.getName())).thenReturn(true);
            when(validation.isValidTemplate(notificationTemplatesDto.getTemplate())).thenReturn(true);
            when(validation.isValidRowVersion(notificationTemplatesDto.getRowVersion())).thenReturn(true);
            NotificationTemplatesDto notificationTemplatesDto1 = service.updateNotificationTemplate(notificationTemplatesDto,notificationTemplatesDto.getId());
            Assertions.assertEquals(TestConstants.NOTIFICATION_TEMPLATE_NAME, notificationTemplatesDto1.getName());
        }
        catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.VALIDATION_FAILD);
        }
    }


    @Test
    public void updateNotificationTemplateNullTest() throws NotifyException {
        try {

            when(repository.getById(notificationTemplatesDto.getId())).thenReturn(null);
            service.updateNotificationTemplate(notificationTemplatesDto,notificationTemplatesDto.getId());

        }catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.NO_RECORDS_FOUND);
        }
    }


    @Test
    public void updateNotificationTemplateExceptionTest() throws NotifyException {
        try {

            when(repository.getById(notificationTemplatesDto.getId())).thenReturn(notificationTemplatesEntity);
            when(repository.save(notificationTemplatesEntity)).thenThrow(new HibernateException(TestConstants.EXCEPTION_TEST));
            when(assembler.entityToDto(notificationTemplatesEntity)).thenReturn(notificationTemplatesDto);
            when(validation.isValidEventId(notificationTemplatesDto.getEventId())).thenReturn(true);
            when(validation.isTemplateValidCodeForUpdate(notificationTemplatesDto.getCode(),notificationTemplatesDto.getId())).thenReturn(true);
            when(validation.isValidType(notificationTemplatesDto.getType())).thenReturn(true);
            when(validation.isValidName(notificationTemplatesDto.getName())).thenReturn(true);
            when(validation.isValidTemplate(notificationTemplatesDto.getTemplate())).thenReturn(true);
            when(validation.isValidRowVersion(notificationTemplatesDto.getRowVersion())).thenReturn(true);
            service.updateNotificationTemplate(notificationTemplatesDto,notificationTemplatesDto.getId());

        }
        catch(NotifyException e)
        {
            assertEquals(e.getCode(), NotifyException.UNABLE_TO_UPDATE_NOTIFICATION_TEMPLATE);
        }
    }

}

