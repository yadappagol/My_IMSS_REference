package com.imss.rc.notify.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.notify.assembler.NotificationPushAssembler;
import com.imss.rc.notify.dto.NotificationPushDto;
import com.imss.rc.notify.entity.NotificationPushEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.notify.repository.NotificationPushRepository;
import com.imss.rc.notify.util.TestConstants;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.imss.rc.notify.util.TestConstants.EXCEPTION_OCCURRED;
import static com.imss.rc.notify.util.TestConstants.TEST_CASE_FAILED;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@SpringBootTest(classes=NotificationPushServiceImplTest.class)
public class NotificationPushServiceImplTest {

    @InjectMocks
    private NotificationPushServiceImpl service;

    @Mock
    private NotificationPushRepository repository;

    @Mock
    NotificationPushAssembler assembler;

    private NotificationPushEntity notificationPushEntity;
    private NotificationPushDto notificationPushDto;
    private PaginationDto paginationDto;
    @Before
    public void init() throws IOException {
        MockitoAnnotations.initMocks(this);
        ObjectMapper mapper = new ObjectMapper();
        notificationPushEntity=mapper.readValue(ResourceUtils.getFile("classpath:notificationDetails.json"), NotificationPushEntity.class);
        notificationPushDto=mapper.readValue(ResourceUtils.getFile("classpath:notificationDetails.json"), NotificationPushDto.class);
        paginationDto=mapper.readValue(ResourceUtils.getFile("classpath:paginationDto.json"), PaginationDto.class);
    }

    @Test
    public void getAllPushNotificationTest() throws NotifyException
    {
        try {
            List<NotificationPushEntity> notificationPushEntityList = new ArrayList<NotificationPushEntity>();
            List<NotificationPushDto> notificationPushDtoList = new ArrayList<NotificationPushDto>();
            notificationPushEntityList.add(notificationPushEntity);
            notificationPushDtoList.add(notificationPushDto);

            PageableEntity<NotificationPushEntity> list = new PageableEntity<>();
            list.setData(notificationPushEntityList);
            list.setCount(TestConstants.COUNT);

            notificationPushDto.setPaginationDto(paginationDto);

            when(repository.getAllPushWithFilters(Mockito.any(),Mockito.any())).thenReturn(list);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(notificationPushDtoList);
            BaseListDto<NotificationPushDto> result = service.getAllPushNotification(notificationPushDto);
            assertEquals(TestConstants.RESULT_DATA, result.getDataList().size());
            assertEquals(TestConstants.COUNT, result.getPagination().getCount());
        }
        catch(Exception e)
        {
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }

    @Test
    public void getAllPushNotificationNegTest() throws NotifyException
    {
        try {
            List<NotificationPushEntity> notificationPushEntityList = new ArrayList<NotificationPushEntity>();
            List<NotificationPushDto> notificationPushDtoList = new ArrayList<NotificationPushDto>();
            notificationPushEntityList.add(notificationPushEntity);
            notificationPushDtoList.add(notificationPushDto);

            PageableEntity<NotificationPushEntity> list = new PageableEntity<>();
            list.setData(notificationPushEntityList);
            list.setCount(TestConstants.COUNT);

            notificationPushDto.setPaginationDto(paginationDto);

            when(repository.getAllPushWithFilters(Mockito.any(),Mockito.any())).thenReturn(null);
            service.getAllPushNotification(notificationPushDto);

        }catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.UNABLE_TO_RETRIEVE_TEMPLATE_DETAILS);
        }
    }
}
