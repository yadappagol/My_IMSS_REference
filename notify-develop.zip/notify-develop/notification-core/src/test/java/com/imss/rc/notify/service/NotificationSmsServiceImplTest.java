package com.imss.rc.notify.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.notify.assembler.NotificationSmsAssembler;
import com.imss.rc.notify.dto.NotificationSmsDto;
import com.imss.rc.notify.entity.NotificationSmsEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.notify.repository.NotificationSmsRepository;
import com.imss.rc.notify.util.TestConstants;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.imss.rc.notify.util.TestConstants.EXCEPTION_OCCURRED;
import static com.imss.rc.notify.util.TestConstants.TEST_CASE_FAILED;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@SpringBootTest(classes=NotificationSmsServiceImplTest.class)
public class NotificationSmsServiceImplTest {

    @InjectMocks
    private NotificationSmsServiceImpl service;

    @Mock
    private NotificationSmsRepository repository;

    @Mock
    NotificationSmsAssembler assembler;
    private NotificationSmsEntity notificationSmsEntity;
    private NotificationSmsDto notificationSmsDto;
    private PaginationDto paginationDto;
    @Before
    public void init() throws IOException {
        MockitoAnnotations.initMocks(this);
        ObjectMapper mapper = new ObjectMapper();
        notificationSmsEntity=mapper.readValue(ResourceUtils.getFile("classpath:notificationDetails.json"), NotificationSmsEntity.class);
        notificationSmsDto=mapper.readValue(ResourceUtils.getFile("classpath:notificationDetails.json"), NotificationSmsDto.class);
        paginationDto=mapper.readValue(ResourceUtils.getFile("classpath:paginationDto.json"), PaginationDto.class);
    }


    @Test
    public void getAllSmsNotificationTest() throws NotifyException
    {
        try {
            List<NotificationSmsEntity> notificationSmsEntityList = new ArrayList<NotificationSmsEntity>();
            List<NotificationSmsDto> notificationSmsDtoList = new ArrayList<NotificationSmsDto>();
            notificationSmsEntityList.add(notificationSmsEntity);
            notificationSmsDtoList.add(notificationSmsDto);

            PageableEntity<NotificationSmsEntity> list = new PageableEntity<>();
            list.setData(notificationSmsEntityList);
            list.setCount(TestConstants.COUNT);

            notificationSmsDto.setPaginationDto(paginationDto);

            when(repository.getAllSmsWithFilters(Mockito.any(),Mockito.any())).thenReturn(list);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(notificationSmsDtoList);
            BaseListDto<NotificationSmsDto> result = service.getAllSmsNotification(notificationSmsDto);
            assertEquals(TestConstants.RESULT_DATA, result.getDataList().size());
            assertEquals(TestConstants.COUNT, result.getPagination().getCount());
        }
        catch(Exception e)
        {
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }

    @Test
    public void getAllSmsNotificationNegTest() throws NotifyException
    {
        try {
            List<NotificationSmsEntity> notificationSmsEntityList = new ArrayList<NotificationSmsEntity>();
            List<NotificationSmsDto> notificationSmsDtoList = new ArrayList<>();
            notificationSmsEntityList.add(notificationSmsEntity);
            notificationSmsDtoList.add(notificationSmsDto);
            PageableEntity<NotificationSmsEntity> list = new PageableEntity<>();
            list.setData(notificationSmsEntityList);
            list.setCount(TestConstants.COUNT);

            notificationSmsDto.setPaginationDto(paginationDto);

            when(repository.getAllSmsWithFilters(Mockito.any(),Mockito.any())).thenReturn(null);
            service.getAllSmsNotification(notificationSmsDto);

        }
        catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.UNABLE_TO_RETRIEVE_TEMPLATE_DETAILS);
        }
    }
}
