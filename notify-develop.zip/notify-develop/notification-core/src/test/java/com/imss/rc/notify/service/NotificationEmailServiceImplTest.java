package com.imss.rc.notify.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.notify.assembler.NotificationEmailAssembler;
import com.imss.rc.notify.dto.NotificationEmailDto;
import com.imss.rc.notify.entity.NotificationEmailEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.notify.repository.NotificationEmailRepository;
import com.imss.rc.notify.util.TestConstants;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.imss.rc.notify.util.TestConstants.EXCEPTION_OCCURRED;
import static com.imss.rc.notify.util.TestConstants.TEST_CASE_FAILED;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@SpringBootTest(classes=NotificationEventsServiceImplTest.class)
public class NotificationEmailServiceImplTest {

    @InjectMocks
    private NotificationEmailServiceImpl service;

    @Mock
    private NotificationEmailRepository repository;

    @Mock
    NotificationEmailAssembler assembler;

    private NotificationEmailEntity notificationEmailEntity;
    private NotificationEmailDto notificationEmailDto;
    private PaginationDto paginationDto;

    @Before
    public void init() throws IOException {
        MockitoAnnotations.initMocks(this);
        ObjectMapper mapper = new ObjectMapper();
        notificationEmailEntity=mapper.readValue(ResourceUtils.getFile("classpath:notificationDetails.json"), NotificationEmailEntity.class);
        notificationEmailDto=mapper.readValue(ResourceUtils.getFile("classpath:notificationDetails.json"), NotificationEmailDto.class);
        paginationDto=mapper.readValue(ResourceUtils.getFile("classpath:paginationDto.json"), PaginationDto.class);
    }

    @Test
    public void getAllEmailNotificationTest() throws NotifyException
    {
        try {
            List<NotificationEmailEntity> notificationEmailEntityList = new ArrayList<>();
            notificationEmailEntityList.add(notificationEmailEntity);
            List<NotificationEmailDto> notificationEmailDtoList = new ArrayList<>();
            notificationEmailDtoList.add(notificationEmailDto);
            PageableEntity<NotificationEmailEntity> list = new PageableEntity<>();
            list.setData(notificationEmailEntityList);
            list.setCount(TestConstants.COUNT);

            notificationEmailDto.setPaginationDto(paginationDto);

            when(repository.getAllEmailWithFilters(Mockito.any(),Mockito.any())).thenReturn(list);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(notificationEmailDtoList);
            BaseListDto<NotificationEmailDto> result = service.getAllEmailNotification(notificationEmailDto);
            assertEquals(TestConstants.RESULT_DATA, result.getDataList().size());
            assertEquals(TestConstants.COUNT, result.getPagination().getCount());
        }
        catch(Exception e)
        {
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }

    @Test
    public void getAllEmailNotificationNegTest() throws NotifyException
    {
        try {
            List<NotificationEmailEntity> notificationEmailEntityList = new ArrayList<>();
            notificationEmailEntityList.add(notificationEmailEntity);
            List<NotificationEmailDto> notificationEmailDtoList = new ArrayList<>();
            notificationEmailDtoList.add(notificationEmailDto);

            PageableEntity<NotificationEmailEntity> list = new PageableEntity<>();
            list.setData(notificationEmailEntityList);
            list.setCount(TestConstants.COUNT);

            notificationEmailDto.setPaginationDto(paginationDto);

            when(repository.getAllEmailWithFilters(Mockito.any(),Mockito.any())).thenReturn(null);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(notificationEmailDtoList);
            service.getAllEmailNotification(notificationEmailDto);

        }catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.UNABLE_TO_RETRIEVE_TEMPLATE_DETAILS);
        }
    }
}
