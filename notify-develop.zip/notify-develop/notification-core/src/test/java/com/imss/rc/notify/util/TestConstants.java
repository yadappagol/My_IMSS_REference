package com.imss.rc.notify.util;

public class TestConstants {

    private TestConstants()
    {

    }

    public static final boolean TEST_CASE_FAILED = true;

    public static final String EXECUTION_WENT_THROUGH = "Execution went through";
    public static final String EXCEPTION_OCCURRED = "Exception occurred";
    public static final String CHECKING_RIGHT_ERROR_CODE = "Checking Right Error Code";
    public static final String NOTIFICATION_TEMPLATE_NAME = "User Registration OTP";
    public static final String NOTIFICATION_EVENT_NAME = "User Registration";
    public static final String EXCEPTION_TEST = "Test";
    public static final String USER_NAME = "health";
    public static final String COUNT_MODE = "cnt";
    public static final String DETAIL_MODE = "det";
    public static final Integer STATUS = 1;
    public static final Integer EVENT_ID = 101;
    public static final Integer NOTIFICATION_TEMPLATE_ID = 1;
    public static final Integer USER_PREFERENCE_ID = 1;
    public static final int COUNT = 27;
    public static final int RESULT_DATA = 1;
    public static final int RESULT_DATA_ZERO = 0;
    public static final String FALSE_COUNT_MODE = "count";
    public static final String FALSE_DETAIL_MODE = "detail";
}
