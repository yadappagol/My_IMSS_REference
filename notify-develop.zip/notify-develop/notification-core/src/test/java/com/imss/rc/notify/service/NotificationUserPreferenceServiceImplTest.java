package com.imss.rc.notify.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.notify.assembler.NotificationUserPreferenceAssembler;
import com.imss.rc.notify.dto.NotificationUserPreferenceDto;
import com.imss.rc.notify.dto.PreferencesDto;
import com.imss.rc.notify.entity.NotificationEventsEntity;
import com.imss.rc.notify.entity.NotificationUserPreferenceEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.util.KafkaNotifySendMessage;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import com.imss.rc.notify.dto.*;
import com.imss.rc.notify.repository.NotificationEventsRepository;
import com.imss.rc.notify.repository.NotificationUserPreferenceRepository;
import com.imss.rc.notify.util.TestConstants;
import com.imss.rc.notify.validation.NotifyValidation;
import org.hibernate.HibernateException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.imss.rc.notify.util.TestConstants.EXCEPTION_OCCURRED;
import static com.imss.rc.notify.util.TestConstants.TEST_CASE_FAILED;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@SpringBootTest(classes=NotificationUserPreferenceServiceImplTest.class)
public class NotificationUserPreferenceServiceImplTest {

    @InjectMocks
    private NotificationUserPreferenceServiceImpl service;

    @Mock
    private NotificationUserPreferenceRepository repository;

    @Mock
    private NotificationEventsRepository eventRepository;

    @Mock
    private NotifyValidation validation;

    @Mock
    NotificationUserPreferenceAssembler assembler;

    @Mock
    KafkaNotifySendMessage sendData;

    private NotificationUserPreferenceDto notificationUserPreferenceDto;
    private NotificationUserPreferenceEntity notificationUserPreferenceEntity;
    private AuditMasterDto auditMasterDto;
    private NotificationEventsEntity notificationEventsEntity;


    @Before
    public void init() throws IOException {
        MockitoAnnotations.initMocks(this);
        ObjectMapper mapper = new ObjectMapper();
        notificationUserPreferenceDto=mapper.readValue(ResourceUtils.getFile("classpath:notificationUserPreferenceDto.json"), NotificationUserPreferenceDto.class);
        notificationUserPreferenceEntity=mapper.readValue(ResourceUtils.getFile("classpath:notificationUserPreferenceEntity.json"), NotificationUserPreferenceEntity.class);
        auditMasterDto=mapper.readValue(ResourceUtils.getFile("classpath:auditMasterDto.json"), AuditMasterDto.class);
        notificationEventsEntity=mapper.readValue(ResourceUtils.getFile("classpath:notificationEventsEntity.json"), NotificationEventsEntity.class);

    }


    @Test
    public void updateUserPreferencesTest() throws NotifyException {
        try {

            notificationUserPreferenceEntity.setIsDeleted(((short) GlobalYesNoEnum.NO.getValue()));
            Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
            when(repository.getUser(Mockito.any(),Mockito.any())).thenReturn(notificationUserPreferenceEntity);
            when(repository.save(notificationUserPreferenceEntity)).thenReturn(notificationUserPreferenceEntity);
            when(assembler.entityToDto(notificationUserPreferenceEntity)).thenReturn(notificationUserPreferenceDto);
            when(validation.ispreferencesValid(notificationUserPreferenceDto.getPreferences())).thenReturn(true);
            NotificationUserPreferenceDto notificationUserPreferenceDto1 = service.updateUserPreferences(notificationUserPreferenceDto,notificationUserPreferenceDto.getUserName(),notificationUserPreferenceDto.getEventId());
            assertEquals(TestConstants.EVENT_ID, notificationUserPreferenceDto1.getEventId());
            when(repository.getUser(Mockito.any(),Mockito.any())).thenReturn(null);
            when(eventRepository.getNotificationEvent(Mockito.any())).thenReturn(notificationEventsEntity);
            NotificationUserPreferenceDto notificationUserPreferenceDto2 = service.updateUserPreferences(notificationUserPreferenceDto,notificationUserPreferenceDto.getUserName(),notificationUserPreferenceDto.getEventId());
            assertEquals(TestConstants.USER_PREFERENCE_ID, notificationUserPreferenceDto2.getId());
        }
        catch(Exception e)
        {
            assertEquals(EXCEPTION_OCCURRED,"Exception Occurred");
        }
    }

    @Test
    public void updateUserPreferencesNotifyExceptionTest() throws NotifyException {
        try {

            notificationUserPreferenceEntity.setIsDeleted(((short) GlobalYesNoEnum.NO.getValue()));
            Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
            when(repository.getUser(Mockito.any(),Mockito.any())).thenReturn(notificationUserPreferenceEntity);
            when(repository.save(notificationUserPreferenceEntity)).thenReturn(notificationUserPreferenceEntity);
            when(assembler.entityToDto(notificationUserPreferenceEntity)).thenReturn(notificationUserPreferenceDto);
            when(validation.ispreferencesValid(notificationUserPreferenceDto.getPreferences())).thenReturn(true);
            NotificationUserPreferenceDto notificationUserPreferenceDto1 = service.updateUserPreferences(notificationUserPreferenceDto,notificationUserPreferenceDto.getUserName(),notificationUserPreferenceDto.getEventId());
            assertEquals(TestConstants.EVENT_ID, notificationUserPreferenceDto1.getEventId());
            when(repository.getUser(Mockito.any(),Mockito.any())).thenReturn(null);
            notificationEventsEntity.setIsUserOverrideAllowed((short) GlobalYesNoEnum.NO.getValue());
            when(eventRepository.getNotificationEvent(Mockito.any())).thenReturn(notificationEventsEntity);
            NotificationUserPreferenceDto notificationUserPreferenceDto2 = service.updateUserPreferences(notificationUserPreferenceDto,notificationUserPreferenceDto.getUserName(),notificationUserPreferenceDto.getEventId());
            assertEquals(TestConstants.USER_PREFERENCE_ID, notificationUserPreferenceDto2.getId());
        }catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.USER_OVERRIDE_NOT_ALLOWED);
        }
    }

    @Test
    public void updateUserPreferencesExceptionTest() throws NotifyException {
        try {

            when(repository.getUser(Mockito.any(),Mockito.any())).thenThrow(new HibernateException(TestConstants.EXCEPTION_TEST));
            when(validation.ispreferencesValid(notificationUserPreferenceDto.getPreferences())).thenReturn(true);
            service.updateUserPreferences(notificationUserPreferenceDto,notificationUserPreferenceDto.getUserName(),notificationUserPreferenceDto.getEventId());

        }catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.USER_OVERRIDE_NOT_ALLOWED);
        }
    }

    @Test
    public void updateUserPreferencesNegTest() throws NotifyException {
        try {
            when(validation.ispreferencesValid(notificationUserPreferenceDto.getPreferences())).thenReturn(false);
            service.updateUserPreferences(notificationUserPreferenceDto,notificationUserPreferenceDto.getUserName(),notificationUserPreferenceDto.getEventId());

        } catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.VALIDATION_FAILD);
        }
    }

    @Test
    public void getUserSpecificPreferencesTest() throws NotifyException {
        try {

            notificationUserPreferenceEntity.setIsDeleted(((short) GlobalYesNoEnum.NO.getValue()));
            when(repository.getUser(Mockito.any(),Mockito.any())).thenReturn(notificationUserPreferenceEntity);
            when(assembler.entityToDto(notificationUserPreferenceEntity)).thenReturn(notificationUserPreferenceDto);
            NotificationUserPreferenceDto  notificationUserPreferenceDto1  = service.getUserSpecificPreferences(notificationUserPreferenceDto.getUserName(),notificationUserPreferenceDto.getEventId());
            assertEquals(TestConstants.EVENT_ID, notificationUserPreferenceDto1.getEventId());
        } catch (Exception ex) {
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }

    @Test
    public void getUserSpecificPreferencesNegTest() throws NotifyException {
        try {
            notificationUserPreferenceEntity.setIsDeleted(((short) GlobalYesNoEnum.YES.getValue()));
            when(repository.getUser(Mockito.any(),Mockito.any())).thenReturn(null);
            when(assembler.entityToDto(notificationUserPreferenceEntity)).thenReturn(notificationUserPreferenceDto);
            NotificationUserPreferenceDto  notificationUserPreferenceDto1  = service.getUserSpecificPreferences(notificationUserPreferenceDto.getUserName(),notificationUserPreferenceDto.getEventId());
            assertEquals(TestConstants.EVENT_ID, notificationUserPreferenceDto1.getEventId());
        }catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.EVENT_SPECIFIC_USER_PREFERENCE_NOT_FOUND);
        }
    }

    @Test
    public void getUserSpecificPreferencesExceptionTest() throws NotifyException {
        try {
            when(repository.getUser(Mockito.any(),Mockito.any())).thenThrow(new NullPointerException(TestConstants.EXCEPTION_TEST));;
            NotificationUserPreferenceDto  notificationUserPreferenceDto1  = service.getUserSpecificPreferences(notificationUserPreferenceDto.getUserName(),notificationUserPreferenceDto.getEventId());
            assertEquals(TestConstants.EVENT_ID, notificationUserPreferenceDto1.getEventId());
        }catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.EVENT_SPECIFIC_USER_PREFERENCE_NOT_FOUND);
        }
    }

    @Test
    public void getAllPreferencesByUserNameTest() throws NotifyException
    {
        try {
            BaseListDto<NotificationUserPreferenceDto> preferenceDtoList = new  BaseListDto<>();
            List<NotificationUserPreferenceEntity> userPreferenceEntityList = new ArrayList<NotificationUserPreferenceEntity>();
            List<NotificationUserPreferenceDto> userPreferenceDtoList = new ArrayList<NotificationUserPreferenceDto>();
            userPreferenceEntityList.add(notificationUserPreferenceEntity);
            userPreferenceDtoList.add(notificationUserPreferenceDto);

            ObjectMapper mapper = new ObjectMapper();
            when(repository.findAllByUserName(Mockito.any())).thenReturn(userPreferenceEntityList);
            when(assembler.entityListToDtoList(userPreferenceEntityList)).thenReturn(userPreferenceDtoList);
            preferenceDtoList.setDataList(assembler.entityListToDtoList(userPreferenceEntityList));
            for(int i=0; i<preferenceDtoList.getDataList().size(); i++){
                preferenceDtoList.getDataList().get(i).setPreferences(mapper.readValue(userPreferenceEntityList.get(i).getPreferences(), PreferencesDto.class));
            }
            BaseListDto<NotificationUserPreferenceDto> result = service.getAllPreferencesByUserName(notificationUserPreferenceDto.getUserName());
            assertEquals(TestConstants.EVENT_ID, result.getDataList().get(0).getEventId());
        }
        catch(Exception e)
        {
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }

    @Test
    public void getAllPreferencesByUserNameNegTest() throws NotifyException
    {
        try {
            when(repository.findAllByUserName(Mockito.any())).thenReturn(null);
            service.getAllPreferencesByUserName(notificationUserPreferenceDto.getUserName());

        }catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.USER_PREFERENCE_LIST_NOT_FOUND);
        }

    }

    @Test
    public void getAllPreferencesByUserNameExceptionTest() throws NotifyException
    {
        try {
            when(repository.findAllByUserName(Mockito.any())).thenThrow(new NullPointerException(TestConstants.EXCEPTION_TEST));;
            service.getAllPreferencesByUserName(notificationUserPreferenceDto.getUserName());

        }catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.USER_PREFERENCE_LIST_NOT_FOUND);

        }

    }

}
