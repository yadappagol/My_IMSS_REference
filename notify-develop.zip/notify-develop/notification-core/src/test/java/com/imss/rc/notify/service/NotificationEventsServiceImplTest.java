package com.imss.rc.notify.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.notify.assembler.NotificationEventsAssembler;
import com.imss.rc.notify.dto.NotificationEventsDto;
import com.imss.rc.notify.entity.NotificationEventsEntity;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.notify.util.KafkaNotifySendMessage;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.notify.repository.NotificationEventsRepository;
import com.imss.rc.notify.util.TestConstants;
import com.imss.rc.notify.validation.NotifyValidation;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.ResourceUtils;

import javax.persistence.EntityManager;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.imss.rc.notify.util.TestConstants.EXCEPTION_OCCURRED;
import static com.imss.rc.notify.util.TestConstants.TEST_CASE_FAILED;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@SpringBootTest(classes=NotificationEventsServiceImplTest.class)
public class NotificationEventsServiceImplTest {

    @InjectMocks
    private NotificationEventsServiceImpl service;

    @Mock
    private NotificationEventsRepository repository;

    @Mock
    private NotifyValidation validation;

    @Mock
    NotificationEventsAssembler assembler;

    @Mock
    EntityManager em;

    @Mock
    KafkaNotifySendMessage sendData;

    private NotificationEventsEntity notificationEventsEntity;
    private NotificationEventsDto notificationEventsDto;
    private AuditMasterDto auditMasterDto;
    private PaginationDto paginationDto;

    @Before
    public void init() throws IOException {
        MockitoAnnotations.initMocks(this);
        ObjectMapper mapper = new ObjectMapper();
        notificationEventsEntity=mapper.readValue(ResourceUtils.getFile("classpath:notificationEventsEntity.json"), NotificationEventsEntity.class);
        notificationEventsDto=mapper.readValue(ResourceUtils.getFile("classpath:notificationEventsDto.json"), NotificationEventsDto.class);
        auditMasterDto=mapper.readValue(ResourceUtils.getFile("classpath:auditMasterDto.json"), AuditMasterDto.class);
        paginationDto=mapper.readValue(ResourceUtils.getFile("classpath:paginationDto.json"), PaginationDto.class);
    }

    @Test
    public void addNotificationEventTest() throws NotifyException {
        try {

            when(repository.save(notificationEventsEntity)).thenReturn(notificationEventsEntity);
            when(assembler.entityToDto(notificationEventsEntity)).thenReturn(notificationEventsDto);
            when(assembler.dtoToEntity(notificationEventsDto)).thenReturn(notificationEventsEntity);
            when(validation.isUserOverrideValid(notificationEventsDto.getIsUserOverrideAllowed())).thenReturn(true);
            when(validation.isNotifyEventValidCode(notificationEventsDto.getCode())).thenReturn(true);
            when(validation.ispreferencesValid(notificationEventsDto.getPreferences())).thenReturn(true);
            when(validation.isValidName(notificationEventsDto.getName())).thenReturn(true);
            when(validation.isCategoryValid(notificationEventsDto.getCategoryId())).thenReturn(true);
            NotificationEventsDto notificationEventsDto1 = service.addNotificationEvent(notificationEventsDto);
            assertEquals(TestConstants.NOTIFICATION_EVENT_NAME, notificationEventsDto1.getName());
        }
        catch(Exception e)
        {
            assertEquals(EXCEPTION_OCCURRED,"Exception Occurred");
        }
    }

    @Test
    public void addNotificationEventNegTest() throws NotifyException {
        try {

            when(validation.isUserOverrideValid(notificationEventsDto.getIsUserOverrideAllowed())).thenReturn(true);
            when(validation.isNotifyEventValidCode(notificationEventsDto.getCode())).thenReturn(false);
            when(validation.ispreferencesValid(notificationEventsDto.getPreferences())).thenReturn(true);
            when(validation.isValidName(notificationEventsDto.getName())).thenReturn(true);
            service.addNotificationEvent(notificationEventsDto);

        }
        catch(NotifyException e)
        {
           Assertions.assertEquals(e.getCode(),NotifyException.VALIDATION_FAILD);
        }
    }

    @Test
    public void addNotificationEventExceptionTest() throws NotifyException {
        try {
            when(repository.save(notificationEventsEntity)).thenThrow(new NullPointerException(TestConstants.EXCEPTION_TEST));
            when(assembler.dtoToEntity(notificationEventsDto)).thenReturn(notificationEventsEntity);
            when(validation.isUserOverrideValid(notificationEventsDto.getIsUserOverrideAllowed())).thenReturn(true);
            when(validation.isNotifyEventValidCode(notificationEventsDto.getCode())).thenReturn(true);
            when(validation.ispreferencesValid(notificationEventsDto.getPreferences())).thenReturn(true);
            when(validation.isValidName(notificationEventsDto.getName())).thenReturn(true);
            when(validation.isCategoryValid(notificationEventsDto.getCategoryId())).thenReturn(true);
            service.addNotificationEvent(notificationEventsDto);

        }
        catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.UNABLE_TO_ADD_NOTIFICATION_EVENT);
        }
    }

    @Test
    public void updateNotificationEventNegTest() throws NotifyException {
        try {
            when(repository.getNotificationEvent(notificationEventsEntity.getId())).thenReturn(notificationEventsEntity);
            when(repository.save(notificationEventsEntity)).thenReturn(notificationEventsEntity);
            when(assembler.entityToDto(notificationEventsEntity)).thenReturn(notificationEventsDto);
            when(validation.isUserOverrideValid(notificationEventsDto.getIsUserOverrideAllowed())).thenReturn(true);
            when(validation.isValidCodeForUpdate(notificationEventsDto.getCode(),notificationEventsDto.getId())).thenReturn(false);
            when(validation.ispreferencesValid(notificationEventsDto.getPreferences())).thenReturn(true);
            when(validation.isValidName(notificationEventsDto.getName())).thenReturn(true);
            when(validation.isValidRowVersion(notificationEventsDto.getRowVersion())).thenReturn(true);
            when(validation.isCategoryValid(notificationEventsDto.getCategoryId())).thenReturn(true);
            service.updateNotificationEvent(notificationEventsDto,notificationEventsDto.getId());

        }
        catch(NotifyException e)
        {
           Assertions.assertEquals(e.getCode(),NotifyException.VALIDATION_FAILD);
        }
    }

    @Test
    public void updateNotificationEventNullTest() throws NotifyException {
        try {
            when(repository.getNotificationEvent(notificationEventsDto.getId())).thenReturn(null);
            NotificationEventsDto notificationEventsDto1 = service.updateNotificationEvent(notificationEventsDto,notificationEventsDto.getId());
            assertEquals(TestConstants.NOTIFICATION_EVENT_NAME, notificationEventsDto1.getName());
        }
        catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.NO_RECORDS_FOUND);
        }
    }

    @Test
    public void updateNotificationEventExceptionTest() throws NotifyException {
        try {
            when(repository.getNotificationEvent(notificationEventsEntity.getId())).thenThrow(new NullPointerException(TestConstants.EXCEPTION_TEST));
            when(repository.save(notificationEventsEntity)).thenReturn(notificationEventsEntity);
            when(assembler.entityToDto(notificationEventsEntity)).thenReturn(notificationEventsDto);
            when(validation.isUserOverrideValid(notificationEventsDto.getIsUserOverrideAllowed())).thenReturn(true);
            when(validation.isValidCodeForUpdate(notificationEventsDto.getCode(),notificationEventsDto.getId())).thenReturn(true);
            when(validation.ispreferencesValid(notificationEventsDto.getPreferences())).thenReturn(true);
            when(validation.isValidName(notificationEventsDto.getName())).thenReturn(true);
            when(validation.isValidRowVersion(notificationEventsDto.getRowVersion())).thenReturn(true);
            when(validation.isCategoryValid(notificationEventsDto.getCategoryId())).thenReturn(true);
            service.updateNotificationEvent(notificationEventsDto,notificationEventsDto.getId());

        }
        catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.UNABLE_TO_UPDATE_NOTIFICATION_EVENT);
        }
    }


    @Test
    public void updateNotificationEventTest() throws NotifyException {
        try {
            Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
            when(repository.getNotificationEvent(notificationEventsEntity.getId())).thenReturn(notificationEventsEntity);
            when(repository.save(notificationEventsEntity)).thenReturn(notificationEventsEntity);
            when(assembler.entityToDto(notificationEventsEntity)).thenReturn(notificationEventsDto);
            when(validation.isUserOverrideValid(notificationEventsDto.getIsUserOverrideAllowed())).thenReturn(true);
            when(validation.isValidCodeForUpdate(notificationEventsDto.getCode(),notificationEventsDto.getId())).thenReturn(true);
            when(validation.ispreferencesValid(notificationEventsDto.getPreferences())).thenReturn(true);
            when(validation.isValidName(notificationEventsDto.getName())).thenReturn(true);
            when(validation.isValidRowVersion(notificationEventsDto.getRowVersion())).thenReturn(true);
            when(validation.isCategoryValid(notificationEventsDto.getCategoryId())).thenReturn(true);
            NotificationEventsDto notificationEventsDto1 = service.updateNotificationEvent(notificationEventsDto,notificationEventsDto.getId());
            assertEquals(TestConstants.NOTIFICATION_EVENT_NAME, notificationEventsDto1.getName());
        }
        catch(Exception e)
        {
            assertEquals(EXCEPTION_OCCURRED,"Exception Occurred");
        }
    }

    @Test
    public void deleteNotificationEventTest() throws NotifyException {
        try {
            when(repository.getNotificationEvent(Mockito.anyInt())).thenReturn(notificationEventsEntity);
            when(repository.save(notificationEventsEntity)).thenReturn(notificationEventsEntity);
            IdDto dto = service.deleteNotificationEvent(notificationEventsDto);
            Assertions.assertEquals(TestConstants.EVENT_ID,dto.getId());
        } catch (Exception ex){
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }

    }

    @Test
    public void deleteNotificationEventNegTest() throws NotifyException {
        try {
            when(repository.getNotificationEvent(Mockito.anyInt())).thenReturn(null);
            service.deleteNotificationEvent(notificationEventsDto);

        }catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.NOTIFICATION_EVENT_NOT_FOUND);
        }

    }

    @Test
    public void deleteNotificationEventExceptionTest() throws NotifyException {
        try {
            when(repository.getNotificationEvent(Mockito.anyInt())).thenReturn(notificationEventsEntity);
            when(repository.save(notificationEventsEntity)).thenThrow(new NullPointerException(TestConstants.EXCEPTION_TEST));
            service.deleteNotificationEvent(notificationEventsDto);

        }catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.NOTIFICATION_EVENT_NOT_DELETED);
        }

    }

    @Test
    public void getNotificationEventByIdTest() throws NotifyException {
        try {
            Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
            when(repository.getNotificationEvent(notificationEventsEntity.getId())).thenReturn(notificationEventsEntity);
            when(assembler.entityToDto(notificationEventsEntity)).thenReturn(notificationEventsDto);
            NotificationEventsDto  notificationTemplatesDto1  = service.getNotificationEventById(notificationEventsDto);
            Assert.assertEquals(TestConstants.NOTIFICATION_EVENT_NAME, notificationTemplatesDto1.getName());
        } catch (Exception ex) {
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }

    @Test
    public void getNotificationEventByIdNegTest() throws NotifyException {
        try {
            when(repository.getNotificationEvent(notificationEventsDto.getId())).thenReturn(null);
             service.getNotificationEventById(notificationEventsDto);

        }catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.NOTIFICATION_EVENT_NOT_FOUND);
        }
    }

    @Test
    public void getNotificationEventByIdExceptionTest() throws NotifyException {
        try {
            Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
            when(repository.getNotificationEvent(notificationEventsEntity.getId())).thenThrow(new NullPointerException(TestConstants.EXCEPTION_TEST));
            when(assembler.entityToDto(notificationEventsEntity)).thenReturn(notificationEventsDto);
            service.getNotificationEventById(notificationEventsDto);

        } catch (NotifyException e) {
            Assertions.assertEquals(e.getCode(),NotifyException.NOTIFICATION_EVENT_NOT_FOUND);
        }
    }

    @Test
    public void getAllNotificationEventsTest() throws NotifyException
    {
        try {
            List<NotificationEventsEntity> notificationEventsEntityList = new ArrayList<NotificationEventsEntity>();
            notificationEventsEntityList.add(notificationEventsEntity);

            List<NotificationEventsDto> notificationEventsDtoList = new ArrayList<NotificationEventsDto>();
            notificationEventsDtoList.add(notificationEventsDto);

            PageableEntity<NotificationEventsEntity> list = new PageableEntity<>();
            list.setData(notificationEventsEntityList);
            list.setCount(TestConstants.COUNT);

            notificationEventsDto.setPaginationDto(paginationDto);
            Mockito.doCallRealMethod().doNothing().when(sendData).sendMessage(auditMasterDto);
            when(repository.getAllNotificationEventsWithFilters(Mockito.any(),Mockito.any())).thenReturn(list);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(notificationEventsDtoList);
            BaseListDto<NotificationEventsDto> result = service.getAllNotificationEvents(notificationEventsDto);
            Assert.assertEquals(TestConstants.RESULT_DATA, result.getDataList().size());
            Assert.assertEquals(TestConstants.COUNT, result.getPagination().getCount());
        }
        catch(Exception e)
        {
            Assert.assertTrue(EXCEPTION_OCCURRED, TEST_CASE_FAILED);
        }
    }

    @Test
    public void getAllNotificationEventsExceptionTest() throws NotifyException
    {
        try {
            notificationEventsDto.setPaginationDto(paginationDto);
            when(repository.getAllNotificationEventsWithFilters(Mockito.any(),Mockito.any())).thenThrow(new NullPointerException(TestConstants.EXCEPTION_TEST));
            service.getAllNotificationEvents(notificationEventsDto);

        }
        catch(NotifyException e)
        {
            Assertions.assertEquals(e.getCode(),NotifyException.NOTIFICATION_EVENTS_LIST_NOT_RETRIEVED);
        }
    }

    @Test
    public void findByIdTest() {
        when(repository.getNotificationEvent(Mockito.anyInt())).thenReturn(notificationEventsEntity);
        service.findById(notificationEventsEntity.getId());
    }


}
