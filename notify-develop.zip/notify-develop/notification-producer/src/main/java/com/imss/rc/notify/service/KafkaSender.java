package com.imss.rc.notify.service;

import com.imss.rc.notify.dto.NotificationRequestsDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


@Service
@Component
public class KafkaSender {
    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaSender.class);

    @Autowired
    @Qualifier("notifyProducerTemplate")
    private KafkaTemplate<String, NotificationRequestsDto> kafkaTemplate1;

    @Value("${kafka.rc.notify.send.topic}")
    private String topicName;

    @Autowired
    public KafkaSender(
            @Qualifier("notifyProducerTemplate") KafkaTemplate<String, NotificationRequestsDto> kafkaTemplate) {
        this.kafkaTemplate1 = kafkaTemplate;
    }

    public void sendData(NotificationRequestsDto notification) {
        LOGGER.debug(String.format("#### -> Producing message -> %s", notification));
        kafkaTemplate1.send(topicName,notification);
        LOGGER.info("message send successfully");

    }
}
