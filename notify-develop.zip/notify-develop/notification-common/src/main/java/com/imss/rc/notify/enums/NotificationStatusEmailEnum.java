package com.imss.rc.notify.enums;

public enum NotificationStatusEmailEnum {
    NOT_SENT("Not Sent", 0),
    SENT("Sent",1),
    ERROR_IN_SENDING("Error in Sending",2);

    private String name;
    private Integer value;
    NotificationStatusEmailEnum(String name, Integer value) {
        this.name = name;
        this.value = value;
    }

    public Integer getValue(){
        return this.value;
    }
    public String getName(){
        return this.name;
    }
}
