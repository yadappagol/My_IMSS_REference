package com.imss.rc.notify.dto;

import com.imss.rc.commons.constants.Constants;
import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.PaginationDto;
import lombok.Data;


import java.text.SimpleDateFormat;
import java.util.Date;

@Data
public class NotificationEmailDto extends BaseDto {
    private Integer requestId;
    private String toEmails;
    private String ccEmails;
    private String subjectLine;
    private String mailBody;
    private int status;
    private Date sentDate;
    private String sentDateDisplay;

    private String mode;
    private String  startDate;
    private String  endDate;
    private PaginationDto paginationDto;

    public NotificationEmailDto() {

    }

    public String getSentDateDisplay(){
        //TODO: Need to pick this from the config
        SimpleDateFormat sdf = new SimpleDateFormat(Constants.UI_DATE_TIME_PATTERN);

        if(sentDate != null){
            return sdf.format(sentDate);
        }

        return null;
    }

}
