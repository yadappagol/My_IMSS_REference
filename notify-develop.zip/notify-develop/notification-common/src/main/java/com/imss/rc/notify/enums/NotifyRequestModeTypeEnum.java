package com.imss.rc.notify.enums;

public enum NotifyRequestModeTypeEnum {
    SPECIFIC("S"),
    EVENT("E");

    private String value;
    NotifyRequestModeTypeEnum(String value) {
        this.value = value;
    }

    public String getValue(){
        return this.value;
    }
}
