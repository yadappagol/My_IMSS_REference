package com.imss.rc.notify.assembler;
import com.imss.rc.commons.assembler.BaseAssembler;
import com.imss.rc.notify.dto.NotificationUserPreferenceDto;
import com.imss.rc.notify.entity.NotificationUserPreferenceEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
@Component
public class NotificationUserPreferenceAssembler {



    private static BaseAssembler<NotificationUserPreferenceDto, NotificationUserPreferenceEntity> getBaseAssembler(){
        return new BaseAssembler<>(NotificationUserPreferenceDto::new, NotificationUserPreferenceEntity::new);
    }

    /**
     * Method to convert NotificationEventsEntity entity object to NotificationEventsDto dto object
     * @param entity the entity object with the data
     * @return A new NotificationEventsDto object with the data from the entity object
     */
    public NotificationUserPreferenceDto entityToDto(NotificationUserPreferenceEntity entity){
        return getBaseAssembler().entityToDto(entity);
    }

    /**
     * Method to convert NotificationEventsDto dto object to NotificationEventsEntity entity object
     * @param dto the dto object with the data
     * @return A new NotificationEventsEntity entity object with the data from the dto object
     */
    public NotificationUserPreferenceEntity dtoToEntity(NotificationUserPreferenceDto dto){
        return getBaseAssembler().dtoToEntity(dto);
    }


    /**
     * Method to convert a list of NotificationEventsDto dto objects to a list of NotificationEventsEntity entity objects
     * @param entityList A list of NotificationEventsEntity entity objects
     * @return A new list of NotificationEventsDto dto objects
     */
    public List<NotificationUserPreferenceDto> entityListToDtoList(List<NotificationUserPreferenceEntity> entityList){
        ArrayList<NotificationUserPreferenceDto> dtoList = new ArrayList();

        entityList.stream().forEach(k -> {
            NotificationUserPreferenceDto dto = this.entityToDto(k);
            if(k.getEventIdObj()!= null){
                dto.setEventName(k.getEventIdObj().getName());
            }
            dtoList.add(dto);
        });
        return dtoList;
    }


    /**
     * Method to convert a list of NotificationEventsEntity entity objects to a list of NotificationEventsDto dto objects
     * @param dtoList A list of NotificationEventsDto dto objects
     * @return A new list of NotificationEventsEntity entity objects
     */
    public List<NotificationUserPreferenceEntity> dtoListToEntityList(List<NotificationUserPreferenceDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }

}
