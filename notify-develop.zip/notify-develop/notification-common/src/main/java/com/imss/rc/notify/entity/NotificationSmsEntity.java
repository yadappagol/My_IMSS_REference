package com.imss.rc.notify.entity;

import com.imss.rc.commons.entity.BaseEntity;
import lombok.Data;
import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "notification_sms")
public class NotificationSmsEntity extends BaseEntity{

    public static final String COLUMN_NAME_TO_NUMBER = "toNumber";
    public static final String COLUMN_NAME_STATUS = "status";
    public static final String COLUMN_NAME_TO_SENT_DATE = "sentDate";
    public static final String COLUMN_NAME_CREATED_DATE = "createdDate";


    @Column(name="request_id")
    private Integer requestId;

    @Column(name="to_number")
    private String toNumber;

    @Column(name="message")
    private String message;

    @Column(name="status")
    private int status;

    @Column(name="sent_date")
    private Date sentDate;

    @Column(name="remarks")
    private String remarks;

    public NotificationSmsEntity() {

    }
}
