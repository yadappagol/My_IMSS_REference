package com.imss.rc.notify.entity;

import com.imss.rc.commons.entity.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "notification_requests")
public class NotificationRequestsEntity extends BaseEntity {

    @Column(name="template_id")
    private Integer templateId;

    @Column(name="event_id")
    private Integer eventId;

    @Column(name="payload")
    private String payload;

    @Column(name="modes")
    private String modes;

    @Column(name="received_date")
    private Date receivedDate;

    @Column(name="received_from")
    private Integer receivedFrom;

    @Column(name="status")
    private Integer status;

    @Column(name="remarks")
    private String remarks;


}
