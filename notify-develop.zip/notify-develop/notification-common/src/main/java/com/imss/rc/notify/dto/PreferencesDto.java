package com.imss.rc.notify.dto;

import lombok.Data;

@Data
public class PreferencesDto {
    private String sms;
    private String email;
    private String inapp;
    private String push;

    @Override
    public String toString() {
        return "PreferencesDto{" +
                "sms='" + sms + '\'' +
                ", email='" + email + '\'' +
                ", inapp='" + inapp + '\'' +
                ", push='" + push + '\'' +
                '}';
    }
}
