package com.imss.rc.notify.entity;


import com.imss.rc.commons.entity.BaseEntity;
import lombok.Data;
import javax.persistence.*;

@Data
@Entity
@Table(name = "notification_user_preference")
public class NotificationUserPreferenceEntity extends BaseEntity{

    @ManyToOne(targetEntity = NotificationEventsEntity.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "event_id", referencedColumnName = "pk_id", insertable = false, updatable = false)
    private NotificationEventsEntity eventIdObj;

    @Column(name="user_name")
    private String userName;

    @Column(name="event_id")
    private Integer eventId;

    @Column(name="preferences")
    private String preferences;

    public NotificationUserPreferenceEntity() {

    }
}
