package com.imss.rc.notify.assembler;

import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.commons.assembler.BaseAssembler;
import com.imss.rc.notify.dto.NotificationSmsDto;
import com.imss.rc.notify.entity.NotificationSmsEntity;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class NotificationSmsAssembler {
    private static Map<String, String> sortByList;
    static {
        sortByList = new HashMap<>();
        sortByList.put("toNumber", NotificationSmsEntity.COLUMN_NAME_TO_NUMBER);
        sortByList.put("status", NotificationSmsEntity.COLUMN_NAME_STATUS);
        sortByList.put("sent", NotificationSmsEntity.COLUMN_NAME_TO_SENT_DATE);
        sortByList.put("created", NotificationSmsEntity.COLUMN_NAME_CREATED_DATE);

    }
    private static BaseAssembler<NotificationSmsDto, NotificationSmsEntity> getBaseAssembler(){
        return new BaseAssembler<>(NotificationSmsDto::new, NotificationSmsEntity::new);
    }

    /**
     * Method to convert NotificationEventsEntity entity object to NotificationEventsDto dto object
     * @param entity the entity object with the data
     * @return A new NotificationEventsDto object with the data from the entity object
     */
    public NotificationSmsDto entityToDto(NotificationSmsEntity entity){
        return getBaseAssembler().entityToDto(entity);
    }

    /**
     * Method to convert NotificationEventsDto dto object to NotificationEventsEntity entity object
     * @param dto the dto object with the data
     * @return A new NotificationEventsEntity entity object with the data from the dto object
     */
    public NotificationSmsEntity dtoToEntity(NotificationSmsDto dto){
        return getBaseAssembler().dtoToEntity(dto);
    }


    /**
     * Method to convert a list of NotificationEventsDto dto objects to a list of NotificationEventsEntity entity objects
     * @param entityList A list of NotificationEventsEntity entity objects
     * @return A new list of NotificationEventsDto dto objects
     */
    public List<NotificationSmsDto> entityListToDtoList(List<NotificationSmsEntity> entityList){
        return getBaseAssembler().entityListToDtoList(entityList);
    }


    /**
     * Method to convert a list of NotificationEventsEntity entity objects to a list of NotificationEventsDto dto objects
     * @param dtoList A list of NotificationEventsDto dto objects
     * @return A new list of NotificationEventsEntity entity objects
     */
    public List<NotificationSmsEntity> dtoListToEntityList(List<NotificationSmsDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }

    public static String getSortByColumn(String input) throws NotifyException {
        return BaseAssembler.getSortByColumn(input, sortByList);
    }
}
