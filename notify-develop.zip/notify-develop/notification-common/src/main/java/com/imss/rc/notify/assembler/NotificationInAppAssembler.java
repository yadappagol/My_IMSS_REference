package com.imss.rc.notify.assembler;

import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.commons.assembler.BaseAssembler;
import com.imss.rc.notify.dto.NotificationInAppDto;
import com.imss.rc.notify.entity.NotificationInAppEntity;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class NotificationInAppAssembler {

    private static Map<String, String> sortByList;
    static {
        sortByList = new HashMap<>();
        sortByList.put("userId", NotificationInAppEntity.COLUMN_NAME_USER_NAME);
        sortByList.put("title", NotificationInAppEntity.COLUMN_NAME_TITLE);
        sortByList.put("status", NotificationInAppEntity.COLUMN_NAME_STATUS);
        sortByList.put("created", NotificationInAppEntity.COLUMN_NAME_CREATED_DATE);

    }
    private static BaseAssembler<NotificationInAppDto, NotificationInAppEntity> getBaseAssembler(){
        return new BaseAssembler<>(NotificationInAppDto::new, NotificationInAppEntity::new);
    }

    /**
     * Method to convert NotificationEventsEntity entity object to NotificationEventsDto dto object
     * @param entity the entity object with the data
     * @return A new NotificationEventsDto object with the data from the entity object
     */
    public NotificationInAppDto entityToDto(NotificationInAppEntity entity){
        return getBaseAssembler().entityToDto(entity);
    }

    /**
     * Method to convert NotificationEventsDto dto object to NotificationEventsEntity entity object
     * @param dto the dto object with the data
     * @return A new NotificationEventsEntity entity object with the data from the dto object
     */
    public NotificationInAppEntity dtoToEntity(NotificationInAppDto dto){
        return getBaseAssembler().dtoToEntity(dto);
    }


    /**
     * Method to convert a list of NotificationEventsDto dto objects to a list of NotificationEventsEntity entity objects
     * @param entityList A list of NotificationEventsEntity entity objects
     * @return A new list of NotificationEventsDto dto objects
     */
    public List<NotificationInAppDto> entityListToDtoList(List<NotificationInAppEntity> entityList){
        return getBaseAssembler().entityListToDtoList(entityList);
    }


    /**
     * Method to convert a list of NotificationEventsEntity entity objects to a list of NotificationEventsDto dto objects
     * @param dtoList A list of NotificationEventsDto dto objects
     * @return A new list of NotificationEventsEntity entity objects
     */
    public List<NotificationInAppEntity> dtoListToEntityList(List<NotificationInAppDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }

    public static String getSortByColumn(String input) throws NotifyException {
        return BaseAssembler.getSortByColumn(input, sortByList);
    }
}
