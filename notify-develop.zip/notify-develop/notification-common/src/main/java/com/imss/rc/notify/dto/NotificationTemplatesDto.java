package com.imss.rc.notify.dto;

import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.PaginationDto;
import lombok.Data;

import java.util.List;


@Data
public class NotificationTemplatesDto extends BaseDto {

    private String eventName;
    private Integer eventId;
    private String code;
    private Short type;
    private String name;
    private String description;
    private List<TemplateDto> template;
    private PaginationDto paginationDto;

    public NotificationTemplatesDto(){}


}
