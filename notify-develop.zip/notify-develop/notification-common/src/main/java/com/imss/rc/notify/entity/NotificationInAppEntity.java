package com.imss.rc.notify.entity;

import com.imss.rc.commons.entity.BaseEntity;
import lombok.Data;
import javax.persistence.*;


@Data
@Entity
@Table(name = "notification_in_app")
public class NotificationInAppEntity extends BaseEntity{

    public static final String COLUMN_NAME_USER_NAME = "userName";
    public static final String COLUMN_NAME_TITLE = "title";
    public static final String COLUMN_NAME_STATUS = "status";
    public static final String COLUMN_NAME_CREATED_DATE = "createdDate";


    @Column(name="request_id")
    private Integer requestId;

    @Column(name="user_name")
    private String userName;

    @Column(name="title")
    private String title;

    @Column(name="content")
    private String content;

    @Column(name="status")
    private Integer status;

    public NotificationInAppEntity() {

    }
}
