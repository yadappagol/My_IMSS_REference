package com.imss.rc.notify.dto;

import com.imss.rc.commons.dto.BaseDto;
import lombok.Data;

import java.util.Date;

@Data
public class NotificationRequestsDto extends BaseDto {
    private Integer templateId;
    private Integer eventId;
    private String payload;
    private Date receivedDate;
    private int receivedFrom;

    private String requestModeType;
    private PreferencesDto mode;
    private String userName;
    private String templateCode;
}
