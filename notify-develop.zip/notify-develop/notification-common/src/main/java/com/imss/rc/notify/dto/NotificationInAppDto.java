package com.imss.rc.notify.dto;

import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.PaginationDto;
import lombok.Data;

@Data
public class NotificationInAppDto extends BaseDto {
    private Integer requestId;
    private String userName;
    private String title;
    private String content;
    private Integer status;

    private String mode;
    private String  startDate;
    private String  endDate;
    private PaginationDto paginationDto;

    public NotificationInAppDto() {
    }
}