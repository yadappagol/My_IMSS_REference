package com.imss.rc.notify.enums;

public enum NotificationStatusInAppEnum {
    NOT_NOTIFIED_UNREAD("Not Notified", 0),
    NOTIFIED_UNREAD("Notified, Unread",1),
    NOTIFIED_READ("Read",2);

    private String name;
    private Integer value;
    NotificationStatusInAppEnum(String name, Integer value) {
        this.name = name;
        this.value = value;
    }

    public Integer getValue(){
        return this.value;
    }
    public String getName(){
        return this.name;
    }
}
