package com.imss.rc.notify.assembler;

import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.commons.assembler.BaseAssembler;
import com.imss.rc.notify.dto.NotificationEmailDto;
import com.imss.rc.notify.entity.NotificationEmailEntity;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class NotificationEmailAssembler {

    private static Map<String, String> sortByList;
    static {
        sortByList = new HashMap<>();
        sortByList.put("subject", NotificationEmailEntity.COLUMN_NAME_SUBJECT_LINE);
        sortByList.put("status", NotificationEmailEntity.COLUMN_NAME_STATUS);
        sortByList.put("toEmail", NotificationEmailEntity.COLUMN_NAME_TO_EMAIL);
        sortByList.put("sent", NotificationEmailEntity.COLUMN_NAME_SENT_DATE);
        sortByList.put("created", NotificationEmailEntity.COLUMN_NAME_CREATED_DATE);

    }
    private static BaseAssembler<NotificationEmailDto, NotificationEmailEntity> getBaseAssembler(){
        return new BaseAssembler<>(NotificationEmailDto::new, NotificationEmailEntity::new);
    }

    /**
     * Method to convert NotificationEventsEntity entity object to NotificationEventsDto dto object
     * @param entity the entity object with the data
     * @return A new NotificationEventsDto object with the data from the entity object
     */
    public NotificationEmailDto entityToDto(NotificationEmailEntity entity){
        return getBaseAssembler().entityToDto(entity);
    }

    /**
     * Method to convert NotificationEventsDto dto object to NotificationEventsEntity entity object
     * @param dto the dto object with the data
     * @return A new NotificationEventsEntity entity object with the data from the dto object
     */
    public NotificationEmailEntity dtoToEntity(NotificationEmailDto dto){
        return getBaseAssembler().dtoToEntity(dto);
    }


    /**
     * Method to convert a list of NotificationEventsDto dto objects to a list of NotificationEventsEntity entity objects
     * @param entityList A list of NotificationEventsEntity entity objects
     * @return A new list of NotificationEventsDto dto objects
     */
    public List<NotificationEmailDto> entityListToDtoList(List<NotificationEmailEntity> entityList){
        return getBaseAssembler().entityListToDtoList(entityList);
    }


    /**
     * Method to convert a list of NotificationEventsEntity entity objects to a list of NotificationEventsDto dto objects
     * @param dtoList A list of NotificationEventsDto dto objects
     * @return A new list of NotificationEventsEntity entity objects
     */
    public List<NotificationEmailEntity> dtoListToEntityList(List<NotificationEmailDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }

    public static String getSortByColumn(String input) throws NotifyException {
        return BaseAssembler.getSortByColumn(input, sortByList);
    }
}
