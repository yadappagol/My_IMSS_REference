package com.imss.rc.notify.assembler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.commons.assembler.BaseAssembler;
import com.imss.rc.notify.dto.NotificationEventsDto;
import com.imss.rc.notify.dto.PreferencesDto;
import com.imss.rc.notify.entity.NotificationEventsEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class NotificationEventsAssembler {

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationEventsAssembler.class);

    private static Map<String, String> sortByList;
    static {
        sortByList = new HashMap<>();
        sortByList.put("name", NotificationEventsEntity.COLUMN_NAME_BY_NAME);
        sortByList.put("code", NotificationEventsEntity.COLUMN_NAME_CODE);
        }

    private static BaseAssembler<NotificationEventsDto, NotificationEventsEntity> getBaseAssembler(){
        return new BaseAssembler<>(NotificationEventsDto::new, NotificationEventsEntity::new);
    }

    /**
     * Method to convert NotificationEventsEntity entity object to NotificationEventsDto dto object
     * @param entity the entity object with the data
     * @return A new NotificationEventsDto object with the data from the entity object
     */
    public NotificationEventsDto entityToDto(NotificationEventsEntity entity){
        NotificationEventsDto dto =  getBaseAssembler().entityToDto(entity);

        try {
            if (entity.getPreferences() != null && !entity.getPreferences().isEmpty()) {
                ObjectMapper mapper = new ObjectMapper();
                dto.setPreferences(mapper.readValue(entity.getPreferences(), PreferencesDto.class));
            }
        } catch(Exception ex){
            LOGGER.error("Error while processing notification event preferences in assembler",ex);
        }
        return dto;
    }

    /**
     * Method to convert NotificationEventsDto dto object to NotificationEventsEntity entity object
     * @param dto the dto object with the data
     * @return A new NotificationEventsEntity entity object with the data from the dto object
     */
    public NotificationEventsEntity dtoToEntity(NotificationEventsDto dto){
        NotificationEventsEntity entity =  getBaseAssembler().dtoToEntity(dto);

        try {
            JSONObject jsonObj = new JSONObject(dto);
            entity.setPreferences(jsonObj.getString("preferences"));
        } catch(Exception ex){
            LOGGER.error("Error while processing notification event preferences in assembler",ex);
        }
        return entity;
    }


    /**
     * Method to convert a list of NotificationEventsDto dto objects to a list of NotificationEventsEntity entity objects
     * @param entityList A list of NotificationEventsEntity entity objects
     * @return A new list of NotificationEventsDto dto objects
     */
    public List<NotificationEventsDto> entityListToDtoList(List<NotificationEventsEntity> entityList){
        return getBaseAssembler().entityListToDtoList(entityList);
    }


    /**
     * Method to convert a list of NotificationEventsEntity entity objects to a list of NotificationEventsDto dto objects
     * @param dtoList A list of NotificationEventsDto dto objects
     * @return A new list of NotificationEventsEntity entity objects
     */
    public List<NotificationEventsEntity> dtoListToEntityList(List<NotificationEventsDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }

    public static String getSortByColumn(String input) throws NotifyException {
        return BaseAssembler.getSortByColumn(input, sortByList);
    }
}
