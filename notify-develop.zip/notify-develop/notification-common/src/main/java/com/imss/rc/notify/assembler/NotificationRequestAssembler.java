package com.imss.rc.notify.assembler;

import com.imss.rc.commons.assembler.BaseAssembler;
import com.imss.rc.notify.dto.NotificationRequestsDto;
import com.imss.rc.notify.entity.NotificationRequestsEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class NotificationRequestAssembler {


    private static BaseAssembler<NotificationRequestsDto, NotificationRequestsEntity> getBaseAssembler(){
        return new BaseAssembler<>(NotificationRequestsDto::new, NotificationRequestsEntity::new);
    }

    /**
     * Method to convert NotificationRequestsEntity entity object to NotificationRequestsDto dto object
     * @param entity the entity object with the data
     * @return A new NotificationRequestsDto object with the data from the entity object
     */
    public NotificationRequestsDto entityToDto(NotificationRequestsEntity entity){
        return getBaseAssembler().entityToDto(entity);
    }

    /**
     * Method to convert NotificationRequestsDto dto object to NotificationRequestsEntity entity object
     * @param dto the dto object with the data
     * @return A new NotificationRequestsEntity entity object with the data from the dto object
     */
    public NotificationRequestsEntity dtoToEntity(NotificationRequestsDto dto){
        return getBaseAssembler().dtoToEntity(dto);
    }


    /**
     * Method to convert a list of NotificationRequestsDto dto objects to a list of NotificationRequestsEntity entity objects
     * @param entityList A list of NotificationRequestsEntity entity objects
     * @return A new list of NotificationRequestsDto dto objects
     */
    public List<NotificationRequestsDto> entityListToDtoList(List<NotificationRequestsEntity> entityList){
        return getBaseAssembler().entityListToDtoList(entityList);
    }


    /**
     * Method to convert a list of NotificationRequestsEntity entity objects to a list of NotificationRequestsDto dto objects
     * @param dtoList A list of NotificationRequestsDto dto objects
     * @return A new list of NotificationRequestsEntity entity objects
     */
    public List<NotificationRequestsEntity> dtoListToEntityList(List<NotificationRequestsDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }
}
