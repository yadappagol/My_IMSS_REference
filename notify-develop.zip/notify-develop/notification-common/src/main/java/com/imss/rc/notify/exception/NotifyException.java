/**
 * COPYRIGHT: Jakkur Technoparks Pvt. Ltd. (JTPL)
 * This software is the sole property of JTPL
 * and is protected by copyright law and international
 * treaty provisions. Unauthorized reproduction or
 * redistribution of this program, or any portion of
 * it may result in severe civil and criminal penalties
 * and will be prosecuted to the maximum extent possible
 * under the law. JTPL reserves all rights not
 * expressly granted. You may not reverse engineer, decompile,
 * or disassemble the software, except and only to the
 * extent that such activity is expressly permitted
 * by applicable law notwithstanding this limitation.
 * THIS SOFTWARE IS PROVIDED TO YOU "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
 * YOU ASSUME THE ENTIRE RISK AS TO THE ACCURACY
 * AND THE USE OF THIS SOFTWARE. JTPL SHALL NOT BE LIABLE FOR
 * ANY DAMAGES WHATSOEVER ARISING OUT OF THE USE OF OR INABILITY TO
 * USE THIS SOFTWARE, EVEN IF JTPL HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/
package com.imss.rc.notify.exception;

import com.imss.rc.commons.exception.IMSSException;
import org.springframework.http.HttpStatus;

public class NotifyException extends IMSSException  {

    public static final String ERROR_OCCURRED ="1000" ;
    public static final String TEMPLATE_NOT_DELETED= "1001";
    public static final String UNABLE_TO_RETRIEVE_TEMPLATE_DETAILS ="1002";
    public static final String UNABLE_TO_UPDATE_NOTIFICATION_TEMPLATE = "1003";
    public static final String UNABLE_TO_ADD_NOTIFICATION_TEMPLATE = "1004";
    public static final String INVALID_ORDER_BY_COLUMN = "1005";
    public static final String FIELD_VALUE_MISSING = "1006";
    public static final String NOTIFICATION_DETAILS_NOT_FOUND = "1007";
    public static final String CODE_NOT_VALID = "1008";
    public static final String TYPE_NOT_VALID = "1009";
    public static final String NAME_NOT_VALID = "1010";
    public static final String DISCRIPTION_NOT_VALID = "1011";
    public static final String TEMPLATE_NOT_VALID = "1012";
    public static final String TEMPLATE_NOT_FOUND = "1013";
    public static final String EVENTS_NOT_FOUND ="1014" ;
    public static final String NO_RECORDS_FOUND = "1015";
    public static final String INVALID_DATE_FORMAT = "1016";
    public static final String SMS_MODE_LANGUAGE_NOT_VALID = "1017";
    public static final String UNABLE_TO_ADD_NOTIFICATION_EVENT = "1018";
    public static final String SMS_MODE_EXPRESSION_NOT_VALID = "1019";
    public static final String SMS_MODE_NOTIFY_LANGUAGE_NOT_VALID = "1020";
    public static final String EMAIL_MODE_LANGUAGE_NOT_VALID = "1021";
    public static final String EMAIL_MODE_EXPRESSION_NOT_VALID = "1022";
    public static final String EMAIL_MODE_NOTIFY_LANGUAGE_NOT_VALID = "1023";
    public static final String IS_OVERRIDE_NOT_VALID = "1024";
    public static final String INAPP_MODE_LANGUAGE_NOT_VALID = "1025";
    public static final String INAPP_MODE_EXPRESSION_NOT_VALID = "1026";
    public static final String INAPP_MODE_NOTIFY_LANGUAGE_NOT_VALID = "1027";
    public static final String PREFERENCE_NOT_VALID = "1028";
    public static final String PUSH_MODE_LANGUAGE_NOT_VALID = "1029";
    public static final String PUSH_MODE_EXPRESSION_NOT_VALID = "1030";
    public static final String PUSH_MODE_NOTIFY_LANGUAGE_NOT_VALID = "1031";
    public static final String UNABLE_TO_UPDATE_NOTIFICATION_EVENT = "1032";
    public static final String MODE_NOT_VALID = "1033";
    public static final String NOTIFICATION_EVENT_NOT_FOUND = "1034";
    public static final String NOTIFICATION_EVENT_NOT_DELETED = "1035";
    public static final String NOTIFICATION_EVENTS_LIST_NOT_RETRIEVED = "1036";
    public static final String USER_PREFERENCE_LIST_NOT_FOUND = "1037";
    public static final String USER_OVERRIDE_NOT_ALLOWED = "1038";
    public static final String EVENT_SPECIFIC_USER_PREFERENCE_NOT_FOUND = "1039";
    public static final String TYPE_NOT_FOUND  = "1040";
    public static final String EVENT_ID_NOT_FOUND = "1041";
    public static final String CODE_NOT_FOUND = "1042";
    public static final String PREFERENCE_NOT_FOUND = "1043";
    public static final String NAME_NOT_FOUND = "1044";
    public static final String UNABLE_TO_FIND_NOTIFICATION_TEMPLATE = "1045";
    public static final String UNABLE_TO_FIND_NOTIFICATION_SMS = "1046";
    public static final String UNABLE_TO_FIND_NOTIFICATION_PUSH = "1047";
    public static final String UNABLE_TO_FIND_NOTIFICATION_IN_APP = "1048";
    public static final String UNABLE_TO_FIND_NOTIFICATION_EVENT = "1049";
    public static final String UNABLE_TO_FIND_NOTIFICATION_EMAIL = "1050";
    public static final String MANDATORY_FIELD_ROW_VERSION_REQUIRED = "1051";
    public static final String VALIDATION_FAILD = "1052";
    public static final String UNABLE_TO_UPDATE_NOTIFICATION_IN_APP = "1053";


    public static final String MESSAGE_BUNDLE_NAME = "notify_errors_messages";
    public static final String MODULE_CODE = "NOTIFY";
    public static final String ERROR_CODE_PREFIX = "notify.error.";

    public static final String SMS_CONTENT_DETAILS_MANDATORY = "110";
    public static final String SMS_MODE_NOT_VALID = "111";
    public static final String SMS_MODE_MANDATORY = "112";
    public static final String EMAIL_MODE_NOT_VALID = "113";
    public static final String INAPP_MODE_NOT_VALID = "114";
    public static final String SMS_MODE_LANGUAGE_MANDATORY = "115";
    public static final String SMS_MODE_EXPRESSION_MANDATORY = "116";
    public static final String SMS_MODE_NOTIFY_LANGUAGE_MANDATORY = "117";
    public static final String EMAIL_MODE_LANGUAGE_MANDATORY = "118";
    public static final String EMAIL_MODE_CONTENT_DETAILS_MANDATORY = "119";
    public static final String EMAIL_MODE_EXPRESSION_MANDATORY = "120";
    public static final String EMAIL_MODE_NOTIFY_LANGUAGE_MANDATORY = "121";
    public static final String EMAIL_MODE_MANDATORY = "122";
    public static final String INAPP_MODE_LANGUAGE_MANDATORY = "123";
    public static final String INAPP_MODE_CONTENT_DETAILS_MANDATORY = "124";
    public static final String INAPP_MODE_EXPRESSION_MANDATORY = "125";
    public static final String INAPP_MODE_NOTIFY_LANGUAGE_MANDATORY = "126";
    public static final String INAPP_MODE_MANDATORY = "127";
    public static final String PUSH_MODE_LANGUAGE_MANDATORY = "128";
    public static final String PUSH_MODE_CONTENT_DETAILS_MANDATORY = "129";
    public static final String PUSH_MODE_EXPRESSION_MANDATORY = "130";
    public static final String PUSH_MODE_NOTIFY_LANGUAGE_MANDATORY = "131";
    public static final String PUSH_MODE_NOT_VALID = "132";
    public static final String PUSH_MODE_MANDATORY = "133";
    public static final String IS_OVERRIDE_MANDATORY = "134";
    public static final String MODE_MANDATORY = "135";

    public static final String CONSUMER_EXPRESSION_PATH_NOT_FOUND_IN_PAYLOAD = "1054";
    public static final String CONSUMER_TEMPLATE_ID_OR_CODE_NOT_FOUND = "1055";
    public static final String CONSUMER_TEMPLATE_ID_AND_CODE_FOUND_BLANK = "1056";
    public static final String CONSUMER_MODE_NOT_FOUND_IN_TEMPLATE_DEFINITION = "1057";
    public static final String CONSUMER_INVALID_NOTIFICATION_MODE = "1058";
    public static final String CONSUMER_ERROR_WHILE_PROCESSING_REQUEST = "1059";
    public static final String CONSUMER_EVENT_ID_FOUND_BLANK = "1060";
    public static final String CONSUMER_INVALID_EVENT_ID = "1061";
    public static final String CONSUMER_NO_TEMPLATES_FOUND_FOR_EVENT = "1062";
    public static final String CONSUMER_CONTENT_NOT_FOUND_FOR_LANGUAGE = "1063";
    public static final String CONSUMER_UNKNOWN_NOTIFY_REQUEST_MODE = "1064";
    public static final String MESSAGE_NOT_SENT = "1065";
    public static final String CATEGORY_NOT_FOUND = "1066";
    public static final String INVALID_CATEGORY_ID = "1067";
    public static final String STATUS_NOT_VALID = "1068";
    public static final String UNAUTHORIZED_USER_ACCESS = "1069";

    public NotifyException(String code, Object[] args, Throwable cause, HttpStatus httpStatus) {
        super(code, args, cause, httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);

    }

    public NotifyException(String code, Object[] args, HttpStatus httpStatus) {
        super(code, args, httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

    public NotifyException(String code, Throwable cause, HttpStatus httpStatus) {
        super(code,  cause, httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

    public NotifyException(String code, HttpStatus httpStatus) {
        super(code,httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }


}
