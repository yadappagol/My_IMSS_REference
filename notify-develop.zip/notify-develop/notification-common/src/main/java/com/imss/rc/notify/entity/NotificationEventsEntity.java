package com.imss.rc.notify.entity;

import com.imss.rc.commons.entity.BaseEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "notification_events")
public class NotificationEventsEntity extends BaseEntity {

    public static final String COLUMN_NAME_BY_NAME = "name";
    public static final String COLUMN_NAME_CODE = "code";
    public static final String COLUMN_NAME_IS_USER_OVERRIDE_ALLOWED = "isUserOverrideAllowed";
    public static final String COLUMN_NAME_CATEGORY_ID = "categoryId";
    public static final String COLUMN_NAME_DESCRIPTION="description";

    @Column(name="code")
    private String code;

    @Column(name="name")
    private String name;

    @Column(name="category_id")
    private int categoryId;

    @Column(name="description")
    private String description;

    @Column(name="is_user_override_allowed")
    private Short isUserOverrideAllowed;

    @Column(name="preferences")
    private String preferences;

    public NotificationEventsEntity() {

    }
}
