package com.imss.rc.notify.util;

public class AuditConstants
{
private AuditConstants(){}
    
    public static  final int AUDIT_EVENTS= 1;
    public static final int CONFIGURATION_UPDATES=2;
    public static final int INSURANCE_CORE_DATA=3;
    public static final int INSURANCE_SUB_CATEGORY= 4;
    public static final int INSURANCE_PRODUCT_TYPES= 5;
    public  static final int INSURANCE_INPUT_FIELDS=6;
    public static final int INSURANCE_PRODUCTS = 7;
    public  static final int NOTIFICATION_EVENT=8;
    public  static final int USER_PREFERENCE_NOTIFICATION=9;

    public static final int NOTIFICATION_TEMPLATE =10 ;

    public static final String ROLE = "Admin";
}
