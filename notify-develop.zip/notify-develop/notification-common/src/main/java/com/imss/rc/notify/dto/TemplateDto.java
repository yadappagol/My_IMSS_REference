package com.imss.rc.notify.dto;

import lombok.Data;

import java.util.List;

@Data
public class TemplateDto {
    private String mode;
    private List<ContentDetailsDto> contentDetails;
    private String toExpression;
    private String notifyLanguage;

    @Override
    public String toString() {
        return "TemplateDto{" +
                "mode='" + mode + '\'' +
                ", contentDetails=" + contentDetails.toString() +
                ", toExpression='" + toExpression + '\'' +
                ", notifyLanguage='" + notifyLanguage + '\'' +
                '}';
    }
}
