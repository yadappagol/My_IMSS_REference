package com.imss.rc.notify.enums;

public enum NotifyModeEnum {
    SMS("sms"),
    INAPP("inapp"),
    EMAIL("email"),
    PUSH("push");

    private String value;
    NotifyModeEnum(String value) {
        this.value = value;
    }

    public String getValue(){
        return this.value;
    }
}
