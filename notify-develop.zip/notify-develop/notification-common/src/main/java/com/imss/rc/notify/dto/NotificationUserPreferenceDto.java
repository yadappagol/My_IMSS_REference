package com.imss.rc.notify.dto;

import com.imss.rc.commons.dto.BaseDto;
import lombok.Data;

@Data
public class
NotificationUserPreferenceDto extends BaseDto {
    private String userName;
    private Integer eventId;
    private PreferencesDto preferences;
    private String eventName;

    public NotificationUserPreferenceDto() {
    }

}
