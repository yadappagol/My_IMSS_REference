package com.imss.rc.notify.entity;

import com.imss.rc.commons.entity.BaseEntity;
import lombok.Data;
import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "notification_email")
public class NotificationEmailEntity extends BaseEntity{

    public static final String COLUMN_NAME_SUBJECT_LINE = "subjectLine";
    public static final String COLUMN_NAME_STATUS = "status";
    public static final String COLUMN_NAME_TO_EMAIL = "toEmails";
    public static final String COLUMN_NAME_SENT_DATE = "sentDate";
    public static final String COLUMN_NAME_CREATED_DATE = "createdDate";


    @Column(name="request_id")
    private Integer requestId;

    @Column(name="to_emails")
    private String toEmails;

    @Column(name="cc_emails")
    private String ccEmails;

    @Column(name="subject_line")
    private String subjectLine;

    @Column(name="mail_body")
    private String mailBody;

    @Column(name="status")
    private int status;

    @Column(name="sent_date")
    private Date sentDate;

    public NotificationEmailEntity() {
        
    }

}
