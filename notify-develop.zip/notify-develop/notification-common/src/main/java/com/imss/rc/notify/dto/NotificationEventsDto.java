package com.imss.rc.notify.dto;

import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.PaginationDto;
import lombok.Data;

@Data
public class NotificationEventsDto extends BaseDto {
    private String code;
    private String name;
    private String description;
    private Short isUserOverrideAllowed;
    private int categoryId;

    private PreferencesDto preferences;
    private PaginationDto paginationDto;

    public NotificationEventsDto() {
    }

}
