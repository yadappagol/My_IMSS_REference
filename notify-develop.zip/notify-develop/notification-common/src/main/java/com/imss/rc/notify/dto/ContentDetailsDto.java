package com.imss.rc.notify.dto;

import lombok.Data;

@Data
public class ContentDetailsDto {
    private String language ;
    private String title;
    private String content;

    @Override
    public String toString() {
        return "ContentDetailsDto{" +
                "language='" + language + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                '}';
    }
}
