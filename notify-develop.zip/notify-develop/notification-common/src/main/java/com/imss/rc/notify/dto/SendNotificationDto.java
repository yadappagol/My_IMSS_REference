package com.imss.rc.notify.dto;

import com.imss.rc.commons.dto.ResponseDto;
import lombok.Data;

@Data
public class SendNotificationDto extends ResponseDto {
    private String[] users;
    private String message;
    private String subject;
    private String title;
    private PreferencesDto mode;
}
