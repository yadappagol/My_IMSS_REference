package com.imss.rc.notify.assembler;

import com.imss.rc.notify.exception.NotifyException;
import com.imss.rc.commons.assembler.BaseAssembler;
import com.imss.rc.notify.dto.NotificationTemplatesDto;
import com.imss.rc.notify.entity.NotificationTemplatesEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class NotificationTemplatesAssembler {
    private static Map<String, String> sortByList;
    static {
        sortByList = new HashMap<>();
        sortByList.put("name",NotificationTemplatesEntity.COLUMN_NAME_BY_NAME);
        sortByList.put("code",NotificationTemplatesEntity.COLUMN_NAME_CODE);
        sortByList.put("eventName",NotificationTemplatesEntity.COLUMN_NAME_EVENT_ID);
        sortByList.put("created",NotificationTemplatesEntity.COLUMN_NAME_CREATED_DATE);
        sortByList.put("modified",NotificationTemplatesEntity.COLUMN_NAME_MODIFIED_DATE);
    }

    private static BaseAssembler<NotificationTemplatesDto, NotificationTemplatesEntity> getBaseAssembler(){
        return new BaseAssembler<>(NotificationTemplatesDto::new, NotificationTemplatesEntity::new);
    }

    /**
     * Method to convert NotificationEventsEntity entity object to NotificationEventsDto dto object
     * @param entity the entity object with the data
     * @return A new NotificationEventsDto object with the data from the entity object
     */
    public NotificationTemplatesDto entityToDto(NotificationTemplatesEntity entity){
        return getBaseAssembler().entityToDto(entity);
    }

    /**
     * Method to convert NotificationEventsDto dto object to NotificationEventsEntity entity object
     * @param dto the dto object with the data
     * @return A new NotificationEventsEntity entity object with the data from the dto object
     */
    public NotificationTemplatesEntity dtoToEntity(NotificationTemplatesDto dto){
        return getBaseAssembler().dtoToEntity(dto);
    }


    /**
     * Method to convert a list of NotificationEventsDto dto objects to a list of NotificationEventsEntity entity objects
     * @param entityList A list of NotificationEventsEntity entity objects
     * @return A new list of NotificationEventsDto dto objects
     */
    public List<NotificationTemplatesDto> entityListToDtoList(List<NotificationTemplatesEntity> entityList){
        ArrayList<NotificationTemplatesDto> dtoList = new ArrayList();

        entityList.stream().forEach(k -> {
            NotificationTemplatesDto dto = this.entityToDto(k);
            if(k.getEventsIdObj() != null){
                dto.setEventName(k.getEventsIdObj().getName());
            }
            dtoList.add(dto);
        });
        return dtoList;
    }


    /**
     * Method to convert a list of NotificationEventsEntity entity objects to a list of NotificationEventsDto dto objects
     * @param dtoList A list of NotificationEventsDto dto objects
     * @return A new list of NotificationEventsEntity entity objects
     */
    public List<NotificationTemplatesEntity> dtoListToEntityList(List<NotificationTemplatesDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }

    public static String getSortByColumn(String input) throws NotifyException {
        return BaseAssembler.getSortByColumn(input, sortByList);
    }
}
