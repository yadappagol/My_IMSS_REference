package com.imss.rc.notify.enums;

public enum NotificationRequestStatusEnum {
    RECEIVED(0),
    PROCESSED_SUCCESSFULLY(1),
    PROCESSED_WITH_ERRORS(2);

    private int value;
    NotificationRequestStatusEnum(int value) {
        this.value = value;
    }

    public int getValue(){
        return this.value;
    }
}
