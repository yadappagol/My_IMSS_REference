package com.imss.rc.notify.constants;

public class NotifyTestConstant {

    private NotifyTestConstant(){

    }
    public static final String CHECK_TITLE = "checking title";
    public static final String CHECK_CONTENT = "checking content";
    public static final String CHECK_MAIL_BODY = "checking mail body";
    public static final String CHECK_SUBJECTLINE = "checking subject line";
    public static final String CHECK_TO_MAIL = "checking mail";
    public static final String CHECK_CC_MAIL = "checking  cc mail";
    public static final String CHECK_MESSAGE = "checking message";
    public static final String CHECK_REQUEST_ID = "checking request id";
    public static final String CHECK_SENT_DATE = "checking sent date";
    public static final String CHECK_STATUS = "checking status";
    public static final String CHECK_TO_NUMBER = "checking to number";
    public static final String CHECK_IS_OVERRIDE_ALLOWED = "Checking Override allowed";
    public static final String CHECK_PREFERENCE = "Checking preference";
    public static final String CHECK_CODE = "checking code";
    public static final String CHECK_EVENT_ID = "Checking Event id";
    public static final String CHECK_DELETE="Checking is delete";
    public static final String CHECK_DESCRIPTION="Checking Description";
    public static final String CHECK_NAME="Checking Name";
    public static final String CHECK_SUB_CATEGORY_ID="Checking Sub Category Id";
    public static final String CHECK_ID="Checking id";
    public static final String CHECK_CREATED_BY="Checking created by";
    public static final String CHECK_CREATED_DATE="Checking created date";
    public static final String CHECK_MODIFIED_BY="Checking Modified by";
    public static final String CHECK_MODIFIED_DATE="Checking Modified Date";
    public static final String CHECK_ROW_VERSION="Checking Row Version";
    public static final String CHECK_USER_ID = "Checking User Id";


}
