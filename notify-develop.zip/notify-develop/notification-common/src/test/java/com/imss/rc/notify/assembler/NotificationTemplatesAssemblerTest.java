package com.imss.rc.notify.assembler;

import com.imss.rc.notify.constants.NotifyTestConstant;
import com.imss.rc.notify.dto.NotificationTemplatesDto;
import com.imss.rc.notify.entity.NotificationTemplatesEntity;
import com.imss.rc.notify.util.AuditConstants;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Date;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(PowerMockRunner.class)
public class NotificationTemplatesAssemblerTest {
    @InjectMocks
    private NotificationTemplatesAssembler assembler;

    private NotificationTemplatesDto getDto() {
        NotificationTemplatesDto dto = new NotificationTemplatesDto();

        dto.setDescription("R1");
        dto.setName("Vehicles");
        dto.setEventId(1);
        dto.setCode("kjhg");
        dto.setType((short) 1);
        dto.setCreatedBy("admin");
        dto.setCreatedDate(new Date(System.currentTimeMillis()));
        dto.setId(1000001);
        dto.setIsDeleted((short)0);
        dto.setModifiedBy("admin");
        dto.setModifiedDate(new Date(System.currentTimeMillis()));
        dto.setRowVersion(1);
        dto.setResponseMessage("successful");
        dto.setResponseCode("200");
        dto.setResponseStatus("success");

        return dto;
    }

    private NotificationTemplatesEntity getEntity() {
        NotificationTemplatesEntity entity = new NotificationTemplatesEntity();

        entity.setEventId(101);
        entity.setCode("abcdef");
        entity.setDescription("R1");
        entity.setName("User Registration");
        entity.setCreatedBy(AuditConstants.ROLE);
        entity.setCreatedDate(new Date(System.currentTimeMillis()));
        entity.setId(1000001);
        entity.setIsDeleted((short)0);
        entity.setModifiedBy(AuditConstants.ROLE);
        entity.setModifiedDate(new Date(System.currentTimeMillis()));
        entity.setTemplate("template");
        return entity;
    }

    @Test
    public void testA03DtoListToEntityList() {

        ArrayList<NotificationTemplatesDto> dtoList = new ArrayList<>();
        dtoList.add(getDto());
        ArrayList<NotificationTemplatesEntity> entityList = (ArrayList) assembler.dtoListToEntityList(dtoList);
        int index = 0;
        for (NotificationTemplatesEntity entity : entityList) {


            Assert.assertEquals(NotifyTestConstant.CHECK_DELETE, entity.getIsDeleted(), dtoList.get(index).getIsDeleted());
            Assert.assertEquals(NotifyTestConstant.CHECK_EVENT_ID, entity.getEventId(), dtoList.get(index).getEventId());
            Assert.assertEquals(NotifyTestConstant.CHECK_DESCRIPTION, entity.getDescription(), dtoList.get(index).getDescription());
            Assert.assertEquals(NotifyTestConstant.CHECK_CODE, entity.getCode(), dtoList.get(index).getCode());
            Assert.assertEquals(NotifyTestConstant.CHECK_NAME, entity.getName(), dtoList.get(index).getName());
            Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_BY, entity.getCreatedBy(), dtoList.get(index).getCreatedBy());
            Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_DATE, entity.getCreatedDate(), dtoList.get(index).getCreatedDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_NAME, entity.getId(), dtoList.get(index).getId());
            Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_BY, entity.getModifiedBy(), dtoList.get(index).getModifiedBy());
            Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_DATE, entity.getModifiedDate(), dtoList.get(index).getModifiedDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_ROW_VERSION, entity.getRowVersion(), dtoList.get(index).getRowVersion());


            index++;
        }
    }

    @Test
    public void testA04EntityListToDtoList() {

        ArrayList<NotificationTemplatesEntity> entityList = new ArrayList<>();
        entityList.add(getEntity());
        ArrayList<NotificationTemplatesDto> dtoList = (ArrayList) assembler.entityListToDtoList(entityList);
        int index = 0;
        for (NotificationTemplatesDto dto : dtoList) {


            Assert.assertEquals(NotifyTestConstant.CHECK_DELETE, dto.getIsDeleted(), dtoList.get(index).getIsDeleted());
            Assert.assertEquals(NotifyTestConstant.CHECK_EVENT_ID, dto.getEventId(), dtoList.get(index).getEventId());
            Assert.assertEquals(NotifyTestConstant.CHECK_DESCRIPTION, dto.getDescription(), dtoList.get(index).getDescription());
            Assert.assertEquals(NotifyTestConstant.CHECK_CODE, dto.getCode(), dtoList.get(index).getCode());
            Assert.assertEquals(NotifyTestConstant.CHECK_NAME, dto.getName(), dtoList.get(index).getName());
            Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_BY, dto.getCreatedBy(), dtoList.get(index).getCreatedBy());
            Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_DATE, dto.getCreatedDate(), dtoList.get(index).getCreatedDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_ID, dto.getId(), dtoList.get(index).getId());
            Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_BY, dto.getModifiedBy(), dtoList.get(index).getModifiedBy());
            Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_DATE, dto.getModifiedDate(), dtoList.get(index).getModifiedDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_ROW_VERSION, dto.getRowVersion(), dtoList.get(index).getRowVersion());


            index++;
        }
    }

    @Test
    public void testA01EntityToDto() {
        NotificationTemplatesEntity entity = getEntity();
        NotificationTemplatesDto dto = assembler.entityToDto(entity);


        Assert.assertEquals(NotifyTestConstant.CHECK_DELETE, entity.getIsDeleted(), dto.getIsDeleted());
        Assert.assertEquals(NotifyTestConstant.CHECK_EVENT_ID, entity.getEventId(), dto.getEventId());
        Assert.assertEquals(NotifyTestConstant.CHECK_DESCRIPTION, entity.getDescription(), dto.getDescription());
        Assert.assertEquals(NotifyTestConstant.CHECK_CODE, entity.getCode(), dto.getCode());
        Assert.assertEquals(NotifyTestConstant.CHECK_NAME, entity.getName(), dto.getName());
        Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_BY, entity.getCreatedBy(), dto.getCreatedBy());
        Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_DATE, entity.getCreatedDate(), dto.getCreatedDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_ID, entity.getId(), dto.getId());
        Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_BY, entity.getModifiedBy(), dto.getModifiedBy());
        Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_DATE, entity.getModifiedDate(), dto.getModifiedDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_ROW_VERSION, entity.getRowVersion(), dto.getRowVersion());

    }

    @Test
    public void testA02DtoToEntity() {

        NotificationTemplatesDto dto = getDto();
        NotificationTemplatesEntity entity = assembler.dtoToEntity(dto);


        Assert.assertEquals(NotifyTestConstant.CHECK_DELETE, dto.getIsDeleted(), entity.getIsDeleted());
        Assert.assertEquals(NotifyTestConstant.CHECK_EVENT_ID, dto.getEventId(), entity.getEventId());
        Assert.assertEquals(NotifyTestConstant.CHECK_DESCRIPTION, dto.getDescription(), entity.getDescription());
        Assert.assertEquals(NotifyTestConstant.CHECK_CODE, dto.getCode(), entity.getCode());
        Assert.assertEquals(NotifyTestConstant.CHECK_NAME, dto.getName(), entity.getName());
        Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_BY, dto.getCreatedBy(), entity.getCreatedBy());
        Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_DATE, dto.getCreatedDate(), entity.getCreatedDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_NAME, dto.getId(), entity.getId());
        Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_BY, dto.getModifiedBy(), entity.getModifiedBy());
        Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_DATE, dto.getModifiedDate(), entity.getModifiedDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_ROW_VERSION, dto.getRowVersion(), entity.getRowVersion());

    }


}
