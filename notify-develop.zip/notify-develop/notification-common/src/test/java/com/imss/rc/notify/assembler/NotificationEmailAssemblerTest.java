package com.imss.rc.notify.assembler;

import com.imss.rc.notify.constants.NotifyTestConstant;
import com.imss.rc.notify.dto.NotificationEmailDto;
import com.imss.rc.notify.entity.NotificationEmailEntity;
import com.imss.rc.notify.util.AuditConstants;
import org.json.JSONException;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Date;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(PowerMockRunner.class)
public class NotificationEmailAssemblerTest {
    @InjectMocks
    private NotificationEmailAssembler assembler;

    private NotificationEmailDto getDto() {

        NotificationEmailDto dto = new NotificationEmailDto();

        dto.setRequestId(101);
        dto.setToEmails("abc@gmail.com");
        dto.setCcEmails("sms notification");
        dto.setMailBody("email notification");
        dto.setSubjectLine("Email");
        dto.setStatus(1);
        dto.setSentDate(new Date(System.currentTimeMillis()));
        dto.setCreatedBy("admin");
        dto.setCreatedDate(new Date(System.currentTimeMillis()));
        dto.setId(1000001);
        dto.setIsDeleted((short) 0);
        dto.setModifiedBy("admin");
        dto.setModifiedDate(new Date(System.currentTimeMillis()));
        dto.setRowVersion(1);
        dto.setResponseMessage("successful");
        dto.setResponseCode("200");
        dto.setResponseStatus("success");

        return dto;

    }

    private NotificationEmailEntity getEntity() throws JSONException {
        NotificationEmailEntity entity = new NotificationEmailEntity();
        entity.setRequestId(101);
        entity.setToEmails("abc@gmail.com");
        entity.setCcEmails("sms notification");
        entity.setMailBody("email notification");
        entity.setSubjectLine("Email");
        entity.setStatus(1);
        entity.setSentDate(new Date(System.currentTimeMillis()));
        entity.setCreatedBy(AuditConstants.ROLE);
        entity.setCreatedDate(new Date(System.currentTimeMillis()));
        entity.setId(1000001);
        entity.setIsDeleted((short)0);
        entity.setModifiedBy(AuditConstants.ROLE);
        entity.setModifiedDate(new Date(System.currentTimeMillis()));

        return entity;
    }

    @Test
    public void testA03DtoListToEntityList() {

        ArrayList<NotificationEmailDto> dtoList = new ArrayList<>();
        dtoList.add(getDto());
        ArrayList<NotificationEmailEntity> entityList = (ArrayList) assembler.dtoListToEntityList(dtoList);
        int index = 0;
        for (NotificationEmailEntity entity : entityList) {


            Assert.assertEquals(NotifyTestConstant.CHECK_DELETE, entity.getIsDeleted(), dtoList.get(index).getIsDeleted());
            Assert.assertEquals(NotifyTestConstant.CHECK_MAIL_BODY, entity.getMailBody(), dtoList.get(index).getMailBody());
            Assert.assertEquals(NotifyTestConstant.CHECK_SUBJECTLINE, entity.getSubjectLine(), dtoList.get(index).getSubjectLine());
            Assert.assertEquals(NotifyTestConstant.CHECK_TO_MAIL, entity.getToEmails(), dtoList.get(index).getToEmails());
            Assert.assertEquals(NotifyTestConstant.CHECK_CC_MAIL, entity.getCcEmails(), dtoList.get(index).getCcEmails());
            Assert.assertEquals(NotifyTestConstant.CHECK_REQUEST_ID, entity.getRequestId(), dtoList.get(index).getRequestId());
            Assert.assertEquals(NotifyTestConstant.CHECK_SENT_DATE, entity.getSentDate(), dtoList.get(index).getSentDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_STATUS, entity.getStatus(), dtoList.get(index).getStatus());
            Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_BY, entity.getCreatedBy(), dtoList.get(index).getCreatedBy());
            Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_DATE, entity.getCreatedDate(), dtoList.get(index).getCreatedDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_ID, entity.getId(), dtoList.get(index).getId());
            Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_BY, entity.getModifiedBy(), dtoList.get(index).getModifiedBy());
            Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_DATE, entity.getModifiedDate(), dtoList.get(index).getModifiedDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_ROW_VERSION, entity.getRowVersion(), dtoList.get(index).getRowVersion());


            index++;
        }
    }

    @Test
    public void testA04EntityListToDtoList() throws JSONException {

        ArrayList<NotificationEmailEntity> entityList = new ArrayList<>();
        entityList.add(getEntity());
        ArrayList<NotificationEmailDto> dtoList = (ArrayList) assembler.entityListToDtoList(entityList);
        int index = 0;
        for (NotificationEmailDto dto : dtoList) {


            Assert.assertEquals(NotifyTestConstant.CHECK_DELETE, dto.getIsDeleted(), dtoList.get(index).getIsDeleted());
            Assert.assertEquals(NotifyTestConstant.CHECK_MAIL_BODY, dto.getMailBody(), dtoList.get(index).getMailBody());
            Assert.assertEquals(NotifyTestConstant.CHECK_SUBJECTLINE, dto.getSubjectLine(), dtoList.get(index).getSubjectLine());
            Assert.assertEquals(NotifyTestConstant.CHECK_TO_MAIL, dto.getToEmails(), dtoList.get(index).getToEmails());
            Assert.assertEquals(NotifyTestConstant.CHECK_CC_MAIL, dto.getCcEmails(), dtoList.get(index).getCcEmails());
            Assert.assertEquals(NotifyTestConstant.CHECK_REQUEST_ID, dto.getRequestId(), dtoList.get(index).getRequestId());
            Assert.assertEquals(NotifyTestConstant.CHECK_SENT_DATE, dto.getSentDate(), dtoList.get(index).getSentDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_STATUS, dto.getStatus(), dtoList.get(index).getStatus());
            Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_BY, dto.getCreatedBy(), dtoList.get(index).getCreatedBy());
            Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_DATE, dto.getCreatedDate(), dtoList.get(index).getCreatedDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_NAME, dto.getId(), dtoList.get(index).getId());
            Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_BY, dto.getModifiedBy(), dtoList.get(index).getModifiedBy());
            Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_DATE, dto.getModifiedDate(), dtoList.get(index).getModifiedDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_ROW_VERSION, dto.getRowVersion(), dtoList.get(index).getRowVersion());


            index++;
        }
    }

    @Test
    public void testA01EntityToDto() throws JSONException {
        NotificationEmailEntity entity = getEntity();
        NotificationEmailDto dto = assembler.entityToDto(entity);


        Assert.assertEquals(NotifyTestConstant.CHECK_DELETE, entity.getIsDeleted(), dto.getIsDeleted());
        Assert.assertEquals(NotifyTestConstant.CHECK_MAIL_BODY, dto.getMailBody(), dto.getMailBody());
        Assert.assertEquals(NotifyTestConstant.CHECK_SUBJECTLINE, dto.getSubjectLine(), dto.getSubjectLine());
        Assert.assertEquals(NotifyTestConstant.CHECK_TO_MAIL, dto.getToEmails(), dto.getToEmails());
        Assert.assertEquals(NotifyTestConstant.CHECK_CC_MAIL, dto.getCcEmails(), dto.getCcEmails());
        Assert.assertEquals(NotifyTestConstant.CHECK_REQUEST_ID, dto.getRequestId(), dto.getRequestId());
        Assert.assertEquals(NotifyTestConstant.CHECK_SENT_DATE, dto.getSentDate(), dto.getSentDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_STATUS, dto.getStatus(), dto.getStatus());
        Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_BY, entity.getCreatedBy(), dto.getCreatedBy());
        Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_DATE, entity.getCreatedDate(), dto.getCreatedDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_NAME, entity.getId(), dto.getId());
        Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_BY, entity.getModifiedBy(), dto.getModifiedBy());
        Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_DATE, entity.getModifiedDate(), dto.getModifiedDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_ROW_VERSION, entity.getRowVersion(), dto.getRowVersion());

    }

    @Test
    public void testA02DtoToEntity() {

        NotificationEmailDto dto = getDto();
        NotificationEmailEntity entity = assembler.dtoToEntity(dto);


        Assert.assertEquals(NotifyTestConstant.CHECK_DELETE, dto.getIsDeleted(), entity.getIsDeleted());
        Assert.assertEquals(NotifyTestConstant.CHECK_MAIL_BODY, dto.getMailBody(), entity.getMailBody());
        Assert.assertEquals(NotifyTestConstant.CHECK_SUBJECTLINE, dto.getSubjectLine(), entity.getSubjectLine());
        Assert.assertEquals(NotifyTestConstant.CHECK_TO_MAIL, dto.getToEmails(), entity.getToEmails());
        Assert.assertEquals(NotifyTestConstant.CHECK_CC_MAIL, dto.getCcEmails(), entity.getCcEmails());
        Assert.assertEquals(NotifyTestConstant.CHECK_REQUEST_ID, dto.getRequestId(), entity.getRequestId());
        Assert.assertEquals(NotifyTestConstant.CHECK_SENT_DATE, dto.getSentDate(), entity.getSentDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_STATUS, dto.getStatus(), entity.getStatus());
        Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_BY, dto.getCreatedBy(), entity.getCreatedBy());
        Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_DATE, dto.getCreatedDate(), entity.getCreatedDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_NAME, dto.getId(), entity.getId());
        Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_BY, dto.getModifiedBy(), entity.getModifiedBy());
        Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_DATE, dto.getModifiedDate(), entity.getModifiedDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_ROW_VERSION, dto.getRowVersion(), entity.getRowVersion());

    }
}
