package com.imss.rc.notify.util;

public class TestConstants {

    public static final boolean TEST_CASE_FAILED = true;

    public static final String EXECUTION_WENT_THROUGH = "Execution went through";
    public static final String EXCEPTION_OCCURRED = "Exception occurred";
    public static final String CHECKING_RIGHT_ERROR_CODE = "Checking Right Error Code";
}
