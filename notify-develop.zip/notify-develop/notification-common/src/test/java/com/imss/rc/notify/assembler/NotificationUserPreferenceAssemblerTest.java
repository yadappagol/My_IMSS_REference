package com.imss.rc.notify.assembler;

import com.imss.rc.notify.constants.NotifyTestConstant;
import com.imss.rc.notify.dto.NotificationUserPreferenceDto;
import com.imss.rc.notify.dto.PreferencesDto;
import com.imss.rc.notify.entity.NotificationUserPreferenceEntity;
import com.imss.rc.notify.util.AuditConstants;
import org.json.JSONException;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Date;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(PowerMockRunner.class)
public class NotificationUserPreferenceAssemblerTest {
    @InjectMocks
    private NotificationUserPreferenceAssembler assembler;

    private NotificationUserPreferenceDto getDto() {

        NotificationUserPreferenceDto dto = new NotificationUserPreferenceDto();
        PreferencesDto preferences = null;
        dto.setUserName("user101");
        dto.setEventId(2);
        dto.setPreferences(preferences);
        dto.setCreatedBy("admin");
        dto.setCreatedDate(new Date(System.currentTimeMillis()));
        dto.setId(1000001);
        dto.setIsDeleted((short) 0);
        dto.setModifiedBy("admin");
        dto.setModifiedDate(new Date(System.currentTimeMillis()));
        dto.setRowVersion(1);
        dto.setResponseMessage("successful");
        dto.setResponseCode("200");
        dto.setResponseStatus("success");

        return dto;

    }

    private NotificationUserPreferenceEntity getEntity() throws JSONException {
        NotificationUserPreferenceEntity entity = new NotificationUserPreferenceEntity();
        entity.setUserName("user101");
        entity.setEventId(2);
        entity.setPreferences(null);
        entity.setCreatedBy(AuditConstants.ROLE);
        entity.setCreatedDate(new Date(System.currentTimeMillis()));
        entity.setId(1000001);
        entity.setIsDeleted((short)0);
        entity.setModifiedBy(AuditConstants.ROLE);
        entity.setModifiedDate(new Date(System.currentTimeMillis()));

        return entity;
    }

    @Test
    public void testA03DtoListToEntityList() {

        ArrayList<NotificationUserPreferenceDto> dtoList = new ArrayList<>();
        dtoList.add(getDto());
        ArrayList<NotificationUserPreferenceEntity> entityList = (ArrayList) assembler.dtoListToEntityList(dtoList);
        int index = 0;
        for (NotificationUserPreferenceEntity entity : entityList) {


            Assert.assertEquals(NotifyTestConstant.CHECK_DELETE, entity.getIsDeleted(), dtoList.get(index).getIsDeleted());
            Assert.assertEquals(NotifyTestConstant.CHECK_PREFERENCE, entity.getPreferences(), dtoList.get(index).getPreferences());
            Assert.assertEquals(NotifyTestConstant.CHECK_USER_ID, entity.getUserName(), dtoList.get(index).getUserName());
            Assert.assertEquals(NotifyTestConstant.CHECK_EVENT_ID, entity.getEventId(), dtoList.get(index).getEventId());
            Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_BY, entity.getCreatedBy(), dtoList.get(index).getCreatedBy());
            Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_DATE, entity.getCreatedDate(), dtoList.get(index).getCreatedDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_ID, entity.getId(), dtoList.get(index).getId());
            Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_BY, entity.getModifiedBy(), dtoList.get(index).getModifiedBy());
            Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_DATE, entity.getModifiedDate(), dtoList.get(index).getModifiedDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_ROW_VERSION, entity.getRowVersion(), dtoList.get(index).getRowVersion());


            index++;
        }
    }

    @Test
    public void testA04EntityListToDtoList() throws JSONException {

        ArrayList<NotificationUserPreferenceEntity> entityList = new ArrayList<>();
        entityList.add(getEntity());
        ArrayList<NotificationUserPreferenceDto> dtoList = (ArrayList) assembler.entityListToDtoList(entityList);
        int index = 0;
        for (NotificationUserPreferenceDto dto : dtoList) {


            Assert.assertEquals(NotifyTestConstant.CHECK_DELETE, dto.getIsDeleted(), dtoList.get(index).getIsDeleted());
            Assert.assertEquals(NotifyTestConstant.CHECK_PREFERENCE, dto.getPreferences(), dtoList.get(index).getPreferences());
            Assert.assertEquals(NotifyTestConstant.CHECK_USER_ID, dto.getUserName(), dtoList.get(index).getUserName());
            Assert.assertEquals(NotifyTestConstant.CHECK_EVENT_ID, dto.getEventId(), dtoList.get(index).getEventId());
            Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_BY, dto.getCreatedBy(), dtoList.get(index).getCreatedBy());
            Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_DATE, dto.getCreatedDate(), dtoList.get(index).getCreatedDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_ID, dto.getId(), dtoList.get(index).getId());
            Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_BY, dto.getModifiedBy(), dtoList.get(index).getModifiedBy());
            Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_DATE, dto.getModifiedDate(), dtoList.get(index).getModifiedDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_ROW_VERSION, dto.getRowVersion(), dtoList.get(index).getRowVersion());


            index++;
        }
    }

    @Test
    public void testA01EntityToDto() throws JSONException {
        NotificationUserPreferenceEntity entity = getEntity();
        NotificationUserPreferenceDto dto = assembler.entityToDto(entity);


        Assert.assertEquals(NotifyTestConstant.CHECK_DELETE, entity.getIsDeleted(), dto.getIsDeleted());
        Assert.assertEquals(NotifyTestConstant.CHECK_PREFERENCE, entity.getPreferences(), dto.getPreferences());
        Assert.assertEquals(NotifyTestConstant.CHECK_USER_ID, entity.getUserName(), dto.getUserName());
        Assert.assertEquals(NotifyTestConstant.CHECK_EVENT_ID, entity.getEventId(), dto.getEventId());
        Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_BY, entity.getCreatedBy(), dto.getCreatedBy());
        Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_DATE, entity.getCreatedDate(), dto.getCreatedDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_NAME, entity.getId(), dto.getId());
        Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_BY, entity.getModifiedBy(), dto.getModifiedBy());
        Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_DATE, entity.getModifiedDate(), dto.getModifiedDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_ROW_VERSION, entity.getRowVersion(), dto.getRowVersion());

    }

    @Test
    public void testA02DtoToEntity() {

        NotificationUserPreferenceDto dto = getDto();
        NotificationUserPreferenceEntity entity = assembler.dtoToEntity(dto);


        Assert.assertEquals(NotifyTestConstant.CHECK_DELETE, dto.getIsDeleted(), entity.getIsDeleted());
        Assert.assertEquals(NotifyTestConstant.CHECK_PREFERENCE, dto.getPreferences(), entity.getPreferences());
        Assert.assertEquals(NotifyTestConstant.CHECK_USER_ID, dto.getUserName(), entity.getUserName());
        Assert.assertEquals(NotifyTestConstant.CHECK_EVENT_ID, dto.getEventId(), entity.getEventId());
        Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_BY, dto.getCreatedBy(), entity.getCreatedBy());
        Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_DATE, dto.getCreatedDate(), entity.getCreatedDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_NAME, dto.getId(), entity.getId());
        Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_BY, dto.getModifiedBy(), entity.getModifiedBy());
        Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_DATE, dto.getModifiedDate(), entity.getModifiedDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_ROW_VERSION, dto.getRowVersion(), entity.getRowVersion());

    }

}
