package com.imss.rc.notify.assembler;

import com.imss.rc.notify.constants.NotifyTestConstant;
import com.imss.rc.notify.dto.NotificationEventsDto;
import com.imss.rc.notify.dto.PreferencesDto;
import com.imss.rc.notify.entity.NotificationEventsEntity;
import com.imss.rc.notify.util.AuditConstants;

import org.json.JSONException;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Date;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(PowerMockRunner.class)
public class NotificationEventsAssemblerTest {
    @InjectMocks
    private NotificationEventsAssembler assembler;

    private NotificationEventsDto getDto() {

            NotificationEventsDto dto = new NotificationEventsDto();
            PreferencesDto preferences = null;
            dto.setDescription("R1");
            dto.setName("Vehicles");
            dto.setIsUserOverrideAllowed((short) 1);
            dto.setCode("kjhg");
            dto.setPreferences(preferences);
            dto.setCreatedBy("admin");
            dto.setCreatedDate(new Date(System.currentTimeMillis()));
            dto.setId(1000001);
            dto.setIsDeleted((short) 0);
            dto.setModifiedBy("admin");
            dto.setModifiedDate(new Date(System.currentTimeMillis()));
            dto.setRowVersion(1);
            dto.setResponseMessage("successful");
            dto.setResponseCode("200");
            dto.setResponseStatus("success");

            return dto;

    }

    private NotificationEventsEntity getEntity() throws JSONException {
        NotificationEventsEntity entity = new NotificationEventsEntity();
        entity.setIsUserOverrideAllowed((short) 1);
        entity.setCode("abcdef");
        entity.setPreferences(null);
        entity.setDescription("R1");
        entity.setName("User Registration");
        entity.setCreatedBy(AuditConstants.ROLE);
        entity.setCreatedDate(new Date(System.currentTimeMillis()));
        entity.setId(1000001);
        entity.setIsDeleted((short)0);
        entity.setModifiedBy(AuditConstants.ROLE);
        entity.setModifiedDate(new Date(System.currentTimeMillis()));

        return entity;
    }

    @Test
    public void testA03DtoListToEntityList() {

        ArrayList<NotificationEventsDto> dtoList = new ArrayList<>();
        dtoList.add(getDto());
        ArrayList<NotificationEventsEntity> entityList = (ArrayList) assembler.dtoListToEntityList(dtoList);
        int index = 0;
        for (NotificationEventsEntity entity : entityList) {


            Assert.assertEquals(NotifyTestConstant.CHECK_DELETE, entity.getIsDeleted(), dtoList.get(index).getIsDeleted());
            Assert.assertEquals(NotifyTestConstant.CHECK_IS_OVERRIDE_ALLOWED, entity.getIsUserOverrideAllowed(), dtoList.get(index).getIsUserOverrideAllowed());
            Assert.assertEquals(NotifyTestConstant.CHECK_PREFERENCE, entity.getPreferences(), dtoList.get(index).getPreferences());
            Assert.assertEquals(NotifyTestConstant.CHECK_DESCRIPTION, entity.getDescription(), dtoList.get(index).getDescription());
            Assert.assertEquals(NotifyTestConstant.CHECK_CODE, entity.getCode(), dtoList.get(index).getCode());
            Assert.assertEquals(NotifyTestConstant.CHECK_NAME, entity.getName(), dtoList.get(index).getName());
            Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_BY, entity.getCreatedBy(), dtoList.get(index).getCreatedBy());
            Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_DATE, entity.getCreatedDate(), dtoList.get(index).getCreatedDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_NAME, entity.getId(), dtoList.get(index).getId());
            Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_BY, entity.getModifiedBy(), dtoList.get(index).getModifiedBy());
            Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_DATE, entity.getModifiedDate(), dtoList.get(index).getModifiedDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_ROW_VERSION, entity.getRowVersion(), dtoList.get(index).getRowVersion());


            index++;
        }
    }

    @Test
    public void testA04EntityListToDtoList() throws JSONException {

        ArrayList<NotificationEventsEntity> entityList = new ArrayList<>();
        entityList.add(getEntity());
        ArrayList<NotificationEventsDto> dtoList = (ArrayList) assembler.entityListToDtoList(entityList);
        int index = 0;
        for (NotificationEventsDto dto : dtoList) {


            Assert.assertEquals(NotifyTestConstant.CHECK_DELETE, dto.getIsDeleted(), dtoList.get(index).getIsDeleted());
            Assert.assertEquals(NotifyTestConstant.CHECK_IS_OVERRIDE_ALLOWED, dto.getIsUserOverrideAllowed(), dtoList.get(index).getIsUserOverrideAllowed());
            Assert.assertEquals(NotifyTestConstant.CHECK_DESCRIPTION, dto.getDescription(), dtoList.get(index).getDescription());
            Assert.assertEquals(NotifyTestConstant.CHECK_CODE, dto.getCode(), dtoList.get(index).getCode());
            Assert.assertEquals(NotifyTestConstant.CHECK_NAME, dto.getName(), dtoList.get(index).getName());
            Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_BY, dto.getCreatedBy(), dtoList.get(index).getCreatedBy());
            Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_DATE, dto.getCreatedDate(), dtoList.get(index).getCreatedDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_ID, dto.getId(), dtoList.get(index).getId());
            Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_BY, dto.getModifiedBy(), dtoList.get(index).getModifiedBy());
            Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_DATE, dto.getModifiedDate(), dtoList.get(index).getModifiedDate());
            Assert.assertEquals(NotifyTestConstant.CHECK_ROW_VERSION, dto.getRowVersion(), dtoList.get(index).getRowVersion());


            index++;
        }
    }

    @Test
    public void testA01EntityToDto() throws JSONException {
        NotificationEventsEntity entity = getEntity();
        NotificationEventsDto dto = assembler.entityToDto(entity);


        Assert.assertEquals(NotifyTestConstant.CHECK_DELETE, entity.getIsDeleted(), dto.getIsDeleted());
        Assert.assertEquals(NotifyTestConstant.CHECK_IS_OVERRIDE_ALLOWED, entity.getIsUserOverrideAllowed(), dto.getIsUserOverrideAllowed());
        Assert.assertEquals(NotifyTestConstant.CHECK_DESCRIPTION, entity.getDescription(), dto.getDescription());
        Assert.assertEquals(NotifyTestConstant.CHECK_CODE, entity.getCode(), dto.getCode());
        Assert.assertEquals(NotifyTestConstant.CHECK_NAME, entity.getName(), dto.getName());
        Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_BY, entity.getCreatedBy(), dto.getCreatedBy());
        Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_DATE, entity.getCreatedDate(), dto.getCreatedDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_NAME, entity.getId(), dto.getId());
        Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_BY, entity.getModifiedBy(), dto.getModifiedBy());
        Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_DATE, entity.getModifiedDate(), dto.getModifiedDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_ROW_VERSION, entity.getRowVersion(), dto.getRowVersion());

    }

    @Test
    public void testA02DtoToEntity() {

        NotificationEventsDto dto = getDto();
        NotificationEventsEntity entity = assembler.dtoToEntity(dto);


        Assert.assertEquals(NotifyTestConstant.CHECK_DELETE, dto.getIsDeleted(), entity.getIsDeleted());
        Assert.assertEquals(NotifyTestConstant.CHECK_IS_OVERRIDE_ALLOWED, dto.getIsUserOverrideAllowed(), entity.getIsUserOverrideAllowed());
        Assert.assertEquals(NotifyTestConstant.CHECK_DESCRIPTION, dto.getDescription(), entity.getDescription());
        Assert.assertEquals(NotifyTestConstant.CHECK_CODE, dto.getCode(), entity.getCode());
        Assert.assertEquals(NotifyTestConstant.CHECK_NAME, dto.getName(), entity.getName());
        Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_BY, dto.getCreatedBy(), entity.getCreatedBy());
        Assert.assertEquals(NotifyTestConstant.CHECK_CREATED_DATE, dto.getCreatedDate(), entity.getCreatedDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_ID, dto.getId(), entity.getId());
        Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_BY, dto.getModifiedBy(), entity.getModifiedBy());
        Assert.assertEquals(NotifyTestConstant.CHECK_MODIFIED_DATE, dto.getModifiedDate(), entity.getModifiedDate());
        Assert.assertEquals(NotifyTestConstant.CHECK_ROW_VERSION, dto.getRowVersion(), entity.getRowVersion());

    }


}
