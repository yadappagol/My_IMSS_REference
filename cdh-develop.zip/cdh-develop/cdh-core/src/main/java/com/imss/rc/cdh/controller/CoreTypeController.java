package com.imss.rc.cdh.controller;

import com.imss.rc.cdh.dto.CoreDataDetailsDto;
import com.imss.rc.cdh.dto.CoreDataTypesDto;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

public interface CoreTypeController {

    //1.List all core data types
    @GetMapping(value = "/core-data-types",produces = "application/json")
    @ResponseBody
    BaseListDto<CoreDataTypesDto> getCoreDataTypes(@RequestParam Integer limit,
                                                   @RequestParam Integer page,
                                                   @RequestParam(required = false) String key,
                                                   @RequestParam(required = false) String name,
                                                   @RequestParam(required = false) Integer isVisible,
                                                   @RequestParam(required = false) String sortBy,
                                                   @RequestParam(required = false) String sortType, HttpServletRequest request)  throws CdhException;

    //3.To retrieve the details of a specific core data
    @GetMapping(value = "/core-data/{id}", produces = "application/json")
    @ResponseBody
    CoreDataDetailsDto getCoreDataDetailsById(@PathVariable("id") Integer id, HttpServletRequest request)  throws CdhException;

    //4.To add a new record
    @PostMapping(value="/core-data" ,produces = "application/json")
    @ResponseBody
    CoreDataDetailsDto saveCoreDataDetails(@RequestBody CoreDataDetailsDto coreDataDetailsDto, HttpServletRequest request) throws CdhException;

    //5.To Update a record
    @PutMapping(value = "/core-data/{id}", produces = "application/json")
    CoreDataDetailsDto updateCoreDataDetailsById(@RequestBody CoreDataDetailsDto coreDataDetailsDto, @PathVariable("id") Integer id,HttpServletRequest request)  throws CdhException;

    //6.To Delete a record
    @DeleteMapping(value = "/core-data/{id}", produces = "application/json")
    IdDto deleteCoreDataDetailsById(@PathVariable("id") Integer id, HttpServletRequest request) throws CdhException;

    //2.To retrieve the list of core data for specific type
    @GetMapping(value = "/core-data", produces = "application/json")
    @ResponseBody
    BaseListDto<CoreDataDetailsDto> getAllCoreDataDetails(@RequestParam Integer typeId,
                                                  @RequestParam Integer limit,
                                                  @RequestParam Integer page,
                                                  @RequestParam(required = false) String name,
                                                  @RequestParam(required = false) String sortBy,
                                                  @RequestParam(required = false) String sortType,HttpServletRequest request)  throws CdhException;

    //2.To retrieve the list of core data for specific type
    @GetMapping(value = "/multi-core-data", produces = "application/json")
    @ResponseBody
    BaseListDto<BaseListDto<CoreDataDetailsDto>>  getAllCoreDataDetailsForMultiple(@RequestParam String typeIds,
                                                                            @RequestParam Integer limit,
                                                                            @RequestParam Integer page,
                                                                            @RequestParam(required = false) String name,
                                                                            @RequestParam(required = false) String sortBy,
                                                                            @RequestParam(required = false) String sortType,HttpServletRequest request)  throws CdhException;


}
