package com.imss.rc.cdh.service;

import com.imss.rc.cdh.dto.MultiLevelCoreDataDto;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;

public interface MultiLevelCoreDataService {

    public MultiLevelCoreDataDto saveMultiLevelCoreData(MultiLevelCoreDataDto multiLevelCoreDataDto)  throws CdhException;

    public MultiLevelCoreDataDto updateMultiLevelCoreDataById(MultiLevelCoreDataDto multiLevelCoreDataDto,
                                                              Integer id) throws CdhException;

    public IdDto deleteMultiLevelCoreDataById(MultiLevelCoreDataDto multiLevelCoreDataDto)  throws CdhException;

    public MultiLevelCoreDataDto getMultiLevelCoreDataById(Integer id)  throws CdhException;

    public BaseListDto<MultiLevelCoreDataDto> getAllMultiLevelCoreData(MultiLevelCoreDataDto multiLevelCoreDataDto)  throws CdhException;

}
