package com.imss.rc.cdh.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.cdh.dto.CoreDataDetailsDto;
import com.imss.rc.cdh.dto.CoreDataTypesDto;
import com.imss.rc.cdh.repository.CoreDataTypeRepository;
import com.imss.rc.cdh.util.KafkaSendCdhMessage;
import com.imss.rc.cdh.validation.ValidateCdh;
import com.imss.rc.cdh.assembler.CoreDataDetailsAssembler;
import com.imss.rc.cdh.assembler.CoreDataTypesAssembler;
import com.imss.rc.cdh.constants.CdhConstants;
import com.imss.rc.cdh.entity.CoreDataDetailsEntity;
import com.imss.rc.cdh.entity.CoreDataTypesEntity;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.enums.AuditEnum;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.cdh.enums.DefaultValue;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.cdh.repository.CoreDataDetailsRepository;
import com.imss.rc.commons.constants.SortTypeConstants;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.ActionTypeEnum;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import java.util.*;

@Service
public class CoreTypeServiceImpl implements CoreTypeService{

    @Autowired
    CoreDataTypeRepository coreDataTypeRepository;

    @Autowired
    CoreDataDetailsRepository coreDataDetailsRepository;

    @Autowired
    CoreDataTypesAssembler assembler;

    @Autowired
    CoreDataDetailsAssembler detailAssembler;

    @Autowired
    EntityManager em;

    @Autowired
    ValidateCdh validate;

    @Autowired
    KafkaSendCdhMessage kafkaSendCdhMessage;


    private static final Logger LOG = LoggerFactory.getLogger(CoreTypeServiceImpl.class);

    //1.List all core data types
    /**
     * This method retrieves the list of core data types
     * @param dto for which the list of core data types need to be retrieved
     * @return CoreDataTypesDto
     * @throws CdhException is thrown
     */
    @Override
    public BaseListDto<CoreDataTypesDto> getAllCoreDataTypes(CoreDataTypesDto dto) throws CdhException{
        BaseListDto<CoreDataTypesDto> dtoList = new BaseListDto<>();
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        try {

            //If the order by is blank then setting it to default by asc
            if(Objects.isNull(dto.getPagination().getSortType()) || dto.getPagination().getSortType().isEmpty()){
                dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }
            //If the sort by is blank then set the default sort by column to name and order by asc
            if(Objects.isNull(dto.getPagination().getSortBy()) || dto.getPagination().getSortBy().isEmpty()){
                dto.getPagination().setSortBy(CdhConstants.SORT_BY_NAME);
                dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }

            PageableEntity<CoreDataTypesEntity> data = coreDataTypeRepository.getAllCoreDataTypesWithFilters(em, dto);

            PaginationDto pageDto = dto.getPagination();
            pageDto.setCount(data.getCount());


            dtoList.setPagination(pageDto);
            dtoList.setDataList(assembler.entityListToDtoList(data.getData()));
            dtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            dtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            dtoList.setAuditEventId(AuditEnum.INSURANCE_CORE_DATA.getValue());

            auditMasterDto.setEventId(AuditEnum.INSURANCE_CORE_DATA.getValue());
            auditMasterDto.setWhen(dto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(dtoList.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(dto.getCreatedBy());
            auditMasterDto.setDescription(String.format(CdhConstants.RETRIEVED_CORE_DATA_TYPES_LIST,
                    dtoList.getPagination().getPage(),
                    dtoList.getPagination().getLimit(),
                    dtoList.getPagination().getSortBy(),
                    dtoList.getPagination().getSortType(),
                    dtoList.getPagination().getCount())
            );
            kafkaSendCdhMessage.sendMessage(auditMasterDto);
            return dtoList;
        } catch (CdhException ex) {
            throw ex;
        } catch (Exception ex) {
            LOG.error("Exception in view all core data type  :", ex);
            throw new CdhException(CdhException.UNABLE_TO_FIND_CORE_DATA_TYPES, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * This method retrieves the details of core data
     * @param id for which the core data details need to be retrieved
     * @return CoreDataDetailsDto
     * @throws CdhException CdhException is thrown
     */
    //3.To retrieve the details of a specific core data
    @Override
    public CoreDataDetailsDto getCoreDataDetailsById(int id) throws CdhException{
        CoreDataDetailsDto coreDataDetailsDto ;
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        try {
            CoreDataDetailsEntity coreDataDetailsEntity = coreDataDetailsRepository.getOne(id);
            if (coreDataDetailsEntity.getIsDeleted() == GlobalYesNoEnum.YES.getValue()) {
                throw  new CdhException(CdhException.CORE_DATA_NOT_FOUND, new String[]{String.valueOf(id)}, HttpStatus.NOT_FOUND) ;
            }
            ObjectMapper mapper = new ObjectMapper();
            coreDataDetailsDto = detailAssembler.entityToDto(coreDataDetailsEntity);
            if(Objects.nonNull(coreDataDetailsEntity.getAdditionalData())) {
                HashMap<String, Object> map = (HashMap<String, Object>) mapper.readValue(coreDataDetailsEntity.getAdditionalData(), Map.class);
                coreDataDetailsDto.setAdditionalData(map);
            }
            coreDataDetailsDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            coreDataDetailsDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);

            //Auditing the updates
            auditMasterDto.setEventId(AuditEnum.INSURANCE_CORE_DATA.getValue());
            auditMasterDto.setWhen(coreDataDetailsDto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(id));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(coreDataDetailsDto.getCreatedBy());
            auditMasterDto.setDescription(String.format(CdhConstants.RETRIEVED_CORE_DATA_DETAILS,coreDataDetailsDto.getName()));
            kafkaSendCdhMessage.sendMessage(auditMasterDto);

        } catch (CdhException ex) {
            throw ex;
        } catch (EntityNotFoundException ex) {
            throw  new CdhException(CdhException.CORE_DATA_NOT_FOUND, new String[]{String.valueOf(id)}, HttpStatus.NOT_FOUND) ;
        } catch (Exception ex) {
            LOG.error("Exception in view core data details:", ex);
            throw new CdhException(CdhException.UNABLE_TO_FIND_CORE_DATA_TYPES, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return coreDataDetailsDto;
    }

    /**
     * This method saves the details of core data
     * @param coreDataDetailsDto for which the core data details need to be saved
     * @return CoreDataDetailsDto
     * @throws CdhException CdhException is thrown
     */
    //4.To add a new record
    @Override
    public CoreDataDetailsDto saveCoreDataDetails(CoreDataDetailsDto coreDataDetailsDto)  throws CdhException {
        ObjectMapper mapper = new ObjectMapper();
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        try {
            HashMap<String,Object> map = coreDataDetailsDto.getAdditionalData();
            CoreDataDetailsEntity coreDataDetailsEntity ;
            coreDataDetailsEntity = detailAssembler.dtoToEntity(coreDataDetailsDto);
            if(validate.isNameValid(coreDataDetailsDto.getName()) && validate.isValidTypeId(coreDataDetailsDto.getTypeId())) {

                coreDataDetailsEntity.setIsEditable(DefaultValue.isEditable.getNumVal());
                coreDataDetailsEntity.setAdditionalData(mapper.writeValueAsString(map));
                coreDataDetailsEntity.setIsDeleted((short) GlobalYesNoEnum.NO.getValue());

                //Use the auth data in the dto to resolve the base data
                UserAuthDataHandler.resolveEntityBaseData(coreDataDetailsDto, coreDataDetailsEntity);
                coreDataDetailsEntity.setModifiedDate(coreDataDetailsEntity.getCreatedDate());
                coreDataDetailsRepository.save(coreDataDetailsEntity);
            }
            HashMap<String, Object> data = (HashMap<String, Object>) mapper.readValue(coreDataDetailsEntity.getAdditionalData(), Map.class);
            CoreDataDetailsDto coreDataDetailDto = detailAssembler.entityToDto(coreDataDetailsEntity);
            coreDataDetailDto.setAdditionalData(data);
            coreDataDetailDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            coreDataDetailDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);

            //auditing the updates
            auditMasterDto.setEventId(AuditEnum.INSURANCE_CORE_DATA.getValue());
            auditMasterDto.setWhen(coreDataDetailDto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(coreDataDetailsEntity.getTypeId()));
            auditMasterDto.setActionType(ActionTypeEnum.ADD.getValue());
            auditMasterDto.setWho(coreDataDetailDto.getCreatedBy());
            auditMasterDto.setDescription(String.format(CdhConstants.ADDED_CORE_DATA_DETAILS, coreDataDetailDto.getName()));
            kafkaSendCdhMessage.sendMessage(auditMasterDto);
            return coreDataDetailDto;
        } catch(CdhException ex){
            throw ex;
        } catch (Exception ex) {
            LOG.error("Exception in add core data details :", ex);
            throw new CdhException(CdhException.UNABLE_TO_CREATE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * This method updates the details of core data
     * @param id for which the core data details need to be retrieved and updated
     * @return CoreDataDetailsDto
     * @throws CdhException  is thrown
     */
    @Override
    public CoreDataDetailsDto updateCoreDataDetailsById(CoreDataDetailsDto coreDataDetailsDto, Integer id) throws CdhException {
        try {
            ObjectMapper mapper = new ObjectMapper();
            CoreDataDetailsEntity  coreDataDetailsEntity  = coreDataDetailsRepository.getOne(id);
            if( coreDataDetailsEntity.getIsDeleted() == GlobalYesNoEnum.YES.getValue()){
                throw  new CdhException(CdhException.CORE_DATA_NOT_FOUND, new String[]{String.valueOf(coreDataDetailsDto.getId())}, HttpStatus.NOT_FOUND) ;
            }
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            HashMap<String,Object> map = coreDataDetailsDto.getAdditionalData();
            if (coreDataDetailsEntity.getIsEditable()==DefaultValue.isEditable.getNumVal()  &&
                    validate.isNameValid(coreDataDetailsDto.getName()) &&
                    validate.isValidTypeId(coreDataDetailsDto.getTypeId()))
            {
                detailAssembler.dtoToEntity(coreDataDetailsDto);
                //Use the auth data in the dto to resolve the base data
               UserAuthDataHandler.resolveEntityBaseData(coreDataDetailsDto, coreDataDetailsEntity);

                coreDataDetailsEntity.setTypeId(coreDataDetailsDto.getTypeId());
                coreDataDetailsEntity.setDescription(coreDataDetailsDto.getDescription());
                coreDataDetailsEntity.setName(coreDataDetailsDto.getName());
                coreDataDetailsEntity.setIsDeleted((short) GlobalYesNoEnum.NO.getValue());
                coreDataDetailsEntity.setAdditionalData(mapper.writeValueAsString(map));
                coreDataDetailsRepository.saveAndFlush(coreDataDetailsEntity);

                HashMap<String, Object> data = (HashMap<String, Object>) mapper.readValue(coreDataDetailsEntity.getAdditionalData(), Map.class);
                CoreDataDetailsDto coreDataDetailDto = detailAssembler.entityToDto(coreDataDetailsEntity);
                coreDataDetailDto.setAdditionalData(data);
                coreDataDetailDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                coreDataDetailDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);

                //auditing the updates made
                auditMasterDto.setEventId(AuditEnum.INSURANCE_CORE_DATA.getValue());
                auditMasterDto.setWhen(coreDataDetailsDto.getModifiedDate());
                auditMasterDto.setReferenceId(String.valueOf(id));
                auditMasterDto.setActionType(ActionTypeEnum.UPDATE.getValue());
                auditMasterDto.setWho(coreDataDetailsDto.getModifiedBy());
                auditMasterDto.setDescription(String.format(CdhConstants.UPDATED_CORE_DATA_DETAILS,coreDataDetailsDto.getName()));
                kafkaSendCdhMessage.sendMessage(auditMasterDto);
                return coreDataDetailsDto;
            } else {
                throw new CdhException(CdhException.ROW_IS_NOT_EDITABLE,HttpStatus.NOT_FOUND);
            }
        } catch(CdhException ex){
            throw ex;
        }catch (EntityNotFoundException ex) {
            throw  new CdhException(CdhException.CORE_DATA_NOT_FOUND, new String[]{String.valueOf(coreDataDetailsDto.getId())}, HttpStatus.NOT_FOUND) ;
        } catch(Exception ex){
            LOG.error("Exception in update core data details :", ex);
            throw new CdhException(CdhException.UNABLE_TO_UPDATE_CORE_DATA_TYPES, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    /**
     * This method deletes the details of core data
     * @param coreDataDetailsDto for which the core data details need to be retrieved and deleted
     * @return IdDto
     * @throws CdhException is thrown
     */
    //6.To Delete a record
    @Override
    public IdDto deleteCoreDataDetailsById(CoreDataDetailsDto coreDataDetailsDto) throws CdhException{
        ResponseDto response = new ResponseDto();
        IdDto idDto=new IdDto();
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        try {
            CoreDataDetailsEntity coreDataDetailsEntity=coreDataDetailsRepository.getOne(coreDataDetailsDto.getId());
            if( coreDataDetailsEntity.getIsDeleted() == GlobalYesNoEnum.YES.getValue()){
                throw  new CdhException(CdhException.CORE_DATA_NOT_FOUND, new String[]{String.valueOf(coreDataDetailsDto.getId())}, HttpStatus.NOT_FOUND) ;
            }
            if(validate.isEditable(coreDataDetailsDto.getId())) {
                coreDataDetailsEntity.setIsDeleted((short) GlobalYesNoEnum.YES.getValue());

                //Use the auth data in the dto to resolve the base data
                 UserAuthDataHandler.resolveEntityBaseData(coreDataDetailsDto, coreDataDetailsEntity);

                coreDataDetailsRepository.save(coreDataDetailsEntity);
                response.setResponseStatus(ResponseDto.STATUS_SUCCESS);
                response.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);

                //auditing the updates made
                auditMasterDto.setEventId(AuditEnum.INSURANCE_CORE_DATA.getValue());
                auditMasterDto.setWhen(coreDataDetailsDto.getModifiedDate());
                auditMasterDto.setReferenceId(String.valueOf(coreDataDetailsDto.getId()));
                auditMasterDto.setActionType(ActionTypeEnum.DELETE.getValue());
                auditMasterDto.setWho(coreDataDetailsDto.getModifiedBy());
                auditMasterDto.setDescription(String.format(CdhConstants.DELETED_CORE_DATA_DETAILS,coreDataDetailsEntity.getName()));
                kafkaSendCdhMessage.sendMessage(auditMasterDto);
            } else {
                throw new CdhException(CdhException.ROW_IS_NOT_EDITABLE, HttpStatus.BAD_REQUEST);
            }
            idDto.setId(coreDataDetailsDto.getId());
        } catch(CdhException ex){
            throw ex;
        } catch (EntityNotFoundException ex) {
            throw  new CdhException(CdhException.CORE_DATA_NOT_FOUND, new String[]{String.valueOf(coreDataDetailsDto.getId())}, HttpStatus.NOT_FOUND) ;
        } catch (Exception ex) {
            LOG.error("Exception in delete core data details:", ex);
            throw new CdhException(CdhException.UNABLE_TO_DELETE_CORE_DATA_TYPES, HttpStatus.INTERNAL_SERVER_ERROR) ;
        }
        return idDto;
    }

    /**
     * This method retrieves the list of details of core data
     * @param dto for which the list of core data details need to be retrieved
     * @return BaseListDto<CoreDataDetailsDto>
     * @throws CdhException is thrown
     */
    @Override
    public BaseListDto<CoreDataDetailsDto> getAllCoreDataDetails(CoreDataDetailsDto dto) throws CdhException{
        BaseListDto<CoreDataDetailsDto> dtoList = new BaseListDto<>();
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        try {

            //If the order by is blank then setting it to default by asc
            if(Objects.isNull(dto.getPagination().getSortType()) || dto.getPagination().getSortType().isEmpty()){
                dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }
            //If the sort by is blank then set the default sort by column to name and order by asc
            if(Objects.isNull(dto.getPagination().getSortBy()) || dto.getPagination().getSortBy().isEmpty()){
                dto.getPagination().setSortBy(CdhConstants.SORT_BY_NAME);
                dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }

            PageableEntity<CoreDataDetailsEntity> data = coreDataDetailsRepository.getAllCoreDataDetailsWithFilters(em, dto);

            PaginationDto pageDto = dto.getPagination();
            pageDto.setCount(data.getCount());

            dtoList.setPagination(pageDto);

            dtoList.setDataList(detailAssembler.entityListToDtoList(data.getData()));
            dtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            dtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            dtoList.setAuditEventId(AuditEnum.INSURANCE_CORE_DATA.getValue());

            //auditing the updates made
            auditMasterDto.setEventId(AuditEnum.INSURANCE_CORE_DATA.getValue());
            auditMasterDto.setWhen(dto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(dto.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(dto.getCreatedBy());
            auditMasterDto.setDescription(String.format(CdhConstants.RETRIEVED_CORE_DATA_DETAILS_LIST,
                    dtoList.getPagination().getPage(),
                    dtoList.getPagination().getLimit(),
                    dtoList.getPagination().getSortBy(),
                    dtoList.getPagination().getSortType(),
                    dtoList.getPagination().getCount())
            );
            kafkaSendCdhMessage.sendMessage(auditMasterDto);
            return dtoList;
        } catch (CdhException ex) {
            throw ex;
        } catch (Exception ex) {
            LOG.error("Exception in view all core data details :", ex);
            throw new CdhException(CdhException.UNABLE_TO_FIND_CORE_DATA_DETAILS, HttpStatus.NOT_FOUND) ;
        }
    }
}
