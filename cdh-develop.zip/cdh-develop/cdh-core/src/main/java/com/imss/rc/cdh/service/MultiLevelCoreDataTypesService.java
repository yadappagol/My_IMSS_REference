package com.imss.rc.cdh.service;

import com.imss.rc.cdh.dto.MultiLevelCoreDataTypesDto;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;

public interface MultiLevelCoreDataTypesService {

    public MultiLevelCoreDataTypesDto saveMultiLevelCoreDataTypes(MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto)  throws CdhException;

    public MultiLevelCoreDataTypesDto updateMultiLevelCoreDataTypesById(MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto,
                                                                        Integer id) throws CdhException;

    public IdDto deleteMultiLevelCoreDataTypesById(MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto)  throws CdhException;

    public MultiLevelCoreDataTypesDto getMultiLevelCoreDataTypesById(Integer id)  throws CdhException;

    public BaseListDto<MultiLevelCoreDataTypesDto> getAllMultiLevelCoreDataTypes(MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto)  throws CdhException;
}
