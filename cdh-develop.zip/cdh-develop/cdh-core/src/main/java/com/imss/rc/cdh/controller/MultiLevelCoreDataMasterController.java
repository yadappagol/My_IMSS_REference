package com.imss.rc.cdh.controller;

import com.imss.rc.cdh.dto.MultiLevelCoreDataMasterDto;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

public interface MultiLevelCoreDataMasterController {

    @PostMapping(value="/ml-core-data/masters" ,produces = "application/json")
    @ResponseBody
    MultiLevelCoreDataMasterDto saveMultiLevelCoreData(@RequestBody MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto, HttpServletRequest request) throws CdhException;

    @PutMapping(value = "/ml-core-data/masters/{id}", produces = "application/json")
    MultiLevelCoreDataMasterDto updateMultiLevelCoreDataById(@RequestBody MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto, @PathVariable("id") Integer id, HttpServletRequest request)  throws CdhException;

    @DeleteMapping(value = "/ml-core-data/masters/{id}", produces = "application/json")
    IdDto deleteMultiLevelCoreDataById(@PathVariable("id") Integer id, HttpServletRequest request) throws CdhException;

    @GetMapping(value = "/ml-core-data/masters", produces = "application/json")
    @ResponseBody
    BaseListDto<MultiLevelCoreDataMasterDto> getAllMultiLevelCoreDataById(@RequestParam Integer typeId,
                                                                          @RequestParam Integer limit,
                                                                          @RequestParam Integer page,
                                                                          @RequestParam(required = false) String name,
                                                                          @RequestParam(required = false) String sortBy,
                                                                          @RequestParam(required = false) String sortType, HttpServletRequest request)  throws CdhException;

    @GetMapping(value = "/ml-core-data/masters/{id}", produces = "application/json")
    @ResponseBody
    MultiLevelCoreDataMasterDto getMultiLevelCoreDataMasterById(@PathVariable("id") Integer id,HttpServletRequest request)  throws CdhException;
}
