package com.imss.rc.cdh.service;

import com.imss.rc.cdh.dto.CoreDataDetailsDto;
import com.imss.rc.cdh.dto.CoreDataTypesDto;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;

public interface CoreTypeService {

    public BaseListDto<CoreDataTypesDto> getAllCoreDataTypes(CoreDataTypesDto dto)  throws CdhException;

    public CoreDataDetailsDto getCoreDataDetailsById(int id)  throws CdhException;

    public IdDto deleteCoreDataDetailsById(CoreDataDetailsDto coreDataDetailsDto)  throws CdhException;

    public CoreDataDetailsDto saveCoreDataDetails(CoreDataDetailsDto coreDataDetailsDto)  throws CdhException;

    public CoreDataDetailsDto updateCoreDataDetailsById(CoreDataDetailsDto coreDataDetailsDto,
                                                     Integer id) throws CdhException;
    public BaseListDto<CoreDataDetailsDto> getAllCoreDataDetails(CoreDataDetailsDto dto) throws CdhException;
}
