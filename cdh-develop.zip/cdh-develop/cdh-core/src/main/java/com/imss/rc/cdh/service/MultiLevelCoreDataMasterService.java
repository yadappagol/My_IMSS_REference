package com.imss.rc.cdh.service;

import com.imss.rc.cdh.dto.MultiLevelCoreDataMasterDto;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;

public interface MultiLevelCoreDataMasterService {

    public MultiLevelCoreDataMasterDto saveMultiLevelCoreDataMaster(MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto)  throws CdhException;

    public MultiLevelCoreDataMasterDto updateMultiLevelCoreDataMasterById(MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto,
                                                                          Integer id) throws CdhException;

    public IdDto deleteMultiLevelCoreDataMasterById(MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto)  throws CdhException;

    public MultiLevelCoreDataMasterDto getMultiLevelCoreDataMasterById(Integer id)  throws CdhException;

    public BaseListDto<MultiLevelCoreDataMasterDto> getAllMultiLevelCoreDataMaster(MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto)  throws CdhException;

}
