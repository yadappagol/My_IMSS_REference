package com.imss.rc.cdh.controller;

import com.imss.rc.cdh.dto.MultiLevelCoreDataTypesDto;
import com.imss.rc.cdh.service.MultiLevelCoreDataTypesService;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Objects;

@RestController
public class MultiLevelCoreDataTypesControllerImpl implements MultiLevelCoreDataTypesController{

    @Autowired
    MultiLevelCoreDataTypesService multiLevelCoreDataTypesService;

    @Override
    public MultiLevelCoreDataTypesDto saveMultiLevelCoreDataTypes(MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto, HttpServletRequest request) throws CdhException {
       UserAuthDataHandler.resolveAuthBaseData(multiLevelCoreDataTypesDto, request);
        return multiLevelCoreDataTypesService.saveMultiLevelCoreDataTypes(multiLevelCoreDataTypesDto);
    }

    @Override
    public MultiLevelCoreDataTypesDto updateMultiLevelCoreDataTypesById(MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto, Integer id, HttpServletRequest request) throws CdhException {
        UserAuthDataHandler.resolveAuthBaseData(multiLevelCoreDataTypesDto, request);
        return  multiLevelCoreDataTypesService.updateMultiLevelCoreDataTypesById(multiLevelCoreDataTypesDto,id);
    }

    @Override
    public IdDto deleteMultiLevelCoreDataTypesById(Integer id, HttpServletRequest request) throws CdhException {
        MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto= new MultiLevelCoreDataTypesDto();
        multiLevelCoreDataTypesDto.setId(id);
        UserAuthDataHandler.resolveAuthBaseData(multiLevelCoreDataTypesDto, request);
        return multiLevelCoreDataTypesService.deleteMultiLevelCoreDataTypesById(multiLevelCoreDataTypesDto);
    }

    @Override
    public BaseListDto<MultiLevelCoreDataTypesDto> getAllMultiLevelCoreDataTypes(Integer limit, Integer page, String key, String name, Integer isVisible, String sortBy, String sortType, HttpServletRequest request) throws CdhException {
        if (Objects.isNull(page)||page < GlobalYesNoEnum.YES.getValue()) {
            throw new CdhException(CdhException.INVALID_PAGE, HttpStatus.BAD_REQUEST);
        }
        if (Objects.isNull(limit) || limit < GlobalYesNoEnum.YES.getValue()) {
            throw new CdhException(CdhException.INVALID_LIMIT, HttpStatus.BAD_REQUEST);
        }
        MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto= new MultiLevelCoreDataTypesDto();
        if(!StringUtils.isEmpty(key)) {
            multiLevelCoreDataTypesDto.setKey(key);
        }
        if(!StringUtils.isEmpty(name)) {
            multiLevelCoreDataTypesDto.setName(name);
        }
        if(!StringUtils.isEmpty(isVisible)) {
            multiLevelCoreDataTypesDto.setIsVisible(isVisible);
        }
        PaginationDto pageDto = new PaginationDto();
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);
        multiLevelCoreDataTypesDto.setPagination(pageDto);

        UserAuthDataHandler.resolveAuthBaseData(multiLevelCoreDataTypesDto, request);
        return multiLevelCoreDataTypesService.getAllMultiLevelCoreDataTypes(multiLevelCoreDataTypesDto);
    }

    @Override
    public MultiLevelCoreDataTypesDto getMultiLevelCoreDataTypesById(Integer id,HttpServletRequest request)  throws CdhException
    {
        MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto= new MultiLevelCoreDataTypesDto();
        multiLevelCoreDataTypesDto.setId(id);
        UserAuthDataHandler.resolveAuthBaseData(multiLevelCoreDataTypesDto, request);
        return multiLevelCoreDataTypesService.getMultiLevelCoreDataTypesById(id);
    }
}
