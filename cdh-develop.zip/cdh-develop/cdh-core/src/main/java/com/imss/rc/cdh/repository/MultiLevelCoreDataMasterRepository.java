package com.imss.rc.cdh.repository;

import com.imss.rc.cdh.assembler.MultiLevelCoreDataMasterAssembler;
import com.imss.rc.cdh.constants.CdhConstants;
import com.imss.rc.cdh.dto.MultiLevelCoreDataMasterDto;
import com.imss.rc.cdh.entity.MultiLevelCoreDataEntity;
import com.imss.rc.cdh.entity.MultiLevelCoreDataMasterEntity;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.entity.PageableEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public interface MultiLevelCoreDataMasterRepository extends JpaRepository<MultiLevelCoreDataMasterEntity,Integer> {

    default PageableEntity<MultiLevelCoreDataMasterEntity> getAllMultiLevelCoreDataWithFilters(EntityManager em, MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto) throws CdhException {

        PageableEntity<MultiLevelCoreDataMasterEntity> retData = new PageableEntity<>();

        List<Predicate> predicateList = new ArrayList<>();
        CriteriaBuilder criteriaBuilder ;
        Root<MultiLevelCoreDataMasterEntity> multiLevelCoreDataMasterEntityRoot;

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        multiLevelCoreDataMasterEntityRoot = countQuery.from(MultiLevelCoreDataMasterEntity.class);

        predicateList = applySearchFilters(criteriaBuilder, predicateList, multiLevelCoreDataMasterEntityRoot, multiLevelCoreDataMasterDto);

        countQuery.select(criteriaBuilder.count(multiLevelCoreDataMasterEntityRoot));
        countQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));
        long count = em.createQuery(countQuery).getSingleResult();
        retData.setCount(count);

        predicateList.clear();

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<MultiLevelCoreDataMasterEntity> listCriteriaQuery = criteriaBuilder.createQuery(MultiLevelCoreDataMasterEntity.class);

        multiLevelCoreDataMasterEntityRoot = listCriteriaQuery.from(MultiLevelCoreDataMasterEntity.class);

        listCriteriaQuery.select(multiLevelCoreDataMasterEntityRoot);
        predicateList = applySearchFilters(criteriaBuilder, predicateList, multiLevelCoreDataMasterEntityRoot, multiLevelCoreDataMasterDto);

        listCriteriaQuery.where( criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));

        String sortByColumn = MultiLevelCoreDataMasterAssembler.getSortByColumn(multiLevelCoreDataMasterDto.getPagination().getSortBy());

        Order order;
        if(CdhConstants.ASC.equals( multiLevelCoreDataMasterDto.getPagination().getSortType())){
            order = criteriaBuilder.asc(multiLevelCoreDataMasterEntityRoot.get(sortByColumn));
        } else {
            order = criteriaBuilder.desc(multiLevelCoreDataMasterEntityRoot.get(sortByColumn));
        }

        TypedQuery<MultiLevelCoreDataMasterEntity> query = em.createQuery(listCriteriaQuery.orderBy(order))
                .setFirstResult((multiLevelCoreDataMasterDto.getPagination().getPage() - 1) * multiLevelCoreDataMasterDto.getPagination().getLimit())
                .setMaxResults(multiLevelCoreDataMasterDto.getPagination().getLimit());
        retData.setData(query.getResultList());

        return retData;
    }

    default List<Predicate> applySearchFilters(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Root<MultiLevelCoreDataMasterEntity> coreDataTypeEntityRoot,
                                               MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto) throws CdhException {

        //Adding the mandatory is deleted check
        predicateList.add(criteriaBuilder.equal(coreDataTypeEntityRoot.get(MultiLevelCoreDataMasterEntity.COLUMN_NAME_IS_DELETED), 0));

        //Adding the mandatory multi_level_core_data_types_id check
        predicateList.add(criteriaBuilder.equal(coreDataTypeEntityRoot.get(MultiLevelCoreDataMasterEntity.COLUMN_NAME_MULTI_LEVEL_CORE_DATA_MASTER_MULTI_LEVEL_CORE_DATA_TYPES_ID), multiLevelCoreDataMasterDto.getMultiLevelCoreDataTypesId()));

        //Adding filter for name if present
        if (Optional.ofNullable(multiLevelCoreDataMasterDto.getName()).isPresent() && !multiLevelCoreDataMasterDto.getName().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.like(criteriaBuilder.upper(coreDataTypeEntityRoot.get(MultiLevelCoreDataMasterEntity.COLUMN_NAME_MULTI_LEVEL_CORE_DATA_MASTER_NAME)), "%"+multiLevelCoreDataMasterDto.getName().toUpperCase()+"%"));
        }

        //Adding filter for order if present
        if (Optional.ofNullable(multiLevelCoreDataMasterDto.getOrder()).isPresent() && multiLevelCoreDataMasterDto.getOrder() != 0) {
            predicateList.add(criteriaBuilder.like(criteriaBuilder.upper(coreDataTypeEntityRoot.get(MultiLevelCoreDataMasterEntity.COLUMN_NAME_MULTI_LEVEL_CORE_DATA_MASTER_ORDER)), "%"+multiLevelCoreDataMasterDto.getOrder()+"%"));
        }

        return predicateList;
    }

    @Query(value="from MultiLevelCoreDataMasterEntity cd where cd.isDeleted=0 and multiLevelCoreDataMasterId=:typeId")
    public List<MultiLevelCoreDataMasterEntity> findByTypeId(@Param("typeId") Integer typeId);
}
