package com.imss.rc.cdh.repository;

import com.imss.rc.cdh.assembler.CoreDataDetailsAssembler;
import com.imss.rc.cdh.dto.CoreDataDetailsDto;
import com.imss.rc.cdh.entity.CoreDataDetailsEntity;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.constants.SortTypeConstants;
import com.imss.rc.commons.entity.PageableEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Transactional
@Repository
public interface CoreDataDetailsRepository extends JpaRepository<CoreDataDetailsEntity,Integer> {

    @Modifying
    @Query(value="update CoreDataDetailsEntity set isDeleted= 1 where id= :id")
    public void isDelete(@Param("id") int id);

    @Query(value="from CoreDataDetailsEntity cd where cd.isDeleted=0 and cd.id= :id")
    public CoreDataDetailsEntity getCategoryId(@Param("id") int id);

    @Query(value="Select cd.id from CoreDataDetailsEntity cd where cd.isDeleted=0 and cd.id= :id")
    public Integer findByDisplayMode(@Param("id") int id);


    @Query(value="Select cd.id from CoreDataDetailsEntity cd where cd.isDeleted=0 and cd.id= :id")
    public Integer findByFindComposition(@Param("id") int id);

    @Query(value="select id from CoreDataDetailsEntity where isEditable=1 AND id= :id ")
    public List<Integer> isEditable(@Param("id") int id);

    @Query(value="Select cde.id from CoreDataDetailsEntity cde  where cde.typeId= :dataListTypeId and isDeleted=0")
    public List<Integer> getDataListId(@Param("dataListTypeId") int dataListTypeId);

    @Query(value="Select cde.id from CoreDataDetailsEntity cde  where cde.typeId= :dataListId and isDeleted=0")
    public List<Integer> getDataList(@Param("dataListId") int dataListId);

    @Query(value="from CoreDataDetailsEntity cd where cd.name=:name and typeId=:typeId")
    public CoreDataDetailsEntity getCoreDataDetailsByNameAndTypeId(@Param("name") String name, @Param("typeId") Integer typeId);

    @Query(value="from CoreDataDetailsEntity cd where cd.isDeleted=0 and cd.id= :id and typeId=:typeId")
    public CoreDataDetailsEntity findByUserId(@Param("id") int id,@Param("typeId") Integer typeId);

    default PageableEntity<CoreDataDetailsEntity> getAllCoreDataDetailsWithFilters(EntityManager em, CoreDataDetailsDto coreDataDetailsDto) throws CdhException {

        PageableEntity<CoreDataDetailsEntity> retData = new PageableEntity<>();

        List<Predicate> predicateList = new ArrayList<>();
        CriteriaBuilder criteriaBuilder ;
        Root<CoreDataDetailsEntity> coreDataDetailsEntityRoot ;

        /** This is to get the count of records */
        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        coreDataDetailsEntityRoot = countQuery.from(CoreDataDetailsEntity.class);

        predicateList = applySearchFilters(criteriaBuilder, predicateList, coreDataDetailsEntityRoot, coreDataDetailsDto);

        countQuery.select(criteriaBuilder.count(coreDataDetailsEntityRoot));
        countQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));
        long count = em.createQuery(countQuery).getSingleResult();
        retData.setCount(count);
        /***********************************/


        /** This is to get the list based on the page and limit *******/

        //Clear out the predicateList created using the count root
        predicateList.clear();

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<CoreDataDetailsEntity> listCriteriaQuery = criteriaBuilder.createQuery(CoreDataDetailsEntity.class);

        coreDataDetailsEntityRoot = listCriteriaQuery.from(CoreDataDetailsEntity.class);

        listCriteriaQuery.select(coreDataDetailsEntityRoot);
        predicateList = applySearchFilters(criteriaBuilder, predicateList, coreDataDetailsEntityRoot, coreDataDetailsDto);

        listCriteriaQuery.where( criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));

        String sortByColumn = CoreDataDetailsAssembler.getSortByColumn(coreDataDetailsDto.getPagination().getSortBy());

        Order order;
        if(SortTypeConstants.SORT_TYPE_ASC.equals( coreDataDetailsDto.getPagination().getSortType())){
            order = criteriaBuilder.asc(coreDataDetailsEntityRoot.get(sortByColumn));
        } else {
            order = criteriaBuilder.desc(coreDataDetailsEntityRoot.get(sortByColumn));
        }

        TypedQuery<CoreDataDetailsEntity> query = em.createQuery(listCriteriaQuery.orderBy(order))
                .setFirstResult((coreDataDetailsDto.getPagination().getPage() - 1) * coreDataDetailsDto.getPagination().getLimit())
                .setMaxResults(coreDataDetailsDto.getPagination().getLimit());
        retData.setData(query.getResultList());
        /***********************************/

        return retData;
    }


    default List<Predicate> applySearchFilters(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Root<CoreDataDetailsEntity> coreDataDetailsEntityRoot,
                                               CoreDataDetailsDto coreDataDetailsDto) throws CdhException {

        //Adding the mandatory is deleted check
        predicateList.add(criteriaBuilder.equal(coreDataDetailsEntityRoot.get(CoreDataDetailsEntity.COLUMN_NAME_CORE_DATA_DETAILS_IS_DELETED), 0));

        //Adding the mandatory type id check
        predicateList.add(criteriaBuilder.equal(coreDataDetailsEntityRoot.get(CoreDataDetailsEntity.COLUMN_NAME_CORE_DATA_DETAILS_TYPE_ID), coreDataDetailsDto.getTypeId()));


        //Adding filter for name if present
        if (Optional.ofNullable(coreDataDetailsDto.getName()).isPresent() && !coreDataDetailsDto.getName().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.like(criteriaBuilder.upper(coreDataDetailsEntityRoot.get(CoreDataDetailsEntity.COLUMN_NAME_CORE_DATA_DETAILS_NAME)), "%"+coreDataDetailsDto.getName().toUpperCase()+"%"));
        }

        return predicateList;
    }

}
