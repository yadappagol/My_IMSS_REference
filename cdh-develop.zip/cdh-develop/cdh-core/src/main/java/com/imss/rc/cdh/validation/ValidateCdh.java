package com.imss.rc.cdh.validation;

import com.imss.rc.cdh.repository.*;
import com.imss.rc.cdh.constants.CdhConstants;
import com.imss.rc.cdh.entity.CoreDataTypesEntity;
import com.imss.rc.cdh.entity.MultiLevelCoreDataEntity;
import com.imss.rc.cdh.entity.MultiLevelCoreDataMasterEntity;
import com.imss.rc.cdh.entity.MultiLevelCoreDataTypesEntity;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Component
public class ValidateCdh
{
    @Autowired
    CoreDataDetailsRepository repository;

    @Autowired
    CoreDataTypeRepository coreDataTypeRepository;

    @Autowired
    MultiLevelCoreDataTypesRepository multiLevelCoreDataTypesRepository;

    @Autowired
    MultiLevelCoreDataMasterRepository multiLevelCoreDataMasterRepository;

    @Autowired
    MultiLevelCoreDataRepository multiLevelCoreDataRepository;

    public boolean isEditable(int id) throws CdhException
    {
        List<Integer> listIds=repository.isEditable(id);
        if( Objects.isNull(listIds)||listIds.isEmpty())
        {
            throw new CdhException(CdhException.ROW_IS_NOT_EDITABLE, HttpStatus.BAD_REQUEST);
        }
        return true;
    }

    public boolean isNameValid(String name) throws CdhException {
        if (Objects.isNull(name)|| name.isEmpty()) {
            throw new CdhException(CdhException.MANDATORY_NAME_FIELD, HttpStatus.BAD_REQUEST);
        }
        if (name.length() <= CdhConstants.MAX_LENGTH && name.trim().replace(" ", "").matches(CdhConstants.REGEX_PATTERN))
        {
            return true;
        }
        else {
                throw new CdhException(CdhException.NAME_NOT_VALID, HttpStatus.BAD_REQUEST);
             }
    }


    public boolean isValidTypeId(int typeId) throws CdhException
    {
        if(Objects.nonNull(typeId)||typeId != GlobalYesNoEnum.NO.getValue() )
        {
            CoreDataTypesEntity entity =coreDataTypeRepository.findByTypeId(typeId);
            if(Objects.isNull(entity))
            {
                throw new CdhException(CdhException.TYPE_DOES_NOT_EXIST, HttpStatus.BAD_REQUEST);
            }
            return true;
        }
        throw new CdhException(CdhException.MANDATORY_TYPE_ID_FIELD, HttpStatus.BAD_REQUEST);
    }

    public boolean isValidMultiLevelCoreDataTypesId(Integer typeId) throws CdhException
    {
        if(Objects.nonNull(typeId)||typeId != GlobalYesNoEnum.NO.getValue() )
        {
            Optional<MultiLevelCoreDataTypesEntity> entity = multiLevelCoreDataTypesRepository.findById(typeId);
            if(!entity.isPresent())
            {
                throw new CdhException(CdhException.TYPE_DOES_NOT_EXIST, HttpStatus.BAD_REQUEST);
            }
            return true;
        }
        throw new CdhException(CdhException.MANDATORY_TYPE_ID_FIELD, HttpStatus.BAD_REQUEST);
    }

    public boolean isValidMultiLevelCoreDataMasterId(Integer typeId) throws CdhException
    {
        if(Objects.nonNull(typeId)||typeId != GlobalYesNoEnum.NO.getValue() )
        {
            Optional<MultiLevelCoreDataMasterEntity> entity = multiLevelCoreDataMasterRepository.findById(typeId);
            if(!entity.isPresent())
            {
                throw new CdhException(CdhException.TYPE_DOES_NOT_EXIST, HttpStatus.BAD_REQUEST);
            }
            return true;
        }
        throw new CdhException(CdhException.MANDATORY_TYPE_ID_FIELD, HttpStatus.BAD_REQUEST);
    }

    public boolean isValidMultiLevelCoreDataParentId(Integer typeId) throws CdhException
    {
        if(Objects.nonNull(typeId)||typeId != GlobalYesNoEnum.NO.getValue() )
        {
            Optional<MultiLevelCoreDataEntity> entity = multiLevelCoreDataRepository.findById(typeId);
            if(!entity.isPresent())
            {
                throw new CdhException(CdhException.TYPE_DOES_NOT_EXIST, HttpStatus.BAD_REQUEST);
            }
            return true;
        }
        return false;
    }
}



