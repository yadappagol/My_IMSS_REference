package com.imss.rc.cdh.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.cdh.enums.DefaultValue;
import com.imss.rc.cdh.validation.ValidateCdh;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.enums.AuditEnum;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.cdh.assembler.MultiLevelCoreDataAssembler;
import com.imss.rc.cdh.constants.CdhConstants;
import com.imss.rc.cdh.dto.MultiLevelCoreDataDto;
import com.imss.rc.cdh.entity.MultiLevelCoreDataEntity;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.cdh.repository.MultiLevelCoreDataRepository;
import com.imss.rc.cdh.util.KafkaSendCdhMessage;
import com.imss.rc.commons.constants.SortTypeConstants;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.ActionTypeEnum;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class MultiLevelCoreDataServiceImpl implements MultiLevelCoreDataService {

    @Autowired
    MultiLevelCoreDataAssembler multiLevelCoreDataAssembler;

    @Autowired
    ValidateCdh validateCdh;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    MultiLevelCoreDataRepository multiLevelCoreDataRepository;

    @Autowired
    KafkaSendCdhMessage kafkaSendCdhMessage;

    @Autowired
    EntityManager entityManager;

    private static final Logger LOGGER = LoggerFactory.getLogger(MultiLevelCoreDataServiceImpl.class);

    @Override
    public MultiLevelCoreDataDto saveMultiLevelCoreData(MultiLevelCoreDataDto multiLevelCoreDataDto) throws CdhException {
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        try{
            MultiLevelCoreDataEntity multiLevelCoreDataEntity = multiLevelCoreDataAssembler.dtoToEntity(multiLevelCoreDataDto);
            if(validateCdh.isNameValid(multiLevelCoreDataDto.getName()) && validateCdh.isValidMultiLevelCoreDataMasterId(multiLevelCoreDataDto.getMultiLevelCoreDataMasterId())){
                if(multiLevelCoreDataDto.getParentId() != null && validateCdh.isValidMultiLevelCoreDataParentId(multiLevelCoreDataDto.getParentId())){
                    multiLevelCoreDataEntity.setParentId(multiLevelCoreDataDto.getParentId());
                }
                UserAuthDataHandler.resolveEntityBaseData(multiLevelCoreDataDto,multiLevelCoreDataEntity);
                multiLevelCoreDataEntity.setModifiedDate(multiLevelCoreDataEntity.getCreatedDate());
                if(!StringUtils.isEmpty(multiLevelCoreDataDto.getAdditionalData())){
                    HashMap<String,Object> map = multiLevelCoreDataDto.getAdditionalData();
                    multiLevelCoreDataEntity.setAdditionalData(objectMapper.writeValueAsString(map));
                }
                multiLevelCoreDataEntity.setIsDeleted((short) GlobalYesNoEnum.NO.getValue());
                multiLevelCoreDataEntity.setIsEditable(DefaultValue.isEditable.getNumVal());
                multiLevelCoreDataRepository.save(multiLevelCoreDataEntity);
            }
            MultiLevelCoreDataDto multiLevelCoreDataDTO = multiLevelCoreDataAssembler.entityToDto(multiLevelCoreDataEntity);
            multiLevelCoreDataDTO.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            multiLevelCoreDataDTO.setResponseMessage(ResponseDto.STATUS_SUCCESS);

            //auditing the updates
            auditMasterDto.setEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA.getValue());
            auditMasterDto.setWhen(multiLevelCoreDataDTO.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(multiLevelCoreDataEntity.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.ADD.getValue());
            auditMasterDto.setWho(multiLevelCoreDataDTO.getCreatedBy());
            auditMasterDto.setDescription(String.format(CdhConstants.ADDED_MULTI_LEVEL_CORE_DATA, multiLevelCoreDataDTO.getName()));
            kafkaSendCdhMessage.sendMessage(auditMasterDto);

            return multiLevelCoreDataDTO;
        }catch(CdhException ex){
            throw ex;
        } catch (Exception ex) {
            LOGGER.error("Exception in add multi level core data :", ex);
            throw new CdhException(CdhException.UNABLE_TO_CREATE_MULTI_LEVEL_CORE_DATA, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public MultiLevelCoreDataDto updateMultiLevelCoreDataById(MultiLevelCoreDataDto multiLevelCoreDataDto, Integer id) throws CdhException {
        try{
            MultiLevelCoreDataEntity multiLevelCoreDataEntity = multiLevelCoreDataRepository.getOne(id);
            if( multiLevelCoreDataEntity.getIsDeleted() == GlobalYesNoEnum.YES.getValue()){
                throw  new CdhException(CdhException.MULTI_LEVEL_CORE_DATA_NOT_FOUND, new String[]{String.valueOf(id)}, HttpStatus.NOT_FOUND) ;
            }
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            if(multiLevelCoreDataEntity.getIsEditable()==DefaultValue.isEditable.getNumVal()  &&
                    validateCdh.isNameValid(multiLevelCoreDataDto.getName()) &&
                    validateCdh.isValidMultiLevelCoreDataMasterId(multiLevelCoreDataDto.getMultiLevelCoreDataMasterId())){
                if(multiLevelCoreDataDto.getParentId() != null){
                    if(validateCdh.isValidMultiLevelCoreDataParentId(multiLevelCoreDataDto.getParentId())){
                        multiLevelCoreDataEntity.setParentId(multiLevelCoreDataDto.getParentId());
                    }
                }
                UserAuthDataHandler.resolveEntityBaseData(multiLevelCoreDataDto,multiLevelCoreDataEntity);
                multiLevelCoreDataEntity.setName(multiLevelCoreDataDto.getName());
                multiLevelCoreDataEntity.setIsLeaf(multiLevelCoreDataDto.getIsLeaf());
                multiLevelCoreDataEntity.setIsDeleted((short) GlobalYesNoEnum.NO.getValue());
                if(!StringUtils.isEmpty(multiLevelCoreDataDto.getAdditionalData())){
                    HashMap<String,Object> map = multiLevelCoreDataDto.getAdditionalData();
                    multiLevelCoreDataEntity.setAdditionalData(objectMapper.writeValueAsString(map));
                }
                if(multiLevelCoreDataDto.getDescription() != null){
                        multiLevelCoreDataEntity.setDescription(multiLevelCoreDataDto.getDescription());
                }
                multiLevelCoreDataRepository.saveAndFlush(multiLevelCoreDataEntity);

                MultiLevelCoreDataDto multiLevelCoreDataDTO = multiLevelCoreDataAssembler.entityToDto(multiLevelCoreDataEntity);
                multiLevelCoreDataDTO.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                multiLevelCoreDataDTO.setResponseStatus(ResponseDto.STATUS_SUCCESS);

                //auditing the updates made
                auditMasterDto.setEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA.getValue());
                auditMasterDto.setWhen(multiLevelCoreDataDTO.getModifiedDate());
                auditMasterDto.setReferenceId(String.valueOf(id));
                auditMasterDto.setActionType(ActionTypeEnum.UPDATE.getValue());
                auditMasterDto.setWho(multiLevelCoreDataDTO.getModifiedBy());
                auditMasterDto.setDescription(String.format(CdhConstants.UPDATE_MULTI_LEVEL_CORE_DATA,multiLevelCoreDataDTO.getName()));
                kafkaSendCdhMessage.sendMessage(auditMasterDto);

                return multiLevelCoreDataDTO;
            }else{
                throw new CdhException(CdhException.ROW_IS_NOT_EDITABLE,HttpStatus.NOT_FOUND);
            }
        }catch(CdhException ex){
            throw ex;
        }catch (EntityNotFoundException ex) {
            throw  new CdhException(CdhException.MULTI_LEVEL_CORE_DATA_NOT_FOUND, new String[]{String.valueOf(id)}, HttpStatus.NOT_FOUND) ;
        }catch (Exception ex) {
            LOGGER.error("Exception in update multi level core data :", ex);
            throw new CdhException(CdhException.UNABLE_TO_UPDATE_MULTI_LEVEL_CORE_DATA, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public IdDto deleteMultiLevelCoreDataById(MultiLevelCoreDataDto multiLevelCoreDataDto) throws CdhException {
        IdDto idDto=new IdDto();
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        try{
            MultiLevelCoreDataEntity multiLevelCoreDataEntity = multiLevelCoreDataRepository.getOne(multiLevelCoreDataDto.getId());
            if( multiLevelCoreDataEntity.getIsDeleted() == GlobalYesNoEnum.YES.getValue()){
                throw  new CdhException(CdhException.MULTI_LEVEL_CORE_DATA_NOT_FOUND, new String[]{String.valueOf(multiLevelCoreDataDto.getId())}, HttpStatus.NOT_FOUND) ;
            }
            if( multiLevelCoreDataEntity.getIsEditable()== GlobalYesNoEnum.NO.getValue()){
                throw new CdhException(CdhException.ROW_IS_NOT_EDITABLE,HttpStatus.NOT_FOUND);
            }
            multiLevelCoreDataEntity.setIsDeleted((short) GlobalYesNoEnum.YES.getValue());

            UserAuthDataHandler.resolveEntityBaseData(multiLevelCoreDataDto, multiLevelCoreDataEntity);

            multiLevelCoreDataRepository.save(multiLevelCoreDataEntity);

            //auditing the updates made
            auditMasterDto.setEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA.getValue());
            auditMasterDto.setWhen(multiLevelCoreDataDto.getModifiedDate());
            auditMasterDto.setReferenceId(String.valueOf(multiLevelCoreDataDto.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.DELETE.getValue());
            auditMasterDto.setWho(multiLevelCoreDataDto.getModifiedBy());
            auditMasterDto.setDescription(String.format(CdhConstants.DELETE_MULTI_LEVEL_CORE_DATA,multiLevelCoreDataEntity.getName()));
            kafkaSendCdhMessage.sendMessage(auditMasterDto);

            idDto.setId(multiLevelCoreDataDto.getId());
        }catch(CdhException ex){
            throw ex;
        }catch (EntityNotFoundException ex) {
            throw  new CdhException(CdhException.MULTI_LEVEL_CORE_DATA_NOT_FOUND, new String[]{String.valueOf(multiLevelCoreDataDto.getId())}, HttpStatus.NOT_FOUND) ;
        }catch (Exception ex) {
            LOGGER.error("Exception in delete multi level core data :", ex);
            throw new CdhException(CdhException.UNABLE_TO_DELETE_MULTI_LEVEL_CORE_DATA, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return idDto;
    }

    @Override
    public MultiLevelCoreDataDto getMultiLevelCoreDataById(Integer id) throws CdhException {
        MultiLevelCoreDataDto multiLevelCoreDataDto;
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        try{
            MultiLevelCoreDataEntity multiLevelCoreDataEntity = multiLevelCoreDataRepository.getOne(id);
            if (multiLevelCoreDataEntity.getIsDeleted() == GlobalYesNoEnum.YES.getValue()) {
                throw  new CdhException(CdhException.MULTI_LEVEL_CORE_DATA_NOT_FOUND, new String[]{String.valueOf(id)}, HttpStatus.NOT_FOUND) ;
            }
            multiLevelCoreDataDto = multiLevelCoreDataAssembler.entityToDto(multiLevelCoreDataEntity);
            if(!StringUtils.isEmpty(multiLevelCoreDataEntity.getAdditionalData())) {
                HashMap<String, Object> map = (HashMap<String, Object>) objectMapper.readValue(multiLevelCoreDataEntity.getAdditionalData(), Map.class);
                multiLevelCoreDataDto.setAdditionalData(map);
            }
            multiLevelCoreDataDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            multiLevelCoreDataDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);

            //Auditing the updates
            auditMasterDto.setEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA.getValue());
            auditMasterDto.setWhen(multiLevelCoreDataDto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(id));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(multiLevelCoreDataDto.getCreatedBy());
            auditMasterDto.setDescription(String.format(CdhConstants.RETRIEVE_MULTI_LEVEL_CORE_DATA,multiLevelCoreDataDto.getName()));
            kafkaSendCdhMessage.sendMessage(auditMasterDto);

        }catch(CdhException ex){
            throw ex;
        }catch (EntityNotFoundException ex) {
            throw  new CdhException(CdhException.MULTI_LEVEL_CORE_DATA_NOT_FOUND, new String[]{String.valueOf(id)}, HttpStatus.NOT_FOUND) ;
        }catch (Exception ex) {
            LOGGER.error("Exception in get multi level core data by id :", ex);
            throw new CdhException(CdhException.UNABLE_TO_FIND_MULTI_LEVEL_CORE_DATA, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return multiLevelCoreDataDto;
    }

    @Override
    public BaseListDto<MultiLevelCoreDataDto> getAllMultiLevelCoreData(MultiLevelCoreDataDto multiLevelCoreDataDto) throws CdhException {
        BaseListDto<MultiLevelCoreDataDto> dtoList = new BaseListDto<>();
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        try{
            if(Objects.isNull(multiLevelCoreDataDto.getPagination().getSortType()) || multiLevelCoreDataDto.getPagination().getSortType().isEmpty()){
                multiLevelCoreDataDto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }
            //If the sort by is blank then set the default sort by column to name and order by asc
            if(Objects.isNull(multiLevelCoreDataDto.getPagination().getSortBy()) || multiLevelCoreDataDto.getPagination().getSortBy().isEmpty()){
                multiLevelCoreDataDto.getPagination().setSortBy(CdhConstants.SORT_BY_NAME);
                multiLevelCoreDataDto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }

            PageableEntity<MultiLevelCoreDataEntity> data = multiLevelCoreDataRepository.getAllMultiLevelCoreDataWithFilters(entityManager, multiLevelCoreDataDto);

            PaginationDto pageDto = multiLevelCoreDataDto.getPagination();
            pageDto.setCount(data.getCount());

            dtoList.setPagination(pageDto);

            dtoList.setDataList(multiLevelCoreDataAssembler.entityListToDtoList(data.getData()));
            dtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            dtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            dtoList.setAuditEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA.getValue());

            //auditing the updates made
            auditMasterDto.setEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA.getValue());
            auditMasterDto.setWhen(multiLevelCoreDataDto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(multiLevelCoreDataDto.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(multiLevelCoreDataDto.getCreatedBy());
            auditMasterDto.setDescription(String.format(CdhConstants.RETRIEVE_MULTI_LEVEL_CORE_DATA_LIST,
                    dtoList.getPagination().getPage(),
                    dtoList.getPagination().getLimit(),
                    dtoList.getPagination().getSortBy(),
                    dtoList.getPagination().getSortType(),
                    dtoList.getPagination().getCount())
            );
            kafkaSendCdhMessage.sendMessage(auditMasterDto);
            return dtoList;
        }catch (CdhException ex) {
            throw ex;
        }catch (Exception ex) {
            LOGGER.error("Exception in view all multi level core data :", ex);
            throw new CdhException(CdhException.UNABLE_TO_FIND_MULTI_LEVEL_CORE_DATA, HttpStatus.NOT_FOUND) ;
        }
    }
}
