package com.imss.rc.cdh.controller;

import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.cdh.dto.MultiLevelCoreDataDto;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.cdh.service.MultiLevelCoreDataService;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Objects;

@RestController
public class MultiLevelCoreDataControllerImpl implements MultiLevelCoreDataController {

    @Autowired
    MultiLevelCoreDataService multiLevelCoreDataService;



    @Override
    public MultiLevelCoreDataDto saveMultiLevelCoreData(MultiLevelCoreDataDto multiLevelCoreDataDto, HttpServletRequest request) throws CdhException {
        UserAuthDataHandler.resolveAuthBaseData(multiLevelCoreDataDto, request);
        return multiLevelCoreDataService.saveMultiLevelCoreData(multiLevelCoreDataDto);
    }

    @Override
    public MultiLevelCoreDataDto updateMultiLevelCoreDataById(MultiLevelCoreDataDto multiLevelCoreDataDto, Integer id, HttpServletRequest request) throws CdhException {
        UserAuthDataHandler.resolveAuthBaseData(multiLevelCoreDataDto, request);
        return  multiLevelCoreDataService.updateMultiLevelCoreDataById(multiLevelCoreDataDto,id);
    }

    @Override
    public IdDto deleteMultiLevelCoreDataById(Integer id, HttpServletRequest request) throws CdhException {
        MultiLevelCoreDataDto multiLevelCoreDataDto= new MultiLevelCoreDataDto();
        multiLevelCoreDataDto.setId(id);
        UserAuthDataHandler.resolveAuthBaseData(multiLevelCoreDataDto, request);
        return multiLevelCoreDataService.deleteMultiLevelCoreDataById(multiLevelCoreDataDto);
    }


    @Override
    public BaseListDto<MultiLevelCoreDataDto> getAllMultiLevelCoreData(Integer limit, Integer page, Integer parentId, Integer typeId, String name, String sortBy, String sortType, HttpServletRequest request) throws CdhException {
        if (Objects.isNull(page) || page < GlobalYesNoEnum.YES.getValue()) {
            throw new CdhException(CdhException.INVALID_PAGE, HttpStatus.BAD_REQUEST);
        }
        if (Objects.isNull(limit) || limit < GlobalYesNoEnum.YES.getValue()) {
            throw new CdhException(CdhException.INVALID_LIMIT, HttpStatus.BAD_REQUEST);
        }
        MultiLevelCoreDataDto multiLevelCoreDataDto = new MultiLevelCoreDataDto();
        multiLevelCoreDataDto.setName(name);
        if (!StringUtils.isEmpty(parentId)) {
            multiLevelCoreDataDto.setParentId(parentId);
        }
        if (!StringUtils.isEmpty(typeId)) {
            multiLevelCoreDataDto.setMultiLevelCoreDataMasterId(typeId);
        }

        PaginationDto pageDto = new PaginationDto();
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);
        multiLevelCoreDataDto.setPagination(pageDto);
        UserAuthDataHandler.resolveAuthBaseData(multiLevelCoreDataDto, request);
        return multiLevelCoreDataService.getAllMultiLevelCoreData(multiLevelCoreDataDto);
    }

    @Override
    public MultiLevelCoreDataDto getMultiLevelCoreDataById(Integer id,HttpServletRequest request)  throws CdhException
    {
        MultiLevelCoreDataDto multiLevelCoreDataDto= new MultiLevelCoreDataDto();
        multiLevelCoreDataDto.setId(id);
        UserAuthDataHandler.resolveAuthBaseData(multiLevelCoreDataDto, request);
        return multiLevelCoreDataService.getMultiLevelCoreDataById(id);
    }
}
