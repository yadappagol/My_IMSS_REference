package com.imss.rc.cdh.controller;

import com.imss.rc.cdh.dto.MultiLevelCoreDataDto;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

public interface MultiLevelCoreDataController {

    @PostMapping(value="/ml-core-data" ,produces = "application/json")
    @ResponseBody
    MultiLevelCoreDataDto saveMultiLevelCoreData(@RequestBody MultiLevelCoreDataDto multiLevelCoreDataDto, HttpServletRequest request) throws CdhException;

    @PutMapping(value = "/ml-core-data/{id}", produces = "application/json")
    MultiLevelCoreDataDto updateMultiLevelCoreDataById(@RequestBody MultiLevelCoreDataDto multiLevelCoreDataDto, @PathVariable("id") Integer id, HttpServletRequest request)  throws CdhException;

    @DeleteMapping(value = "/ml-core-data/{id}", produces = "application/json")
    IdDto deleteMultiLevelCoreDataById(@PathVariable("id") Integer id, HttpServletRequest request) throws CdhException;


    @GetMapping(value = "/ml-core-data", produces = "application/json")
    @ResponseBody
    BaseListDto<MultiLevelCoreDataDto> getAllMultiLevelCoreData(@RequestParam Integer limit,
                                                                @RequestParam Integer page,
                                                                @RequestParam(required = false) Integer parentId,
                                                                @RequestParam(required = false) Integer typeId,
                                                                @RequestParam(required = false) String name,
                                                                @RequestParam(required = false) String sortBy,
                                                                @RequestParam(required = false) String sortType, HttpServletRequest request) throws CdhException;

    @GetMapping(value = "/ml-core-data/{id}", produces = "application/json")
    @ResponseBody
    MultiLevelCoreDataDto getMultiLevelCoreDataById(@PathVariable("id") Integer id,HttpServletRequest request)  throws CdhException;

}
