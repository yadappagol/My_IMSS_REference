package com.imss.rc.cdh.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.cdh.dto.MultiLevelCoreDataMasterDto;
import com.imss.rc.cdh.util.KafkaSendCdhMessage;
import com.imss.rc.cdh.validation.ValidateCdh;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.enums.AuditEnum;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.cdh.assembler.MultiLevelCoreDataMasterAssembler;
import com.imss.rc.cdh.constants.CdhConstants;
import com.imss.rc.cdh.entity.MultiLevelCoreDataMasterEntity;
import com.imss.rc.cdh.enums.DefaultValue;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.cdh.repository.MultiLevelCoreDataMasterRepository;
import com.imss.rc.commons.constants.SortTypeConstants;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.ActionTypeEnum;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import java.util.HashMap;
import java.util.Objects;

@Service
public class MultiLevelCoreDataMasterServiceImpl implements MultiLevelCoreDataMasterService {

    @Autowired
    MultiLevelCoreDataMasterAssembler multiLevelCoreDataMasterAssembler;

    @Autowired
    ValidateCdh validateCdh;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    MultiLevelCoreDataMasterRepository multiLevelCoreDataMasterRepository;

    @Autowired
    KafkaSendCdhMessage kafkaSendCdhMessage;

    @Autowired
    EntityManager entityManager;

    private static final Logger LOGGER = LoggerFactory.getLogger(MultiLevelCoreDataMasterServiceImpl.class);

    @Override
    public MultiLevelCoreDataMasterDto saveMultiLevelCoreDataMaster(MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto) throws CdhException {
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        try{

            MultiLevelCoreDataMasterEntity multiLevelCoreDataMasterEntity = multiLevelCoreDataMasterAssembler.dtoToEntity(multiLevelCoreDataMasterDto);
            if(validateCdh.isNameValid(multiLevelCoreDataMasterDto.getName()) && validateCdh.isValidMultiLevelCoreDataTypesId(multiLevelCoreDataMasterDto.getMultiLevelCoreDataTypesId())){
                UserAuthDataHandler.resolveEntityBaseData(multiLevelCoreDataMasterDto,multiLevelCoreDataMasterEntity);
                multiLevelCoreDataMasterEntity.setModifiedDate(multiLevelCoreDataMasterEntity.getCreatedDate());
                multiLevelCoreDataMasterEntity.setIsEditable(DefaultValue.isEditable.getNumVal());
                multiLevelCoreDataMasterEntity.setIsDeleted((short) GlobalYesNoEnum.NO.getValue());
                if(!StringUtils.isEmpty(multiLevelCoreDataMasterDto.getAdditionalData())){
                    HashMap<String,Object> map = multiLevelCoreDataMasterDto.getAdditionalData();
                    multiLevelCoreDataMasterEntity.setAdditionalData(objectMapper.writeValueAsString(map));
                }
                multiLevelCoreDataMasterRepository.save(multiLevelCoreDataMasterEntity);
            }

            MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDTO = multiLevelCoreDataMasterAssembler.entityToDto(multiLevelCoreDataMasterEntity);
            multiLevelCoreDataMasterDTO.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            multiLevelCoreDataMasterDTO.setResponseMessage(ResponseDto.STATUS_SUCCESS);

            //auditing the updates
            auditMasterDto.setEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA_MASTER.getValue());
            auditMasterDto.setWhen(multiLevelCoreDataMasterDTO.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(multiLevelCoreDataMasterEntity.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.ADD.getValue());
            auditMasterDto.setWho(multiLevelCoreDataMasterDTO.getCreatedBy());
            auditMasterDto.setDescription(String.format(CdhConstants.ADDED_MULTI_LEVEL_CORE_DATA_MASTER, multiLevelCoreDataMasterDTO.getName()));
            kafkaSendCdhMessage.sendMessage(auditMasterDto);

            return multiLevelCoreDataMasterDTO;
        }catch(CdhException ex){
            throw ex;
        } catch (Exception ex) {
            LOGGER.error("Exception in add multi level core data master :", ex);
            throw new CdhException(CdhException.UNABLE_TO_CREATE_MULTI_LEVEL_CORE_DATA_MASTER, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public MultiLevelCoreDataMasterDto updateMultiLevelCoreDataMasterById(MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto, Integer id) throws CdhException {
        try{
            MultiLevelCoreDataMasterEntity multiLevelCoreDataMasterEntity = multiLevelCoreDataMasterRepository.getOne(id);
            if (multiLevelCoreDataMasterEntity.getIsDeleted() == GlobalYesNoEnum.YES.getValue()) {
                throw  new CdhException(CdhException.MULTI_LEVEL_CORE_DATA_MASTER_NOT_FOUND, new String[]{String.valueOf(id)}, HttpStatus.NOT_FOUND) ;
            }
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            if(multiLevelCoreDataMasterEntity.getIsEditable()==DefaultValue.isEditable.getNumVal()  &&
                    validateCdh.isNameValid(multiLevelCoreDataMasterDto.getName()) && validateCdh.isValidMultiLevelCoreDataTypesId(multiLevelCoreDataMasterDto.getMultiLevelCoreDataTypesId())){
                UserAuthDataHandler.resolveEntityBaseData(multiLevelCoreDataMasterDto,multiLevelCoreDataMasterEntity);
                multiLevelCoreDataMasterEntity.setName(multiLevelCoreDataMasterDto.getName());
                multiLevelCoreDataMasterEntity.setMultiLevelCoreDataTypesId(multiLevelCoreDataMasterDto.getMultiLevelCoreDataTypesId());
                multiLevelCoreDataMasterEntity.setOrder(multiLevelCoreDataMasterDto.getOrder());
                multiLevelCoreDataMasterEntity.setIsDeleted((short) GlobalYesNoEnum.NO.getValue());
                if(!StringUtils.isEmpty(multiLevelCoreDataMasterDto.getAdditionalData())){
                    HashMap<String,Object> map = multiLevelCoreDataMasterDto.getAdditionalData();
                    multiLevelCoreDataMasterEntity.setAdditionalData(objectMapper.writeValueAsString(map));
                }
                multiLevelCoreDataMasterRepository.saveAndFlush(multiLevelCoreDataMasterEntity);

                MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDTO = multiLevelCoreDataMasterAssembler.entityToDto(multiLevelCoreDataMasterEntity);

                multiLevelCoreDataMasterDTO.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                multiLevelCoreDataMasterDTO.setResponseStatus(ResponseDto.STATUS_SUCCESS);

                //auditing the updates made
                auditMasterDto.setEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA_MASTER.getValue());
                auditMasterDto.setWhen(multiLevelCoreDataMasterDTO.getModifiedDate());
                auditMasterDto.setReferenceId(String.valueOf(id));
                auditMasterDto.setActionType(ActionTypeEnum.UPDATE.getValue());
                auditMasterDto.setWho(multiLevelCoreDataMasterDTO.getModifiedBy());
                auditMasterDto.setDescription(String.format(CdhConstants.UPDATE_MULTI_LEVEL_CORE_DATA_MASTER,multiLevelCoreDataMasterDTO.getName()));
                kafkaSendCdhMessage.sendMessage(auditMasterDto);

                return multiLevelCoreDataMasterDTO;
            }else{
                throw new CdhException(CdhException.ROW_IS_NOT_EDITABLE,HttpStatus.NOT_FOUND);
            }
        }catch(CdhException ex){
            throw ex;
        }catch (EntityNotFoundException ex) {
            throw  new CdhException(CdhException.MULTI_LEVEL_CORE_DATA_MASTER_NOT_FOUND, new String[]{String.valueOf(id)}, HttpStatus.NOT_FOUND) ;
        }catch (Exception ex) {
            LOGGER.error("Exception in update multi level core data master :", ex);
            throw new CdhException(CdhException.UNABLE_TO_UPDATE_MULTI_LEVEL_CORE_DATA_MASTER, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public IdDto deleteMultiLevelCoreDataMasterById(MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto) throws CdhException {
        IdDto idDto=new IdDto();
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        try{
            MultiLevelCoreDataMasterEntity multiLevelCoreDataMasterEntity = multiLevelCoreDataMasterRepository.getOne(multiLevelCoreDataMasterDto.getId());
            if( multiLevelCoreDataMasterEntity.getIsDeleted() == GlobalYesNoEnum.YES.getValue()){
                throw  new CdhException(CdhException.MULTI_LEVEL_CORE_DATA_MASTER_NOT_FOUND, new String[]{String.valueOf(multiLevelCoreDataMasterDto.getId())}, HttpStatus.NOT_FOUND) ;
            }
            if( multiLevelCoreDataMasterEntity.getIsEditable()== GlobalYesNoEnum.NO.getValue()){
                throw new CdhException(CdhException.ROW_IS_NOT_EDITABLE,HttpStatus.NOT_FOUND);
            }
            multiLevelCoreDataMasterEntity.setIsDeleted((short) GlobalYesNoEnum.YES.getValue());

           UserAuthDataHandler.resolveEntityBaseData(multiLevelCoreDataMasterDto, multiLevelCoreDataMasterEntity);

            multiLevelCoreDataMasterRepository.save(multiLevelCoreDataMasterEntity);

            //auditing the updates made
            auditMasterDto.setEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA_MASTER.getValue());
            auditMasterDto.setWhen(multiLevelCoreDataMasterDto.getModifiedDate());
            auditMasterDto.setReferenceId(String.valueOf(multiLevelCoreDataMasterDto.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.DELETE.getValue());
            auditMasterDto.setWho(multiLevelCoreDataMasterDto.getModifiedBy());
            auditMasterDto.setDescription(String.format(CdhConstants.DELETE_MULTI_LEVEL_CORE_DATA_MASTER,multiLevelCoreDataMasterEntity.getName()));
            kafkaSendCdhMessage.sendMessage(auditMasterDto);

            idDto.setId(multiLevelCoreDataMasterDto.getId());
        }catch(CdhException ex){
            throw ex;
        }catch (EntityNotFoundException ex) {
            throw  new CdhException(CdhException.MULTI_LEVEL_CORE_DATA_MASTER_NOT_FOUND, new String[]{String.valueOf(multiLevelCoreDataMasterDto.getId())}, HttpStatus.NOT_FOUND) ;
        } catch (Exception ex) {
            LOGGER.error("Exception in delete multi level core data master:", ex);
            throw new CdhException(CdhException.UNABLE_TO_DELETE_MULTI_LEVEL_CORE_DATA_MASTER, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return idDto;
    }

    @Override
    public MultiLevelCoreDataMasterDto getMultiLevelCoreDataMasterById(Integer id) throws CdhException {
        MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto;
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        try{
            MultiLevelCoreDataMasterEntity multiLevelCoreDataMasterEntity = multiLevelCoreDataMasterRepository.getOne(id);
            if (multiLevelCoreDataMasterEntity.getIsDeleted() == GlobalYesNoEnum.YES.getValue()) {
                throw  new CdhException(CdhException.MULTI_LEVEL_CORE_DATA_MASTER_NOT_FOUND, new String[]{String.valueOf(id)}, HttpStatus.NOT_FOUND) ;
            }
            multiLevelCoreDataMasterDto = multiLevelCoreDataMasterAssembler.entityToDto(multiLevelCoreDataMasterEntity);

            multiLevelCoreDataMasterDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            multiLevelCoreDataMasterDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);

            //Auditing the updates
            auditMasterDto.setEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA_MASTER.getValue());
            auditMasterDto.setWhen(multiLevelCoreDataMasterDto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(id));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(multiLevelCoreDataMasterDto.getCreatedBy());
            auditMasterDto.setDescription(String.format(CdhConstants.RETRIEVE_MULTI_LEVEL_CORE_DATA_MASTER,multiLevelCoreDataMasterDto.getName()));
            kafkaSendCdhMessage.sendMessage(auditMasterDto);

        }catch(CdhException ex){
            throw ex;
        }catch (EntityNotFoundException ex) {
            throw  new CdhException(CdhException.MULTI_LEVEL_CORE_DATA_MASTER_NOT_FOUND, new String[]{String.valueOf(id)}, HttpStatus.NOT_FOUND) ;
        }catch (Exception ex) {
            LOGGER.error("Exception in get multi level core data by id :", ex);
            throw new CdhException(CdhException.UNABLE_TO_FIND_MULTI_LEVEL_CORE_DATA_MASTER, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return multiLevelCoreDataMasterDto;
    }

    @Override
    public BaseListDto<MultiLevelCoreDataMasterDto> getAllMultiLevelCoreDataMaster(MultiLevelCoreDataMasterDto dto) throws CdhException {
        BaseListDto<MultiLevelCoreDataMasterDto> dtoList = new BaseListDto<>();
        AuditMasterDto auditMasterDto = new AuditMasterDto();
        try {

            //If the sortType is blank then setting it to default by asc
            if (Objects.isNull(dto.getPagination().getSortType()) || dto.getPagination().getSortType().isEmpty()) {
                dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }
            //If the sort by is blank then set the default sort by column to name and order by asc
            if (Objects.isNull(dto.getPagination().getSortBy()) || dto.getPagination().getSortBy().isEmpty()) {
                dto.getPagination().setSortBy(CdhConstants.SORT_BY_ORDER);
                dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }

            PageableEntity<MultiLevelCoreDataMasterEntity> data = multiLevelCoreDataMasterRepository.getAllMultiLevelCoreDataWithFilters(entityManager, dto);

            PaginationDto pageDto = dto.getPagination();
            pageDto.setCount(data.getCount());

            dtoList.setPagination(pageDto);
            dtoList.setDataList(multiLevelCoreDataMasterAssembler.entityListToDtoList(data.getData()));
            dtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            dtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            dtoList.setAuditEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA_MASTER.getValue());

            auditMasterDto.setEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA_MASTER.getValue());
            auditMasterDto.setWhen(dto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(dtoList.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(dto.getCreatedBy());
            auditMasterDto.setDescription(String.format(CdhConstants.RETRIEVE_MULTI_LEVEL_CORE_DATA_MASTER,
                    dtoList.getPagination().getPage(),
                    dtoList.getPagination().getLimit(),
                    dtoList.getPagination().getSortBy(),
                    dtoList.getPagination().getSortType(),
                    dtoList.getPagination().getCount())
            );
            kafkaSendCdhMessage.sendMessage(auditMasterDto);
            return dtoList;
        }catch (CdhException ex) {
            throw ex;
        } catch (Exception ex) {
            LOGGER.error("Exception in view all core data details :", ex);
            throw new CdhException(CdhException.UNABLE_TO_FIND_MULTI_LEVEL_CORE_DATA_MASTER, HttpStatus.NOT_FOUND);
        }
    }
}
