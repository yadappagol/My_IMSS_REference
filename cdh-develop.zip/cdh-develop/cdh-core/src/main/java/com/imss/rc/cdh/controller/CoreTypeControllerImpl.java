package com.imss.rc.cdh.controller;

import com.imss.rc.cdh.dto.CoreDataDetailsDto;
import com.imss.rc.cdh.dto.CoreDataTypesDto;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.cdh.service.CoreTypeService;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@RestController
public class CoreTypeControllerImpl implements CoreTypeController{

    @Autowired
    CoreTypeService coreTypeService;

    @Override
    public BaseListDto<CoreDataTypesDto> getCoreDataTypes(Integer limit,
                                                          Integer page,
                                                          String key,
                                                          String name,
                                                          Integer isVisible,
                                                          String sortBy,
                                                          String sortType, HttpServletRequest request)  throws CdhException
    {
        if (Objects.isNull(page)||page < GlobalYesNoEnum.YES.getValue()) {
            throw new CdhException(CdhException.INVALID_PAGE, HttpStatus.BAD_REQUEST);
        }
        if (Objects.isNull(limit) || limit < GlobalYesNoEnum.YES.getValue()) {
            throw new CdhException(CdhException.INVALID_LIMIT, HttpStatus.BAD_REQUEST);
        }

        CoreDataTypesDto dto = new CoreDataTypesDto();
        dto.setKey(key);
        dto.setName(name);
        dto.setIsVisible(isVisible);


        PaginationDto pageDto = new PaginationDto();
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);
        dto.setPagination(pageDto);
        UserAuthDataHandler.resolveAuthBaseData(dto, request);
        return coreTypeService.getAllCoreDataTypes(dto);
    }

    //3.To retrieve the details of a specific core data
    @Override
    public CoreDataDetailsDto getCoreDataDetailsById(Integer id, HttpServletRequest request)  throws CdhException
    {
        CoreDataDetailsDto coreDataDetailsDto= new CoreDataDetailsDto();
        coreDataDetailsDto.setId(id);
        UserAuthDataHandler.resolveAuthBaseData(coreDataDetailsDto, request);
        return coreTypeService.getCoreDataDetailsById(id);
    }

    //4.To add a new record
    @Override
    public CoreDataDetailsDto saveCoreDataDetails(CoreDataDetailsDto coreDataDetailsDto, HttpServletRequest request)  throws CdhException
    {
        UserAuthDataHandler.resolveAuthBaseData(coreDataDetailsDto, request);
        return coreTypeService.saveCoreDataDetails(coreDataDetailsDto);
    }

    //5.To Update a record
    @Override
    public CoreDataDetailsDto updateCoreDataDetailsById(CoreDataDetailsDto coreDataDetailsDto, Integer id, HttpServletRequest request) throws CdhException {
        UserAuthDataHandler.resolveAuthBaseData(coreDataDetailsDto, request);
        return  coreTypeService.updateCoreDataDetailsById(coreDataDetailsDto,id);
    }

    //6.To Delete a record
    @Override
    public IdDto deleteCoreDataDetailsById(Integer id, HttpServletRequest request)  throws CdhException
    {
        CoreDataDetailsDto coreDataDetailsDto= new CoreDataDetailsDto();
        coreDataDetailsDto.setId(id);
        UserAuthDataHandler.resolveAuthBaseData(coreDataDetailsDto, request);
        return coreTypeService.deleteCoreDataDetailsById(coreDataDetailsDto);
    }

    //2.To retrieve the list of core data for specific type
    @Override
    public BaseListDto<CoreDataDetailsDto> getAllCoreDataDetails(Integer typeId,
                                             Integer limit,
                                             Integer page,
                                             String name,
                                             String sortBy,
                                             String sortType,HttpServletRequest request)  throws CdhException
    {
        if (Objects.isNull(page)||page < GlobalYesNoEnum.YES.getValue()) {
            throw new CdhException(CdhException.INVALID_PAGE, HttpStatus.BAD_REQUEST);
        }
        if (Objects.isNull(limit) || limit < GlobalYesNoEnum.YES.getValue()) {
            throw new CdhException(CdhException.INVALID_LIMIT, HttpStatus.BAD_REQUEST);
        }
        CoreDataDetailsDto dto = new CoreDataDetailsDto();
        dto.setName(name);
        dto.setTypeId(typeId);

        PaginationDto pageDto = new PaginationDto();
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);
        dto.setPagination(pageDto);

       UserAuthDataHandler.resolveAuthBaseData(dto, request);
        return coreTypeService.getAllCoreDataDetails(dto);
    }


    //2.To retrieve the list of core data for specific type
    @Override
    public BaseListDto<BaseListDto<CoreDataDetailsDto>> getAllCoreDataDetailsForMultiple(String typeIds,
                                                                                  Integer limit,
                                                                                  Integer page,
                                                                                  String name,
                                                                                  String sortBy,
                                                                                  String sortType,HttpServletRequest request)  throws CdhException
    {
        if (Objects.isNull(page)||page < GlobalYesNoEnum.YES.getValue()) {
            throw new CdhException(CdhException.INVALID_PAGE, HttpStatus.BAD_REQUEST);
        }
        if (Objects.isNull(limit) || limit < GlobalYesNoEnum.YES.getValue()) {
            throw new CdhException(CdhException.INVALID_LIMIT, HttpStatus.BAD_REQUEST);
        }

        BaseListDto<BaseListDto<CoreDataDetailsDto>> listOfMasters = new BaseListDto<>();
        listOfMasters.setDataList(new ArrayList<>());

        List<BaseListDto<CoreDataDetailsDto>> dtoList = new ArrayList<>();

        String[] indvTypeIds = typeIds.split(",");
        for(String typeId : indvTypeIds){
            CoreDataDetailsDto dto = new CoreDataDetailsDto();
            dto.setName(name);
            dto.setTypeId(Integer.parseInt(typeId));


            PaginationDto pageDto = new PaginationDto();
            pageDto.setLimit(limit);
            pageDto.setPage(page);
            pageDto.setSortType(sortType);
            pageDto.setSortBy(sortBy);
            dto.setPagination(pageDto);
            UserAuthDataHandler.resolveAuthBaseData(dto, request);
            dtoList.add(coreTypeService.getAllCoreDataDetails(dto));
        }
        listOfMasters.setDataList(dtoList);

        return listOfMasters;
    }

}
