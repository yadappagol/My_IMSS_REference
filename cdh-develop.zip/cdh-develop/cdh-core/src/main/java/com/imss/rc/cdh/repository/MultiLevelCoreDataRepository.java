package com.imss.rc.cdh.repository;

import com.imss.rc.cdh.assembler.MultiLevelCoreDataAssembler;
import com.imss.rc.cdh.constants.CdhConstants;
import com.imss.rc.cdh.dto.MultiLevelCoreDataDto;
import com.imss.rc.cdh.entity.CoreDataDetailsEntity;
import com.imss.rc.cdh.entity.MultiLevelCoreDataEntity;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.entity.PageableEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public interface MultiLevelCoreDataRepository extends JpaRepository<MultiLevelCoreDataEntity,Integer> {

    default PageableEntity<MultiLevelCoreDataEntity> getAllMultiLevelCoreDataWithFilters(EntityManager em, MultiLevelCoreDataDto multiLevelCoreDataDto) throws CdhException {

        PageableEntity<MultiLevelCoreDataEntity> retData = new PageableEntity<>();

        List<Predicate> predicateList = new ArrayList<>();
        CriteriaBuilder criteriaBuilder ;
        Root<MultiLevelCoreDataEntity> multiLevelCoreDataEntityRoot;

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        multiLevelCoreDataEntityRoot = countQuery.from(MultiLevelCoreDataEntity.class);

        predicateList = applySearchFilters(criteriaBuilder, predicateList, multiLevelCoreDataEntityRoot, multiLevelCoreDataDto);

        countQuery.select(criteriaBuilder.count(multiLevelCoreDataEntityRoot));
        countQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));
        long count = em.createQuery(countQuery).getSingleResult();
        retData.setCount(count);

        predicateList.clear();

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<MultiLevelCoreDataEntity> listCriteriaQuery = criteriaBuilder.createQuery(MultiLevelCoreDataEntity.class);

        multiLevelCoreDataEntityRoot = listCriteriaQuery.from(MultiLevelCoreDataEntity.class);

        listCriteriaQuery.select(multiLevelCoreDataEntityRoot);
        predicateList = applySearchFilters(criteriaBuilder, predicateList, multiLevelCoreDataEntityRoot, multiLevelCoreDataDto);

        listCriteriaQuery.where( criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));

        String sortByColumn = MultiLevelCoreDataAssembler.getSortByColumn(multiLevelCoreDataDto.getPagination().getSortBy());

        Order order;
        if(CdhConstants.ASC.equals( multiLevelCoreDataDto.getPagination().getSortType())){
            order = criteriaBuilder.asc(multiLevelCoreDataEntityRoot.get(sortByColumn));
        } else {
            order = criteriaBuilder.desc(multiLevelCoreDataEntityRoot.get(sortByColumn));
        }

        TypedQuery<MultiLevelCoreDataEntity> query = em.createQuery(listCriteriaQuery.orderBy(order))
                .setFirstResult((multiLevelCoreDataDto.getPagination().getPage() - 1) * multiLevelCoreDataDto.getPagination().getLimit())
                .setMaxResults(multiLevelCoreDataDto.getPagination().getLimit());
        retData.setData(query.getResultList());

        return retData;
    }

    default List<Predicate> applySearchFilters(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Root<MultiLevelCoreDataEntity> coreDataTypeEntityRoot,
                                               MultiLevelCoreDataDto coreDataTypesDto) throws CdhException {

        //Adding the mandatory is deleted check
        predicateList.add(criteriaBuilder.equal(coreDataTypeEntityRoot.get(MultiLevelCoreDataEntity.COLUMN_NAME_IS_DELETED), 0));

        //Adding filter for name if present
        if (Optional.ofNullable(coreDataTypesDto.getName()).isPresent() && !coreDataTypesDto.getName().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.like(criteriaBuilder.upper(coreDataTypeEntityRoot.get(MultiLevelCoreDataEntity.COLUMN_NAME_MULTI_LEVEL_CORE_DATA_NAME)), "%"+coreDataTypesDto.getName().toUpperCase()+"%"));
        }

        //Adding the filter multi_level_core_data_master_id check
        if (Optional.ofNullable(coreDataTypesDto.getMultiLevelCoreDataMasterId()).isPresent()) {
            predicateList.add(criteriaBuilder.equal(coreDataTypeEntityRoot.get(MultiLevelCoreDataEntity.COLUMN_NAME_MULTI_LEVEL_CORE_DATA_MULTI_LEVEL_CORE_DATA_MASTER_ID), coreDataTypesDto.getMultiLevelCoreDataMasterId()));
        }

        //Adding the filter parentId check
        if (Optional.ofNullable(coreDataTypesDto.getParentId()).isPresent()) {
            predicateList.add(criteriaBuilder.equal(coreDataTypeEntityRoot.get(MultiLevelCoreDataEntity.COLUMN_NAME_MULTI_LEVEL_CORE_DATA_PARENT_ID), coreDataTypesDto.getParentId()));
        }

        return predicateList;
    }


    @Query(value="from MultiLevelCoreDataEntity cd where cd.isDeleted=0 and multiLevelCoreDataMasterId=:typeId")
    public List<MultiLevelCoreDataEntity> findByTypeId(@Param("typeId") Integer typeId);

}
