package com.imss.rc.cdh.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.cdh.repository.MultiLevelCoreDataTypesRepository;
import com.imss.rc.cdh.validation.ValidateCdh;
import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.enums.AuditEnum;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.cdh.assembler.MultiLevelCoreDataTypesAssembler;
import com.imss.rc.cdh.constants.CdhConstants;
import com.imss.rc.cdh.dto.MultiLevelCoreDataTypesDto;
import com.imss.rc.cdh.entity.MultiLevelCoreDataTypesEntity;
import com.imss.rc.cdh.enums.DefaultValue;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.cdh.util.KafkaSendCdhMessage;
import com.imss.rc.commons.constants.SortTypeConstants;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.dto.ResponseDto;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.ActionTypeEnum;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.persistence.EntityManager;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class MultiLevelCoreDataTypesServiceImpl implements MultiLevelCoreDataTypesService {

    @Autowired
    MultiLevelCoreDataTypesAssembler multiLevelCoreDataTypesAssembler;

    @Autowired
    ValidateCdh validateCdh;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    MultiLevelCoreDataTypesRepository multiLevelCoreDataTypesRepository;

    @Autowired
    KafkaSendCdhMessage kafkaSendCdhMessage;

    @Autowired
    EntityManager entityManager;

    private static final Logger LOGGER = LoggerFactory.getLogger(MultiLevelCoreDataServiceImpl.class);

    @Override
    public MultiLevelCoreDataTypesDto saveMultiLevelCoreDataTypes(MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto) throws CdhException {
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        try{
            HashMap<String, Object> data = null;
            MultiLevelCoreDataTypesEntity multiLevelCoreDataTypesEntity = multiLevelCoreDataTypesAssembler.dtoToEntity(multiLevelCoreDataTypesDto);
            if(validateCdh.isNameValid(multiLevelCoreDataTypesDto.getName())){
                UserAuthDataHandler.resolveEntityBaseData(multiLevelCoreDataTypesDto,multiLevelCoreDataTypesEntity);
                multiLevelCoreDataTypesEntity.setModifiedDate(multiLevelCoreDataTypesEntity.getCreatedDate());
                multiLevelCoreDataTypesEntity.setIsDeleted((short) GlobalYesNoEnum.NO.getValue());
                multiLevelCoreDataTypesEntity.setIsVisible(DefaultValue.isVisible.getNumVal());
                if(!StringUtils.isEmpty(multiLevelCoreDataTypesDto.getAdditionalData())){
                    HashMap<String,Object> map = multiLevelCoreDataTypesDto.getAdditionalData();
                    multiLevelCoreDataTypesEntity.setAdditionalData(objectMapper.writeValueAsString(map));
                    data = (HashMap<String, Object>) objectMapper.readValue(multiLevelCoreDataTypesEntity.getAdditionalData(), Map.class);
                }
                multiLevelCoreDataTypesRepository.save(multiLevelCoreDataTypesEntity);
            }
            MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDTO = multiLevelCoreDataTypesAssembler.entityToDto(multiLevelCoreDataTypesEntity);
            if(data != null) {
                multiLevelCoreDataTypesDTO.setAdditionalData(data);
            }
            multiLevelCoreDataTypesDTO.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            multiLevelCoreDataTypesDTO.setResponseMessage(ResponseDto.STATUS_SUCCESS);

            //auditing the updates
            auditMasterDto.setEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA_TYPES.getValue());
            auditMasterDto.setWhen(multiLevelCoreDataTypesDTO.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(multiLevelCoreDataTypesEntity.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.ADD.getValue());
            auditMasterDto.setWho(multiLevelCoreDataTypesDTO.getCreatedBy());
            auditMasterDto.setDescription(String.format(CdhConstants.ADDED_MULTI_LEVEL_CORE_DATA_TYPES, multiLevelCoreDataTypesDTO.getName()));
            kafkaSendCdhMessage.sendMessage(auditMasterDto);

            return multiLevelCoreDataTypesDTO;
        }catch(CdhException ex){
            throw ex;
        } catch (Exception ex) {
            LOGGER.error("Exception in add multi level core data types :", ex);
            throw new CdhException(CdhException.UNABLE_TO_CREATE_MULTI_LEVEL_CORE_DATA_TYPES, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public MultiLevelCoreDataTypesDto updateMultiLevelCoreDataTypesById(MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto, Integer id) throws CdhException {
        try{
            MultiLevelCoreDataTypesEntity multiLevelCoreDataTypesEntity = multiLevelCoreDataTypesRepository.getOne(id);
            if( multiLevelCoreDataTypesEntity.getIsDeleted() == GlobalYesNoEnum.YES.getValue()){
                throw  new CdhException(CdhException.MULTI_LEVEL_CORE_DATA_TYPES_NOT_FOUND, new String[]{String.valueOf(multiLevelCoreDataTypesDto.getId())}, HttpStatus.NOT_FOUND) ;
            }
            AuditMasterDto auditMasterDto=new AuditMasterDto();
            HashMap<String, Object> data = null;
            if(validateCdh.isNameValid(multiLevelCoreDataTypesDto.getName())){
                UserAuthDataHandler.resolveEntityBaseData(multiLevelCoreDataTypesDto,multiLevelCoreDataTypesEntity);
                multiLevelCoreDataTypesEntity.setName(multiLevelCoreDataTypesDto.getName());
                multiLevelCoreDataTypesEntity.setKey(multiLevelCoreDataTypesDto.getKey());
                multiLevelCoreDataTypesEntity.setDescription(multiLevelCoreDataTypesDto.getDescription());
                multiLevelCoreDataTypesEntity.setIsDeleted((short) GlobalYesNoEnum.NO.getValue());
                if(!StringUtils.isEmpty(multiLevelCoreDataTypesDto.getAdditionalData())){
                    HashMap<String,Object> map = multiLevelCoreDataTypesDto.getAdditionalData();
                    multiLevelCoreDataTypesEntity.setAdditionalData(objectMapper.writeValueAsString(map));
                    data = (HashMap<String, Object>) objectMapper.readValue(multiLevelCoreDataTypesEntity.getAdditionalData(), Map.class);
                }
                multiLevelCoreDataTypesRepository.saveAndFlush(multiLevelCoreDataTypesEntity);
                MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDTO = multiLevelCoreDataTypesAssembler.entityToDto(multiLevelCoreDataTypesEntity);
                if(data != null) {
                    multiLevelCoreDataTypesDTO.setAdditionalData(data);
                }
                multiLevelCoreDataTypesDTO.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
                multiLevelCoreDataTypesDTO.setResponseStatus(ResponseDto.STATUS_SUCCESS);

                //auditing the updates made
                auditMasterDto.setEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA_TYPES.getValue());
                auditMasterDto.setWhen(multiLevelCoreDataTypesDTO.getModifiedDate());
                auditMasterDto.setReferenceId(String.valueOf(id));
                auditMasterDto.setActionType(ActionTypeEnum.UPDATE.getValue());
                auditMasterDto.setWho(multiLevelCoreDataTypesDTO.getModifiedBy());
                auditMasterDto.setDescription(String.format(CdhConstants.UPDATE_MULTI_LEVEL_CORE_DATA_TYPES,multiLevelCoreDataTypesDTO.getName()));
                kafkaSendCdhMessage.sendMessage(auditMasterDto);

                return multiLevelCoreDataTypesDTO;
            }else{
                throw new CdhException(CdhException.ROW_IS_NOT_EDITABLE,HttpStatus.NOT_FOUND);
            }
        }catch(CdhException ex){
            throw ex;
        }catch (Exception ex) {
            LOGGER.error("Exception in update multi level core data types :", ex);
            throw new CdhException(CdhException.UNABLE_TO_UPDATE_MULTI_LEVEL_CORE_DATA_TYPES, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public IdDto deleteMultiLevelCoreDataTypesById(MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto) throws CdhException {
        IdDto idDto=new IdDto();
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        try{
            MultiLevelCoreDataTypesEntity multiLevelCoreDataTypesEntity = multiLevelCoreDataTypesRepository.getOne(multiLevelCoreDataTypesDto.getId());
            if( multiLevelCoreDataTypesEntity.getIsDeleted() == GlobalYesNoEnum.YES.getValue()){
                throw  new CdhException(CdhException.MULTI_LEVEL_CORE_DATA_TYPES_NOT_FOUND, new String[]{String.valueOf(multiLevelCoreDataTypesDto.getId())}, HttpStatus.NOT_FOUND) ;
            }
            multiLevelCoreDataTypesEntity.setIsDeleted((short) GlobalYesNoEnum.YES.getValue());

            UserAuthDataHandler.resolveEntityBaseData(multiLevelCoreDataTypesDto, multiLevelCoreDataTypesEntity);

            multiLevelCoreDataTypesRepository.save(multiLevelCoreDataTypesEntity);

            //auditing the updates made
            auditMasterDto.setEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA_MASTER.getValue());
            auditMasterDto.setWhen(multiLevelCoreDataTypesDto.getModifiedDate());
            auditMasterDto.setReferenceId(String.valueOf(multiLevelCoreDataTypesDto.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.DELETE.getValue());
            auditMasterDto.setWho(multiLevelCoreDataTypesDto.getModifiedBy());
            auditMasterDto.setDescription(String.format(CdhConstants.DELETE_MULTI_LEVEL_CORE_DATA_MASTER,multiLevelCoreDataTypesEntity.getName()));
            kafkaSendCdhMessage.sendMessage(auditMasterDto);

            idDto.setId(multiLevelCoreDataTypesDto.getId());
        }catch(CdhException ex){
            throw ex;
        }catch (Exception ex) {
            LOGGER.error("Exception in delete multi level core data types:", ex);
            throw new CdhException(CdhException.UNABLE_TO_DELETE_MULTI_LEVEL_CORE_DATA_TYPES, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return idDto;
    }

    @Override
    public MultiLevelCoreDataTypesDto getMultiLevelCoreDataTypesById(Integer id) throws CdhException {
        MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto;
        AuditMasterDto auditMasterDto=new AuditMasterDto();
        try{
            MultiLevelCoreDataTypesEntity multiLevelCoreDataTypesEntity = multiLevelCoreDataTypesRepository.getOne(id);
            if (multiLevelCoreDataTypesEntity.getIsDeleted() == GlobalYesNoEnum.YES.getValue()) {
                throw  new CdhException(CdhException.MULTI_LEVEL_CORE_DATA_MASTER_NOT_FOUND, new String[]{String.valueOf(id)}, HttpStatus.NOT_FOUND) ;
            }
            multiLevelCoreDataTypesDto = multiLevelCoreDataTypesAssembler.entityToDto(multiLevelCoreDataTypesEntity);
            if(!StringUtils.isEmpty(multiLevelCoreDataTypesEntity.getAdditionalData())) {
                HashMap<String, Object> map = (HashMap<String, Object>) objectMapper.readValue(multiLevelCoreDataTypesEntity.getAdditionalData(), Map.class);
                multiLevelCoreDataTypesDto.setAdditionalData(map);
            }
            multiLevelCoreDataTypesDto.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            multiLevelCoreDataTypesDto.setResponseStatus(ResponseDto.STATUS_SUCCESS);

            //Auditing the updates
            auditMasterDto.setEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA_TYPES.getValue());
            auditMasterDto.setWhen(multiLevelCoreDataTypesDto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(id));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(multiLevelCoreDataTypesDto.getCreatedBy());
            auditMasterDto.setDescription(String.format(CdhConstants.RETRIEVE_MULTI_LEVEL_CORE_DATA_TYPES,multiLevelCoreDataTypesDto.getName()));
            kafkaSendCdhMessage.sendMessage(auditMasterDto);

        }catch(CdhException ex){
            throw ex;
        }catch (Exception ex) {
            LOGGER.error("Exception in get multi level core data types by id :", ex);
            throw new CdhException(CdhException.UNABLE_TO_FIND_MULTI_LEVEL_CORE_DATA_TYPES, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return multiLevelCoreDataTypesDto;
    }

    @Override
    public BaseListDto<MultiLevelCoreDataTypesDto> getAllMultiLevelCoreDataTypes(MultiLevelCoreDataTypesDto dto) throws CdhException {
        BaseListDto<MultiLevelCoreDataTypesDto> dtoList = new BaseListDto<>();
        AuditMasterDto auditMasterDto = new AuditMasterDto();
        try {

            //If the order by is blank then setting it to default by asc
            if (Objects.isNull(dto.getPagination().getSortType()) || dto.getPagination().getSortType().isEmpty()) {
                dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }
            //If the sort by is blank then set the default sort by column to name and order by asc
            if (Objects.isNull(dto.getPagination().getSortBy()) || dto.getPagination().getSortBy().isEmpty()) {
                dto.getPagination().setSortBy(CdhConstants.SORT_BY_NAME);
                dto.getPagination().setSortType(SortTypeConstants.SORT_TYPE_ASC);
            }

            PageableEntity<MultiLevelCoreDataTypesEntity> data = multiLevelCoreDataTypesRepository.getAllMultiLevelCoreDataTypesWithFilters(entityManager, dto);

            PaginationDto pageDto = dto.getPagination();
            pageDto.setCount(data.getCount());


            dtoList.setPagination(pageDto);
            dtoList.setDataList(multiLevelCoreDataTypesAssembler.entityListToDtoList(data.getData()));
            dtoList.setResponseStatus(ResponseDto.STATUS_SUCCESS);
            dtoList.setResponseCode(ResponseDto.STATUS_CODE_SUCCESS);
            dtoList.setAuditEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA_TYPES.getValue());

            auditMasterDto.setEventId(AuditEnum.CFMS_MULTI_LEVEL_CORE_DATA_TYPES.getValue());
            auditMasterDto.setWhen(dto.getCreatedDate());
            auditMasterDto.setReferenceId(String.valueOf(dtoList.getId()));
            auditMasterDto.setActionType(ActionTypeEnum.VIEW.getValue());
            auditMasterDto.setWho(dto.getCreatedBy());
            auditMasterDto.setDescription(String.format(CdhConstants.RETRIEVE_MULTI_LEVEL_CORE_DATA_TYPES,
                    dtoList.getPagination().getPage(),
                    dtoList.getPagination().getLimit(),
                    dtoList.getPagination().getSortBy(),
                    dtoList.getPagination().getSortType(),
                    dtoList.getPagination().getCount())
            );
            kafkaSendCdhMessage.sendMessage(auditMasterDto);
            return dtoList;
        }catch (CdhException ex) {
            throw ex;
        } catch (Exception ex) {
            LOGGER.error("Exception in view all core data details :", ex);
            throw new CdhException(CdhException.UNABLE_TO_FIND_MULTI_LEVEL_CORE_DATA_TYPES, HttpStatus.NOT_FOUND);
        }
    }
}
