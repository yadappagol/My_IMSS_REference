package com.imss.rc.cdh.util;

import com.imss.rc.audit.dto.AuditMasterDto;
import com.imss.rc.audit.service.KafkaProducerSender;
import com.imss.rc.cdh.exception.CdhException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class KafkaSendCdhMessage
{

    @Autowired
    KafkaProducerSender kafkaProducerSender;

    private static final Logger LOG = LoggerFactory.getLogger(KafkaSendCdhMessage.class);

    public void sendMessage(AuditMasterDto auditMasterDto)
    {
        try {
            kafkaProducerSender.sendData(auditMasterDto);
            }
        catch (Exception e) {
        LOG.error(CdhException.MESSAGE_NOT_SENT);
        }
    }
}
