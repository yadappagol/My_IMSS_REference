package com.imss.rc.cdh.repository;

import com.imss.rc.cdh.assembler.CoreDataTypesAssembler;
import com.imss.rc.cdh.dto.CoreDataTypesDto;
import com.imss.rc.cdh.entity.CoreDataTypesEntity;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Repository
public interface CoreDataTypeRepository extends JpaRepository<CoreDataTypesEntity,Integer> {

    @Query(value="from CoreDataTypesEntity cdt where cdt.id = :typeId")
    public CoreDataTypesEntity findByTypeId(@Param("typeId") int typeId);

    default PageableEntity<CoreDataTypesEntity> getAllCoreDataTypesWithFilters(EntityManager em, CoreDataTypesDto coreDataTypesDto) throws CdhException {

        PageableEntity<CoreDataTypesEntity> retData = new PageableEntity<>();

        List<Predicate> predicateList = new ArrayList<>();
        CriteriaBuilder criteriaBuilder ;
        Root<CoreDataTypesEntity> coreDataTypesEntityRoot ;

        /** This is to get the count of records */
        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        coreDataTypesEntityRoot = countQuery.from(CoreDataTypesEntity.class);

        predicateList = applySearchFilters(criteriaBuilder, predicateList, coreDataTypesEntityRoot, coreDataTypesDto);

        countQuery.select(criteriaBuilder.count(coreDataTypesEntityRoot));
        countQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));
        long count = em.createQuery(countQuery).getSingleResult();
        retData.setCount(count);
        /***********************************/


        /** This is to get the list based on the page and limit *******/

        //Clear out the predicateList created using the count root
        predicateList.clear();

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<CoreDataTypesEntity> listCriteriaQuery = criteriaBuilder.createQuery(CoreDataTypesEntity.class);

        coreDataTypesEntityRoot = listCriteriaQuery.from(CoreDataTypesEntity.class);

        listCriteriaQuery.select(coreDataTypesEntityRoot);
        predicateList = applySearchFilters(criteriaBuilder, predicateList, coreDataTypesEntityRoot, coreDataTypesDto);

        listCriteriaQuery.where( criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));

        String sortByColumn = CoreDataTypesAssembler.getSortByColumn(coreDataTypesDto.getPagination().getSortBy());

        Order order;
        if("asc".equals( coreDataTypesDto.getPagination().getSortType())){
            order = criteriaBuilder.asc(coreDataTypesEntityRoot.get(sortByColumn));
        } else {
            order = criteriaBuilder.desc(coreDataTypesEntityRoot.get(sortByColumn));
        }

        TypedQuery<CoreDataTypesEntity> query = em.createQuery(listCriteriaQuery.orderBy(order))
                .setFirstResult((coreDataTypesDto.getPagination().getPage() - 1) * coreDataTypesDto.getPagination().getLimit())
                .setMaxResults(coreDataTypesDto.getPagination().getLimit());
        retData.setData(query.getResultList());
        /***********************************/


        return retData;
    }


    default List<Predicate> applySearchFilters(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Root<CoreDataTypesEntity> coreDataTypeEntityRoot,
                                               CoreDataTypesDto coreDataTypesDto) throws CdhException {

        //Adding filter for is Visible present
        if (Optional.ofNullable(coreDataTypesDto.getIsVisible()).isPresent() && coreDataTypesDto.getIsVisible().intValue() != GlobalYesNoEnum.NO.getValue()) {
            predicateList.add(criteriaBuilder.equal(coreDataTypeEntityRoot.get(CoreDataTypesEntity.COLUMN_NAME_CORE_DATA_TYPE_IS_VISIBLE), coreDataTypesDto.getIsVisible()));
        }
        //Adding filter for name if present
        if (Optional.ofNullable(coreDataTypesDto.getName()).isPresent() && !coreDataTypesDto.getName().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.like(criteriaBuilder.upper(coreDataTypeEntityRoot.get(CoreDataTypesEntity.COLUMN_NAME_CORE_DATA_TYPE_NAME)), "%"+coreDataTypesDto.getName().toUpperCase()+"%"));
        }

        //Adding filter for key if present
        if (Optional.ofNullable(coreDataTypesDto.getKey()).isPresent() && !coreDataTypesDto.getKey().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.like(criteriaBuilder.upper(coreDataTypeEntityRoot.get(CoreDataTypesEntity.COLUMN_NAME_CORE_DATA_TYPE_KEY)), "%"+coreDataTypesDto.getKey().toUpperCase()+"%"));
        }

        return predicateList;
    }

}
