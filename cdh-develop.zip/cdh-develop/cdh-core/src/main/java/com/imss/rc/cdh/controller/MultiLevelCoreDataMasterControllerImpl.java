package com.imss.rc.cdh.controller;

import com.imss.rc.cdh.dto.MultiLevelCoreDataMasterDto;
import com.imss.rc.cdh.service.MultiLevelCoreDataMasterService;
import com.imss.rc.auth.util.UserAuthDataHandler;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Objects;

@RestController
public class MultiLevelCoreDataMasterControllerImpl implements MultiLevelCoreDataMasterController{

    @Autowired
    MultiLevelCoreDataMasterService multiLevelCoreDataMasterService;

    @Override
    public MultiLevelCoreDataMasterDto saveMultiLevelCoreData(MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto, HttpServletRequest request) throws CdhException {
        UserAuthDataHandler.resolveAuthBaseData(multiLevelCoreDataMasterDto, request);
        return multiLevelCoreDataMasterService.saveMultiLevelCoreDataMaster(multiLevelCoreDataMasterDto);
    }

    @Override
    public MultiLevelCoreDataMasterDto updateMultiLevelCoreDataById(MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto, Integer id, HttpServletRequest request) throws CdhException {
        UserAuthDataHandler.resolveAuthBaseData(multiLevelCoreDataMasterDto, request);
        return  multiLevelCoreDataMasterService.updateMultiLevelCoreDataMasterById(multiLevelCoreDataMasterDto,id);
    }

    @Override
    public IdDto deleteMultiLevelCoreDataById(Integer id, HttpServletRequest request) throws CdhException {
        MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto= new MultiLevelCoreDataMasterDto();
        multiLevelCoreDataMasterDto.setId(id);
        UserAuthDataHandler.resolveAuthBaseData(multiLevelCoreDataMasterDto, request);
        return multiLevelCoreDataMasterService.deleteMultiLevelCoreDataMasterById(multiLevelCoreDataMasterDto);
    }

    @Override
    public BaseListDto<MultiLevelCoreDataMasterDto> getAllMultiLevelCoreDataById(Integer typeId, Integer limit, Integer page, String name, String sortBy, String sortType, HttpServletRequest request) throws CdhException {
        if (Objects.isNull(page)||page < GlobalYesNoEnum.YES.getValue()) {
            throw new CdhException(CdhException.INVALID_PAGE, HttpStatus.BAD_REQUEST);
        }
        if (Objects.isNull(limit) || limit < GlobalYesNoEnum.YES.getValue()) {
            throw new CdhException(CdhException.INVALID_LIMIT, HttpStatus.BAD_REQUEST);
        }
        MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto= new MultiLevelCoreDataMasterDto();
        multiLevelCoreDataMasterDto.setMultiLevelCoreDataTypesId(typeId);
        if(!StringUtils.isEmpty(typeId)){
            multiLevelCoreDataMasterDto.setId(typeId);
        }
        if(!StringUtils.isEmpty(name)) {
            multiLevelCoreDataMasterDto.setName(name);
        }

        PaginationDto pageDto = new PaginationDto();
        pageDto.setLimit(limit);
        pageDto.setPage(page);
        pageDto.setSortType(sortType);
        pageDto.setSortBy(sortBy);
        multiLevelCoreDataMasterDto.setPagination(pageDto);

        UserAuthDataHandler.resolveAuthBaseData(multiLevelCoreDataMasterDto, request);
        return multiLevelCoreDataMasterService.getAllMultiLevelCoreDataMaster(multiLevelCoreDataMasterDto);
    }

    @Override
    public MultiLevelCoreDataMasterDto getMultiLevelCoreDataMasterById(Integer id,HttpServletRequest request)  throws CdhException
    {
        MultiLevelCoreDataMasterDto multiLevelCoreDataDto= new MultiLevelCoreDataMasterDto();
        multiLevelCoreDataDto.setId(id);
        UserAuthDataHandler.resolveAuthBaseData(multiLevelCoreDataDto, request);
        return multiLevelCoreDataMasterService.getMultiLevelCoreDataMasterById(id);
    }
}
