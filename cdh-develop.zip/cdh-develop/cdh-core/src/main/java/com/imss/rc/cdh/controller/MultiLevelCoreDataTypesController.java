package com.imss.rc.cdh.controller;

import com.imss.rc.cdh.dto.MultiLevelCoreDataTypesDto;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

public interface MultiLevelCoreDataTypesController {

    @PostMapping(value="/ml-core-data/types" ,produces = "application/json")
    @ResponseBody
    MultiLevelCoreDataTypesDto saveMultiLevelCoreDataTypes(@RequestBody MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto, HttpServletRequest request) throws CdhException;

    @PutMapping(value = "/ml-core-data/types/{id}", produces = "application/json")
    MultiLevelCoreDataTypesDto updateMultiLevelCoreDataTypesById(@RequestBody MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto, @PathVariable("id") Integer id, HttpServletRequest request)  throws CdhException;

    @DeleteMapping(value = "/ml-core-data/types/{id}", produces = "application/json")
    IdDto deleteMultiLevelCoreDataTypesById(@PathVariable("id") Integer id, HttpServletRequest request) throws CdhException;

    @GetMapping(value = "/ml-core-data/types", produces = "application/json")
    @ResponseBody
    BaseListDto<MultiLevelCoreDataTypesDto> getAllMultiLevelCoreDataTypes(@RequestParam Integer limit,
                                                                              @RequestParam Integer page,
                                                                              @RequestParam(required = false) String key,
                                                                              @RequestParam(required = false) String name,
                                                                              @RequestParam(required = false) Integer isVisible,
                                                                              @RequestParam(required = false) String sortBy,
                                                                              @RequestParam(required = false) String sortType, HttpServletRequest request)  throws CdhException;

    @GetMapping(value = "/ml-core-data/types/{id}", produces = "application/json")
    @ResponseBody
    MultiLevelCoreDataTypesDto getMultiLevelCoreDataTypesById(@PathVariable("id") Integer id,HttpServletRequest request)  throws CdhException;

}
