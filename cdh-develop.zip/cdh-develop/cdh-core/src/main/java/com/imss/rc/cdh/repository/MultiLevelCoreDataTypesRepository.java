package com.imss.rc.cdh.repository;

import com.imss.rc.cdh.assembler.MultiLevelCoreDataTypesAssembler;
import com.imss.rc.cdh.constants.CdhConstants;
import com.imss.rc.cdh.dto.MultiLevelCoreDataTypesDto;
import com.imss.rc.cdh.entity.MultiLevelCoreDataTypesEntity;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.entity.PageableEntity;
import com.imss.rc.commons.enums.GlobalYesNoEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public interface MultiLevelCoreDataTypesRepository extends JpaRepository<MultiLevelCoreDataTypesEntity,Integer> {

    default PageableEntity<MultiLevelCoreDataTypesEntity> getAllMultiLevelCoreDataTypesWithFilters(EntityManager em, MultiLevelCoreDataTypesDto multiLevelCoreDataMasterDto) throws CdhException {

        PageableEntity<MultiLevelCoreDataTypesEntity> retData = new PageableEntity<>();

        List<Predicate> predicateList = new ArrayList<>();
        CriteriaBuilder criteriaBuilder ;
        Root<MultiLevelCoreDataTypesEntity> multiLevelCoreDataTypesEntityRoot;

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
        multiLevelCoreDataTypesEntityRoot = countQuery.from(MultiLevelCoreDataTypesEntity.class);

        predicateList = applySearchFilters(criteriaBuilder, predicateList, multiLevelCoreDataTypesEntityRoot, multiLevelCoreDataMasterDto);

        countQuery.select(criteriaBuilder.count(multiLevelCoreDataTypesEntityRoot));
        countQuery.where(criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));
        long count = em.createQuery(countQuery).getSingleResult();
        retData.setCount(count);

        predicateList.clear();

        criteriaBuilder = em.getCriteriaBuilder();
        CriteriaQuery<MultiLevelCoreDataTypesEntity> listCriteriaQuery = criteriaBuilder.createQuery(MultiLevelCoreDataTypesEntity.class);

        multiLevelCoreDataTypesEntityRoot = listCriteriaQuery.from(MultiLevelCoreDataTypesEntity.class);

        listCriteriaQuery.select(multiLevelCoreDataTypesEntityRoot);
        predicateList = applySearchFilters(criteriaBuilder, predicateList, multiLevelCoreDataTypesEntityRoot, multiLevelCoreDataMasterDto);

        listCriteriaQuery.where( criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()])));

        String sortByColumn = MultiLevelCoreDataTypesAssembler.getSortByColumn(multiLevelCoreDataMasterDto.getPagination().getSortBy());

        Order order;
        if(CdhConstants.ASC.equals( multiLevelCoreDataMasterDto.getPagination().getSortType())){
            order = criteriaBuilder.asc(multiLevelCoreDataTypesEntityRoot.get(sortByColumn));
        } else {
            order = criteriaBuilder.desc(multiLevelCoreDataTypesEntityRoot.get(sortByColumn));
        }

        TypedQuery<MultiLevelCoreDataTypesEntity> query = em.createQuery(listCriteriaQuery.orderBy(order))
                .setFirstResult((multiLevelCoreDataMasterDto.getPagination().getPage() - 1) * multiLevelCoreDataMasterDto.getPagination().getLimit())
                .setMaxResults(multiLevelCoreDataMasterDto.getPagination().getLimit());
        retData.setData(query.getResultList());

        return retData;
    }

    default List<Predicate> applySearchFilters(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Root<MultiLevelCoreDataTypesEntity> multiLevelCoreDataTypesEntityRoot,
                                               MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto) throws CdhException {

        //Adding the mandatory is deleted check
        predicateList.add(criteriaBuilder.equal(multiLevelCoreDataTypesEntityRoot.get(MultiLevelCoreDataTypesEntity.COLUMN_NAME_IS_DELETED), 0));

        //Adding filter for is Visible present
        if (Optional.ofNullable(multiLevelCoreDataTypesDto.getIsVisible()).isPresent() && multiLevelCoreDataTypesDto.getIsVisible().intValue() != GlobalYesNoEnum.NO.getValue()) {
            predicateList.add(criteriaBuilder.equal(multiLevelCoreDataTypesEntityRoot.get(MultiLevelCoreDataTypesEntity.COLUMN_NAME_CORE_DATA_TYPE_IS_VISIBLE), multiLevelCoreDataTypesDto.getIsVisible()));
        }

        //Adding filter for name if present
        if (Optional.ofNullable(multiLevelCoreDataTypesDto.getName()).isPresent() && !multiLevelCoreDataTypesDto.getName().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.like(criteriaBuilder.upper(multiLevelCoreDataTypesEntityRoot.get(MultiLevelCoreDataTypesEntity.COLUMN_NAME_MULTI_LEVEL_CORE_DATA_TYPES_NAME)), "%"+multiLevelCoreDataTypesDto.getName().toUpperCase()+"%"));
        }

        //Adding filter for key if present
        if (Optional.ofNullable(multiLevelCoreDataTypesDto.getKey()).isPresent() && !multiLevelCoreDataTypesDto.getKey().trim().isEmpty()) {
            predicateList.add(criteriaBuilder.like(criteriaBuilder.upper(multiLevelCoreDataTypesEntityRoot.get(MultiLevelCoreDataTypesEntity.COLUMN_NAME_CORE_DATA_TYPE_KEY)), "%"+multiLevelCoreDataTypesDto.getKey().toUpperCase()+"%"));
        }

        return predicateList;
    }

}
