CREATE TABLE `core_data_types` (
`pk_id` int(11) NOT NULL AUTO_INCREMENT,
`core_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
`name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
`description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
`additional_data` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
`is_visible` smallint(6) DEFAULT NULL,
CONSTRAINT `core_data_types_pkey` PRIMARY KEY (`pk_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

CREATE TABLE `core_data_details` (
`pk_id` int(11) NOT NULL AUTO_INCREMENT,
`type_id` int(11) NOT NULL,
`name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
`description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
`additional_data` text COLLATE utf8_unicode_ci,
`is_editable` smallint(6) DEFAULT NULL,
`is_deleted` smallint(6) DEFAULT NULL,
`created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
`created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
`modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
`modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
`row_version` int(11) DEFAULT NULL,
CONSTRAINT `core_data_details_pkey` PRIMARY KEY (`pk_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10000 DEFAULT CHARSET=utf8;

CREATE TABLE multi_level_core_data
(
    `pk_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `parent_id` int(11) DEFAULT NULL,
    `is_leaf` smallint DEFAULT NULL,
    `multi_level_core_data_master_id` int(11),
    `additional_data` text COLLATE utf8_unicode_ci,
    `is_deleted` smallint(6) DEFAULT NULL,
    `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `row_version` int(11) DEFAULT NULL,
    CONSTRAINT multi_level_core_data_pkey PRIMARY KEY (pk_id)
)ENGINE=InnoDB AUTO_INCREMENT=200000 DEFAULT CHARSET=utf8;

CREATE TABLE multilevel_core_data_types
(
    `pk_id` int(11) NOT NULL AUTO_INCREMENT,
    `core_key` varchar(25),
    `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `additional_data` text COLLATE utf8_unicode_ci,
    `is_visible` smallint(6) DEFAULT NULL,
    `is_deleted` smallint(6) DEFAULT NULL,
    `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `row_version` int(11) DEFAULT NULL,
    CONSTRAINT multilevel_core_data_types_pkey PRIMARY KEY (pk_id)
) ENGINE=InnoDB AUTO_INCREMENT=200000 DEFAULT CHARSET=utf8;

CREATE TABLE multi_level_core_data_master
(
    `pk_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `multi_level_core_datatypes_id` int(11),
    `morder` int(11) DEFAULT NULL,
    `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `additional_data` text COLLATE utf8_unicode_ci,
    `is_editable` smallint(6) DEFAULT NULL,
    `is_deleted` smallint(6) DEFAULT NULL,
    `created_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
    `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `row_version` int(11) DEFAULT NULL,
    CONSTRAINT multi_level_core_data_master_pkey PRIMARY KEY (pk_id)
) ENGINE=InnoDB AUTO_INCREMENT=200000 DEFAULT CHARSET=utf8;