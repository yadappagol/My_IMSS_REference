ALTER TABLE core_data_details
    DROP FOREIGN KEY core_data_details_type_id_fkey ;
	
drop table core_data_details;
drop table core_data_types;
drop table multi_level_core_data;
drop table multi_level_core_data_master;
drop table multilevel_core_data_types;
