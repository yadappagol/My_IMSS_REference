ALTER TABLE core_data_details
    ADD CONSTRAINT core_data_details_type_id_fkey 
		FOREIGN KEY(type_id) 
			REFERENCES core_data_types(pk_id);
