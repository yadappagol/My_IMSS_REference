



drop table core_data_details;
drop table core_data_types;
drop table multi_level_core_data;
drop table multi_level_core_data_master;
drop table multilevel_core_data_types;
