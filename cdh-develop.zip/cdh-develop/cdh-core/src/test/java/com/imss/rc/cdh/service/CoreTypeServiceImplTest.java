package com.imss.rc.cdh.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.imss.rc.cdh.assembler.CoreDataDetailsAssembler;
import com.imss.rc.cdh.assembler.CoreDataTypesAssembler;
import com.imss.rc.cdh.dto.CoreDataDetailsDto;
import com.imss.rc.cdh.dto.CoreDataTypesDto;
import com.imss.rc.cdh.entity.CoreDataDetailsEntity;
import com.imss.rc.cdh.entity.CoreDataTypesEntity;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.cdh.repository.CoreDataDetailsRepository;
import com.imss.rc.cdh.repository.CoreDataTypeRepository;
import com.imss.rc.cdh.util.KafkaSendCdhMessage;
import com.imss.rc.cdh.util.TestConstants;
import com.imss.rc.cdh.validation.ValidateCdh;
import com.imss.rc.commons.dto.BaseListDto;
import com.imss.rc.commons.dto.IdDto;
import com.imss.rc.commons.dto.PaginationDto;
import com.imss.rc.commons.entity.PageableEntity;
import org.hibernate.HibernateException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@SpringBootTest(classes= CoreTypeServiceImplTest.class)
public class CoreTypeServiceImplTest {

    private static final Logger LOG = LoggerFactory.getLogger(CoreTypeServiceImplTest.class);

    @InjectMocks
    private CoreTypeServiceImpl coreTypeService;

    @Mock
    private CoreDataTypeRepository coreDataTypeRepository;

    @Mock
    private CoreDataTypesAssembler assembler;

    @Mock
    private CoreDataDetailsRepository coreDataDetailsRepository;

    @Mock
    private CoreDataDetailsAssembler coreDataDetailsAssembler;

    @Mock
    private KafkaSendCdhMessage kafkaSendCdhMessage;

    @Mock
    private ValidateCdh validateCdh;

    private CoreDataDetailsEntity coreDataDetailsEntity;

    private CoreDataDetailsDto coreDataDetailsDto;

    private CoreDataTypesEntity coreDataTypesEntity;

    private CoreDataTypesDto coreDataTypesDto;

    private PaginationDto paginationDto;

    private JSONObject convertJsonToObject(String fileName) throws IOException, ParseException {
        JSONObject jsonObject= new JSONObject();
        try {
            JSONParser jsonParser = new JSONParser();
            FileReader reader = new FileReader(fileName);
            Object obj = jsonParser.parse(reader);
            jsonObject = (JSONObject) obj;
        }
        catch(Exception ex)
        {
            LOG.error(TestConstants.EXCEPTION_OCCURRED,ex);
            throw ex;
        }
        return jsonObject;
    }

    private File readFile(String fileName)  {
        File file=null;
        try {
             file=new File(fileName);
        }
        catch(Exception ex)
        {
            throw ex;
        }
        return file;
    }

    @Before
    public void init() throws IOException, ParseException {
        try {
            Gson gson = new GsonBuilder().create();
            ObjectMapper objectMapper = new ObjectMapper();
            MockitoAnnotations.initMocks(this);

            //CoreDataDetailsEntity
            coreDataDetailsEntity = objectMapper.readValue(readFile("src/test/java/com/imss/rc/cdh/util/CoreDataDetailsEntity.json"), CoreDataDetailsEntity.class);

            //CoreDataDetailsDto
            coreDataDetailsDto = objectMapper.readValue(readFile("src/test/java/com/imss/rc/cdh/util/CoreDataDetailsDto.json"), CoreDataDetailsDto.class);

            //CoreDataTypesEntity
            coreDataTypesEntity=objectMapper.readValue(readFile("src/test/java/com/imss/rc/cdh/util/CoreDataTypesEntity.json"), CoreDataTypesEntity.class);

            //CoreDataTypesDto
            coreDataTypesDto=objectMapper.readValue(readFile("src/test/java/com/imss/rc/cdh/util/CoreDataTypesDto.json"), CoreDataTypesDto.class);

            //Pagination DTO
            JSONObject jsonFieldObject = convertJsonToObject("src/test/java/com/imss/rc/cdh/util/PaginationDto.json");
            paginationDto = gson.fromJson(String.valueOf(jsonFieldObject), PaginationDto.class);

        } catch(Exception ex){
            LOG.error(TestConstants.EXCEPTION_OCCURRED,ex);
            throw ex;
        }
    }

    @Test
    public void testGetAllCoreDataTypes() throws CdhException
    {
        try {
            coreDataTypesDto.setPagination(paginationDto);

            List<CoreDataTypesEntity> coreDataTypesEntityList = new ArrayList<>();
            coreDataTypesEntityList.add(coreDataTypesEntity);

            PageableEntity<CoreDataTypesEntity> list = new PageableEntity<>();
            list.setData(coreDataTypesEntityList);
            list.setCount(TestConstants.VALUE_FOR_COUNT_FIELD);

            List<CoreDataTypesDto> coreDataTypesDtoList = new ArrayList<>();
            coreDataTypesDtoList.add(coreDataTypesDto);

            when(coreDataTypeRepository.getAllCoreDataTypesWithFilters(Mockito.any(),Mockito.any())).thenReturn(list);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(coreDataTypesDtoList);
            BaseListDto<CoreDataTypesDto> result = coreTypeService.getAllCoreDataTypes(coreDataTypesDto);
            assertEquals(TestConstants.VALUE_FOR_SIZE_FIELD, result.getDataList().size());
            assertEquals(TestConstants.VALUE_FOR_COUNT_FIELD, result.getPagination().getCount());

        }
        catch(Exception e)
        {
            Assert.assertTrue(TestConstants.EXCEPTION_OCCURRED, TestConstants.TEST_CASE_FAILED);
        }
    }

    @Test
    public void testGetAllFieldsNegative() throws CdhException
    {
        try {
            coreDataTypesDto.setPagination(paginationDto);

            List<CoreDataTypesEntity> coreDataTypesEntityList = new ArrayList<>();
            coreDataTypesEntityList.add(coreDataTypesEntity);

            PageableEntity<CoreDataTypesEntity> list = new PageableEntity<>();
            list.setData(coreDataTypesEntityList);
            list.setCount(TestConstants.VALUE_FOR_COUNT_FIELD);

            List<CoreDataTypesDto> coreDataTypesDtoList = new ArrayList<>();
            coreDataTypesDtoList.add(coreDataTypesDto);
            when(coreDataTypeRepository.getAllCoreDataTypesWithFilters(Mockito.any(),Mockito.any())).thenReturn(null);
            when(assembler.entityListToDtoList(list.getData())).thenReturn(coreDataTypesDtoList);
            coreTypeService.getAllCoreDataTypes(coreDataTypesDto);
            Assert.assertTrue(TestConstants.EXECUTION_WENT_THROUGH, TestConstants.TEST_CASE_FAILED);
        }catch (CdhException ex) {
            Assert.assertEquals(TestConstants.CHECKING_RIGHT_ERROR_CODE, CdhException.UNABLE_TO_FIND_CORE_DATA_TYPES, ex.getCode());
        }
    }

    @Test
    public void testGetAllCoreDataDetails() throws CdhException
    {
        try {
            coreDataDetailsDto.setPagination(paginationDto);

            List<CoreDataDetailsEntity> coreDataDetailsEntityList = new ArrayList<>();
            coreDataDetailsEntityList.add(coreDataDetailsEntity);

            PageableEntity<CoreDataDetailsEntity> list = new PageableEntity<>();
            list.setData(coreDataDetailsEntityList);
            list.setCount(TestConstants.VALUE_FOR_COUNT_FIELD);

            List<CoreDataDetailsDto> coreDataDetailsDtoList = new ArrayList<>();
            coreDataDetailsDtoList.add(coreDataDetailsDto);

            when(coreDataDetailsRepository.getAllCoreDataDetailsWithFilters(Mockito.any(),Mockito.any())).thenReturn(list);
            when(coreDataDetailsAssembler.entityListToDtoList(list.getData())).thenReturn(coreDataDetailsDtoList);
            BaseListDto<CoreDataDetailsDto> result = coreTypeService.getAllCoreDataDetails(coreDataDetailsDto);
            assertEquals(TestConstants.VALUE_FOR_SIZE_FIELD, result.getDataList().size());
            assertEquals(TestConstants.VALUE_FOR_COUNT_FIELD, result.getPagination().getCount());

        }
        catch(Exception e)
        {
            Assert.assertTrue(TestConstants.EXCEPTION_OCCURRED, TestConstants.TEST_CASE_FAILED);
        }
    }

    @Test
    public void testGetAllCoreDataDetailsNeg() throws CdhException
    {
        try {
            coreDataDetailsDto.setPagination(paginationDto);

            List<CoreDataDetailsEntity> coreDataDetailsEntityList = new ArrayList<>();
            coreDataDetailsEntityList.add(coreDataDetailsEntity);

            PageableEntity<CoreDataDetailsEntity> list = new PageableEntity<>();
            list.setData(coreDataDetailsEntityList);
            list.setCount(TestConstants.VALUE_FOR_COUNT_FIELD);

            List<CoreDataDetailsDto> coreDataDetailsDtoList = new ArrayList<>();
            coreDataDetailsDtoList.add(coreDataDetailsDto);

            when(coreDataDetailsRepository.getAllCoreDataDetailsWithFilters(Mockito.any(),Mockito.any())).thenReturn(null);
            when(coreDataDetailsAssembler.entityListToDtoList(list.getData())).thenReturn(coreDataDetailsDtoList);
            coreTypeService.getAllCoreDataDetails(coreDataDetailsDto);
            Assert.assertTrue(TestConstants.EXECUTION_WENT_THROUGH, TestConstants.TEST_CASE_FAILED);
        }catch (CdhException ex) {
            Assert.assertEquals(TestConstants.CHECKING_RIGHT_ERROR_CODE, CdhException.UNABLE_TO_FIND_CORE_DATA_DETAILS, ex.getCode());
        }
    }

    @Test
    public void testGetCoreDataDetailsById() throws CdhException {
        try {

            when(coreDataDetailsRepository.getOne(coreDataDetailsDto.getId())).thenReturn(coreDataDetailsEntity);
            when(coreDataDetailsAssembler.entityToDto(coreDataDetailsEntity)).thenReturn(coreDataDetailsDto);
            CoreDataDetailsDto coreDataDetailsDto1=coreTypeService.getCoreDataDetailsById(coreDataDetailsEntity.getId());
            assertEquals(TestConstants.VALUE_FOR_NAME_FIELD, coreDataDetailsDto1.getName());
            assertEquals(TestConstants.VALUE_FOR_DESCRIPTION_FIELD, coreDataDetailsDto1.getDescription());
        } catch (Exception ex) {
            Assert.assertTrue(TestConstants.EXCEPTION_OCCURRED, TestConstants.TEST_CASE_FAILED);
        }
    }

    @Test
    public void testGetCoreDataDetailsForIsDeleted() throws CdhException {
        try {
            coreDataDetailsEntity.setIsDeleted(TestConstants.VALUE_FOR_IS_DELETED);
            when(coreDataDetailsRepository.getOne(coreDataDetailsDto.getId())).thenReturn(coreDataDetailsEntity);
            when(coreDataDetailsAssembler.entityToDto(coreDataDetailsEntity)).thenReturn(coreDataDetailsDto);
           coreTypeService.getCoreDataDetailsById(coreDataDetailsEntity.getId());
            Assert.assertTrue(TestConstants.EXECUTION_WENT_THROUGH, TestConstants.TEST_CASE_FAILED);
        }catch (CdhException ex) {
            Assert.assertEquals(TestConstants.CHECKING_RIGHT_ERROR_CODE, CdhException.CORE_DATA_NOT_FOUND, ex.getCode());
        }
    }

    @Test
    public void testGetCoreDataDetailsNeg() throws CdhException {
        try {
            when(coreDataDetailsRepository.getOne(coreDataDetailsDto.getId())).thenReturn(coreDataDetailsEntity);
            doThrow(new HibernateException(TestConstants.EXCEPTION_OCCURRED)).when(coreDataDetailsAssembler).entityToDto(coreDataDetailsEntity);
            coreTypeService.getCoreDataDetailsById(coreDataDetailsEntity.getId());
            Assert.assertTrue(TestConstants.EXECUTION_WENT_THROUGH, TestConstants.TEST_CASE_FAILED);
        }catch (CdhException ex) {
            Assert.assertEquals(TestConstants.CHECKING_RIGHT_ERROR_CODE, CdhException.UNABLE_TO_FIND_CORE_DATA_TYPES, ex.getCode());
        }
    }

    @Test
    public void testDeleteCoreDataDetailsById() throws CdhException {
        try {
            when(coreDataDetailsRepository.getOne(coreDataDetailsDto.getId())).thenReturn(coreDataDetailsEntity);
            when(validateCdh.isEditable(coreDataDetailsDto.getIsEditable())).thenReturn(true);
            when(coreDataDetailsRepository.save(coreDataDetailsEntity)).thenReturn(coreDataDetailsEntity);
            IdDto idDto=coreTypeService.deleteCoreDataDetailsById(coreDataDetailsDto);
            assertEquals(TestConstants.VALUE_FOR_IS_DELETED, coreDataDetailsEntity.getIsDeleted());
            assertEquals(TestConstants.VALUE_FOR_ID,idDto.getId());

        } catch (Exception ex) {
            Assert.assertTrue(TestConstants.EXCEPTION_OCCURRED, TestConstants.TEST_CASE_FAILED);
        }
    }

    @Test
    public void testDeleteCoreDataDetailsIsDeleted() throws Exception {
        try {
            coreDataDetailsEntity.setIsDeleted(TestConstants.VALUE_FOR_IS_DELETED);
            when(coreDataDetailsRepository.getOne(coreDataDetailsDto.getId())).thenReturn(coreDataDetailsEntity);
            when(validateCdh.isEditable(coreDataDetailsDto.getIsEditable())).thenReturn(true);
            when(coreDataDetailsRepository.save(coreDataDetailsEntity)).thenReturn(coreDataDetailsEntity);
            coreTypeService.deleteCoreDataDetailsById(coreDataDetailsDto);
            Assert.assertTrue(TestConstants.EXECUTION_WENT_THROUGH, TestConstants.TEST_CASE_FAILED);
        }catch (CdhException ex) {
            Assert.assertEquals(TestConstants.CHECKING_RIGHT_ERROR_CODE, CdhException.CORE_DATA_NOT_FOUND, ex.getCode());
        }
    }

    @Test
    public void testDeleteCoreDataDetailsIsEditable() throws Exception {
        try {
            coreDataDetailsEntity.setIsEditable(TestConstants.VALUE_FOR_IS_EDITABLE);
            when(coreDataDetailsRepository.getOne(coreDataDetailsDto.getId())).thenReturn(coreDataDetailsEntity);
            when(validateCdh.isEditable(coreDataDetailsDto.getIsEditable())).thenReturn(false);
            when(coreDataDetailsRepository.save(coreDataDetailsEntity)).thenReturn(coreDataDetailsEntity);
            coreTypeService.deleteCoreDataDetailsById(coreDataDetailsDto);
            Assert.assertTrue(TestConstants.EXECUTION_WENT_THROUGH, TestConstants.TEST_CASE_FAILED);
        }catch (CdhException ex) {
            Assert.assertEquals(TestConstants.CHECKING_RIGHT_ERROR_CODE, CdhException.ROW_IS_NOT_EDITABLE, ex.getCode());
        }
    }

    @Test
    public void testDeleteCoreDataDetailsNeg() throws Exception {
        try {
            when(coreDataDetailsRepository.getOne(coreDataDetailsDto.getId())).thenReturn(coreDataDetailsEntity);
            when(validateCdh.isEditable(coreDataDetailsDto.getIsEditable())).thenReturn(true);
            doThrow(new HibernateException(TestConstants.EXCEPTION_OCCURRED)).when(coreDataDetailsRepository).save(coreDataDetailsEntity);
            coreTypeService.deleteCoreDataDetailsById(coreDataDetailsDto);
            Assert.assertTrue(TestConstants.EXECUTION_WENT_THROUGH, TestConstants.TEST_CASE_FAILED);
        }catch (CdhException ex) {
            Assert.assertEquals(TestConstants.CHECKING_RIGHT_ERROR_CODE, CdhException.UNABLE_TO_DELETE_CORE_DATA_TYPES, ex.getCode());
        }
    }

    @Test
    public void testSaveCoreDataDetails() throws CdhException {
        try {
            when(coreDataDetailsAssembler.dtoToEntity(coreDataDetailsDto)).thenReturn(coreDataDetailsEntity);
            when(coreDataDetailsAssembler.entityToDto(coreDataDetailsEntity)).thenReturn(coreDataDetailsDto);
            when(validateCdh.isNameValid(coreDataDetailsDto.getName())).thenReturn(true);
            when(validateCdh.isValidTypeId(coreDataDetailsDto.getTypeId())).thenReturn(true);
            when(coreDataDetailsRepository.save(coreDataDetailsEntity)).thenReturn(coreDataDetailsEntity);
            CoreDataDetailsDto coreDataDetailsDto1=coreTypeService.saveCoreDataDetails(coreDataDetailsDto);
            assertEquals(TestConstants.VALUE_FOR_NAME_FIELD, coreDataDetailsDto1.getName());
            assertEquals(TestConstants.VALUE_FOR_DESCRIPTION_FIELD, coreDataDetailsDto1.getDescription());
        } catch (Exception ex) {
            Assert.assertTrue(TestConstants.EXCEPTION_OCCURRED, TestConstants.TEST_CASE_FAILED);
        }
    }

    @Test
    public void testSaveCoreDataDetailsNeg() throws CdhException {
        try {
            when(coreDataDetailsAssembler.dtoToEntity(coreDataDetailsDto)).thenReturn(coreDataDetailsEntity);
            when(coreDataDetailsAssembler.entityToDto(coreDataDetailsEntity)).thenReturn(coreDataDetailsDto);
            when(validateCdh.isNameValid(coreDataDetailsDto.getName())).thenReturn(true);
            when(validateCdh.isValidTypeId(coreDataDetailsDto.getTypeId())).thenReturn(true);
            doThrow(new HibernateException(TestConstants.EXCEPTION_OCCURRED)).when(coreDataDetailsRepository).save(coreDataDetailsEntity);
            coreTypeService.saveCoreDataDetails(coreDataDetailsDto);
            Assert.assertTrue(TestConstants.EXECUTION_WENT_THROUGH, TestConstants.TEST_CASE_FAILED);
        }catch (CdhException ex) {
            Assert.assertEquals(TestConstants.CHECKING_RIGHT_ERROR_CODE, CdhException.UNABLE_TO_CREATE, ex.getCode());
        }
    }

    @Test
    public void testUpdateCoreDataDetails() throws CdhException {
        try {
            when(coreDataDetailsAssembler.dtoToEntity(coreDataDetailsDto)).thenReturn(coreDataDetailsEntity);
            when(coreDataDetailsAssembler.entityToDto(coreDataDetailsEntity)).thenReturn(coreDataDetailsDto);
            when(validateCdh.isNameValid(coreDataDetailsDto.getName())).thenReturn(true);
            when(validateCdh.isValidTypeId(coreDataDetailsDto.getTypeId())).thenReturn(true);
            when(coreDataDetailsRepository.getOne(coreDataDetailsDto.getId())).thenReturn(coreDataDetailsEntity);
            when(coreDataDetailsRepository.save(coreDataDetailsEntity)).thenReturn(coreDataDetailsEntity);
            CoreDataDetailsDto coreDataDetailsDto1=coreTypeService.updateCoreDataDetailsById(coreDataDetailsDto,coreDataDetailsDto.getId());
            assertEquals(TestConstants.VALUE_FOR_NAME_FIELD, coreDataDetailsDto1.getName());
            assertEquals(TestConstants.VALUE_FOR_DESCRIPTION_FIELD, coreDataDetailsDto1.getDescription());
        } catch (Exception ex) {
            Assert.assertTrue(TestConstants.EXCEPTION_OCCURRED, TestConstants.TEST_CASE_FAILED);
        }
    }

    @Test
    public void testUpdateCoreDataDetailsIsEditable() throws CdhException {
        try {
            coreDataDetailsEntity.setIsEditable(TestConstants.VALUE_FOR_IS_EDITABLE);
            when(coreDataDetailsAssembler.dtoToEntity(coreDataDetailsDto)).thenReturn(coreDataDetailsEntity);
            when(coreDataDetailsAssembler.entityToDto(coreDataDetailsEntity)).thenReturn(coreDataDetailsDto);
            when(validateCdh.isNameValid(coreDataDetailsDto.getName())).thenReturn(true);
            when(validateCdh.isValidTypeId(coreDataDetailsDto.getTypeId())).thenReturn(true);
            when(coreDataDetailsRepository.getOne(coreDataDetailsDto.getId())).thenReturn(coreDataDetailsEntity);
            when(coreDataDetailsRepository.save(coreDataDetailsEntity)).thenReturn(coreDataDetailsEntity);
            coreTypeService.updateCoreDataDetailsById(coreDataDetailsDto,coreDataDetailsDto.getId());
            Assert.assertTrue(TestConstants.EXECUTION_WENT_THROUGH, TestConstants.TEST_CASE_FAILED);
        }catch (CdhException ex) {
            Assert.assertEquals(TestConstants.CHECKING_RIGHT_ERROR_CODE, CdhException.ROW_IS_NOT_EDITABLE, ex.getCode());
        }
    }

    @Test
    public void testUpdateCoreDataDetailsNegative() throws CdhException {
        try {
            when(coreDataDetailsAssembler.dtoToEntity(coreDataDetailsDto)).thenReturn(coreDataDetailsEntity);
            when(coreDataDetailsAssembler.entityToDto(coreDataDetailsEntity)).thenReturn(coreDataDetailsDto);
            when(validateCdh.isNameValid(coreDataDetailsDto.getName())).thenReturn(true);
            when(validateCdh.isValidTypeId(coreDataDetailsDto.getTypeId())).thenReturn(true);
            when(coreDataDetailsRepository.getOne(coreDataDetailsDto.getId())).thenReturn(coreDataDetailsEntity);
            doThrow(new HibernateException(TestConstants.EXCEPTION_OCCURRED)).when(coreDataDetailsRepository).saveAndFlush(coreDataDetailsEntity);
            coreTypeService.updateCoreDataDetailsById(coreDataDetailsDto,coreDataDetailsDto.getId());
            Assert.assertTrue(TestConstants.EXECUTION_WENT_THROUGH, TestConstants.TEST_CASE_FAILED);
        }catch (CdhException ex) {
            Assert.assertEquals(TestConstants.CHECKING_RIGHT_ERROR_CODE, CdhException.UNABLE_TO_UPDATE_CORE_DATA_TYPES, ex.getCode());
        }
    }
}
