package com.imss.rc.cdh.dto;

import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.PaginationDto;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;

@Data
@NoArgsConstructor
public class MultiLevelCoreDataTypesDto  extends BaseDto {

    private String key;
    private String name;
    private String description;
    private HashMap<String,Object> additionalData;
    private Integer isVisible;

    private PaginationDto pagination;
}
