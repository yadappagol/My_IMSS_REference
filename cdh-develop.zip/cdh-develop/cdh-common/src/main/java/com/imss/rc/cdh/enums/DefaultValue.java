package com.imss.rc.cdh.enums;

public enum DefaultValue {
    isEditable(1),
    isVisible(1);

    private int numVal;

    DefaultValue(int numVal) {
        this.numVal = numVal;
    }

    public int getNumVal() {
        return numVal;
    }
}
