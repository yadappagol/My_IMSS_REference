package com.imss.rc.cdh.assembler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.cdh.dto.CoreDataDetailsDto;
import com.imss.rc.cdh.constants.CdhConstants;
import com.imss.rc.cdh.entity.CoreDataDetailsEntity;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.assembler.BaseAssembler;
import org.hibernate.Hibernate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class CoreDataDetailsAssembler {

    private static final Logger LOGGER = LoggerFactory.getLogger(CoreDataDetailsAssembler.class);

    private static Map<String, String> sortByList;

    static {
        sortByList = new HashMap<>();
        sortByList.put(CdhConstants.SORT_BY_TYPE_ID, CoreDataDetailsEntity.COLUMN_NAME_CORE_DATA_DETAILS_TYPE_ID);
        sortByList.put(CdhConstants.SORT_BY_NAME,CoreDataDetailsEntity.COLUMN_NAME_CORE_DATA_DETAILS_NAME);
        sortByList.put(CdhConstants.SORT_BY_CREATED,CoreDataDetailsEntity.COLUMN_NAME_CORE_DATA_CREATED);
        sortByList.put(CdhConstants.SORT_BY_MODIFIED,CoreDataDetailsEntity.COLUMN_NAME_CORE_DATA_MODIFIED);
    }

    /**
     * Method to return the entity column variable name based on the sort by field value received from the ui
     * @param input The sort by field as received from the UI
     * @return The column variable name based on which the sorting should happen
     */
    public static String getSortByColumn(String input) throws CdhException {
        return BaseAssembler.getSortByColumn(input, sortByList);
    }

    private static BaseAssembler<CoreDataDetailsDto, CoreDataDetailsEntity> getBaseAssembler(){
        return new BaseAssembler<>(CoreDataDetailsDto::new, CoreDataDetailsEntity::new);
    }

    /**
     * Method to convert CoreDataDetailsEntity entity object to CoreDataDetailsDto dto object
     * @param entity the entity object with the data
     * @return A new CoreDataDetailsDto object with the data from the entity object
     */
    public CoreDataDetailsDto entityToDto(CoreDataDetailsEntity entity){
        CoreDataDetailsDto dto = getBaseAssembler().entityToDto(entity);

        if(entity.getAdditionalData() !=null && !entity.getAdditionalData().trim().isEmpty()){
            try {
                ObjectMapper mapper = new ObjectMapper();
                dto.setAdditionalData((HashMap<String, Object>) mapper.readValue(entity.getAdditionalData(), Map.class));
            } catch (Exception ex){
                LOGGER.error("Error while converting additional data", ex);
            }
        }

        return dto;
    }

    /**
     * Method to convert CoreDataDetailsDto dto object to CoreDataDetailsEntity entity object
     * @param dto the dto object with the data
     * @return A new CoreDataDetailsEntity entity object with the data from the dto object
     */
    public CoreDataDetailsEntity dtoToEntity(CoreDataDetailsDto dto){

        return getBaseAssembler().dtoToEntity(dto);
    }


    /**
     * Method to convert a list of CoreDataDetailsDto dto objects to a list of CoreDataDetailsEntity entity objects
     * @param entityList A list of CoreDataDetailsEntity entity objects
     * @return A new list of CoreDataDetailsDto dto objects
     */
    public List<CoreDataDetailsDto> entityListToDtoList(List<CoreDataDetailsEntity> entityList)
    {
        ArrayList<CoreDataDetailsDto> dtoList = new ArrayList();

        entityList.stream().forEach((k) -> {
                    CoreDataDetailsDto dto = this.entityToDto(k);
                    if(Hibernate.isInitialized(k.getTypeIdObj()) && k.getTypeIdObj() != null){
                        dto.setTypeName(k.getTypeIdObj() .getName());
                    }
            dtoList.add(dto);
        });
        return dtoList;
    }


    /**
     * Method to convert a list of CoreDataDetailsEntity entity objects to a list of ProductMasterDto dto objects
     * @param dtoList A list of CoreDataDetailsDto dto objects
     * @return A new list of CoreDataDetailsEntity entity objects
     */
    public List<CoreDataDetailsEntity> dtoListToEntityList(List<CoreDataDetailsDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }

}
