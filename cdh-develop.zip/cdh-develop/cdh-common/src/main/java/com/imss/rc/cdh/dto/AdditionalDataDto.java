package com.imss.rc.cdh.dto;

import lombok.Data;

@Data
public class AdditionalDataDto {

    private String field;
    private Object value;
}
