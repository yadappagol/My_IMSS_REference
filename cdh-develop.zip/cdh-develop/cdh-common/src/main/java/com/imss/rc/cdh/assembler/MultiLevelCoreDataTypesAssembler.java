package com.imss.rc.cdh.assembler;

import com.imss.rc.cdh.dto.MultiLevelCoreDataTypesDto;
import com.imss.rc.cdh.entity.MultiLevelCoreDataTypesEntity;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.assembler.BaseAssembler;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class MultiLevelCoreDataTypesAssembler {

    private static Map<String, String> sortByList;

    static{
        sortByList = new HashMap<>();
        sortByList.put("key",MultiLevelCoreDataTypesEntity.COLUMN_NAME_CORE_DATA_TYPE_KEY);
        sortByList.put("name", MultiLevelCoreDataTypesEntity.COLUMN_NAME_MULTI_LEVEL_CORE_DATA_TYPES_NAME);
    }

    /**
     * Method to return the entity column variable name based on the sort by field value received from the ui
     * @param input The sort by field as received from the UI
     * @return The column variable name based on which the sorting should happen
     */
    public static String getSortByColumn(String input) throws CdhException {
        return BaseAssembler.getSortByColumn(input, sortByList);
    }

    private static BaseAssembler<MultiLevelCoreDataTypesDto, MultiLevelCoreDataTypesEntity> getBaseAssembler(){
        return new BaseAssembler<>(MultiLevelCoreDataTypesDto::new, MultiLevelCoreDataTypesEntity::new);
    }

    /**
     * Method to convert MultiLevelCoreDataTypesEntity entity object to MultiLevelCoreDataTypesDto dto object
     * @param multiLevelCoreDataTypesEntity the entity object with the data
     * @return A new MultiLevelCoreDataTypesDto object with the data from the entity object
     */
    public MultiLevelCoreDataTypesDto entityToDto(MultiLevelCoreDataTypesEntity multiLevelCoreDataTypesEntity){
        return getBaseAssembler().entityToDto(multiLevelCoreDataTypesEntity);
    }

    /**
     * Method to convert MultiLevelCoreDataTypesDto dto object to MultiLevelCoreDataTypesEntity entity object
     * @param multiLevelCoreDataTypesDto the dto object with the data
     * @return A new MultiLevelCoreDataTypesEntity entity object with the data from the dto object
     */
    public MultiLevelCoreDataTypesEntity dtoToEntity(MultiLevelCoreDataTypesDto multiLevelCoreDataTypesDto){
        return getBaseAssembler().dtoToEntity(multiLevelCoreDataTypesDto);
    }

    /**
     * Method to convert a list of MultiLevelCoreDataTypesDto dto objects to a list of MultiLevelCoreDataTypesEntity entity objects
     * @param entityList A list of MultiLevelCoreDataTypesEntity entity objects
     * @return A new list of MultiLevelCoreDataTypesDto dto objects
     */
    public List<MultiLevelCoreDataTypesDto> entityListToDtoList(List<MultiLevelCoreDataTypesEntity> entityList)
    {
        return getBaseAssembler().entityListToDtoList(entityList);
    }

    /**
     * Method to convert a list of MultiLevelCoreDataTypesEntity entity objects to a list of MultiLevelCoreDataTypesDto dto objects
     * @param dtoList A list of MultiLevelCoreDataTypesDto dto objects
     * @return A new list of MultiLevelCoreDataTypesEntity entity objects
     */
    public List<MultiLevelCoreDataTypesEntity> dtoListToEntityList(List<MultiLevelCoreDataTypesDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }

}
