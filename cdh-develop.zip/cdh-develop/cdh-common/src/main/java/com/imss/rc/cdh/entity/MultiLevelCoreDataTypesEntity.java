package com.imss.rc.cdh.entity;

import com.imss.rc.commons.entity.BaseEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@Entity
@Table(name="multilevel_core_data_types")
public class MultiLevelCoreDataTypesEntity extends BaseEntity {

    public static final String COLUMN_NAME_CORE_DATA_TYPE_KEY ="key" ;
    public static final String COLUMN_NAME_MULTI_LEVEL_CORE_DATA_TYPES_NAME = "name";
    public static final String COLUMN_NAME_CORE_DATA_TYPE_IS_VISIBLE = "isVisible";

    @Column(name="core_key")
    private String key;

    @Column(name="name")
    private String name;

    @Column(name="description")
    private String description;

    @Column(name="additional_data")
    private String additionalData;

    @Column(name="is_visible")
    private Integer isVisible;
}
