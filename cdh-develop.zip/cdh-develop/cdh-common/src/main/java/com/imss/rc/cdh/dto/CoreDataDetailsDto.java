package com.imss.rc.cdh.dto;


import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.PaginationDto;
import lombok.Data;

import java.util.Date;
import java.util.HashMap;

@Data
public class CoreDataDetailsDto extends BaseDto {

    private String typeName;
    private int typeId;
    private String name;
    private String description;
    private HashMap<String,Object> additionalData;
    private int isEditable;
    private String createdBy;
    private Date createdDate;
    private String modifiedBy;
    private Date modifiedDate;
    private Short isDeleted;
    private Integer rowVersion;

    private PaginationDto pagination;

    public CoreDataDetailsDto()
    {

    }
}
