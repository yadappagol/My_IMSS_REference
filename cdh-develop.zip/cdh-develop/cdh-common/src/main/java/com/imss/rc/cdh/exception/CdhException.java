package com.imss.rc.cdh.exception;

import com.imss.rc.commons.exception.IMSSException;
import org.springframework.http.HttpStatus;


public class CdhException extends IMSSException {

    public static final String UNABLE_TO_FIND_CORE_DATA_TYPES = "1000";
    public static final String WRONG_INPUT = "1007";
    public static final String UNABLE_TO_CREATE = "1001";
    public static final String UNABLE_TO_UPDATE_CORE_DATA_TYPES = "1002";
    public static final String UNABLE_TO_DELETE_CORE_DATA_TYPES = "1003";
    public static final String ROW_IS_NOT_EDITABLE = "1004";
    public static final String IS_EDITABLE_DOES_NOT_EXIST = "1005";
    public static final String CORE_DATA_NOT_FOUND = "1006";
    public static final String INVALID_ORDER_BY_COLUMN = "1007";
    public static final String UNABLE_TO_FIND_CORE_DATA_DETAILS ="1008" ;
    public static final String MANDATORY_NAME_FIELD = "1009";
    public static final String NAME_NOT_VALID = "1010";
    public static final String MANDATORY_TYPE_ID_FIELD = "1011";
    public static final String TYPE_DOES_NOT_EXIST = "1012";
    public static final String MESSAGE_NOT_SENT = "1013";
    public static final String CDH_CACHE_NOT_LOADED_PROPERLY = "1014";
    public static final String UNKNOWN_IS_LIST_VALUE = "1015";
    public static final String INVALID_PAGE = "1016";
    public static final String INVALID_LIMIT = "1017";

    public static final String UNABLE_TO_FIND_MULTI_LEVEL_CORE_DATA = "1018";
    public static final String UNABLE_TO_CREATE_MULTI_LEVEL_CORE_DATA = "1019";
    public static final String UNABLE_TO_UPDATE_MULTI_LEVEL_CORE_DATA = "1020";
    public static final String UNABLE_TO_DELETE_MULTI_LEVEL_CORE_DATA = "1021";
    public static final String MULTI_LEVEL_CORE_DATA_NOT_FOUND = "1022";

    public static final String UNABLE_TO_FIND_MULTI_LEVEL_CORE_DATA_MASTER = "1023";
    public static final String UNABLE_TO_CREATE_MULTI_LEVEL_CORE_DATA_MASTER = "1024";
    public static final String UNABLE_TO_UPDATE_MULTI_LEVEL_CORE_DATA_MASTER = "1025";
    public static final String UNABLE_TO_DELETE_MULTI_LEVEL_CORE_DATA_MASTER = "1026";
    public static final String MULTI_LEVEL_CORE_DATA_MASTER_NOT_FOUND = "1027";

    public static final String UNABLE_TO_FIND_MULTI_LEVEL_CORE_DATA_TYPES = "1028";
    public static final String UNABLE_TO_CREATE_MULTI_LEVEL_CORE_DATA_TYPES = "1029";
    public static final String UNABLE_TO_UPDATE_MULTI_LEVEL_CORE_DATA_TYPES = "1030";
    public static final String UNABLE_TO_DELETE_MULTI_LEVEL_CORE_DATA_TYPES = "1031";
    public static final String MULTI_LEVEL_CORE_DATA_TYPES_NOT_FOUND = "1032";

    public static final String MESSAGE_BUNDLE_NAME = "core_data_error_messages";
    public static final String MODULE_CODE = "CDH";
    public static final String ERROR_CODE_PREFIX = "core.data.error.";

    public CdhException(String code, Object[] args, Throwable cause, HttpStatus httpStatus) {
        super(code,args,cause,httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

    public CdhException(String code, Object[] args,HttpStatus httpStatus) {
        super(code,args,httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);

    }

    public CdhException(String code, Throwable cause,HttpStatus httpStatus) {
        super(code, cause,httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }

    public CdhException(String code,HttpStatus httpStatus) {
        super(code,httpStatus);
        super.setAttributes(MESSAGE_BUNDLE_NAME, MODULE_CODE, ERROR_CODE_PREFIX);
    }
}
