package com.imss.rc.cdh.entity;


import com.imss.rc.commons.entity.BaseEntity;
import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name="core_data_details")
public class CoreDataDetailsEntity extends BaseEntity {

    public static final String COLUMN_NAME_CORE_DATA_DETAILS_NAME = "name";
    public static final String COLUMN_NAME_CORE_DATA_DETAILS_IS_DELETED = "isDeleted";
    public static final String COLUMN_NAME_CORE_DATA_DETAILS_TYPE_ID = "typeId";
    public static final String COLUMN_NAME_CORE_DATA_CREATED ="createdDate" ;
    public static final String COLUMN_NAME_CORE_DATA_MODIFIED = "modifiedDate";

    @ManyToOne(targetEntity = CoreDataTypesEntity.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "type_id", referencedColumnName = "pk_id", insertable = false, updatable = false)
    private CoreDataTypesEntity typeIdObj;

    @Column(name="type_id")
    private int typeId;

    @Column(name="name")
    private String name;

    @Column(name="description")
    private String description;

    @Column(name="additional_data")
    private String additionalData;

    @Column(name="is_editable")
    private int isEditable;

    public CoreDataDetailsEntity() {
        super();
    }

}
