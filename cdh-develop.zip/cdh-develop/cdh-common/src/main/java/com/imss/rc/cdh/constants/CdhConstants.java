package com.imss.rc.cdh.constants;

public class CdhConstants {

    public static final String ADDED_CORE_DATA_DETAILS = "Added core data details '%s'";
    public static final String UPDATED_CORE_DATA_DETAILS = "Updated core data details '%s'";
    public static final String RETRIEVED_CORE_DATA_DETAILS_LIST = "Retrieved page %s with limit of %s records of core data list sorted by %s in %s order, total of %s records were found.";
    public static final String RETRIEVED_CORE_DATA_DETAILS = "Retrieved core data details '%s'";
    public static final String DELETED_CORE_DATA_DETAILS = "Deleted core data details '%s'";
    public static final String RETRIEVED_CORE_DATA_TYPES_LIST= "Retrieved page %s with limit of %s records of core data types list sorted by %s in %s order, total of %s records were found.";

    public static final String SORT_BY_NAME = "name";
    public static final String SORT_BY_TYPE_ID = "category";
    public static final String SORT_BY_CREATED ="created" ;
    public static final String SORT_BY_MODIFIED = "modified";
    public static final String SORT_BY_ORDER = "order";
    public static final int MAX_LENGTH = 50;
    public static final String REGEX_PATTERN = "^[A-Za-z0-9 _]*[A-Za-z0-9][A-Za-z0-9 _]*$";

    public static final String ADDED_MULTI_LEVEL_CORE_DATA = "Added multi level core data '%s'";
    public static final String UPDATE_MULTI_LEVEL_CORE_DATA = "Added multi level core data '%s'";
    public static final String DELETE_MULTI_LEVEL_CORE_DATA = "Deleted multi level core data '%s'";
    public static final String RETRIEVE_MULTI_LEVEL_CORE_DATA = "Retrieved multi level core data '%s'";
    public static final String RETRIEVE_MULTI_LEVEL_CORE_DATA_LIST = "Retrieved page %s with limit of %s records of core data list sorted by %s in %s order, total of %s records were found.";

    public static final String ADDED_MULTI_LEVEL_CORE_DATA_MASTER = "Added multi level core data master '%s'";
    public static final String UPDATE_MULTI_LEVEL_CORE_DATA_MASTER = "Added multi level core data master '%s'";
    public static final String DELETE_MULTI_LEVEL_CORE_DATA_MASTER = "Deleted multi level core data master '%s'";
    public static final String RETRIEVE_MULTI_LEVEL_CORE_DATA_MASTER = "Retrieved multi level core data master '%s'";
    public static final String RETRIEVE_MULTI_LEVEL_CORE_DATA__MASTER_LIST = "Retrieved page %s with limit of %s records of core data list sorted by %s in %s order, total of %s records were found.";

    public static final String ADDED_MULTI_LEVEL_CORE_DATA_TYPES = "Added multi level core data types '%s'";
    public static final String UPDATE_MULTI_LEVEL_CORE_DATA_TYPES = "Added multi level core data types '%s'";
    public static final String DELETE_MULTI_LEVEL_CORE_DATA_TYPES = "Deleted multi level core data types '%s'";
    public static final String RETRIEVE_MULTI_LEVEL_CORE_DATA_TYPES = "Retrieved multi level core data types '%s'";
    public static final String RETRIEVE_MULTI_LEVEL_CORE_DATA_TYPES_LIST = "Retrieved page %s with limit of %s records of core data list sorted by %s in %s order, total of %s records were found.";

    public static final String ASC = "asc";

    private CdhConstants(){
    }

}
