package com.imss.rc.cdh.entity;

import com.imss.rc.commons.entity.BaseEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name="multi_level_core_data")
@Data
public class MultiLevelCoreDataEntity extends BaseEntity {

    public static final String COLUMN_NAME_MULTI_LEVEL_CORE_DATA_NAME = "name";
    public static final String COLUMN_NAME_MULTI_LEVEL_CORE_DATA_PARENT_ID = "parentId";
    public static final String COLUMN_NAME_MULTI_LEVEL_CORE_DATA_IS_LEAF = "isLeaf";
    public static final String COLUMN_NAME_MULTI_LEVEL_CORE_DATA_MULTI_LEVEL_CORE_DATA_MASTER_ID = "multiLevelCoreDataMasterId";
    public static final String COLUMN_NAME_MULTI_LEVEL_CORE_DATA_ADDITIONAL_DATA = "additionalData";


    @Column(name="name")
    private String name;

    @Column(name="parent_id")
    private Integer parentId;

    @Column(name="is_leaf")
    private short isLeaf;

    @Column(name="multi_level_core_data_master_id")
    private Integer multiLevelCoreDataMasterId;

    @Column(name="additional_data")
    private String additionalData;

    @Column(name="description")
    private String description;

    @Column(name="is_editable")
    private int isEditable;

}
