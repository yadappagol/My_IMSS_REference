package com.imss.rc.cdh.assembler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.cdh.dto.MultiLevelCoreDataDto;
import com.imss.rc.cdh.entity.MultiLevelCoreDataEntity;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.assembler.BaseAssembler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class MultiLevelCoreDataAssembler {

    private static Map<String, String> sortByList;

    private static final Logger LOGGER = LoggerFactory.getLogger(MultiLevelCoreDataAssembler.class);

    static {
        sortByList = new HashMap<>();
        sortByList.put("name", MultiLevelCoreDataEntity.COLUMN_NAME_MULTI_LEVEL_CORE_DATA_NAME);
        sortByList.put("parentId", MultiLevelCoreDataEntity.COLUMN_NAME_MULTI_LEVEL_CORE_DATA_PARENT_ID);
        sortByList.put("isLeaf", MultiLevelCoreDataEntity.COLUMN_NAME_MULTI_LEVEL_CORE_DATA_IS_LEAF);
        sortByList.put("multiLevelCoreDataMasterId", MultiLevelCoreDataEntity.COLUMN_NAME_MULTI_LEVEL_CORE_DATA_MULTI_LEVEL_CORE_DATA_MASTER_ID);
        sortByList.put("additionalData", MultiLevelCoreDataEntity.COLUMN_NAME_MULTI_LEVEL_CORE_DATA_ADDITIONAL_DATA);
    }

    public static String getSortByColumn(String input) throws CdhException {
        return BaseAssembler.getSortByColumn(input, sortByList);
    }

    private static BaseAssembler<MultiLevelCoreDataDto, MultiLevelCoreDataEntity> getBaseAssembler(){
        return new BaseAssembler<>(MultiLevelCoreDataDto::new, MultiLevelCoreDataEntity::new);
    }

    public MultiLevelCoreDataDto entityToDto(MultiLevelCoreDataEntity multiLevelCoreDataEntity){
        MultiLevelCoreDataDto dto = getBaseAssembler().entityToDto(multiLevelCoreDataEntity);
        if(multiLevelCoreDataEntity.getAdditionalData() !=null && !multiLevelCoreDataEntity.getAdditionalData().trim().isEmpty()){
            try {
                ObjectMapper mapper = new ObjectMapper();
                dto.setAdditionalData((HashMap<String, Object>) mapper.readValue(multiLevelCoreDataEntity.getAdditionalData(), Map.class));
            } catch (Exception ex){
                LOGGER.error("Error while converting additional data", ex);
            }
        }
        return dto;
    }

    public MultiLevelCoreDataEntity dtoToEntity(MultiLevelCoreDataDto multiLevelCoreDataDto){
        return getBaseAssembler().dtoToEntity(multiLevelCoreDataDto);
    }

    public List<MultiLevelCoreDataDto> entityListToDtoList(List<MultiLevelCoreDataEntity> entityList)
    {
        return getBaseAssembler().entityListToDtoList(entityList);
    }

    public List<MultiLevelCoreDataEntity> dtoListToEntityList(List<MultiLevelCoreDataDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }

}
