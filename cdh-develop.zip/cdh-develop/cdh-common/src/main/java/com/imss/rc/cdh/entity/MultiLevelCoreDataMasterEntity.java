package com.imss.rc.cdh.entity;

import com.imss.rc.commons.entity.BaseEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@Entity
@Table(name="multi_level_core_data_master")
public class MultiLevelCoreDataMasterEntity extends BaseEntity {

    public static final String COLUMN_NAME_MULTI_LEVEL_CORE_DATA_MASTER_NAME = "name";
    public static final String COLUMN_NAME_MULTI_LEVEL_CORE_DATA_MASTER_MULTI_LEVEL_CORE_DATA_TYPES_ID = "multiLevelCoreDataTypesId";
    public static final String COLUMN_NAME_MULTI_LEVEL_CORE_DATA_MASTER_ORDER = "order";

    @Column(name="name")
    private String name;

    @Column(name="multi_level_core_datatypes_id")
    private Integer multiLevelCoreDataTypesId;

    @Column(name="morder")
    private Integer order;

    @Column(name="is_editable")
    private int isEditable;

    @Column(name="description")
    private String description;

    @Column(name="additional_data")
    private String additionalData;
}
