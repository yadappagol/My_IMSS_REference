package com.imss.rc.cdh.dto;

import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.PaginationDto;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;

@Data
@NoArgsConstructor
public class MultiLevelCoreDataDto extends BaseDto {

    private String name;
    private Integer parentId;
    private short isLeaf;
    private Integer multiLevelCoreDataMasterId;
    private HashMap<String,Object> additionalData;
    private String description;
    private int isEditable;

    private PaginationDto pagination;
}
