package com.imss.rc.cdh.entity;


import com.imss.rc.commons.entity.IdEntity;
import lombok.Data;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@Entity
@Table(name="core_data_types")
public class CoreDataTypesEntity extends IdEntity {

    public static final String COLUMN_NAME_CORE_DATA_TYPE_KEY ="key" ;
    public static final String COLUMN_NAME_CORE_DATA_TYPE_NAME = "name";
    public static final String COLUMN_NAME_CORE_DATA_TYPE_IS_VISIBLE = "isVisible";

    @Column(name="core_key")
    private String key;

    @Column(name="name")
    private String name;

    @Column(name="description")
    private String description;

    @Column(name="additional_data")
    private String additionalData;

    @Column(name="is_visible")
    private Integer isVisible;

}
