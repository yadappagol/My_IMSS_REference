package com.imss.rc.cdh.dto;

import com.imss.rc.commons.dto.BaseDto;
import com.imss.rc.commons.dto.PaginationDto;
import lombok.Data;


@Data
public class CoreDataTypesDto extends BaseDto {
    private String key;
    private String name;
    private String description;
    private String additionalData;
    private Integer isVisible;
    private Integer rowVersion;

    private PaginationDto pagination;

    public CoreDataTypesDto()
    {
    }
}
