package com.imss.rc.cdh.assembler;

import com.imss.rc.cdh.dto.CoreDataTypesDto;
import com.imss.rc.cdh.entity.CoreDataTypesEntity;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.assembler.BaseAssembler;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class CoreDataTypesAssembler {

    private static Map<String, String> sortByList;

    static {
        sortByList = new HashMap<>();
        sortByList.put("key",CoreDataTypesEntity.COLUMN_NAME_CORE_DATA_TYPE_KEY);
        sortByList.put("name",CoreDataTypesEntity.COLUMN_NAME_CORE_DATA_TYPE_NAME);
    }
    /**
     * Method to return the entity column variable name based on the sort by field value received from the ui
     * @param input The sort by field as received from the UI
     * @return The column variable name based on which the sorting should happen
     */
    public static String getSortByColumn(String input) throws CdhException {
        return BaseAssembler.getSortByColumn(input, sortByList);
    }


    private static BaseAssembler<CoreDataTypesDto, CoreDataTypesEntity> getBaseAssembler(){
        return new BaseAssembler<>(CoreDataTypesDto::new, CoreDataTypesEntity::new);
    }

    /**
     * Method to convert CoreDataTypesEntity entity object to CoreDataTypesDto dto object
     * @param entity the entity object with the data
     * @return A new CoreDataTypesDto object with the data from the entity object
     */
    public CoreDataTypesDto entityToDto(CoreDataTypesEntity entity){
        return getBaseAssembler().entityToDto(entity);
    }

    /**
     * Method to convert CoreDataTypesDto dto object to CoreDataTypesEntity entity object
     * @param dto the dto object with the data
     * @return A new CoreDataTypesEntity entity object with the data from the dto object
     */
    public CoreDataTypesEntity dtoToEntity(CoreDataTypesDto dto){

        return getBaseAssembler().dtoToEntity(dto);
    }


    /**
     * Method to convert a list of CoreDataTypesDto dto objects to a list of CoreDataTypesEntity entity objects
     * @param entityList A list of CoreDataTypesEntity entity objects
     * @return A new list of CoreDataTypesDto dto objects
     */
    public List<CoreDataTypesDto> entityListToDtoList(List<CoreDataTypesEntity> entityList)
    {
        return getBaseAssembler().entityListToDtoList(entityList);
    }


    /**
     * Method to convert a list of CoreDataTypesEntity entity objects to a list of CoreDataTypesDto dto objects
     * @param dtoList A list of CoreDataTypesDto dto objects
     * @return A new list of CoreDataTypesEntity entity objects
     */
    public List<CoreDataTypesEntity> dtoListToEntityList(List<CoreDataTypesDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }

}
