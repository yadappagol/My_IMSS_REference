package com.imss.rc.cdh.assembler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.cdh.dto.MultiLevelCoreDataMasterDto;
import com.imss.rc.cdh.entity.MultiLevelCoreDataMasterEntity;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.assembler.BaseAssembler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class MultiLevelCoreDataMasterAssembler {

    private static final Logger LOGGER = LoggerFactory.getLogger(MultiLevelCoreDataMasterAssembler.class);

    private static Map<String, String> sortByList;

    static{
        sortByList = new HashMap<>();
        sortByList.put("name", MultiLevelCoreDataMasterEntity.COLUMN_NAME_MULTI_LEVEL_CORE_DATA_MASTER_NAME);
        sortByList.put("multiLevelCoreDataTypesId", MultiLevelCoreDataMasterEntity.COLUMN_NAME_MULTI_LEVEL_CORE_DATA_MASTER_MULTI_LEVEL_CORE_DATA_TYPES_ID);
        sortByList.put("order", MultiLevelCoreDataMasterEntity.COLUMN_NAME_MULTI_LEVEL_CORE_DATA_MASTER_ORDER);
    }

    public static String getSortByColumn(String input) throws CdhException {
        return BaseAssembler.getSortByColumn(input, sortByList);
    }

    private static BaseAssembler<MultiLevelCoreDataMasterDto, MultiLevelCoreDataMasterEntity> getBaseAssembler(){
        return new BaseAssembler<>(MultiLevelCoreDataMasterDto::new, MultiLevelCoreDataMasterEntity::new);
    }

    public MultiLevelCoreDataMasterDto entityToDto(MultiLevelCoreDataMasterEntity multiLevelCoreDataMasterEntity){
        MultiLevelCoreDataMasterDto dto = getBaseAssembler().entityToDto(multiLevelCoreDataMasterEntity);
        if(multiLevelCoreDataMasterEntity.getAdditionalData() !=null && !multiLevelCoreDataMasterEntity.getAdditionalData().trim().isEmpty()){
            try {
                ObjectMapper mapper = new ObjectMapper();
                dto.setAdditionalData((HashMap<String, Object>) mapper.readValue(multiLevelCoreDataMasterEntity.getAdditionalData(), Map.class));
            } catch (Exception ex){
                LOGGER.error("Error while converting additional data", ex);
            }
        }
        return dto;
    }

    public MultiLevelCoreDataMasterEntity dtoToEntity(MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto){
        return getBaseAssembler().dtoToEntity(multiLevelCoreDataMasterDto);
    }

    public List<MultiLevelCoreDataMasterDto> entityListToDtoList(List<MultiLevelCoreDataMasterEntity> entityList)
    {
        return getBaseAssembler().entityListToDtoList(entityList);
    }

    public List<MultiLevelCoreDataMasterEntity> dtoListToEntityList(List<MultiLevelCoreDataMasterDto> dtoList){
        return getBaseAssembler().dtoListToEntityList(dtoList);
    }
}
