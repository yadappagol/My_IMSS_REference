Code repository for core data handler.

To understand the design and the architcture please refer to the documentation at http://172.16.2.20:8090/display/IMSS/Core+Data+Handler