package com.imss.rc.cdh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAutoConfiguration
@Configuration
@ComponentScan({"com.imss.rc.audit","com.imss.rc.cdh","com.imss.rc.auth"})
@EnableJpaRepositories("com.imss.rc.cdh")
@EnableAsync
public class CdhCoreApplication extends SpringBootServletInitializer {

    /**
     * The main method that's being called first on application load.
     * @param args the arguments that are to be provided to the spring application run method
     * @author Sandeep
     */
    public static void main(String[] args) {

        SpringApplication.run(CdhCoreApplication.class, args);

    }

}
