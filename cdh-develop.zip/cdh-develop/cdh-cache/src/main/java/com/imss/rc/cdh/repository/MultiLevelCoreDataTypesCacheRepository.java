package com.imss.rc.cdh.repository;

import com.imss.rc.cdh.entity.MultiLevelCoreDataTypesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MultiLevelCoreDataTypesCacheRepository extends JpaRepository<MultiLevelCoreDataTypesEntity,Integer> {

    @Query(value="from MultiLevelCoreDataTypesEntity cd where cd.isDeleted=0")
    public List<MultiLevelCoreDataTypesEntity> getAllMultiLevelCoreDataTypes();

}