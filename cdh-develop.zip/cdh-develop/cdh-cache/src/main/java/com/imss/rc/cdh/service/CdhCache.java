package com.imss.rc.cdh.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.imss.rc.cdh.dto.*;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.commons.enums.CacheDataKeysEnum;
import com.imss.rc.commons.enums.CacheIsListEnum;
import com.imss.rc.commons.enums.CacheOperationEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CdhCache {
    private static final Logger LOGGER = LoggerFactory.getLogger(CdhCache.class);
    public static final String CORE_DATA_TYPES = "coreDataTypes";
    public static final String CORE_DATA_DETAILS = "coreDataDetails";
    public static final String MULTI_CORE_DATA_MASTER = "multiCoreDataMaster";
    public static final String MULTI_CORE_DATA = "multiCoreData";
    public static final String MULTI_CORE_DATA_TYPES = "multiCoreDataTypes";

    private static HashMap<String, Map<Integer,Object>> cdhCache=new HashMap<>();

    public static boolean handleCdhCacheData(Map<String, Object> data){

        if(data.get(CacheDataKeysEnum.TYPE.getValue()).equals("CoreDataDetails")) {

            if(data.get(CacheDataKeysEnum.IS_LIST.getValue()).equals(CacheIsListEnum.YES.getValue())){
                List<CoreDataDetailsDto> coreDataDetailsDtoList;
                ObjectMapper mapper = new ObjectMapper();
                coreDataDetailsDtoList = mapper.convertValue(data.get("data"), new TypeReference<List<CoreDataDetailsDto>>(){});

                for (CoreDataDetailsDto coreDataDetailsDto : coreDataDetailsDtoList) {
                    putCoreDataDetails(coreDataDetailsDto.getId(), coreDataDetailsDto);
                }

                LOGGER.info("#CDH-CACHE : Loaded {} records of core data details into cache, Current total records is {}", coreDataDetailsDtoList.size(), getAllCoreDataDetails().size());
                return true;
            } else if(data.get(CacheDataKeysEnum.IS_LIST.getValue()).equals(CacheIsListEnum.NO.getValue())){

                if(CacheOperationEnum.ADD.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                    CoreDataDetailsDto coreDataDetailsDto = (CoreDataDetailsDto)data.get(CacheDataKeysEnum.DATA.getValue());
                    putCoreDataDetails(coreDataDetailsDto.getId(), coreDataDetailsDto);
                } else if(CacheOperationEnum.REMOVE.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                    CoreDataDetailsDto coreDataDetailsDto = (CoreDataDetailsDto)data.get(CacheDataKeysEnum.DATA.getValue());
                    removeCoreDataDetails(coreDataDetailsDto.getId());
                } else if (CacheOperationEnum.RESET.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                    resetCoreDataDetails();
                    LOGGER.info("#CDH-CACHE : Reset core data details cache successfully");
                }
                LOGGER.debug("#CDH-CACHE : Loaded individual cache successfully");
                return true;
            } else {
                throw new CdhException(CdhException.UNKNOWN_IS_LIST_VALUE, HttpStatus.INTERNAL_SERVER_ERROR);
            }

        }
        if(data.get(CacheDataKeysEnum.TYPE.getValue()).equals("MultiCoreDataMaster")) {

            if (data.get(CacheDataKeysEnum.IS_LIST.getValue()).equals(CacheIsListEnum.YES.getValue())) {
                List<MultiLevelCoreDataMasterDto> multiLevelCoreDataMasterDtoList;
                ObjectMapper mapper = new ObjectMapper();
                multiLevelCoreDataMasterDtoList = mapper.convertValue(data.get("data"), new TypeReference<List<MultiLevelCoreDataMasterDto>>() {
                });

                for (MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto : multiLevelCoreDataMasterDtoList) {
                    putMultiCoreMasterData(multiLevelCoreDataMasterDto.getId(), multiLevelCoreDataMasterDto);
                }

                LOGGER.info("#CDH-CACHE : Loaded {} records of multi core master data details into cache, Current total records is {}", multiLevelCoreDataMasterDtoList.size(), getAllCoreDataDetails().size());
                return true;
            } else if (data.get(CacheDataKeysEnum.IS_LIST.getValue()).equals(CacheIsListEnum.NO.getValue())) {

                if (CacheOperationEnum.ADD.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                    MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto = (MultiLevelCoreDataMasterDto) data.get(CacheDataKeysEnum.DATA.getValue());
                    putMultiCoreMasterData(multiLevelCoreDataMasterDto.getId(), multiLevelCoreDataMasterDto);
                } else if (CacheOperationEnum.REMOVE.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                    MultiLevelCoreDataMasterDto multiLevelCoreDataMasterDto = (MultiLevelCoreDataMasterDto) data.get(CacheDataKeysEnum.DATA.getValue());
                    removeMultiCoreMasterData(multiLevelCoreDataMasterDto.getId());
                } else if (CacheOperationEnum.RESET.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                    resetMultiCoreMasterData();
                    LOGGER.info("#CDH-CACHE : Reset multi core master data details cache successfully");
                }
                LOGGER.debug("#CDH-CACHE : Loaded individual cache successfully");
                return true;
            } else {
                throw new CdhException(CdhException.UNKNOWN_IS_LIST_VALUE, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }if(data.get(CacheDataKeysEnum.TYPE.getValue()).equals("MultiCoreData")) {

            if (data.get(CacheDataKeysEnum.IS_LIST.getValue()).equals(CacheIsListEnum.YES.getValue())) {
                List<MultiLevelCoreDataDto> multiLevelCoreDataDtoList;
                ObjectMapper mapper = new ObjectMapper();
                multiLevelCoreDataDtoList = mapper.convertValue(data.get("data"), new TypeReference<List<MultiLevelCoreDataDto>>() {
                });

                for (MultiLevelCoreDataDto multiLevelCoreDataDto : multiLevelCoreDataDtoList) {
                    putMultiCoreData(multiLevelCoreDataDto.getId(), multiLevelCoreDataDto);
                }

                LOGGER.info("#CDH-CACHE : Loaded {} records of multi core data details into cache, Current total records is {}", multiLevelCoreDataDtoList.size(), getAllCoreDataDetails().size());
                return true;
            }else if (data.get(CacheDataKeysEnum.IS_LIST.getValue()).equals(CacheIsListEnum.NO.getValue())) {

                if (CacheOperationEnum.ADD.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                    MultiLevelCoreDataDto MultiLevelCoreDataDto = (MultiLevelCoreDataDto) data.get(CacheDataKeysEnum.DATA.getValue());
                    putMultiCoreData(MultiLevelCoreDataDto.getId(), MultiLevelCoreDataDto);
                } else if (CacheOperationEnum.REMOVE.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                    MultiLevelCoreDataDto MultiLevelCoreDataDto = (MultiLevelCoreDataDto) data.get(CacheDataKeysEnum.DATA.getValue());
                    removeMultiCoreData(MultiLevelCoreDataDto.getId());
                } else if (CacheOperationEnum.RESET.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                    resetMultiCoreData();
                    LOGGER.info("#CDH-CACHE : Reset multi core data details cache successfully");
                }
                LOGGER.debug("#CDH-CACHE : Loaded individual cache successfully");
                return true;
            } else {
                throw new CdhException(CdhException.UNKNOWN_IS_LIST_VALUE, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }if(data.get(CacheDataKeysEnum.TYPE.getValue()).equals("CoreDataTypes")) {

            if (data.get(CacheDataKeysEnum.IS_LIST.getValue()).equals(CacheIsListEnum.YES.getValue())) {
                List<CoreDataTypesDto> coreDataTypesDtoList;
                ObjectMapper mapper = new ObjectMapper();
                coreDataTypesDtoList = mapper.convertValue(data.get("data"), new TypeReference<List<CoreDataTypesDto>>() {
                });

                for (CoreDataTypesDto coreDataTypesDto : coreDataTypesDtoList) {
                    putCoreDataTypes(coreDataTypesDto.getId(), coreDataTypesDto);
                }

                LOGGER.info("#CDH-CACHE : Loaded {} records of multi core data details into cache, Current total records is {}", coreDataTypesDtoList.size(), getAllCoreDataDetails().size());
                return true;
            }else if (data.get(CacheDataKeysEnum.IS_LIST.getValue()).equals(CacheIsListEnum.NO.getValue())) {

                if (CacheOperationEnum.ADD.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                    CoreDataTypesDto coreDataTypesDto = (CoreDataTypesDto) data.get(CacheDataKeysEnum.DATA.getValue());
                    putCoreDataTypes(coreDataTypesDto.getId(), coreDataTypesDto);
                } else if (CacheOperationEnum.REMOVE.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                    CoreDataTypesDto coreDataTypesDto = (CoreDataTypesDto) data.get(CacheDataKeysEnum.DATA.getValue());
                    removeCoreDataTypes(coreDataTypesDto.getId());
                } else if (CacheOperationEnum.RESET.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                    resetCoreDataTypes();
                    LOGGER.info("#CDH-CACHE : Reset  core data types cache successfully");
                }
                LOGGER.debug("#CDH-CACHE : Loaded individual cache successfully");
                return true;
            } else {
                throw new CdhException(CdhException.UNKNOWN_IS_LIST_VALUE, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }if(data.get(CacheDataKeysEnum.TYPE.getValue()).equals("MultiCoreDataTypes")) {

            if (data.get(CacheDataKeysEnum.IS_LIST.getValue()).equals(CacheIsListEnum.YES.getValue())) {
                List<MultiLevelCoreDataTypesDto> coreDataTypesDtoList;
                ObjectMapper mapper = new ObjectMapper();
                coreDataTypesDtoList = mapper.convertValue(data.get("data"), new TypeReference<List<MultiLevelCoreDataTypesDto>>() {
                });

                for (MultiLevelCoreDataTypesDto coreDataTypesDto : coreDataTypesDtoList) {
                    putMultiCoreDataTypes(coreDataTypesDto.getId(), coreDataTypesDto);
                }

                LOGGER.info("#CDH-CACHE : Loaded {} records of multi core data details into cache, Current total records is {}", coreDataTypesDtoList.size(), getAllCoreDataDetails().size());
                return true;
            }else if (data.get(CacheDataKeysEnum.IS_LIST.getValue()).equals(CacheIsListEnum.NO.getValue())) {

                if (CacheOperationEnum.ADD.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                    MultiLevelCoreDataTypesDto coreDataTypesDto = (MultiLevelCoreDataTypesDto) data.get(CacheDataKeysEnum.DATA.getValue());
                    putMultiCoreDataTypes(coreDataTypesDto.getId(), coreDataTypesDto);
                } else if (CacheOperationEnum.REMOVE.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                    MultiLevelCoreDataTypesDto coreDataTypesDto = (MultiLevelCoreDataTypesDto) data.get(CacheDataKeysEnum.DATA.getValue());
                    removeMultiCoreDataTypes(coreDataTypesDto.getId());
                } else if (CacheOperationEnum.RESET.getValue().equals(data.get(CacheDataKeysEnum.OPERATION.getValue()))) {
                    resetMultiCoreDataTypes();
                    LOGGER.info("#CDH-CACHE : Reset  core data types cache successfully");
                }
                LOGGER.debug("#CDH-CACHE : Loaded individual cache successfully");
                return true;
            } else {
                throw new CdhException(CdhException.UNKNOWN_IS_LIST_VALUE, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }else {
            return false;
        }

    }

    private static void putCoreDataDetails(Integer id, CoreDataDetailsDto obj){
        cdhCache.computeIfAbsent(CORE_DATA_DETAILS, k -> new HashMap<Integer, Object>());
        cdhCache.get(CORE_DATA_DETAILS).put(id, obj);
    }
    private static void removeCoreDataDetails(Integer id){
        cdhCache.computeIfAbsent(CORE_DATA_DETAILS, k -> new HashMap<Integer, Object>());

        cdhCache.get(CORE_DATA_DETAILS).remove(id);
    }
    private static void resetCoreDataDetails(){
        cdhCache.put(CORE_DATA_DETAILS, new HashMap<Integer, Object>());
    }

    private static void putMultiCoreMasterData(Integer id, MultiLevelCoreDataMasterDto obj){
        cdhCache.computeIfAbsent(MULTI_CORE_DATA_MASTER, k -> new HashMap<Integer, Object>());
        cdhCache.get(MULTI_CORE_DATA_MASTER).put(id, obj);
    }
    private static void removeMultiCoreMasterData(Integer id){
        cdhCache.computeIfAbsent(MULTI_CORE_DATA_MASTER, k -> new HashMap<Integer, Object>());

        cdhCache.get(MULTI_CORE_DATA_MASTER).remove(id);
    }
    private static void resetMultiCoreMasterData(){
        cdhCache.put(MULTI_CORE_DATA_MASTER, new HashMap<Integer, Object>());
    }


    private static void putMultiCoreData(Integer id, MultiLevelCoreDataDto obj){
        cdhCache.computeIfAbsent(MULTI_CORE_DATA, k -> new HashMap<Integer, Object>());
        cdhCache.get(MULTI_CORE_DATA).put(id, obj);
    }
    private static void removeMultiCoreData(Integer id){
        cdhCache.computeIfAbsent(MULTI_CORE_DATA, k -> new HashMap<Integer, Object>());

        cdhCache.get(MULTI_CORE_DATA).remove(id);
    }
    private static void resetMultiCoreData(){
        cdhCache.put(MULTI_CORE_DATA, new HashMap<Integer, Object>());
    }

    public static Collection<CoreDataDetailsDto> getAllCoreDataDetails(){
        checkForEmptyCache();

        return (Collection) cdhCache.get(CORE_DATA_DETAILS).values();
    }

    private static void putCoreDataTypes(Integer id, CoreDataTypesDto obj){
        cdhCache.computeIfAbsent(CORE_DATA_TYPES, k -> new HashMap<Integer, Object>());
        cdhCache.get(CORE_DATA_TYPES).put(id, obj);
    }
    private static void removeCoreDataTypes(Integer id){
        cdhCache.computeIfAbsent(CORE_DATA_TYPES, k -> new HashMap<Integer, Object>());

        cdhCache.get(CORE_DATA_TYPES).remove(id);
    }
    private static void resetCoreDataTypes(){
        cdhCache.put(CORE_DATA_TYPES, new HashMap<Integer, Object>());
    }

    private static void putMultiCoreDataTypes(Integer id, MultiLevelCoreDataTypesDto obj){
        cdhCache.computeIfAbsent(MULTI_CORE_DATA_TYPES, k -> new HashMap<Integer, Object>());
        cdhCache.get(MULTI_CORE_DATA_TYPES).put(id, obj);
    }
    private static void removeMultiCoreDataTypes(Integer id){
        cdhCache.computeIfAbsent(MULTI_CORE_DATA_TYPES, k -> new HashMap<Integer, Object>());

        cdhCache.get(MULTI_CORE_DATA_TYPES).remove(id);
    }
    private static void resetMultiCoreDataTypes(){
        cdhCache.put(MULTI_CORE_DATA_TYPES, new HashMap<Integer, Object>());
    }

    @Deprecated
    public static CoreDataDetailsDto getCoreDataDetailsById(Integer id){
        checkForEmptyCache();

        return (CoreDataDetailsDto)cdhCache.get(CORE_DATA_DETAILS).get(id);
    }

    public static CoreDataDetailsDto getCoreDataDetailsByIdAndTypeId(Integer id, Integer typeId){
        checkForEmptyCache();

        CoreDataDetailsDto dto = (CoreDataDetailsDto)cdhCache.get(CORE_DATA_DETAILS).get(id);
        if(dto != null && dto.getTypeId() == typeId){
            return dto;
        } else {
            return null;
        }
    }

    public static Collection<MultiLevelCoreDataMasterDto> getAllMultiCoreDataMaster(){
        checkForEmptyCache();

        return (Collection) cdhCache.get(MULTI_CORE_DATA_MASTER).values();
    }

    public static Collection<MultiLevelCoreDataDto> getAllMultiCoreData(){
        checkForEmptyCache();

        return (Collection) cdhCache.get(MULTI_CORE_DATA).values();
    }

    public static Collection<MultiLevelCoreDataTypesDto> getAllMultiCoreDataTypes(){
        checkForEmptyCache();

        return (Collection) cdhCache.get(MULTI_CORE_DATA_TYPES).values();
    }
    public static Collection<CoreDataTypesDto> getAllCoreDataTypes(){
        checkForEmptyCache();

        return (Collection) cdhCache.get(CORE_DATA_TYPES).values();
    }
    public static MultiLevelCoreDataMasterDto getMultiCoreMasterDataByIdAndTypeId(Integer id, Integer typeId){
        checkForEmptyCache();

        MultiLevelCoreDataMasterDto dto = (MultiLevelCoreDataMasterDto)cdhCache.get(MULTI_CORE_DATA_MASTER).get(id);
        if(dto != null && dto.getMultiLevelCoreDataTypesId() == typeId){
            return dto;
        } else {
            return null;
        }
    }

    public static MultiLevelCoreDataDto getMultiCoreDataByIdAndTypeId(Integer id, Integer typeId){
        checkForEmptyCache();

        MultiLevelCoreDataDto dto = (MultiLevelCoreDataDto)cdhCache.get(MULTI_CORE_DATA).get(id);
        if(dto != null ){
            MultiLevelCoreDataMasterDto masterDto = getMultiCoreMasterDataByIdAndTypeId(dto.getMultiLevelCoreDataMasterId(), typeId);
            if(masterDto != null && masterDto.getMultiLevelCoreDataTypesId() == typeId) {
                return dto;
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    private static void checkForEmptyCache(){
        if(cdhCache == null || cdhCache.isEmpty()){
            throw new CdhException(CdhException.CDH_CACHE_NOT_LOADED_PROPERLY, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /*public static List<CoreDataDetailsDto> getCoreDataDetailsByType(Integer typeId){
        return (CoreDataDetailsDto)cdhCache.get(CORE_DATA_TYPES).get(typeId);
    }*/

}
