package com.imss.rc.cdh.repository;

import com.imss.rc.cdh.entity.MultiLevelCoreDataMasterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MultiLevelCoreDataMasterCacheRepository extends JpaRepository<MultiLevelCoreDataMasterEntity,Integer> {

    @Query(value="from MultiLevelCoreDataMasterEntity cd where cd.isDeleted=0")
    public List<MultiLevelCoreDataMasterEntity> getAllMultiLevelCoreDataMaster();

}