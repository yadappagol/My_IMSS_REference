package com.imss.rc.cdh.service;

import com.imss.rc.cdh.assembler.*;
import com.imss.rc.cdh.dto.*;
import com.imss.rc.cdh.entity.*;
import com.imss.rc.cdh.exception.CdhException;
import com.imss.rc.cdh.repository.*;
import com.imss.rc.commons.dto.BaseListDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CdhCacheService {
    private static final Logger LOG = LoggerFactory.getLogger(CdhCacheService.class);

    @Autowired
    CoreDataDetailsAssembler coreDataDetailsAssembler;

    @Autowired
    MultiLevelCoreDataAssembler multiLevelCoreDataAssembler;

    @Autowired
    MultiLevelCoreDataMasterAssembler multiLevelCoreDataMasterAssembler;

    @Autowired
    MultiLevelCoreDataTypesAssembler multiLevelCoreDataTypesAssembler;

    @Autowired
    CoreDataTypesAssembler coreDataTypesAssembler;

    @Autowired
    CoreDataDetailsCacheRepository coreDataDetailsCacheRepository;

    @Autowired
    MultiLevelCoreDataMasterCacheRepository multiLevelCoreDataMasterCacheRepository;

    @Autowired
    MultiLevelCoreDataCacheRepository multiLevelCoreDataCacheRepository;

    @Autowired
    MultiLevelCoreDataTypesCacheRepository multiLevelCoreDataTypesCacheRepository;

    @Autowired
    CoreDataTypesCacheRepository coreDataTypesCacheRepository;

    /**
     * This method is used for getting all the core data details for the cache
     * @return
     * @throws CdhException
     */
    public BaseListDto<CoreDataDetailsDto> getAllCoreDataListList() throws CdhException {
        BaseListDto<CoreDataDetailsDto> coreDataDtoList = new BaseListDto();
        try{
            List<CoreDataDetailsEntity> coreDataEntityList = coreDataDetailsCacheRepository.getAllCoreDataDetails();
            coreDataDtoList.setDataList(coreDataDetailsAssembler.entityListToDtoList(coreDataEntityList));
        }
        catch (CdhException ex)  {
            throw ex;
        } catch (Exception ex) {
            LOG.error("Exception in getAllCoreDataListList:", ex);
            throw new CdhException(CdhException.UNABLE_TO_FIND_CORE_DATA_DETAILS, HttpStatus.NOT_FOUND);
        }
        return coreDataDtoList;
    }

    /**
     * This method is used for getting all the core data details for the cache
     * @return
     * @throws CdhException
     */
    public BaseListDto<MultiLevelCoreDataMasterDto> getAllMultiCoreDataMaster() throws CdhException {
        BaseListDto<MultiLevelCoreDataMasterDto> masterDtoBaseListDto = new BaseListDto();
        try{
            List<MultiLevelCoreDataMasterEntity> multiLevelCoreDataMasterEntityList = multiLevelCoreDataMasterCacheRepository.getAllMultiLevelCoreDataMaster();
            masterDtoBaseListDto.setDataList(multiLevelCoreDataMasterAssembler.entityListToDtoList(multiLevelCoreDataMasterEntityList));
        }
        catch (CdhException ex)  {
            throw ex;
        } catch (Exception ex) {
            LOG.error("Exception in getAllCoreDataListList:", ex);
            throw new CdhException(CdhException.UNABLE_TO_FIND_CORE_DATA_DETAILS, HttpStatus.NOT_FOUND);
        }
        return masterDtoBaseListDto;
    }


    /**
     * This method is used for getting all the core data details for the cache
     * @return
     * @throws CdhException
     */
    public BaseListDto<MultiLevelCoreDataDto> getAllMultiCoreDataList() throws CdhException {
        BaseListDto<MultiLevelCoreDataDto> multiLevelCoreDataDtoBaseList = new BaseListDto();
        try{
            List<MultiLevelCoreDataEntity> multiLevelCoreDataMasterEntityList = multiLevelCoreDataCacheRepository.getAllMultiLevelCoreData();
            multiLevelCoreDataDtoBaseList.setDataList(multiLevelCoreDataAssembler.entityListToDtoList(multiLevelCoreDataMasterEntityList));
        }
        catch (CdhException ex)  {
            throw ex;
        } catch (Exception ex) {
            LOG.error("Exception in getAllCoreDataListList:", ex);
            throw new CdhException(CdhException.UNABLE_TO_FIND_CORE_DATA_DETAILS, HttpStatus.NOT_FOUND);
        }
        return multiLevelCoreDataDtoBaseList;
    }

    /**
     * This method is used for getting all the multi level core data types for the cache
     * @return
     * @throws CdhException
     */
    public BaseListDto<MultiLevelCoreDataTypesDto> getAllMultiCoreDataTypesList() throws CdhException {
        BaseListDto<MultiLevelCoreDataTypesDto> multiLevelCoreDataDtoBaseList = new BaseListDto<>();
        try{
            List<MultiLevelCoreDataTypesEntity> multiLevelCoreDataMasterEntityList = multiLevelCoreDataTypesCacheRepository.getAllMultiLevelCoreDataTypes();
            multiLevelCoreDataDtoBaseList.setDataList(multiLevelCoreDataTypesAssembler.entityListToDtoList(multiLevelCoreDataMasterEntityList));
        }
        catch (CdhException ex)  {
            throw ex;
        } catch (Exception ex) {
            LOG.error("Exception in getAllCoreDataListList:", ex);
            throw new CdhException(CdhException.UNABLE_TO_FIND_CORE_DATA_DETAILS, HttpStatus.NOT_FOUND);
        }
        return multiLevelCoreDataDtoBaseList;
    }

    /**
     * This method is used for getting all the core data types for the cache
     * @return
     * @throws CdhException
     */
    public BaseListDto<CoreDataTypesDto> getAllCoreDataTypesList() throws CdhException {
        BaseListDto<CoreDataTypesDto> coreDataTypesDtoBaseListDto = new BaseListDto<>();
        try{
            List<CoreDataTypesEntity> coreDataTypesEntityList = coreDataTypesCacheRepository.getAllCoreDataTypes();
            coreDataTypesDtoBaseListDto.setDataList(coreDataTypesAssembler.entityListToDtoList(coreDataTypesEntityList));
        }
        catch (CdhException ex)  {
            throw ex;
        } catch (Exception ex) {
            LOG.error("Exception in getAllCoreDataListList:", ex);
            throw new CdhException(CdhException.UNABLE_TO_FIND_CORE_DATA_DETAILS, HttpStatus.NOT_FOUND);
        }
        return coreDataTypesDtoBaseListDto;
    }

}
