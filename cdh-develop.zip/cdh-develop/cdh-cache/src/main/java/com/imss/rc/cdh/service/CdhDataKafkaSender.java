package com.imss.rc.cdh.service;

import com.imss.rc.commons.kafka.KafkaDataSender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;

public abstract class CdhDataKafkaSender  extends KafkaDataSender {
    private static final Logger LOGGER = LoggerFactory.getLogger(CdhDataKafkaSender.class);

    @Autowired
    CdhCacheService cdhCacheService;

    public abstract void sendCdhCache();

    public void processCdhCache(String topicName,KafkaTemplate<String, Object> kafkaTemplate){
        sendCoreDataDetails(topicName,kafkaTemplate);
        sendMultiCoreMasterData(topicName,kafkaTemplate);
        sendMultiCoreData(topicName,kafkaTemplate);
        sendMultiCoreDataTypes(topicName,kafkaTemplate);
        sendCoreDataTypes(topicName,kafkaTemplate);
    }

    private void sendCoreDataDetails(String topicName, KafkaTemplate<String, Object> kafkaTemplate){
        LOGGER.debug("Sending Core Data Details ");

        super.processListData(topicName,
                "CoreDataDetails",
                10,
                cdhCacheService.getAllCoreDataListList(),
                kafkaTemplate);

        LOGGER.info("successfully sent message");
    }

    private void sendMultiCoreMasterData(String topicName, KafkaTemplate<String, Object> kafkaTemplate){
        LOGGER.debug("Sending Multi level Core Master Data Details ");

        super.processListData(topicName,
                "MultiCoreDataMaster",
                10,
                cdhCacheService.getAllMultiCoreDataMaster(),
                kafkaTemplate);

        LOGGER.info("successfully sent message");
    }

    private void sendMultiCoreData(String topicName, KafkaTemplate<String, Object> kafkaTemplate){
        LOGGER.debug("Sending Multi Core Data Details ");

        super.processListData(topicName,
                "MultiCoreData",
                10,
                cdhCacheService.getAllMultiCoreDataList(),
                kafkaTemplate);

        LOGGER.info("successfully sent message");
    }

    private void sendMultiCoreDataTypes(String topicName, KafkaTemplate<String, Object> kafkaTemplate){
        LOGGER.debug("Sending Multi Core Data Types ");

        super.processListData(topicName,
                "MultiCoreDataTypes",
                10,
                cdhCacheService.getAllMultiCoreDataTypesList(),
                kafkaTemplate);

        LOGGER.info("successfully sent message");
    }

    private void sendCoreDataTypes(String topicName, KafkaTemplate<String, Object> kafkaTemplate){
        LOGGER.debug("Sending Core Data Types ");

        super.processListData(topicName,
                "CoreDataTypes",
                10,
                cdhCacheService.getAllCoreDataTypesList(),
                kafkaTemplate);

        LOGGER.info("successfully sent message");
    }

}
