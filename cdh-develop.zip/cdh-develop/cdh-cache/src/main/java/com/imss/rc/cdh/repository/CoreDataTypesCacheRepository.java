package com.imss.rc.cdh.repository;

import com.imss.rc.cdh.entity.CoreDataTypesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CoreDataTypesCacheRepository extends JpaRepository<CoreDataTypesEntity,Integer> {

    @Query(value="from CoreDataTypesEntity cd ")
    public List<CoreDataTypesEntity> getAllCoreDataTypes();

}